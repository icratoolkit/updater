# Mini İcra Yardımcısı Teknik Proje Dokümantasyonu

## 1. Amaç ve Kapsam

Mini İcra Yardımcısı, UYAP / icra portalında oturumu açık sekme üzerinde çalışan bir Chrome uzantısıdır. Ana hedefi; toplu dosya sorgulama, dosya hesabı, reddiyat kontrolü, talep gönderimi ve haciz süreçlerini tek popup arayüzünden yönetmektir.

Uygulama Türkçe arayüzlüdür. Kod, UI metinleri, export başlıkları, hata mesajları ve dokümantasyonda Türkçe karakterler korunur.

Desteklenen ana iş grupları:

| Grup | İşlev |
|:-----|:------|
| Sorgulama | Yatan para, tarih filtreli ödeme, reddiyat, kalan borç ve kesinleştirme sorguları |
| Dosya Hesabı | İlamlı / ilamsız dosyalarda borç hesabı, vazgeçme ve indirim senaryoları |
| Talep | Masraf avans iadesi, borçlu ödemelerinin hesaba aktarılması, IBAN değişikliği evrak gönderimi |
| Haciz | Araç, banka, Takbis ve alacaklı olduğu icra dosyası sorguları ile talep gönderimi |
| Export | Sonuçları `.xlsx` olarak dışa aktarma |
| Devam Et | Kesilen işlemleri mantıksal kontrol noktasından sürdürme |

---

## 2. Genel Mimari

```text
Kullanıcı
  |
  v
Popup UI
  |
  | chrome.tabs.sendMessage
  v
Content Script
  |
  | script injection + window.postMessage
  v
Injected Runner
  |
  | fetch / FormData / chrome.runtime köprüsü
  v
UYAP / İcra Portalı

Background Service Worker
  ^
  |
  | CORS veya binary proxy gereken isteklerde
  |
Injected Runner / Content Script
```

### 2.1 Katmanlar

| Katman | Sorumluluk | Ana Dosyalar |
|:-------|:-----------|:------------|
| Popup | UI, ayar saklama, input hazırlama, progress gösterimi, export | `src/popup/index.html`, `src/popup/main.js`, `src/popup/modules/*` |
| Content Script | Sayfaya runner dosyalarını enjekte eder, popup ile sayfa bağlamı arasında mesaj taşır | `src/content/content-script.js` |
| Injected Core | Ortak HTTP, parse, tarih, sayı, PDF ve helper fonksiyonları | `src/injected/page-runner-core.js` |
| Injected Extract | UYAP yanıtlarından anlamlı veri çıkarma fonksiyonları | `src/injected/page-runner-extract.js` |
| Query Runner | Sorgulama, dosya hesabı ve talep akışlarını yürütür | `src/injected/page-runner.js` |
| Haciz Runner | Haciz sorguları ve haciz talep gönderimini yürütür | `src/injected/haciz/page-runner-haciz.js` |
| Background | Gerektiğinde proxy / arka plan isteklerini yönetir | `src/background/service-worker.js` |

### 2.2 Dosya Enjeksiyon Sırası

`src/content/content-script.js` sayfa bağlamına dosyaları sıralı enjekte eder:

```text
shared/text-utils.js
shared/hesap/*.js
assets/vendor/fflate.min.js
src/injected/page-runner-core.js
src/popup/modules/talep-template.js
src/injected/page-runner-extract.js
src/injected/page-runner.js
src/injected/haciz/page-runner-haciz.js
```

`talep-template.js` popup içinde de, injected runner içinde de kullanılır. Bu nedenle hem popup HTML’de script olarak yüklenir hem de content script tarafından sayfaya enjekte edilir.

---

## 3. Proje Yapısı

```text
icramini/
├── manifest.json
├── assets/
│   ├── data/
│   │   └── birimler.json
│   ├── icons/
│   ├── templates/
│   │   └── iban_degisikligi_talebi.udf
│   └── vendor/
│       ├── fflate.min.js
│       ├── pdf.min.mjs
│       ├── pdf.worker.min.mjs
│       └── xlsx.bundle.js
├── src/
│   ├── background/
│   ├── content/
│   ├── injected/
│   │   └── haciz/
│   ├── popup/
│   │   ├── modules/
│   │   │   └── haciz/
│   │   └── styles/
│   └── shared/
│       └── hesap/
├── README.md
├── PROJE_DOKUMANTASYONU.md
└── AGENTS.md
```

---

## 4. Veri Girişi ve Birim Eşleştirme

Popup girdi alanı Excel’den iki sütun yapıştırmaya uygundur:

```text
Antalya Genel İcra Dairesi	2026/37855
Adana 3. Genel İcra Dairesi	2026/18605
```

Girdi parse akışı:

```text
textarea
  -> parseRowsFromInput
  -> { birimAdi, dosyaNo, birimId }
  -> birimler.json ile eşleştirme
  -> runner inputs
```

Desteklenen ayırıcılar:

| Format | Örnek |
|:-------|:------|
| Tab | `Birim Adı<TAB>2026/1` |
| Noktalı virgül | `Birim Adı;2026/1` |
| Çoklu boşluk | `Birim Adı    2026/1` |
| Sadece dosya no | `2026/1`, varsayılan birim kullanılır |

Eşleşmeyen birimler popup sonucunda ayrıca gösterilir; işlem tamamen durdurulmaz.

---

## 5. Ortak Runner Akışı

Query tarafındaki çoğu mod şu iskeleti kullanır:

```text
runWorkflow
  |
  | her input için
  v
runOne
  |
  | 1. istek
  v
/search_phrase_detayli.ajx
  |
  | dosyaId, birimId, birimAdi, dosyaDurum
  v
Mod özel adımlar
  |
  v
Sonuç nesnesi
  |
  v
emitProgress -> popup
```

Ortak sonuç alanları:

| Alan | Açıklama |
|:-----|:---------|
| `input` | Dosya no |
| `birimAdi` | Eşleşen veya kullanıcıdan gelen birim adı |
| `dosyaId` | UYAP dosya id |
| `success` | İstek / işleme başarı durumu |
| `isMatch` | Kullanıcıya sonuç olarak gösterilip gösterilmeyeceği |
| `error` | Hata metni |
| `responseJson`, `responseText` | Debug amaçlı ham yanıt |

Dosyalar arası bekleme varsayılan olarak `1 saniye`dir.

---

## 6. Sorgulama Modları

### 6.1 Yatan Para Sorgu

Akış:

```text
/search_phrase_detayli.ajx
  -> dosyaId
/dosya_hesap_bilgileri.ajx
  -> yatanPara
  -> kalanBorc
```

Eşleşme:

```text
yatanPara > 0
```

Excel kolonları:

```text
Birim | Dosya No | Yatan Para | Kalan Borç
```

### 6.2 Yatan Para Tarih Filtreli Sorgu

Normal yatan para sorgusunun tarih kontrollü sürümüdür.

Filtreler:

| Filtre | Kapsam |
|:-------|:------|
| Bugün | Güncel tarih |
| Bu hafta | Haftanın başlangıcı - bugünü |
| Bu ay | Ayın ilk günü - bugünü |
| Özel | Kullanıcının seçtiği tarih aralığı |

Tarih filtreleri ödeme kayıt tarihleri üzerinden değerlendirilir.

### 6.3 Kalan Bakiye Borç Sorgulama

Akış:

```text
/search_phrase_detayli.ajx
  -> dosyaId
/dosya_hesap_bilgileri.ajx
  -> Bakiye Borç Miktarı
```

Eşleşme:

```text
kalanBorc < kullaniciUstSinir
```

Excel kolonları:

```text
Birim | Dosya No | Kalan Borç | Üst Sınır | Yatan Para
```

### 6.4 Kesinleştirme Sorgulama

Akış:

```text
/search_phrase_detayli.ajx
  -> dosyaId
/list_dosya_evraklar.ajx
  -> evrak listesi
view_document_brd.uyap
  -> PDF / UDF / iç doküman bağlantıları
PTT / barkod kontrolleri
  -> tebliğ tarihi
```

Temel değerlendirme:

- Tebligat olgunluğu kontrol edilir.
- Borca itiraz evrakı sayısı dikkate alınır.
- Eşleşen kişi / tebligat detayları gruplanır.

Excel kolonları:

```text
Birim | Dosya No | Kişi No | Tebligat No | Kişi | Tebliğ Tarihi | Barkod
```

---

## 7. Reddiyat Sorgulama

Reddiyat sorgulama artık `dosya_hesap_bilgileri.ajx` isteğini kullanmaz. Doğrudan tahsilat / reddiyat yanıtından ilerler.

Akış:

```text
/search_phrase_detayli.ajx
  -> açık dosya aranır
  -> bulunamazsa kapalı dosya fallback
/dosya_taraf_bilgileri_brd.ajx
  -> alacaklı / alacaklı vekili ad anahtarları
/dosya_tahsilat_reddiyat_bilgileri_brd.ajx
  -> tahsilatList
  -> reddiyatList
  -> harcList
```

### 7.1 Kapalı Dosya Kuralı

Kapalı dosyada herhangi bir tahsilat satırı sonuç kabul edilir.

```text
isDosyaKapali === true
  -> tahsilatList içinde dosya no eşleşen herhangi satır
```

### 7.2 Açık Dosya Kuralları

`Borç Tahsilatı` için:

```text
tahsilatTuru === "Borç Tahsilatı"
AND kalanMiktar > 0
```

`Masraf Avansı Tahsilatı` için:

```text
tahsilatTuru === "Masraf Avansı Tahsilatı"
AND kalanMiktar > 0
AND aynı dosyada herhangi bir "Borç Tahsilatı" girişi var
AND odeyenKisi alacaklı veya alacaklı vekili ile eşleşiyor
```

`Borç Tahsilatı` girişinin `kalanMiktar` değerinin sıfır olması, masraf avansı kuralındaki “borç tahsilatı var mı?” şartını bozmaz.

Excel kolonları:

```text
Birim | Dosya No | Tahsilat Türü | Kalan Miktar
```

---

## 8. Dosya Hesabı Modu

Dosya hesabı modu normal sorgudan daha geniş bir veri toplama zinciri çalıştırır.

Akış:

```text
/search_phrase_detayli.ajx
  -> dosyaId
/list_dosya_evraklar.ajx
  -> takip talebi / ödeme emri / haciz talebi adayları
/dosya_taraf_bilgileri_brd.ajx
  -> alacaklı eşleştirme
/dosyaAyrintiBilgileri_brd.ajx
  -> takip türü
/dosya_hesap_bilgileri.ajx
  -> takipte kesinleşen, vekalet, bakiye
/dosya_tahsilat_reddiyat_bilgileri_brd.ajx
  -> masraf, harç ve tahsilat destek kalemleri
```

### 8.1 Hesap Türleri

| Hesap Türü | Açıklama |
|:-----------|:---------|
| Genel Hesap | Standart toplam borç hesabı |
| Vazgeçme Hesabı | Ana para ve hakediş senaryosu |
| İndirim Hesaplama | Girilen indirim tutarıyla yeniden hesap |

### 8.2 Takip Evrakı Parse

Desteklenen yükleme formatları:

```text
.udf
.zip
content.xml
.xml
.txt
```

Parser kaynakları:

| Kaynak | Kullanım |
|:-------|:---------|
| UDF content.xml | Takip kalemlerini doğrudan metinden çıkarır |
| PDF | PDF.js ile metin okur |
| ZIP | İçindeki `content.xml` dosyasını bulur |

Güncel özel sınıflandırma:

- `DEĞER KAYBI BEDELİ`
- `ÇEKİCİ BEDELİ`

Bu kalemler asıl alacak toplamına dahil edilir.

Excel kolonları çok alanlıdır ve ilk kolon `Birim` olacak şekilde üretilir.

---

## 9. Talep Modu

Talep sekmesinde üç talep tipi vardır:

| Talep | Endpoint | Davranış |
|:------|:---------|:---------|
| Masraf Avans İadesi | `/getIcraTalepEvrakHazirla.uyap` + `/avukatIcraTalepEvrakiGonder.ajx` | Genel talep UDF’i hazırlanır ve gönderilir |
| Borçlu Tarafından Yapılan Ödemelerin Hesaba Aktarılması | `/getIcraTalepEvrakHazirla.uyap` + `/avukatIcraTalepEvrakiGonder.ajx` | Genel talep UDF’i hazırlanır ve gönderilir |
| IBAN Değişikliği Talebi | `/evrakGonder_brd.ajx` | Lokal UDF şablonundan dosya üretilir ve evrak olarak gönderilir |

### 9.1 Masraf Avans İadesi

Akış:

```text
/search_phrase_detayli.ajx
  -> dosyaId
/dosya_borclu_list.ajx
  -> herhangi bir kisiKurumId
/getIcraTalepEvrakHazirla.uyap
  -> Talep.udf
/avukatIcraTalepEvrakiGonder.ajx
  -> multipart gönderim
```

Talep bilgileri:

```json
{
  "grupKodu": 2,
  "talepKodu": 37,
  "talepAdi": "Dosyadaki Avansın İadesi",
  "className": "AvukatTalepDosyaAvansIadesiDvo",
  "hesapKimeAit": "V",
  "hesapKimeAitText": "Vekil"
}
```

### 9.2 Borçlu Ödemelerinin Hesaba Aktarılması

Talep bilgileri:

```json
{
  "grupKodu": 2,
  "talepKodu": 14,
  "talepAdi": "Borçlu Tarafından Yapılan Ödemelerin Hesaba Aktarılması",
  "className": "AvukatTalepGenelOdemeAktarDVO",
  "hesapKimeAit": "V",
  "hesapKimeAitText": "Vekil"
}
```

IBAN kullanıcı arayüzünde gösterilmez. Varsayılan değer ayarlardan gelir:

```text
TR620001009010684338705009
```

### 9.3 IBAN Değişikliği Talebi

Şablon dosyası:

```text
assets/templates/iban_degisikligi_talebi.udf
```

Şablon marker’ları:

| Marker | Üretilen Değer |
|:-------|:---------------|
| `__ILILCE__` | Birim adından ayrıştırılan il / ilçe bölümü |
| `__ICRADAIRESI__` | İcra dairesi bölümü |
| `__DOSYANO__` | Dosya numarası |
| `__TARIH__` | Güncel tarih, `gg.aa.yyyy` |

Örnek:

```text
Antalya Genel İcra Dairesi + 2026/37855
  -> ANTALYA
  -> GENEL İCRA DAİRESİ'NE
  -> 2026/37855 ESAS
```

Gönderim akışı:

```text
/search_phrase_detayli.ajx
  -> dosyaId, birimId, birimAdi, dosyaNo
talep-template.js
  -> iban_degisikligi_talebi.udf içindeki content.xml açılır
  -> marker değerleri değiştirilir
  -> startOffset / length değerleri güncellenir
  -> yeni UDF zip olarak üretilir
/evrakGonder_brd.ajx
  -> file_1 + items + dosyaId + dosyaNo + birim bilgileri
```

Multipart alanları:

| Alan | Değer |
|:-----|:------|
| `file_1` | Üretilen `.udf` |
| `items` | `ICR_GNL_HCZ_BLDRM` evrak türü bilgisi |
| `dosyaId` | Arama sonucundan gelen dosya id |
| `isDusurme` | `false` |
| `evrakTipi` | `undefined` |
| `dosyaNo` | Kullanıcı girdisindeki dosya no |
| `birimId` | Arama / birim eşleştirme sonucu |
| `birimAdi` | Arama / kullanıcı girdisi sonucu |

Talep Excel kolonları:

```text
Birim | Dosya No | Talep | Durum | Mesaj
```

---

## 10. Haciz Modu

Haciz modu borçlu bazlı çalışır.

```text
Dosya listesi
  -> dosya arama
  -> borçlu listesi
  -> seçili haciz sorguları
  -> uygun kayıtları normalize et
  -> talep payload üret
  -> talep gönder
```

Desteklenen sorgular:

| Sorgu | Açıklama | Timeout |
|:------|:---------|:--------|
| Araç | Borçlu araç kayıtları | 30 sn |
| Banka | Borçlu banka kayıtları | 30 sn |
| Takbis | Taşınmaz kayıtları | 60 sn |
| İcra Dosyası | Borçlunun alacaklı olduğu dosyalar | 30 sn |

### 10.1 Kategori Limitleri

Haciz talebinde kategori başına en fazla `10` kayıt gönderilir.

```text
Araç        max 10
Banka       max 10
Takbis      max 10
İcra Dosyası max 10
```

### 10.2 Takbis Gecikme Modeli

Takbis sorgusu gecikirse:

```text
Araç / Banka / İcra Dosyası
  -> beklemeden talep aşamasına geçer
Takbis
  -> yanıt sonradan gelirse ayrıca işlenir
```

### 10.3 Cooldown

Timeout olan haciz sorguları için aynı kombinasyonda `3 dakika` yeniden deneme yapılmaz:

```text
dosya + kişi + sorgu türü
```

---

## 11. Export Mimarisi

Export modülü:

```text
src/popup/modules/export.js
```

Excel üretiminde SheetJS kullanılır. Tüm ana exportlarda `Birim` kolonu bulunur.

| Mod | Kolonlar |
|:----|:---------|
| Yatan Para | `Birim`, `Dosya No`, `Yatan Para`, `Kalan Borç` |
| Kalan | `Birim`, `Dosya No`, `Kalan Borç`, `Üst Sınır`, `Yatan Para` |
| Reddiyat | `Birim`, `Dosya No`, `Tahsilat Türü`, `Kalan Miktar` |
| Kesinleştirme | `Birim`, `Dosya No`, `Kişi No`, `Tebligat No`, `Kişi`, `Tebliğ Tarihi`, `Barkod` |
| Talep | `Birim`, `Dosya No`, `Talep`, `Durum`, `Mesaj` |
| Dosya Hesabı | Alan / Değer düzeninde, ilk alan `Birim` |
| Haciz | Araç, banka, Takbis ve talep sonuçları ayrı bölümler halinde |

CSV fallback vardır; XLSX kütüphanesi yüklenemezse CSV indirilir.

---

## 12. Durdur / Devam Et

Sistem devam et özelliğini ağ isteğini fiziksel olarak sürdürerek değil, mantıksal checkpoint ile sağlar.

### 12.1 Query / Dosya Hesabı / Talep

Storage anahtarları:

| Anahtar | İçerik |
|:--------|:-------|
| `runnerProgress` | Son progress özeti |
| `runnerResults` | Son tamamlanan sonuç |
| `runnerResumeState` | Devam edilebilir durum |
| `runnerLiveView` | Popup tekrar açılınca gösterilecek canlı metin |
| `runnerLastRunPanel` | Son çalıştırılan panel |

### 12.2 Haciz

Storage anahtarları:

| Anahtar | İçerik |
|:--------|:-------|
| `runnerHacizProgress` | Haciz progress |
| `runnerHacizResults` | Haciz sonuçları |
| `runnerHacizResumeState` | Haciz devam durumu |

Popup yeniden açıldığında uygun state varsa `Durdur` butonu `Devam Et` işlevine döner.

---

## 13. Hata Yönetimi ve Debug

Yaygın hata noktaları:

| Hata | Olası Sebep |
|:-----|:------------|
| `dosyaId bulunamadı` | Dosya / birim eşleşmedi, dosya açık-kapalı durumda farklı olabilir |
| `Headers JSON geçersiz` | Ayar JSON’u bozulmuş |
| `Şablon modülü yüklenemedi` | `talep-template.js` enjekte edilmedi veya manifest erişimi eksik |
| `Genel talep şablonu okunamadı` | `assets/templates/iban_degisikligi_talebi.udf` web accessible değil veya dosya yok |
| `UDF açılırken hata` | UDF `content.xml` offset / length değerleri marker değişiminden sonra güncellenmemiş olabilir |

IBAN değişikliği şablonunda marker değişimi sonrası `startOffset` ve `length` değerleri otomatik güncellenir. Bu UDF editörünün içeriği doğru açabilmesi için kritiktir.

---

## 14. Güvenlik ve Veri Saklama

- Veriler `chrome.storage.local` üzerinde saklanır.
- İşlemler kullanıcının açık oturum çerezleriyle yapılır.
- Uygulama dış bir sunucuya özel veri göndermez.
- Host permission geniştir; gerçek istekler aktif UYAP / icra portalı sekmesi bağlamında çalıştırılır.

---

## 15. Build ve Dağıtım

Build script:

```text
scripts/build-extension.mjs
```

Build süreci:

```text
dist/ temizlenir
manifest.json + README.md kopyalanır
assets/ kopyalanır
src/ kopyalanır
JS dosyaları minify + obfuscate edilir
opsiyonel zip üretilir
```

Komutlar:

```bash
node scripts/build-extension.mjs
node scripts/build-extension.mjs --zip
node scripts/build-extension.mjs --clean
```

Not: Build için `terser` ve `javascript-obfuscator` paketlerinin kurulu olması gerekir.

---

## 16. Geliştirme Notları

- Türkçe karakterleri bozma.
- UI metinlerinde mojibake bırakma.
- UYAP endpoint alan adlarını ve payload anahtarlarını gereksiz değiştirme.
- Talep ve haciz gönderimlerinde `Content-Type` elle verilmez; `FormData` boundary’sini tarayıcı belirler.
- Yeni export alanı eklenirse hem `HEADER_TO_FIELD` hem de XLSX numeric header seti kontrol edilmelidir.
- UDF şablonu değiştirilecekse marker’lar korunmalıdır:

```text
__ILILCE__
__ICRADAIRESI__
__DOSYANO__
__TARIH__
```

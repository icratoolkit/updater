﻿[CmdletBinding()]
param(
  [string]$PackageUrl = "https://github.com/icratoolkit/updater/raw/refs/heads/main/icramini.zip",
  [string]$TargetDir = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path,
  [switch]$NoBackup
)

$ErrorActionPreference = "Stop"
$utf8NoBom = New-Object System.Text.UTF8Encoding $false
[Console]::OutputEncoding = $utf8NoBom
$OutputEncoding = $utf8NoBom

function Write-Step {
  param([string]$Message)
  Write-Host ""
  Write-Host "==> $Message"
}

function Remove-IfExists {
  param([string]$Path)
  if (Test-Path -LiteralPath $Path) {
    Remove-Item -LiteralPath $Path -Recurse -Force
  }
}

function Copy-DirectoryContent {
  param(
    [string]$SourceDir,
    [string]$DestinationDir,
    [string[]]$ExcludeNames
  )

  Get-ChildItem -LiteralPath $SourceDir -Force | ForEach-Object {
    if ($ExcludeNames -contains $_.Name) {
      return
    }

    $destinationPath = Join-Path $DestinationDir $_.Name

    if ($_.PSIsContainer) {
      if (-not (Test-Path -LiteralPath $destinationPath)) {
        New-Item -ItemType Directory -Path $destinationPath | Out-Null
      }

      Copy-DirectoryContent -SourceDir $_.FullName -DestinationDir $destinationPath -ExcludeNames $ExcludeNames
      return
    }

    Copy-Item -LiteralPath $_.FullName -Destination $destinationPath -Force
  }
}

function Clear-TargetDirectory {
  param(
    [string]$TargetDir,
    [string[]]$ExcludeNames,
    [string[]]$PreservePaths = @()
  )

  Get-ChildItem -LiteralPath $TargetDir -Force | ForEach-Object {
    if ($ExcludeNames -contains $_.Name) {
      return
    }

    $fullPath = [System.IO.Path]::GetFullPath($_.FullName).TrimEnd("\")
    if ($PreservePaths -contains $fullPath) {
      return
    }

    if ($_.PSIsContainer) {
      Clear-TargetDirectory -TargetDir $_.FullName -ExcludeNames @() -PreservePaths $PreservePaths
      if (-not (Get-ChildItem -LiteralPath $_.FullName -Force)) {
        Remove-Item -LiteralPath $_.FullName -Force
      }
      return
    }

    Remove-Item -LiteralPath $_.FullName -Force
  }
}

$TargetDir = $TargetDir.Trim().Trim('"')
$TargetDir = [System.IO.Path]::GetFullPath($TargetDir)
if (-not (Test-Path -LiteralPath $TargetDir -PathType Container)) {
  throw "Hedef klasör bulunamadı: $TargetDir"
}
$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("icramini-update-" + [System.Guid]::NewGuid().ToString("N"))
$zipPath = Join-Path $tempRoot "icramini.zip"
$extractDir = Join-Path $tempRoot "paket"
$backupRoot = Join-Path $TargetDir "_update_backups"
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupDir = Join-Path $backupRoot $timestamp
$excludeNames = @(".git", "_update_backups")
$preservePaths = @(
  [System.IO.Path]::GetFullPath((Join-Path $TargetDir "update-icramini.bat")).TrimEnd("\"),
  [System.IO.Path]::GetFullPath((Join-Path $TargetDir "scripts\update-icramini.ps1")).TrimEnd("\")
)

try {
  Write-Step "Hazırlanıyor"
  Write-Host "Hedef klasör: $TargetDir"
  New-Item -ItemType Directory -Path $tempRoot, $extractDir | Out-Null

  Write-Step "Güncelleme paketi indiriliyor"
  Invoke-WebRequest -Uri $PackageUrl -OutFile $zipPath -UseBasicParsing

  Write-Step "ZIP paketi açılıyor"
  Expand-Archive -LiteralPath $zipPath -DestinationPath $extractDir -Force

  $packageRoot = $extractDir
  $entries = Get-ChildItem -LiteralPath $extractDir -Force
  if ($entries.Count -eq 1 -and $entries[0].PSIsContainer) {
    $packageRoot = $entries[0].FullName
  }

  $manifestPath = Join-Path $packageRoot "manifest.json"
  if (-not (Test-Path -LiteralPath $manifestPath)) {
    throw "Paket kökünde manifest.json bulunamadı. ZIP içeriği beklenen icramini paketi gibi görünmüyor."
  }

  $packageVersion = (Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json).version
  if ($packageVersion) {
    Write-Host "Paket sürümü: $packageVersion"
  }

  if (-not $NoBackup) {
    Write-Step "Mevcut dosyalar yedekleniyor"
    New-Item -ItemType Directory -Path $backupDir | Out-Null
    Copy-DirectoryContent -SourceDir $TargetDir -DestinationDir $backupDir -ExcludeNames $excludeNames
    Write-Host "Yedek: $backupDir"
  }

  Write-Step "Dosyalar güncelleniyor"
  Clear-TargetDirectory -TargetDir $TargetDir -ExcludeNames $excludeNames -PreservePaths $preservePaths
  Copy-DirectoryContent -SourceDir $packageRoot -DestinationDir $TargetDir -ExcludeNames $excludeNames

  $newManifestPath = Join-Path $TargetDir "manifest.json"
  if (Test-Path -LiteralPath $newManifestPath) {
    $version = (Get-Content -Raw -LiteralPath $newManifestPath | ConvertFrom-Json).version
    if ($version) {
      Write-Host "Kurulan sürüm: $version"
    }
  }

  Write-Step "Tamamlandı"
  Write-Host "Chrome eklentisi açıksa chrome://extensions sayfasından eklentiyi yenileyin."
  exit 0
}
catch {
  Write-Host ""
  Write-Host "Güncelleme başarısız oldu:" -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Write-Host ""
  Write-Host "Yedek alındıysa buradan geri dönebilirsiniz: $backupDir"
  exit 1
}
finally {
  Remove-IfExists -Path $tempRoot
}

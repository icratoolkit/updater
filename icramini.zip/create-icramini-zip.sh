#!/usr/bin/env bash
#Author : icratoolkit dev team
##################################################

set -euo pipefail

SOURCE_DIR=""
OUTPUT_PATH=""
INCLUDE_UPDATER=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --source-dir)
      [[ $# -ge 2 ]] || { printf 'Eksik parametre: --source-dir\n' >&2; exit 2; }
      SOURCE_DIR="$2"
      shift 2
      ;;
    --output-path)
      [[ $# -ge 2 ]] || { printf 'Eksik parametre: --output-path\n' >&2; exit 2; }
      OUTPUT_PATH="$2"
      shift 2
      ;;
    --include-updater)
      INCLUDE_UPDATER=1
      shift
      ;;
    *)
      printf 'Bilinmeyen parametre: %s\n' "$1" >&2
      exit 2
      ;;
  esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -z "$SOURCE_DIR" ]]; then
  SOURCE_DIR="$SCRIPT_DIR"
fi

SOURCE_DIR="$(realpath "$SOURCE_DIR")"
if [[ ! -d "$SOURCE_DIR" ]]; then
  printf 'Kaynak klasör bulunamadı: %s\n' "$SOURCE_DIR" >&2
  EXIT_CODE=1
else
  if [[ -z "$OUTPUT_PATH" ]]; then
    OUTPUT_PATH="$SOURCE_DIR/icramini.zip"
  fi

  OUTPUT_PATH="$(realpath -m "$OUTPUT_PATH")"
  OUTPUT_DIR="$(dirname "$OUTPUT_PATH")"
  TEMP_ROOT="$(mktemp -d "${TMPDIR:-/tmp}/icramini-package-XXXXXXXX")"
  STAGING_DIR="$TEMP_ROOT/icramini"

  cleanup() {
    if [[ -d "$TEMP_ROOT" ]]; then
      rm -rf "$TEMP_ROOT"
    fi
  }

  trap cleanup EXIT

  mkdir -p "$STAGING_DIR" "$OUTPUT_DIR"

  SOURCE_DIR="$SOURCE_DIR" \
  OUTPUT_PATH="$OUTPUT_PATH" \
  STAGING_DIR="$STAGING_DIR" \
  INCLUDE_UPDATER="$INCLUDE_UPDATER" \
  python3 - <<'PY'
import os
import shutil
import zipfile

source_dir = os.environ["SOURCE_DIR"]
output_path = os.environ["OUTPUT_PATH"]
staging_dir = os.environ["STAGING_DIR"]
include_updater = os.environ["INCLUDE_UPDATER"] == "1"

ignored_names = {
    ".git",
    ".github",
    ".vscode",
    "node_modules",
    "dist",
    "release",
    "_update_backups",
    "__MACOSX",
}

# Yalnizca gelistirme icin gereken, uzantiya girmemesi gereken dosyalar
dev_only_paths = {
    "package.json",
    "package-lock.json",
    "eslint.config.js",
    ".prettierrc.json",
    ".prettierignore",
    ".editorconfig",
    ".gitattributes",
    ".gitignore",
    "AGENTS.md",
    "PROJE_DOKUMANTASYONU.md",
    "scripts/injected-api-snapshot.json"
}


def test_ignored_path(relative_path: str) -> bool:
    normalized = relative_path.replace(os.sep, "/").lstrip("/")
    name = os.path.basename(normalized)

    if normalized == "":
        return False

    if name in ignored_names:
        return True

    for ignored_name in ignored_names:
        if normalized == ignored_name or normalized.startswith(f"{ignored_name}/"):
            return True

    if name == ".DS_Store":
        return True

    if normalized == "version.json":
        return True

    if name.endswith(".pem"):
        return True

    # Uretilen paket kendi icine girmesin.
    if name.endswith(".zip"):
        return True

    if normalized in dev_only_paths:
        return True

    # Dogrulama betikleri scripts/ altinda .mjs olarak duruyor; tek tek saymak
    # yerine desenle disliyoruz ki yenisi eklendiginde unutulmasin.
    if normalized.startswith("scripts/") and normalized.endswith(".mjs"):
        return True

    # update-icramini.ps1 pakete girer: PowerShell betigi calismadan once
    # tamamen okuyup ayristirdigi icin uzerine yazilmasi guvenli, boylece
    # guncelleyici duzeltmeleri Windows tarafina da ulasir.
    # update-icramini.bat girmez: cmd.exe toplu is dosyasini bayt konumundan
    # parca parca okur, calisirken uzerine yazilirsa kalan satirlari yanlis
    # konumdan surdurur.
    if not include_updater and normalized == "update-icramini.bat":
        return True

    return False


for root, dirs, files in os.walk(source_dir):
    dirs.sort()
    files.sort()

    rel_root = os.path.relpath(root, source_dir)
    rel_root = "" if rel_root == "." else rel_root

    for directory in list(dirs):
        rel_path = os.path.join(rel_root, directory) if rel_root else directory
        if test_ignored_path(rel_path):
            dirs.remove(directory)
            continue
        os.makedirs(os.path.join(staging_dir, rel_path), exist_ok=True)

    for file_name in files:
        rel_path = os.path.join(rel_root, file_name) if rel_root else file_name
        if test_ignored_path(rel_path):
            continue

        destination_path = os.path.join(staging_dir, rel_path)
        os.makedirs(os.path.dirname(destination_path), exist_ok=True)
        shutil.copy2(os.path.join(root, file_name), destination_path)

if os.path.exists(output_path):
    os.remove(output_path)

file_count = 0
with zipfile.ZipFile(output_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
    for root, _, files in os.walk(staging_dir):
        files.sort()
        for file_name in files:
            full_path = os.path.join(root, file_name)
            archive_name = os.path.relpath(full_path, staging_dir).replace(os.sep, "/")
            archive.write(full_path, archive_name)
            file_count += 1

size_mb = os.path.getsize(output_path) / (1024 * 1024)

print(f"ZIP oluşturuldu: {output_path}")
print(f"Dosya sayısı: {file_count}")
print(f"Boyut: {size_mb:.2f} MB")
PY
  EXIT_CODE=$?
fi

printf '\n'
if [[ "$EXIT_CODE" -eq 0 ]]; then
  printf 'Paket oluşturma tamamlandı.\n'
else
  printf 'Paket oluşturma başarısız oldu. Hata kodu: %s\n' "$EXIT_CODE"
fi

if [[ -t 0 && -t 1 ]]; then
  read -r -p "Devam etmek için Enter'a basın..." _
fi

exit "$EXIT_CODE"

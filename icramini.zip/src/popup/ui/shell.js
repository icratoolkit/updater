(function () {
  "use strict";

  if (window.MiniIcraPopupShell) {
    return;
  }

  const STATUS_COLOR_OK = "#205521";
  const STATUS_COLOR_ERROR = "#a02929";
  const MAX_UNRESOLVED_BIRIM_ROWS = 200;

  const escapeHtml = (value) =>
    String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");

  const normalizeMatchedRow = (row) => {
    if (row && typeof row === "object") {
      return {
        text: String(row.text ?? ""),
        status: String(row.status || "")
      };
    }
    return { text: String(row ?? ""), status: "" };
  };

  const createShell = ({ els, hacizEls, state, runModes }) => {
    const RUN_MODES = runModes;

    const TALEP_RUN_MODES = new Set([
      RUN_MODES.TALEP_MASRAF_AVANS_IADESI,
      RUN_MODES.TALEP_BORCLU_ODEME_AKTAR,
      RUN_MODES.TALEP_KESINLESTIRME,
      RUN_MODES.TALEP_EVRAKI_OLUSTUR
    ]);

    const YATAN_PARA_RUN_MODES = new Set([RUN_MODES.NORMAL, RUN_MODES.DATED, RUN_MODES.KALAN]);

    const getPanelForRunMode = (mode) => {
      if (mode === RUN_MODES.DOSYA_HESABI) {
        return "dosya";
      }
      if (TALEP_RUN_MODES.has(mode)) {
        return "talep";
      }
      return "query";
    };

    const isYatanParaMode = (mode) => YATAN_PARA_RUN_MODES.has(mode);

    const setStatus = (text, isError = false) => {
      els.status.textContent = text;
      els.status.style.color = isError ? STATUS_COLOR_ERROR : STATUS_COLOR_OK;
      if (!isError) {
        state.lastLiveStatus = String(text || "");
      }
    };

    const setHacizStatus = (text, isError = false) => {
      els.status.textContent = text;
      els.status.style.color = isError ? STATUS_COLOR_ERROR : STATUS_COLOR_OK;
    };

    const updateProgressBar = (processed, total) => {
      if (!els.progressWrap || !els.progressFill || !els.progressText) {
        return;
      }
      els.progressWrap.style.display = "";
      const pct = total > 0 ? Math.min(100, Math.round((processed / total) * 100)) : 0;
      els.progressFill.style.width = `${pct}%`;
      els.progressText.textContent = total > 0 ? `${processed}/${total} (%${pct})` : "";
      els.progressFill.classList.toggle("active", pct < 100);
    };

    const hideProgressBar = () => {
      if (!els.progressWrap) {
        return;
      }
      els.progressWrap.style.display = "none";
      if (els.progressFill) {
        els.progressFill.style.width = "0%";
        els.progressFill.classList.remove("active");
      }
      if (els.progressText) {
        els.progressText.textContent = "";
      }
    };

    const updateRowCount = () => {
      if (!els.rowCount || !els.inputs) {
        return;
      }
      const text = els.inputs.value.trim();
      const count = text.length === 0 ? 0 : text.split("\n").filter((line) => line.trim()).length;
      els.rowCount.textContent = count === 0 ? "0 satır" : `${count} satır`;
    };

    const renderMatchedRows = (rows) => {
      const safeRows = Array.isArray(rows) ? rows : [];
      els.matched.innerHTML = safeRows
        .map((row) => {
          const normalized = normalizeMatchedRow(row);
          const isError = normalized.status === "error" || /başarısız|hata/i.test(normalized.text);
          const className = isError ? "matched-line matched-line-error" : "matched-line";
          return `<div class="${className}">${escapeHtml(normalized.text)}</div>`;
        })
        .join("");
    };

    const setMatched = (rows) => {
      const outputRows = [];
      if (Array.isArray(state.unresolvedBirimRows) && state.unresolvedBirimRows.length > 0) {
        outputRows.push("Eşleşmeyen Birimler:", ...state.unresolvedBirimRows, "");
      }

      if (!Array.isArray(rows) || rows.length === 0) {
        if (outputRows.length === 0) {
          outputRows.push("Sonuç bulunamadı.");
        }
        state.lastLiveRows = outputRows.slice();
        renderMatchedRows(outputRows);
        return;
      }

      outputRows.push(...rows);
      state.lastLiveRows = outputRows.slice();
      renderMatchedRows(outputRows);
    };

    const setHacizMatched = (rows) => {
      if (!els.matched) {
        return;
      }
      if (!Array.isArray(rows) || rows.length === 0) {
        els.matched.textContent = "Sonuç bulunamadı.";
        return;
      }
      els.matched.innerHTML = rows.join("<br>");
    };

    const resetStableMatchedRows = () => {
      state.stableMatchedRows = [];
      state.stableMatchedSet = new Set();
    };

    const collectStableMatchedRows = (rows) => {
      for (const row of Array.isArray(rows) ? rows : []) {
        const key = String(row || "").trim();
        if (!key || state.stableMatchedSet.has(key)) {
          continue;
        }
        state.stableMatchedSet.add(key);
        state.stableMatchedRows.push(row);
      }
    };

    // Yatan para modlarında satırlar akış boyunca birikir (her ilerleme mesajı
    // yalnızca o ana kadarki eşleşmeleri taşır); diğer modlarda liste baştan yazılır.
    const mergeStableMatchedRows = (rows, mode) => {
      if (!isYatanParaMode(mode)) {
        return Array.isArray(rows) ? rows : [];
      }
      collectStableMatchedRows(rows);
      return state.stableMatchedRows.slice();
    };

    const setUnresolvedBirimRows = (rows) => {
      state.unresolvedBirimRows = Array.isArray(rows) ? rows.slice(0, MAX_UNRESOLVED_BIRIM_ROWS) : [];
    };

    const persistLiveView = () => {
      try {
        chrome.storage.local.set({
          runnerLiveView: {
            rows: Array.isArray(state.lastLiveRows) ? state.lastLiveRows : [],
            status: String(state.lastLiveStatus || ""),
            runMode: String(state.currentRunMode || "normal"),
            updatedAt: new Date().toISOString()
          }
        });
      } catch {}
    };

    const hasResumeForCurrentPanel = () =>
      state.currentUiPanel === "haciz" ? !!state.resumeHacizState : !!state.resumeQueryState;

    const updateStopResumeButton = () => {
      if (!els.stopBtn) {
        return;
      }
      if (state.isRunning || state.hacizIsRunning) {
        els.stopBtn.disabled = false;
        els.stopBtn.textContent = "Durdur";
        return;
      }
      if (hasResumeForCurrentPanel()) {
        els.stopBtn.disabled = false;
        els.stopBtn.textContent = "Devam Et";
        return;
      }
      els.stopBtn.disabled = true;
      els.stopBtn.textContent = "Durdur";
    };

    const setActivePanel = (panel) => {
      state.currentUiPanel = panel === "dosya" || panel === "haciz" || panel === "talep" ? panel : "query";

      const activeStates = [
        [els.tabQuery, els.queryPanel, "query"],
        [els.tabDosya, els.dosyaPanel, "dosya"],
        [els.tabTalep, els.talepPanel, "talep"],
        [hacizEls.tabHaciz, hacizEls.hacizPanel, "haciz"]
      ];

      for (const [tab, panelEl, name] of activeStates) {
        const isActive = state.currentUiPanel === name;
        if (tab) {
          tab.classList.toggle("active", isActive);
          tab.setAttribute("aria-selected", isActive ? "true" : "false");
        }
        if (panelEl) {
          panelEl.classList.toggle("active", isActive);
        }
      }

      chrome.storage.local.set({ runnerActivePanel: state.currentUiPanel });
      updateStopResumeButton();
    };

    const refreshResumeStates = (done) => {
      chrome.storage.local.get(
        { runnerResumeState: null, runnerHacizResumeState: null },
        ({ runnerResumeState, runnerHacizResumeState }) => {
          state.resumeQueryState = runnerResumeState || null;
          state.resumeHacizState = runnerHacizResumeState || null;
          updateStopResumeButton();
          if (typeof done === "function") {
            done();
          }
        }
      );
    };

    const buildResumeStatusText = (label, detail) => {
      if (label && detail) {
        return `Durduruldu. Son durak: ${label} / ${detail}. Devam Et ile sürdürebilirsin.`;
      }
      if (label) {
        return `Durduruldu. Son durak: ${label}. Devam Et ile sürdürebilirsin.`;
      }
      return "Durduruldu. Devam Et ile sürdürebilirsin.";
    };

    const getQueryResumeStatusText = (checkpoint) =>
      buildResumeStatusText(
        String(checkpoint?.lastProgress?.activeInput || "").trim(),
        String(checkpoint?.lastProgress?.activeStepLabel || "").trim()
      );

    const getHacizResumeStatusText = (checkpoint) =>
      buildResumeStatusText(
        String(checkpoint?.lastProgress?.activeQueryDosyaNo || "").trim(),
        String(checkpoint?.lastProgress?.activeQueryLabel || "").trim()
      );

    return {
      escapeHtml,
      getHacizResumeStatusText,
      getPanelForRunMode,
      getQueryResumeStatusText,
      hideProgressBar,
      isYatanParaMode,
      collectStableMatchedRows,
      mergeStableMatchedRows,
      persistLiveView,
      refreshResumeStates,
      renderMatchedRows,
      resetStableMatchedRows,
      setActivePanel,
      setHacizMatched,
      setHacizStatus,
      setMatched,
      setStatus,
      setUnresolvedBirimRows,
      updateProgressBar,
      updateRowCount,
      updateStopResumeButton
    };
  };

  window.MiniIcraPopupShell = {
    createShell
  };
})();

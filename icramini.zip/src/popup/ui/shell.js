(function () {
  "use strict";

  if (window.MiniIcraPopupShell) {
    return;
  }

  const STATUS_COLOR_OK = "#205521";
  const STATUS_COLOR_ERROR = "#a02929";
  const MAX_UNRESOLVED_BIRIM_ROWS = 200;

  const escapeHtml = (value) =>
    String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");

  const normalizeMatchedRow = (row) => {
    if (row && typeof row === "object") {
      return {
        text: String(row.text ?? ""),
        status: String(row.status || "")
      };
    }
    return { text: String(row ?? ""), status: "" };
  };

  const createShell = ({ els, hacizEls, state, runModes }) => {
    const RUN_MODES = runModes;

    const TALEP_RUN_MODES = new Set([
      RUN_MODES.TALEP_MASRAF_AVANS_IADESI,
      RUN_MODES.TALEP_BORCLU_ODEME_AKTAR,
      RUN_MODES.TALEP_KESINLESTIRME,
      RUN_MODES.TALEP_EVRAKI_OLUSTUR
    ]);

    const YATAN_PARA_RUN_MODES = new Set([RUN_MODES.NORMAL, RUN_MODES.DATED, RUN_MODES.KALAN]);

    const getPanelForRunMode = (mode) => {
      if (mode === RUN_MODES.DOSYA_HESABI) {
        return "dosya";
      }
      if (TALEP_RUN_MODES.has(mode)) {
        return "talep";
      }
      return "query";
    };

    const isYatanParaMode = (mode) => YATAN_PARA_RUN_MODES.has(mode);

    const setStatus = (text, isError = false) => {
      els.status.textContent = text;
      els.status.style.color = isError ? STATUS_COLOR_ERROR : STATUS_COLOR_OK;
      if (!isError) {
        state.lastLiveStatus = String(text || "");
      }
    };

    const setHacizStatus = (text, isError = false) => {
      els.status.textContent = text;
      els.status.style.color = isError ? STATUS_COLOR_ERROR : STATUS_COLOR_OK;
    };

    const updateProgressBar = (processed, total) => {
      if (!els.progressWrap || !els.progressFill || !els.progressText) {
        return;
      }
      els.progressWrap.style.display = "";
      const pct = total > 0 ? Math.min(100, Math.round((processed / total) * 100)) : 0;
      els.progressFill.style.width = `${pct}%`;
      els.progressText.textContent = total > 0 ? `${processed}/${total} (%${pct})` : "";
      els.progressFill.classList.toggle("active", pct < 100);
    };

    const hideProgressBar = () => {
      if (!els.progressWrap) {
        return;
      }
      els.progressWrap.style.display = "none";
      if (els.progressFill) {
        els.progressFill.style.width = "0%";
        els.progressFill.classList.remove("active");
      }
      if (els.progressText) {
        els.progressText.textContent = "";
      }
    };

    const updateRowCount = () => {
      if (!els.rowCount || !els.inputs) {
        return;
      }
      const text = els.inputs.value.trim();
      const count = text.length === 0 ? 0 : text.split("\n").filter((line) => line.trim()).length;
      els.rowCount.textContent = count === 0 ? "0 satır" : `${count} satır`;
    };

    const KESIN_TABS = [
      { key: "kesinlesen", label: "Kesinleştirme", empty: "Kesinleşen dosya bulunamadı." },
      { key: "iade", label: "İade", empty: "İade gelen tebligat bulunamadı." }
    ];

    const renderKesinChip = (label, value, tone) => {
      const text = String(value || "").trim();
      if (!text) {
        return "";
      }
      return [
        `<span class="kesin-chip${tone ? ` kesin-chip-${tone}` : ""}" title="${escapeHtml(text)}">`,
        `<span class="kesin-chip-label">${escapeHtml(label)}</span>`,
        `<span class="kesin-chip-value">${escapeHtml(text)}</span>`,
        `</span>`
      ].join("");
    };

    const renderKesinSatir = (satir, kind) => {
      const chips =
        kind === "iade"
          ? [
              renderKesinChip("İade", satir.iadeTarihi || "-", "warn"),
              renderKesinChip("Neden", satir.aciklama, "muted"),
              renderKesinChip("Barkod", satir.barkod, "code")
            ]
          : [
              renderKesinChip("Tebliğ", satir.tebligTarihi || "-", "info"),
              renderKesinChip("Kesinleşme", satir.kesinlesmeTarihi, "ok"),
              renderKesinChip("Barkod", satir.barkod, "code")
            ];
      return `<div class="kesin-satir">${chips.join("")}</div>`;
    };

    const renderKesinKisi = (kisi, kind) => {
      const satirlar = (kisi.satirlar || []).map((satir) => renderKesinSatir(satir, kind)).join("");
      return [
        `<div class="kesin-kisi">`,
        `<div class="kesin-kisi-ad" title="${escapeHtml(kisi.kisi)}">${escapeHtml(kisi.kisi)}</div>`,
        `<div class="kesin-satirlar">${satirlar}</div>`,
        `</div>`
      ].join("");
    };

    const renderKesinCard = (card, kind) => {
      const kisiler = Array.isArray(card.kisiler) ? card.kisiler : [];
      const meta = `${kisiler.length} kişi · ${Number(card.tebligatSayisi) || 0} tebligat`;
      const birim = card.birimAdi
        ? `<span class="kesin-birim" title="${escapeHtml(card.birimAdi)}">${escapeHtml(card.birimAdi)}</span>`
        : "";
      return [
        `<article class="kesin-card kesin-card-${kind}">`,
        `<div class="kesin-card-head">`,
        `<span class="kesin-dosya">${escapeHtml(card.dosyaNo)}</span>`,
        birim,
        `<span class="kesin-meta">${escapeHtml(meta)}</span>`,
        `</div>`,
        `<div class="kesin-kisiler">${kisiler.map((kisi) => renderKesinKisi(kisi, kind)).join("")}</div>`,
        `</article>`
      ].join("");
    };

    const getKesinCards = (view, key) => (view && Array.isArray(view[key]) ? view[key] : []);

    // Kullanıcı sekme seçmediyse dolu olan sekme açılır; yalnız iade varken boş
    // "Kesinleştirme" listesiyle karşılaşmasın.
    const resolveKesinlestirmeTab = (view) => {
      if (state.kesinlestirmeTabPinned) {
        return state.kesinlestirmeTab === "iade" ? "iade" : "kesinlesen";
      }
      return getKesinCards(view, "kesinlesen").length === 0 && getKesinCards(view, "iade").length > 0
        ? "iade"
        : "kesinlesen";
    };

    const applyKesinlestirmeTab = () => {
      const root = els.kesinResult;
      if (!root || typeof root.querySelectorAll !== "function") {
        return;
      }
      const active = state.kesinlestirmeTab === "iade" ? "iade" : "kesinlesen";
      for (const tab of root.querySelectorAll("[data-kesin-tab]")) {
        const isActive = tab.getAttribute("data-kesin-tab") === active;
        tab.classList.toggle("active", isActive);
        tab.setAttribute("aria-selected", isActive ? "true" : "false");
      }
      for (const pane of root.querySelectorAll("[data-kesin-pane]")) {
        pane.hidden = pane.getAttribute("data-kesin-pane") !== active;
      }
    };

    const selectKesinlestirmeTab = (tab) => {
      state.kesinlestirmeTab = tab === "iade" ? "iade" : "kesinlesen";
      state.kesinlestirmeTabPinned = true;
      applyKesinlestirmeTab();
    };

    const renderKesinlestirmeView = (view) => {
      if (!els.kesinResult) {
        return;
      }
      const tabsHtml = KESIN_TABS.map((tab) => {
        const count = getKesinCards(view, tab.key).length;
        return [
          `<button type="button" class="kesin-tab" role="tab" data-kesin-tab="${tab.key}" aria-selected="false">`,
          `${escapeHtml(tab.label)}<span class="kesin-count kesin-count-${tab.key}">${count}</span>`,
          `</button>`
        ].join("");
      }).join("");

      const panesHtml = KESIN_TABS.map((tab) => {
        const cards = getKesinCards(view, tab.key);
        const body = cards.length
          ? cards.map((card) => renderKesinCard(card, tab.key)).join("")
          : `<div class="kesin-empty">${escapeHtml(tab.empty)}</div>`;
        return `<section class="kesin-pane" role="tabpanel" data-kesin-pane="${tab.key}" hidden>${body}</section>`;
      }).join("");

      const tabsBar = `<div class="kesin-tabs" role="tablist" aria-label="Kesinleştirme">${tabsHtml}</div>`;
      els.kesinResult.innerHTML = tabsBar + panesHtml;
      applyKesinlestirmeTab();
    };

    const hideKesinlestirmeView = () => {
      if (!els.kesinResult) {
        return;
      }
      els.kesinResult.hidden = true;
      els.kesinResult.innerHTML = "";
      state.lastKesinlestirmeView = null;
      if (els.matched) {
        els.matched.hidden = false;
      }
    };

    // Kesinleştirme sonuçları düz metin yerine sekmeli kart görünümünde çiziliyor;
    // metin satırları dışa aktarma ve oturum geri yükleme için saklanmaya devam ediyor.
    const setKesinlestirmeView = (view, textRows) => {
      if (!els.kesinResult) {
        setMatched(textRows);
        return;
      }

      const unresolved = Array.isArray(state.unresolvedBirimRows) ? state.unresolvedBirimRows : [];
      if (els.matched) {
        els.matched.hidden = unresolved.length === 0;
        renderMatchedRows(unresolved.length > 0 ? ["Eşleşmeyen Birimler:", ...unresolved] : []);
      }

      state.lastLiveRows = Array.isArray(textRows) ? textRows.slice() : [];
      state.lastKesinlestirmeView = view || { kesinlesen: [], iade: [] };
      state.kesinlestirmeTab = resolveKesinlestirmeTab(state.lastKesinlestirmeView);
      els.kesinResult.hidden = false;
      renderKesinlestirmeView(state.lastKesinlestirmeView);
    };

    const renderMatchedRows = (rows) => {
      const safeRows = Array.isArray(rows) ? rows : [];
      els.matched.innerHTML = safeRows
        .map((row) => {
          const normalized = normalizeMatchedRow(row);
          const isError = normalized.status === "error" || /başarısız|hata/i.test(normalized.text);
          const className = isError ? "matched-line matched-line-error" : "matched-line";
          return `<div class="${className}">${escapeHtml(normalized.text)}</div>`;
        })
        .join("");
    };

    const setMatched = (rows) => {
      hideKesinlestirmeView();
      const outputRows = [];
      if (Array.isArray(state.unresolvedBirimRows) && state.unresolvedBirimRows.length > 0) {
        outputRows.push("Eşleşmeyen Birimler:", ...state.unresolvedBirimRows, "");
      }

      if (!Array.isArray(rows) || rows.length === 0) {
        if (outputRows.length === 0) {
          outputRows.push("Sonuç bulunamadı.");
        }
        state.lastLiveRows = outputRows.slice();
        renderMatchedRows(outputRows);
        return;
      }

      outputRows.push(...rows);
      state.lastLiveRows = outputRows.slice();
      renderMatchedRows(outputRows);
    };

    const setHacizMatched = (rows) => {
      if (!els.matched) {
        return;
      }
      if (!Array.isArray(rows) || rows.length === 0) {
        els.matched.textContent = "Sonuç bulunamadı.";
        return;
      }
      els.matched.innerHTML = rows.join("<br>");
    };

    const resetStableMatchedRows = () => {
      state.stableMatchedRows = [];
      state.stableMatchedSet = new Set();
    };

    const collectStableMatchedRows = (rows) => {
      for (const row of Array.isArray(rows) ? rows : []) {
        const key = String(row || "").trim();
        if (!key || state.stableMatchedSet.has(key)) {
          continue;
        }
        state.stableMatchedSet.add(key);
        state.stableMatchedRows.push(row);
      }
    };

    // Yatan para modlarında satırlar akış boyunca birikir (her ilerleme mesajı
    // yalnızca o ana kadarki eşleşmeleri taşır); diğer modlarda liste baştan yazılır.
    const mergeStableMatchedRows = (rows, mode) => {
      if (!isYatanParaMode(mode)) {
        return Array.isArray(rows) ? rows : [];
      }
      collectStableMatchedRows(rows);
      return state.stableMatchedRows.slice();
    };

    const setUnresolvedBirimRows = (rows) => {
      state.unresolvedBirimRows = Array.isArray(rows) ? rows.slice(0, MAX_UNRESOLVED_BIRIM_ROWS) : [];
    };

    const persistLiveView = () => {
      try {
        chrome.storage.local.set({
          runnerLiveView: {
            rows: Array.isArray(state.lastLiveRows) ? state.lastLiveRows : [],
            kesinlestirmeView: state.lastKesinlestirmeView || null,
            status: String(state.lastLiveStatus || ""),
            runMode: String(state.currentRunMode || "normal"),
            updatedAt: new Date().toISOString()
          }
        });
      } catch {}
    };

    const hasResumeForCurrentPanel = () =>
      state.currentUiPanel === "haciz" ? !!state.resumeHacizState : !!state.resumeQueryState;

    const updateStopResumeButton = () => {
      if (!els.stopBtn) {
        return;
      }
      if (state.isRunning || state.hacizIsRunning) {
        els.stopBtn.disabled = false;
        els.stopBtn.textContent = "Durdur";
        return;
      }
      if (hasResumeForCurrentPanel()) {
        els.stopBtn.disabled = false;
        els.stopBtn.textContent = "Devam Et";
        return;
      }
      els.stopBtn.disabled = true;
      els.stopBtn.textContent = "Durdur";
    };

    const setActivePanel = (panel) => {
      state.currentUiPanel = panel === "dosya" || panel === "haciz" || panel === "talep" ? panel : "query";

      const activeStates = [
        [els.tabQuery, els.queryPanel, "query"],
        [els.tabDosya, els.dosyaPanel, "dosya"],
        [els.tabTalep, els.talepPanel, "talep"],
        [hacizEls.tabHaciz, hacizEls.hacizPanel, "haciz"]
      ];

      for (const [tab, panelEl, name] of activeStates) {
        const isActive = state.currentUiPanel === name;
        if (tab) {
          tab.classList.toggle("active", isActive);
          tab.setAttribute("aria-selected", isActive ? "true" : "false");
        }
        if (panelEl) {
          panelEl.classList.toggle("active", isActive);
        }
      }

      chrome.storage.local.set({ runnerActivePanel: state.currentUiPanel });
      updateStopResumeButton();
    };

    const refreshResumeStates = (done) => {
      chrome.storage.local.get(
        { runnerResumeState: null, runnerHacizResumeState: null },
        ({ runnerResumeState, runnerHacizResumeState }) => {
          state.resumeQueryState = runnerResumeState || null;
          state.resumeHacizState = runnerHacizResumeState || null;
          updateStopResumeButton();
          if (typeof done === "function") {
            done();
          }
        }
      );
    };

    const buildResumeStatusText = (label, detail) => {
      if (label && detail) {
        return `Durduruldu. Son durak: ${label} / ${detail}. Devam Et ile sürdürebilirsin.`;
      }
      if (label) {
        return `Durduruldu. Son durak: ${label}. Devam Et ile sürdürebilirsin.`;
      }
      return "Durduruldu. Devam Et ile sürdürebilirsin.";
    };

    const getQueryResumeStatusText = (checkpoint) =>
      buildResumeStatusText(
        String(checkpoint?.lastProgress?.activeInput || "").trim(),
        String(checkpoint?.lastProgress?.activeStepLabel || "").trim()
      );

    const getHacizResumeStatusText = (checkpoint) =>
      buildResumeStatusText(
        String(checkpoint?.lastProgress?.activeQueryDosyaNo || "").trim(),
        String(checkpoint?.lastProgress?.activeQueryLabel || "").trim()
      );

    if (els.kesinResult && typeof els.kesinResult.addEventListener === "function") {
      // Sekmeler her ilerleme mesajında yeniden çizildiği için olay kökte dinleniyor.
      els.kesinResult.addEventListener("click", (event) => {
        const target = event && event.target;
        const button = target && typeof target.closest === "function" ? target.closest("[data-kesin-tab]") : null;
        if (button) {
          selectKesinlestirmeTab(button.getAttribute("data-kesin-tab"));
        }
      });
    }

    return {
      escapeHtml,
      getHacizResumeStatusText,
      getPanelForRunMode,
      getQueryResumeStatusText,
      hideProgressBar,
      isYatanParaMode,
      collectStableMatchedRows,
      mergeStableMatchedRows,
      persistLiveView,
      refreshResumeStates,
      renderMatchedRows,
      resetStableMatchedRows,
      setActivePanel,
      setHacizMatched,
      setHacizStatus,
      setKesinlestirmeView,
      setMatched,
      setStatus,
      setUnresolvedBirimRows,
      updateProgressBar,
      updateRowCount,
      updateStopResumeButton
    };
  };

  window.MiniIcraPopupShell = {
    createShell
  };
})();

(function () {
  "use strict";

  if (window.MiniIcraPopupState) {
    return;
  }

  const createAppState = () => ({
    isRunning: false,
    hacizIsRunning: false,
    lastResult: null,
    currentRunMode: "normal",
    currentUiPanel: "query",
    activeRequestId: null,
    activeHacizRequestId: null,
    autoSaveTimer: null,
    progressSyncTimer: null,
    hacizProgressSyncTimer: null,
    lastLiveRows: [],
    lastLiveStatus: "",
    unresolvedBirimRows: [],
    stableMatchedRows: [],
    stableMatchedSet: new Set(),
    resumeQueryState: null,
    resumeHacizState: null,
    lastObservedInputText: "",
    currentThemeMode: "auto",
    currentPalette: "varsayilan",
    latestUpdateNoticeVersion: "",
    docsLoaded: false
  });

  window.MiniIcraPopupState = {
    createAppState
  };
})();

﻿const PopupConfig = window.MiniIcraPopupConfig || {};
const PopupDom = window.MiniIcraPopupDom || {};
const DEFAULT_SETTINGS = PopupConfig.DEFAULT_SETTINGS || {};
const els = typeof PopupDom.getPopupElements === "function" ? PopupDom.getPopupElements() : {};

const HacizConfig = window.MiniIcraHacizConfig || {};
const HacizUtils  = window.MiniIcraHacizUtils  || {};
const hacizEls    = typeof window.MiniIcraHacizDom?.getHacizElements === "function"
  ? window.MiniIcraHacizDom.getHacizElements()
  : {};

const PopupUtils = window.MiniIcraPopupUtils || {};
const PopupQuery = window.MiniIcraPopupQuery || {};
const PopupDosya = window.MiniIcraPopupDosya || {};
const PopupHesap = window.MiniIcraPopupHesap || {};
const PopupExport = window.MiniIcraPopupExport || {};
const RUN_MODES = PopupUtils.RUN_MODES || Object.freeze({
  NORMAL: "normal",
  DATED: "datedCurrentMonth",
  REDDIYAT: "reddiyat",
  KALAN: "kalan",
  KESINLESTIRME: "kesinlestirme",
  DOSYA_HESABI: "dosyaHesabi",
  TALEP_MASRAF_AVANS_IADESI: "talepMasrafAvansIadesi",
  TALEP_BORCLU_ODEME_AKTAR: "talepBorcluOdemeAktar",
  TALEP_KESINLESTIRME: "talepKesinlestirme",
  TALEP_EVRAKI_OLUSTUR: "talepEvrakiOlustur"
});
const normalizeKey = PopupUtils.normalizeKey || ((s) => String(s || "").toLocaleLowerCase("tr-TR").replace(/[^a-z0-9]/g, ""));
const normalizeOdemeDateForUi = PopupUtils.normalizeOdemeDateForUi || ((value) => String(value || "").trim());
const parseRowsFromInput = PopupUtils.parseRowsFromInput || (() => []);
const formatRunStatus = PopupUtils.formatRunStatus || ((progress) => `Çalışıyor... ${progress.processed}/${progress.total} | Eşleşen: ${progress.matchCount}`);
const getMatchedRowsForMode = PopupUtils.getMatchedRowsForMode || (() => []);
const syncDatedFilterVisibility =
  PopupQuery.syncDatedFilterVisibility ||
  ((innerEls) => {
    if (!innerEls || !innerEls.datedFilter || !innerEls.runMode) {
      return;
    }
    const mode = String(innerEls.runMode.value || "normal");
    const isDatedMode = mode === "datedCurrentMonth";
    const isKalanMode = mode === "kalan";
    const isCustom = String(innerEls.datedFilter.value || "") === "custom";
    innerEls.datedFilter.style.display = isDatedMode ? "" : "none";
    if (innerEls.datedCustomRange) {
      innerEls.datedCustomRange.style.display = isDatedMode && isCustom ? "" : "none";
    }
    if (innerEls.kalanQueryWrap) {
      innerEls.kalanQueryWrap.style.display = isKalanMode ? "" : "none";
    }
  });
const syncDosyaHesapTuruVisibility =
  PopupDosya.syncDosyaHesapTuruVisibility ||
  ((innerEls) => {
    if (!innerEls || !innerEls.dosyaIndirimWrap || !innerEls.dosyaHesabiHesapTuru) {
      return;
    }
    const isIndirim = String(innerEls.dosyaHesabiHesapTuru.value || "normal") === "indirim";
    innerEls.dosyaIndirimWrap.style.display = isIndirim ? "" : "none";
  });
const isProgressCompleted =
  PopupQuery.isProgressCompleted ||
  ((progress) => {
    if (!progress) {
      return false;
    }
    if (progress.stopped === true) {
      return true;
    }
    const total = Number(progress.total);
    const processed = Number(progress.processed);
    return Number.isFinite(total) && Number.isFinite(processed) && total > 0 && processed >= total;
  });
const getProgressCompletionStatus =
  PopupQuery.getProgressCompletionStatus ||
  ((progress) =>
    progress && progress.stopped
      ? `Durduruldu. Eşleşen: ${progress.matchCount}/${progress.total}`
      : `Tamamlandı. Eşleşen: ${progress.matchCount}/${progress.total}`);
const getExportData = PopupExport.getExportData || (() => ({ mode: "normal", header: [], rows: [] }));
const downloadExcelXlsx = PopupExport.downloadExcelXlsx || (() => {});

let isRunning = false;
let lastResult = null;
let autoSaveTimer = null;
let activeRequestId = null;
let currentRunMode = "normal";
let lastLiveRows = [];
let lastLiveStatus = "";
let unresolvedBirimRows = [];
let currentUiPanel = "query";
let progressSyncTimer = null;
let currentThemeMode = "auto";
let stableMatchedRows = [];
let stableMatchedSet = new Set();
let resumeQueryState = null;
let resumeHacizState = null;
let lastObservedInputText = "";

const getTodayForDateInput = () => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

const resetDosyaHesabiOdemeTarihi = () => {
  if (els.dosyaHesabiOdemeTarihi) {
    els.dosyaHesabiOdemeTarihi.value = getTodayForDateInput();
  }
};

let hacizIsRunning = false;
let hacizProgressSyncTimer = null;
let activeHacizRequestId = null;
const VERSION_CHECK_URL = "https://raw.githubusercontent.com/icratoolkit/updater/refs/heads/main/version.json";
const VERSION_CHECK_INTERVAL_MS = 24 * 60 * 60 * 1000;
const VERSION_CHECK_FORCE_PARAM = "forceVersionCheck";
const VERSION_CHECK_STORAGE_DEFAULTS = {
  miniIcraVersionCheckLastAt: 0,
  miniIcraVersionCheckLatest: null,
  miniIcraVersionCheckDismissed: null
};
const birimLookupService =
  typeof PopupQuery.createBirimLookupService === "function"
    ? PopupQuery.createBirimLookupService({ normalizeKey })
    : null;


const resolveTheme = (mode) => {
  if (mode === "dark" || mode === "light") {
    return mode;
  }
  try {
    return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  } catch {
    return "light";
  }
};

const applyTheme = (mode) => {
  currentThemeMode = mode === "dark" || mode === "light" ? mode : "auto";
  const resolved = resolveTheme(currentThemeMode);
  document.body.setAttribute("data-theme", resolved);
  if (els.themeToggle) {
    const sunIcon = String.fromCodePoint(0x2600);
    const moonIcon = String.fromCodePoint(0x1F319);
    els.themeToggle.textContent = resolved === "dark" ? sunIcon : moonIcon;
    els.themeToggle.title = resolved === "dark" ? "Açık mod" : "Koyu mod";
  }
};

const toggleTheme = () => {
  const resolved = resolveTheme(currentThemeMode);
  const next = resolved === "dark" ? "light" : "dark";
  applyTheme(next);
  try {
    chrome.storage.local.set({ runnerUiTheme: next });
  } catch {
    
  }
};


// ═══════════════════════════════════════════════════════════════════════════════
// DOCS PANEL — Markdown viewer
// ═══════════════════════════════════════════════════════════════════════════════

let docsLoaded = false;

const mdToHtml = (md) => {
  const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

  /* ── inline formatting ── */
  const inline = (text) => {
    let s = esc(text);
    // images
    s = s.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img src="$2" alt="$1" class="md-img">');
    // links
    s = s.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_, label, href) => {
      if (href.startsWith("#")) {
        return `<a href="${href}" class="md-anchor">${label}</a>`;
      }
      return `<a href="${href}" target="_blank" rel="noopener">${label}</a>`;
    });
    // bold+italic
    s = s.replace(/\*\*\*(.+?)\*\*\*/g, "<strong><em>$1</em></strong>");
    // bold
    s = s.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
    // italic
    s = s.replace(/(?<!\w)\*(.+?)\*(?!\w)/g, "<em>$1</em>");
    s = s.replace(/(?<!\w)_(.+?)_(?!\w)/g, "<em>$1</em>");
    // strikethrough
    s = s.replace(/~~(.+?)~~/g, "<del>$1</del>");
    // inline code (must come after bold/italic)
    s = s.replace(/`([^`]+)`/g, "<code>$1</code>");
    // raw html entities passthrough
    s = s.replace(/&amp;nbsp;/g, "&nbsp;");
    return s;
  };

  /* ── heading id generator ── */
  const slugify = (text) =>
    text
      .toLowerCase()
      .replace(/[`*_~\[\]()]/g, "")
      .replace(/[^\w\s\u00C0-\u024F-]/g, "")
      .trim()
      .replace(/\s+/g, "-");

  const lines = md.split("\n");
  const out = [];
  let inCode = false;
  let codeLang = "";
  let codeLines = [];
  let inTable = false;
  let tableHasHead = false;
  let inBlockquote = false;
  let bqLines = [];
  let listStack = []; // [{type:"ul"|"ol", indent}]
  let inHtmlBlock = false;

  const flushBlockquote = () => {
    if (!inBlockquote) return;
    out.push(`<blockquote>${bqLines.map(inline).join("<br>")}</blockquote>`);
    bqLines = [];
    inBlockquote = false;
  };

  const flushCode = () => {
    if (!inCode) return;
    const langClass = codeLang ? ` class="language-${codeLang}"` : "";
    out.push(`<pre><code${langClass}>${codeLines.join("\n")}</code></pre>`);
    codeLines = [];
    codeLang = "";
    inCode = false;
  };

  const closeTable = () => {
    if (!inTable) return;
    out.push("</tbody></table></div>");
    inTable = false;
    tableHasHead = false;
  };

  const closeAllLists = () => {
    while (listStack.length > 0) {
      const item = listStack.pop();
      out.push(item.type === "ol" ? "</ol>" : "</ul>");
    }
  };

  const handleListItem = (indent, type, content) => {
    // Close deeper lists
    while (listStack.length > 0 && listStack[listStack.length - 1].indent > indent) {
      const item = listStack.pop();
      out.push(item.type === "ol" ? "</ol>" : "</ul>");
    }
    // Open new list or switch type
    if (listStack.length === 0 || listStack[listStack.length - 1].indent < indent) {
      out.push(type === "ol" ? "<ol>" : "<ul>");
      listStack.push({ type, indent });
    } else if (listStack[listStack.length - 1].type !== type) {
      const item = listStack.pop();
      out.push(item.type === "ol" ? "</ol>" : "</ul>");
      out.push(type === "ol" ? "<ol>" : "<ul>");
      listStack.push({ type, indent });
    }
    out.push(`<li>${inline(content)}</li>`);
  };

  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i];

    /* code fences */
    if (raw.trimStart().startsWith("```")) {
      flushBlockquote(); closeTable();
      if (inCode) {
        flushCode();
      } else {
        closeAllLists();
        codeLang = raw.trim().slice(3).trim();
        inCode = true;
      }
      continue;
    }
    if (inCode) { codeLines.push(esc(raw)); continue; }

    const trimmed = raw.trim();

    /* html block passthrough */
    if (inHtmlBlock) {
      if (!trimmed) { inHtmlBlock = false; }
      else { out.push(raw); continue; }
    }

    /* blank line */
    if (!trimmed) {
      flushBlockquote();
      closeTable();
      closeAllLists();
      continue;
    }

    /* html block start */
    if (/^<(?:p|h[1-6]|div|section|article|header|footer|nav|main|aside|figure|figcaption|details|summary|pre|blockquote|hr|br|sub|sup|small)\b/i.test(trimmed)) {
      flushBlockquote(); closeTable(); closeAllLists();
      out.push(raw);
      const selfClosing = /\/>\s*$/.test(trimmed) || /<\/[a-z][a-z0-9]*>\s*$/i.test(trimmed);
      if (!selfClosing) { inHtmlBlock = true; }
      continue;
    }

    /* horizontal rule */
    if (/^(-{3,}|\*{3,}|_{3,})$/.test(trimmed)) {
      flushBlockquote(); closeTable(); closeAllLists();
      out.push("<hr>");
      continue;
    }

    /* heading */
    const hMatch = trimmed.match(/^(#{1,6})\s+(.+)/);
    if (hMatch) {
      flushBlockquote(); closeTable(); closeAllLists();
      const lvl = hMatch[1].length;
      const rawText = hMatch[2].replace(/\s*#+\s*$/, ""); // trailing #
      const id = slugify(rawText.replace(/[📋📌🔍📅🔄📜🧮💾]/gu, "").trim());
      out.push(`<h${lvl} id="${id}">${inline(rawText)}</h${lvl}>`);
      continue;
    }

    /* blockquote */
    if (trimmed.startsWith("> ") || trimmed === ">") {
      closeTable(); closeAllLists();
      inBlockquote = true;
      bqLines.push(trimmed.replace(/^>\s?/, ""));
      continue;
    }
    flushBlockquote();

    /* table */
    if (trimmed.startsWith("|") && trimmed.endsWith("|")) {
      closeAllLists();
      const cells = trimmed.split("|").slice(1, -1).map((c) => c.trim());
      // separator row
      if (cells.every((c) => /^[-:]+$/.test(c))) { continue; }
      if (!inTable) {
        out.push('<div class="table-wrap"><table><thead><tr>' + cells.map((c) => `<th>${inline(c)}</th>`).join("") + "</tr></thead><tbody>");
        inTable = true;
        tableHasHead = true;
      } else {
        out.push("<tr>" + cells.map((c) => `<td>${inline(c)}</td>`).join("") + "</tr>");
      }
      continue;
    }
    if (inTable) {
      closeTable();
    }

    /* list items: allow leading whitespace for nesting */
    const leadingSpaces = raw.match(/^(\s*)/)[1].length;
    const ulMatch = trimmed.match(/^[-*+]\s+(.+)/);
    const olMatch = trimmed.match(/^\d+[.)]\s+(.+)/);
    if (ulMatch) { handleListItem(leadingSpaces, "ul", ulMatch[1]); continue; }
    if (olMatch) { handleListItem(leadingSpaces, "ol", olMatch[1]); continue; }
    closeAllLists();

    /* paragraph */
    out.push(`<p>${inline(trimmed)}</p>`);
  }
  flushBlockquote(); closeTable(); closeAllLists(); flushCode();
  return out.join("\n");
};

const toggleDocs = () => {
  if (!els.docsPanel) { return; }
  const isOpen = els.docsPanel.classList.toggle("open");
  if (els.helpBtn) { els.helpBtn.classList.toggle("active", isOpen); }
  if (isOpen && !docsLoaded) {
    fetch(chrome.runtime.getURL("README.md"))
      .then((r) => r.ok ? r.text() : Promise.reject(r.status))
      .then((md) => {
        if (els.docsContent) {
          let html = mdToHtml(md);
          html = html.replace(/src="(?!https?:\/\/|data:)([^"]+)"/g, (_, p) =>
            `src="${chrome.runtime.getURL(p)}"`
          );
          els.docsContent.innerHTML = html;
          // Enable anchor navigation within docs
          els.docsContent.addEventListener("click", (e) => {
            const a = e.target.closest("a.md-anchor");
            if (!a) return;
            e.preventDefault();
            const id = a.getAttribute("href").slice(1);
            const target = els.docsContent.querySelector(`#${CSS.escape(id)}`);
            if (target) { target.scrollIntoView({ behavior: "smooth", block: "start" }); }
          });
        }
        docsLoaded = true;
      })
      .catch((err) => {
        if (els.docsContent) { els.docsContent.textContent = `Dokümantasyon yüklenemedi: ${err}`; }
      });
  }
};

const closeDocs = () => {
  if (els.docsPanel) { els.docsPanel.classList.remove("open"); }
  if (els.helpBtn) { els.helpBtn.classList.remove("active"); }
};

const parseVersionParts = (version) =>
  String(version || "")
    .trim()
    .split(".")
    .map((part) => {
      const match = String(part).match(/^\d+/);
      return match ? Number(match[0]) : 0;
    });

const compareVersions = (left, right) => {
  const a = parseVersionParts(left);
  const b = parseVersionParts(right);
  const length = Math.max(a.length, b.length, 4);
  for (let i = 0; i < length; i++) {
    const av = Number.isFinite(a[i]) ? a[i] : 0;
    const bv = Number.isFinite(b[i]) ? b[i] : 0;
    if (av > bv) { return 1; }
    if (av < bv) { return -1; }
  }
  return 0;
};

let latestUpdateNoticeVersion = "";

const hideUpdateNotice = () => {
  if (!els.updateNotice) {
    return;
  }

  els.updateNotice.classList.remove("show");
  if (els.updateNoticeText) {
    els.updateNoticeText.textContent = "";
  } else {
    els.updateNotice.textContent = "";
  }
};

const setUpdateNotice = (latestVersion, currentVersion, dismissedVersion = "") => {
  if (!els.updateNotice) {
    return;
  }

  const latest = String(latestVersion || "").trim();
  latestUpdateNoticeVersion = latest;
  if (!latest || latest === String(dismissedVersion || "").trim() || compareVersions(latest, currentVersion) <= 0) {
    hideUpdateNotice();
    return;
  }

  if (els.updateNoticeText) {
    els.updateNoticeText.textContent = `${latest} yeni sürümü mevcut. Güncelleme yapabilirsiniz.`;
  } else {
    els.updateNotice.textContent = `${latest} yeni sürümü mevcut. Güncelleme yapabilirsiniz.`;
  }
  els.updateNotice.classList.add("show");
};

const dismissUpdateNotice = () => {
  const dismissed = String(latestUpdateNoticeVersion || "").trim();
  hideUpdateNotice();
  if (dismissed && chrome?.storage?.local) {
    chrome.storage.local.set({ miniIcraVersionCheckDismissed: dismissed });
  }
};

const fetchJson = async (url) => {
  const response = await fetch(url, { cache: "no-store" });
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }
  return response.json();
};

const getLocalVersion = async () => {
  return String(chrome.runtime.getManifest?.().version || "0.0.0").trim();
};

const shouldForceVersionCheck = () => {
  try {
    return new URLSearchParams(window.location.search).has(VERSION_CHECK_FORCE_PARAM);
  } catch {
    return false;
  }
};

const checkForUpdatesOncePerDay = async (options = {}) => {
  if (!els.updateNotice || !chrome?.storage?.local) {
    return;
  }

  const force = options.force === true || shouldForceVersionCheck();
  const currentVersion = await getLocalVersion();
  chrome.storage.local.get(VERSION_CHECK_STORAGE_DEFAULTS, async (stored) => {
    const now = Date.now();
    const lastAt = Number(stored.miniIcraVersionCheckLastAt || 0);
    const cachedLatest = stored.miniIcraVersionCheckLatest;
    const dismissedVersion = stored.miniIcraVersionCheckDismissed;

    if (!force && cachedLatest && now - lastAt < VERSION_CHECK_INTERVAL_MS) {
      setUpdateNotice(cachedLatest, currentVersion, dismissedVersion);
      return;
    }

    try {
      const remote = await fetchJson(`${VERSION_CHECK_URL}?t=${now}`);
      const latestVersion = String(remote?.version || "").trim();
      chrome.storage.local.set({
        miniIcraVersionCheckLastAt: now,
        miniIcraVersionCheckLatest: latestVersion || null
      });
      setUpdateNotice(latestVersion, currentVersion, dismissedVersion);
    } catch {
      chrome.storage.local.set({ miniIcraVersionCheckLastAt: now });
      setUpdateNotice(cachedLatest, currentVersion, dismissedVersion);
    }
  });
};

window.MiniIcraCheckForUpdates = () => {
  chrome.storage.local.set({ miniIcraVersionCheckDismissed: null }, () => {
    checkForUpdatesOncePerDay({ force: true });
  });
};

const setStatus = (text, isError = false) => {
  els.status.textContent = text;
  els.status.style.color = isError ? "#a02929" : "#205521";
  if (!isError) {
    lastLiveStatus = String(text || "");
  }
};

// ── Progress bar helpers ──
const updateProgressBar = (processed, total) => {
  if (!els.progressWrap || !els.progressFill || !els.progressText) { return; }
  els.progressWrap.style.display = "";
  const pct = total > 0 ? Math.min(100, Math.round((processed / total) * 100)) : 0;
  els.progressFill.style.width = pct + "%";
  els.progressText.textContent = total > 0 ? `${processed}/${total} (%${pct})` : "";
  if (pct >= 100) {
    els.progressFill.classList.remove("active");
  } else {
    els.progressFill.classList.add("active");
  }
};

const hideProgressBar = () => {
  if (!els.progressWrap) { return; }
  els.progressWrap.style.display = "none";
  if (els.progressFill) {
    els.progressFill.style.width = "0%";
    els.progressFill.classList.remove("active");
  }
  if (els.progressText) { els.progressText.textContent = ""; }
};

// ── Row counter ──
const updateRowCount = () => {
  if (!els.rowCount || !els.inputs) { return; }
  const text = els.inputs.value.trim();
  const count = text.length === 0 ? 0 : text.split("\n").filter((l) => l.trim()).length;
  els.rowCount.textContent = count === 0 ? "0 satır" : `${count} satır`;
};

const setActivePanel = (panel) => {
  currentUiPanel = panel === "dosya" ? "dosya" : panel === "haciz" ? "haciz" : panel === "talep" ? "talep" : "query";
  const isQuery = currentUiPanel === "query";
  const isDosya = currentUiPanel === "dosya";
  const isTalep = currentUiPanel === "talep";
  const isHaciz = currentUiPanel === "haciz";

  if (els.tabQuery) {
    els.tabQuery.classList.toggle("active", isQuery);
    els.tabQuery.setAttribute("aria-selected", isQuery ? "true" : "false");
  }
  if (els.tabDosya) {
    els.tabDosya.classList.toggle("active", isDosya);
    els.tabDosya.setAttribute("aria-selected", isDosya ? "true" : "false");
  }
  if (els.tabTalep) {
    els.tabTalep.classList.toggle("active", isTalep);
    els.tabTalep.setAttribute("aria-selected", isTalep ? "true" : "false");
  }
  if (hacizEls.tabHaciz) {
    hacizEls.tabHaciz.classList.toggle("active", isHaciz);
    hacizEls.tabHaciz.setAttribute("aria-selected", isHaciz ? "true" : "false");
  }
  if (els.queryPanel) {
    els.queryPanel.classList.toggle("active", isQuery);
  }
  if (els.dosyaPanel) {
    els.dosyaPanel.classList.toggle("active", isDosya);
  }
  if (els.talepPanel) {
    els.talepPanel.classList.toggle("active", isTalep);
  }
  if (hacizEls.hacizPanel) {
    hacizEls.hacizPanel.classList.toggle("active", isHaciz);
  }
  chrome.storage.local.set({ runnerActivePanel: currentUiPanel });
  updateStopResumeButton();
};

const escapeHtml = (value) => String(value ?? "")
  .replace(/&/g, "&amp;")
  .replace(/</g, "&lt;")
  .replace(/>/g, "&gt;")
  .replace(/\"/g, "&quot;")
  .replace(/\x27/g, "&#39;");

const normalizeMatchedRow = (row) => {
  if (row && typeof row === "object") {
    return {
      text: String(row.text ?? ""),
      status: String(row.status || "")
    };
  }
  return { text: String(row ?? ""), status: "" };
};

const renderMatchedRows = (rows) => {
  const safeRows = Array.isArray(rows) ? rows : [];
  els.matched.innerHTML = safeRows
    .map((row) => {
      const normalized = normalizeMatchedRow(row);
      const isError = normalized.status === "error" || /başarısız|hata/i.test(normalized.text);
      const className = isError ? "matched-line matched-line-error" : "matched-line";
      return `<div class="${className}">${escapeHtml(normalized.text)}</div>`;
    })
    .join("");
};

const setMatched = (rows) => {
  const outputRows = [];
  if (Array.isArray(unresolvedBirimRows) && unresolvedBirimRows.length > 0) {
    outputRows.push("Eşleşmeyen Birimler:", ...unresolvedBirimRows, "");
  }

  if (!Array.isArray(rows) || rows.length === 0) {
    if (outputRows.length === 0) {
      outputRows.push("Sonuç bulunamadı.");
    }
    lastLiveRows = outputRows.slice();
    renderMatchedRows(outputRows);
    return;
  }

  outputRows.push(...rows);
  lastLiveRows = outputRows.slice();
  renderMatchedRows(outputRows);
};

const resetStableMatchedRows = () => {
  stableMatchedRows = [];
  stableMatchedSet = new Set();
};

const getPanelForRunMode = (mode) =>
  mode === RUN_MODES.DOSYA_HESABI ? "dosya" :
    (mode === RUN_MODES.TALEP_MASRAF_AVANS_IADESI || mode === RUN_MODES.TALEP_BORCLU_ODEME_AKTAR || mode === RUN_MODES.TALEP_KESINLESTIRME || mode === RUN_MODES.TALEP_EVRAKI_OLUSTUR) ? "talep" :
      "query";

const syncTalepButtonText = () => {
  if (!els.talepRunBtn || !els.talepType) {
    return;
  }
  els.talepRunBtn.textContent = "Talep Gönder";
};

const syncTalepIbanVisibility = () => {
  if (!els.talepIbanWrap || !els.talepType) {
    return;
  }
  const isIbanDegisikligi = String(els.talepType.value || "") === "talepEvrakiOlustur";
  els.talepIbanWrap.style.display = isIbanDegisikligi ? "" : "none";
};

const isYatanParaMode = (mode) => mode === RUN_MODES.NORMAL || mode === RUN_MODES.DATED || mode === RUN_MODES.KALAN;

const hasResumeForCurrentPanel = () =>
  currentUiPanel === "haciz"
    ? !!resumeHacizState
    : !!resumeQueryState;

const updateStopResumeButton = () => {
  if (!els.stopBtn) {
    return;
  }
  if (isRunning || hacizIsRunning) {
    els.stopBtn.disabled = false;
    els.stopBtn.textContent = "Durdur";
    return;
  }
  if (hasResumeForCurrentPanel()) {
    els.stopBtn.disabled = false;
    els.stopBtn.textContent = "Devam Et";
    return;
  }
  els.stopBtn.disabled = true;
  els.stopBtn.textContent = "Durdur";
};

const refreshResumeStates = (done) => {
  chrome.storage.local.get({ runnerResumeState: null, runnerHacizResumeState: null }, ({ runnerResumeState, runnerHacizResumeState }) => {
    resumeQueryState = runnerResumeState || null;
    resumeHacizState = runnerHacizResumeState || null;
    updateStopResumeButton();
    if (typeof done === "function") {
      done();
    }
  });
};

const getQueryResumeStatusText = (checkpoint) => {
  if (!checkpoint) {
    return "Durduruldu. Devam Et ile sürdürebilirsin.";
  }
  const input = String(checkpoint?.lastProgress?.activeInput || "").trim();
  const step = String(checkpoint?.lastProgress?.activeStepLabel || "").trim();
  if (input && step) {
    return `Durduruldu. Son durak: ${input} / ${step}. Devam Et ile sürdürebilirsin.`;
  }
  if (input) {
    return `Durduruldu. Son durak: ${input}. Devam Et ile sürdürebilirsin.`;
  }
  return "Durduruldu. Devam Et ile sürdürebilirsin.";
};

const getHacizResumeStatusText = (checkpoint) => {
  if (!checkpoint) {
    return "Durduruldu. Devam Et ile sürdürebilirsin.";
  }
  const dosyaNo = String(checkpoint?.lastProgress?.activeQueryDosyaNo || "").trim();
  const label = String(checkpoint?.lastProgress?.activeQueryLabel || "").trim();
  if (dosyaNo && label) {
    return `Durduruldu. Son durak: ${dosyaNo} / ${label}. Devam Et ile sürdürebilirsin.`;
  }
  if (dosyaNo) {
    return `Durduruldu. Son durak: ${dosyaNo}. Devam Et ile sürdürebilirsin.`;
  }
  return "Durduruldu. Devam Et ile sürdürebilirsin.";
};

const mergeStableMatchedRows = (rows, mode) => {
  if (!isYatanParaMode(mode)) {
    return Array.isArray(rows) ? rows : [];
  }
  for (const row of Array.isArray(rows) ? rows : []) {
    const key = String(row || "").trim();
    if (!key || stableMatchedSet.has(key)) {
      continue;
    }
    stableMatchedSet.add(key);
    stableMatchedRows.push(row);
  }
  return stableMatchedRows.slice();
};

const persistLiveView = () => {
  try {
    chrome.storage.local.set({
      runnerLiveView: {
        rows: Array.isArray(lastLiveRows) ? lastLiveRows : [],
        status: String(lastLiveStatus || ""),
        runMode: String(currentRunMode || "normal"),
        updatedAt: new Date().toISOString()
      }
    });
  } catch {
    
  }
};

const getSettingsFromForm = () => ({
  firstEndpointPath: els.firstEndpointPath.value.trim(),
  firstMethod: (els.firstMethod.value || "POST").toUpperCase(),
  firstHeadersText: els.firstHeadersText.value,
  firstBodyTemplate: els.firstBodyTemplate.value,
  secondEndpointPath: els.secondEndpointPath.value.trim(),
  secondMethod: (els.secondMethod.value || "POST").toUpperCase(),
  secondHeadersText: els.secondHeadersText.value,
  secondBodyTemplate: els.secondBodyTemplate.value,
  defaultBirimId: (els.defaultBirimId ? els.defaultBirimId.value : "").trim(),
  defaultBirimAdi: (els.defaultBirimAdi ? els.defaultBirimAdi.value : "").trim(),
  defaultDosyaDurum: (els.defaultDosyaDurum ? els.defaultDosyaDurum.value : "").trim(),
  dosyaHesabiOdemeTarihi: (els.dosyaHesabiOdemeTarihi ? els.dosyaHesabiOdemeTarihi.value : "").trim(),
  dosyaHesabiHesapTuru: (els.dosyaHesabiHesapTuru ? els.dosyaHesabiHesapTuru.value : "normal").trim() || "normal",
  dosyaHesabiDosyaDurumKod: (els.dosyaHesabiDosyaDurumKod ? els.dosyaHesabiDosyaDurumKod.value : "0").trim() === "1" ? "1" : "0",
  dosyaHesabiIndirimTutari: (els.dosyaHesabiIndirimTutari ? els.dosyaHesabiIndirimTutari.value : "").trim(),
  faizOranDusuk: (els.faizOranDusuk ? els.faizOranDusuk.value : "").trim(),
  faizOranYuksek: (els.faizOranYuksek ? els.faizOranYuksek.value : "").trim(),
  faizBolunmeTarihi: (els.faizBolunmeTarihi ? els.faizBolunmeTarihi.value : "").trim(),
  datedFilter: (els.datedFilter ? els.datedFilter.value : "thisMonth").trim() || "thisMonth",
  kalanQueryAmount: (els.kalanQueryAmount ? els.kalanQueryAmount.value : "").trim(),
  queryRunMode: (els.runMode ? els.runMode.value : "normal").trim() || "normal",
  talepType: (els.talepType ? els.talepType.value : "masrafAvansIadesi").trim() || "masrafAvansIadesi",
  talepIbanNo: (els.talepIbanNo ? els.talepIbanNo.value : DEFAULT_SETTINGS.talepIbanNo || "TR620001009010684338705009").trim() || DEFAULT_SETTINGS.talepIbanNo || "TR620001009010684338705009",
  datedFrom: (els.datedFrom ? els.datedFrom.value : "").trim(),
  datedTo: (els.datedTo ? els.datedTo.value : "").trim()
});

const loadBirimLookup = () => (birimLookupService ? birimLookupService.load() : Promise.resolve(new Map()));
const applyBirimLookup = (rows, birimMap, settings) =>
  birimLookupService
    ? birimLookupService.apply(rows, birimMap, settings)
    : { inputs: Array.isArray(rows) ? rows : [], unresolved: 0, unresolvedRows: [] };

const setSettingsToForm = (settings) => {
  els.firstEndpointPath.value = settings.firstEndpointPath || DEFAULT_SETTINGS.firstEndpointPath;
  els.firstMethod.value = settings.firstMethod || DEFAULT_SETTINGS.firstMethod;
  els.firstHeadersText.value = settings.firstHeadersText || DEFAULT_SETTINGS.firstHeadersText;
  els.firstBodyTemplate.value = settings.firstBodyTemplate || DEFAULT_SETTINGS.firstBodyTemplate;
  els.secondEndpointPath.value = settings.secondEndpointPath || DEFAULT_SETTINGS.secondEndpointPath;
  els.secondMethod.value = settings.secondMethod || DEFAULT_SETTINGS.secondMethod;
  els.secondHeadersText.value = settings.secondHeadersText || DEFAULT_SETTINGS.secondHeadersText;
  els.secondBodyTemplate.value = settings.secondBodyTemplate || DEFAULT_SETTINGS.secondBodyTemplate;
  if (els.defaultBirimId) {
    els.defaultBirimId.value = settings.defaultBirimId || DEFAULT_SETTINGS.defaultBirimId;
  }
  if (els.defaultBirimAdi) {
    els.defaultBirimAdi.value = settings.defaultBirimAdi || DEFAULT_SETTINGS.defaultBirimAdi;
  }
  if (els.defaultDosyaDurum) {
    els.defaultDosyaDurum.value = settings.defaultDosyaDurum || DEFAULT_SETTINGS.defaultDosyaDurum;
  }
  if (els.dosyaHesabiOdemeTarihi) {
    els.dosyaHesabiOdemeTarihi.value = normalizeOdemeDateForUi(settings.dosyaHesabiOdemeTarihi || DEFAULT_SETTINGS.dosyaHesabiOdemeTarihi || "") || getTodayForDateInput();
  }
  if (els.dosyaHesabiHesapTuru) {
    els.dosyaHesabiHesapTuru.value = settings.dosyaHesabiHesapTuru || DEFAULT_SETTINGS.dosyaHesabiHesapTuru || "normal";
  }
  if (els.dosyaHesabiDosyaDurumKod) {
    els.dosyaHesabiDosyaDurumKod.value = String(settings.dosyaHesabiDosyaDurumKod || DEFAULT_SETTINGS.dosyaHesabiDosyaDurumKod || "0") === "1" ? "1" : "0";
  }
  syncDosyaHesapTuruVisibility(els);
  if (els.dosyaHesabiIndirimTutari) {
    els.dosyaHesabiIndirimTutari.value = settings.dosyaHesabiIndirimTutari || DEFAULT_SETTINGS.dosyaHesabiIndirimTutari || "";
  }
  if (els.faizOranDusuk) {
    els.faizOranDusuk.value = settings.faizOranDusuk || DEFAULT_SETTINGS.faizOranDusuk || "0.09";
  }
  if (els.faizOranYuksek) {
    els.faizOranYuksek.value = settings.faizOranYuksek || DEFAULT_SETTINGS.faizOranYuksek || "0.24";
  }
  if (els.faizBolunmeTarihi) {
    els.faizBolunmeTarihi.value = settings.faizBolunmeTarihi || DEFAULT_SETTINGS.faizBolunmeTarihi || "2024-06-01";
  }
  if (els.datedFilter) {
    els.datedFilter.value = settings.datedFilter || DEFAULT_SETTINGS.datedFilter || "thisMonth";
  }
  if (els.runMode) {
    els.runMode.value = settings.queryRunMode || DEFAULT_SETTINGS.queryRunMode || "normal";
  }
  if (els.kalanQueryAmount) {
    els.kalanQueryAmount.value = settings.kalanQueryAmount || DEFAULT_SETTINGS.kalanQueryAmount || "";
  }
  if (els.talepType) {
    els.talepType.value = settings.talepType || DEFAULT_SETTINGS.talepType || "masrafAvansIadesi";
  }
  if (els.talepIbanNo) {
    els.talepIbanNo.value = settings.talepIbanNo || DEFAULT_SETTINGS.talepIbanNo || "TR620001009010684338705009";
  }
  if (els.datedFrom) {
    els.datedFrom.value = settings.datedFrom || DEFAULT_SETTINGS.datedFrom || "";
  }
  if (els.datedTo) {
    els.datedTo.value = settings.datedTo || DEFAULT_SETTINGS.datedTo || "";
  }
  syncDatedFilterVisibility(els);
  syncTalepButtonText();
  syncTalepIbanVisibility();
};

const getEffectiveMode = (resultObj, modeOverride) =>
  String(modeOverride || (resultObj && resultObj.runMode) || currentRunMode || RUN_MODES.NORMAL);

const renderResults = (resultObj, modeOverride) => {
  lastResult = resultObj || null;
  const mode = getEffectiveMode(resultObj, modeOverride);

  if (!resultObj || !Array.isArray(resultObj.items) || resultObj.items.length === 0) {
    setMatched([]);
    return;
  }

  const matchedRows = getMatchedRowsForMode(resultObj.items, mode, "result");
  if (isYatanParaMode(mode)) {
    resetStableMatchedRows();
    for (const row of matchedRows) {
      const key = String(row || "").trim();
      if (!key || stableMatchedSet.has(key)) {
        continue;
      }
      stableMatchedSet.add(key);
      stableMatchedRows.push(row);
    }
    setMatched(stableMatchedRows.slice());
  } else {
    setMatched(matchedRows);
  }
  persistLiveView();
};

const renderProgress = (progress, modeOverride) => {
  if (!progress) {
    return;
  }

  updateProgressBar(Number(progress.processed) || 0, Number(progress.total) || 0);

  const matched = Array.isArray(progress.matched) ? progress.matched : [];
  const hasTebligRows = matched.some(
    (x) =>
      x &&
      ((typeof x.tebligTarihi === "string" && x.tebligTarihi.trim()) ||
        (Array.isArray(x.tebligDetaylari) && x.tebligDetaylari.some((d) => d && d.tebligTarihi)))
  );
  const mode = String(modeOverride || progress.runMode || currentRunMode || (hasTebligRows ? RUN_MODES.KESINLESTIRME : RUN_MODES.NORMAL));
  const rows = getMatchedRowsForMode(matched, mode, "progress");
  const rowsToRender = mergeStableMatchedRows(rows, mode);
  setMatched(rowsToRender);
  setStatus(isProgressCompleted(progress) ? getProgressCompletionStatus(progress) : formatRunStatus(progress));
  persistLiveView();
};

const saveConfig = (done) => {
  const settings = getSettingsFromForm();
  const inputText = els.inputs.value;

  chrome.storage.local.set({ runnerSettings: settings, runnerInputText: inputText }, () => {
    if (chrome.runtime.lastError) {
      setStatus(`Kayıt hatası: ${chrome.runtime.lastError.message}`, true);
      return;
    }
    if (typeof done === "function") {
      done({ settings, inputText });
    } else {
      setStatus("Ayarlar kaydedildi.");
    }
  });
};

const saveConfigSilent = () => {
  const settings = getSettingsFromForm();
  chrome.storage.local.set({ runnerSettings: settings, runnerInputText: els.inputs.value });
};

const scheduleAutoSave = () => {
  if (autoSaveTimer) {
    clearTimeout(autoSaveTimer);
  }
  autoSaveTimer = setTimeout(() => {
    saveConfigSilent();
  }, 300);
};

const isInjectableUrl = (url) => /^https?:\/\//i.test(String(url || ""));

const getActiveTab = (cb) => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (chrome.runtime.lastError) {
      setStatus(`Tab hatası: ${chrome.runtime.lastError.message}`, true);
      return;
    }

    const tab = tabs && tabs[0] ? tabs[0] : null;
    if (!tab || !tab.id) {
      setStatus("Aktif tab bulunamadı.", true);
      return;
    }

    if (!isInjectableUrl(tab.url)) {
      setStatus("Bu sayfada çalışmaz. Hedef sitede http/https bir sekme aç.", true);
      return;
    }

    cb(tab);
  });
};

const sendRunMessage = (tabId, payload, cb) => {
  chrome.tabs.sendMessage(tabId, payload, (response) => {
    const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : null;
    cb({ err, response });
  });
};

const ensureContentScriptAndSend = (tabId, payload, cb) => {
  
  chrome.scripting.executeScript(
    {
      target: { tabId },
      files: ["src/content/content-script.js"]
    },
    () => {
      if (chrome.runtime.lastError) {
        cb({ err: chrome.runtime.lastError.message, response: null });
        return;
      }
      sendRunMessage(tabId, payload, cb);
    }
  );
};

const setRunUiState = (running) => {
  const wasRunning = isRunning;
  isRunning = running;
  if (els.runBtn) {
    els.runBtn.disabled = running;
  }
  if (els.dosyaRunBtn) {
    els.dosyaRunBtn.disabled = running;
  }
  if (els.talepRunBtn) {
    els.talepRunBtn.disabled = running;
  }
  if (els.talepType) {
    els.talepType.disabled = running;
  }
  if (els.talepIbanNo) {
    els.talepIbanNo.disabled = running;
  }
  if (els.runMode) {
    els.runMode.disabled = running;
  }
  if (els.tabQuery) {
    els.tabQuery.disabled = running;
  }
  if (els.tabDosya) {
    els.tabDosya.disabled = running;
  }
  if (els.tabTalep) {
    els.tabTalep.disabled = running;
  }
  if (hacizEls.tabHaciz) {
    hacizEls.tabHaciz.disabled = running;
  }
  if (hacizEls.hacizRunBtn) {
    hacizEls.hacizRunBtn.disabled = running;
  }
  updateStopResumeButton();

  if (running) {
    if (!wasRunning) {
      updateProgressBar(0, 0);
    }
    if (!progressSyncTimer) {
      progressSyncTimer = setInterval(() => {
        chrome.storage.local.get({ runnerProgress: null }, ({ runnerProgress }) => {
          if (!runnerProgress || !runnerProgress.progress) {
            return;
          }
          if (activeRequestId && runnerProgress.requestId && runnerProgress.requestId !== activeRequestId) {
            return;
          }
          if (!activeRequestId && runnerProgress.requestId) {
            activeRequestId = runnerProgress.requestId;
          }
          const mode = String(runnerProgress.progress.runMode || currentRunMode || "normal");
          currentRunMode = mode;
          setActivePanel(getPanelForRunMode(mode));
          renderProgress(runnerProgress.progress, mode);
          if (isProgressCompleted(runnerProgress.progress)) {
            setRunUiState(false);
            activeRequestId = null;
            refreshResumeStates();
          }
        });
      }, 1000);
    }
  } else if (progressSyncTimer) {
    clearInterval(progressSyncTimer);
    progressSyncTimer = null;
  }
  updateStopResumeButton();
};

els.saveBtn.addEventListener("click", () => {
  saveConfig();
});

els.exportBtn.addEventListener("click", () => {
  if (currentUiPanel === "haciz") {
    chrome.storage.local.get({ runnerHacizResults: null }, ({ runnerHacizResults }) => {
      const items = (runnerHacizResults && Array.isArray(runnerHacizResults.items)) ? runnerHacizResults.items : [];
      const talepResults = (runnerHacizResults && Array.isArray(runnerHacizResults.talepResults)) ? runnerHacizResults.talepResults : [];
      const exportData = typeof HacizUtils.getHacizExportRows === "function"
        ? HacizUtils.getHacizExportRows(items, talepResults)
        : { aracRows: [], bankaRows: [], takbisRows: [], talepRows: [] };
      const totalRows = exportData.aracRows.length + exportData.bankaRows.length + (exportData.takbisRows ? exportData.takbisRows.length : 0) + exportData.talepRows.length;
      if (totalRows === 0) {
        setHacizStatus("Aktarılacak kayıt yok.", true);
        return;
      }
      if (typeof HacizUtils.downloadHacizXlsx === "function") {
        HacizUtils.downloadHacizXlsx(exportData);
      } else if (typeof HacizUtils.downloadHacizCsv === "function") {
        HacizUtils.downloadHacizCsv(exportData);
      }
      const tkLen = exportData.takbisRows ? exportData.takbisRows.length : 0;
      setHacizStatus(`${totalRows} kayıt dışa aktarıldı (${exportData.aracRows.length} araç, ${exportData.bankaRows.length} banka, ${tkLen} takbis, ${exportData.talepRows.length} talep).`);
    });
    return;
  }

  const tryExport = (resultObj, fallbackMode) => {
    const mode = getEffectiveMode(resultObj, fallbackMode || currentRunMode);
    const data = getExportData(resultObj, mode);
    if (!data.rows || data.rows.length === 0) {
      setStatus("Aktarılacak kayıt yok.", true);
      return false;
    }
    downloadExcelXlsx(data.header, data.rows, data.mode);
    setStatus(`${data.rows.length} kayıt Excel formatında dışa aktarıldı.`);
    return true;
  };

  if (tryExport(lastResult, currentRunMode)) {
    return;
  }

  chrome.storage.local.get({ runnerResults: null, runnerLiveView: null }, ({ runnerResults, runnerLiveView }) => {
    if (runnerResults && Array.isArray(runnerResults.items) && runnerResults.items.length > 0) {
      lastResult = runnerResults;
      tryExport(runnerResults, runnerResults.runMode || currentRunMode);
      return;
    }

    if (runnerLiveView && Array.isArray(runnerLiveView.rows) && runnerLiveView.rows.length > 0) {
      setStatus("Görünen satırlar var ama dışa aktarılabilir ham sonuç bulunamadı. Hesabı yeniden çalıştırıp tekrar deneyin.", true);
      return;
    }

    setStatus("Aktarılacak kayıt yok.", true);
  });
});

const startRun = (runMode) => {
  if (isRunning) {
    return;
  }
  currentRunMode = String(runMode || "normal");

  saveConfig(({ settings, inputText }) => {
    const rawRows = parseRowsFromInput(inputText, settings);
    if (rawRows.length === 0) {
      setStatus("Geçerli girdi yok. Format: birimAdi TAB dosyaNo", true);
      return;
    }
    if (currentRunMode === RUN_MODES.KALAN) {
      const threshold = Number(String(settings.kalanQueryAmount || "").replace(",", "."));
      if (!Number.isFinite(threshold) || threshold < 0) {
        setStatus("Kalan Sorgulama için geçerli bir tutar gir.", true);
        return;
      }
    }
    if (
      currentRunMode === RUN_MODES.TALEP_MASRAF_AVANS_IADESI
      || currentRunMode === RUN_MODES.TALEP_BORCLU_ODEME_AKTAR
      || currentRunMode === RUN_MODES.TALEP_EVRAKI_OLUSTUR
    ) {
      const iban = String(settings.talepIbanNo || DEFAULT_SETTINGS.talepIbanNo || "").replace(/\s+/g, "").toUpperCase();
      if (!/^TR\d{24}$/.test(iban)) {
        setStatus("Talep için geçerli bir IBAN gir.", true);
        return;
      }
    }

    loadBirimLookup().then((birimMap) => {
      const prepared = applyBirimLookup(rawRows, birimMap || new Map(), settings);
      unresolvedBirimRows = Array.isArray(prepared.unresolvedRows) ? prepared.unresolvedRows.slice(0, 200) : [];

  getActiveTab((tab) => {
    chrome.storage.local.set({
	      runnerLastRunPanel: getPanelForRunMode(currentRunMode),
      runnerResumeState: null
    });
    activeRequestId = null;
        resetStableMatchedRows();
        setMatched([]);
        setStatus("Çalışıyor...");
        persistLiveView();
        setRunUiState(true);
        setStatus(
          prepared.unresolved > 0
            ? `Çalışıyor... ${prepared.unresolved} birim eşleşmedi (varsayılan kullanıldı).`
            : "Çalışıyor..."
        );
        persistLiveView();

        ensureContentScriptAndSend(
          tab.id,
          {
            action: "runInPage",
            settings,
            inputs: prepared.inputs,
            runMode,
            enableBarcode: runMode === "kesinlestirme"
          },
          ({ err, response }) => {
            setRunUiState(false);
            activeRequestId = null;

            if (err) {
              setStatus(`İletişim hatası: ${err}`, true);
              return;
            }

            if (!response || !response.ok) {
              setStatus(`Çalıştırma hatası: ${response?.error || "Bilinmeyen hata"}`, true);
              return;
            }

            const r = response.result;
            const mode = getEffectiveMode(r, runMode);
            const statusText =
              mode === "kesinlestirme"
                ? (r.stopped
                    ? `Durduruldu. Eşleşen: ${r.matchCount}/${r.total}`
                    : `Tamamlandı. Eşleşen: ${r.matchCount}/${r.total}`)
                : (r.stopped
                    ? `Durduruldu. Eşleşen: ${r.matchCount}/${r.total}`
                    : `Tamamlandı. Eşleşen: ${r.matchCount}/${r.total}`);
            setStatus(statusText);
            chrome.storage.local.set({ runnerResults: r }, () => {
              renderResults(r, mode);
              persistLiveView();
              refreshResumeStates();
            });
          }
        );
      });
    });
  });
};

const continueQueryRun = () => {
  if (isRunning || !resumeQueryState || !Array.isArray(resumeQueryState.inputs) || resumeQueryState.inputs.length === 0) {
    return;
  }
  const checkpoint = resumeQueryState;
  currentRunMode = String(checkpoint.runMode || "normal");

  getActiveTab((tab) => {
    activeRequestId = null;
    setRunUiState(true);
    setStatus(
      checkpoint.lastProgress && checkpoint.lastProgress.activeInput
        ? `Devam ediliyor... Son durak: ${checkpoint.lastProgress.activeInput} / ${checkpoint.lastProgress.activeStepLabel || "bilinmiyor"}`
        : "Devam ediliyor..."
    );
    ensureContentScriptAndSend(
      tab.id,
      {
        action: "runInPage",
        settings: checkpoint.settings,
        inputs: checkpoint.inputs,
        runMode: checkpoint.runMode,
        enableBarcode: !!checkpoint.enableBarcode,
        resumeOriginalInputs: checkpoint.resumeOriginalInputs,
        resumeCompletedItems: checkpoint.resumeCompletedItems
      },
      ({ err, response }) => {
        setRunUiState(false);
        activeRequestId = null;

        if (err) {
          setStatus(`İletişim hatası: ${err}`, true);
          return;
        }
        if (!response || !response.ok) {
          setStatus(`Çalıştırma hatası: ${response?.error || "Bilinmeyen hata"}`, true);
          return;
        }

        const r = response.result || {};
        const completedItems = Array.isArray(checkpoint.resumeCompletedItems) ? checkpoint.resumeCompletedItems : [];
        const mergedItems = [...completedItems, ...(Array.isArray(r.items) ? r.items : [])];
        const mergedResult = {
          ...r,
          total: Array.isArray(checkpoint.resumeOriginalInputs) ? checkpoint.resumeOriginalInputs.length : (completedItems.length + (r.total || 0)),
          processed: mergedItems.length,
          successCount: mergedItems.filter((x) => x && x.success).length,
          matchCount: mergedItems.filter((x) => x && x.isMatch).length,
          barcodeCount: mergedItems.filter((x) => x && x.barcode).length,
          matchedInputs: mergedItems.filter((x) => x && x.isMatch).map((x) => x.input),
          items: mergedItems
        };
        const mode = getEffectiveMode(mergedResult, checkpoint.runMode);
        setStatus(mergedResult.stopped ? `Durduruldu. Eşleşen: ${mergedResult.matchCount}/${mergedResult.total}` : `Tamamlandı. Eşleşen: ${mergedResult.matchCount}/${mergedResult.total}`);
        chrome.storage.local.set({ runnerResults: mergedResult }, () => {
          renderResults(mergedResult, mode);
          persistLiveView();
          refreshResumeStates();
        });
      }
    );
  });
};

if (els.themeToggle) {
  els.themeToggle.addEventListener("click", toggleTheme);
}

if (els.helpBtn) {
  els.helpBtn.addEventListener("click", toggleDocs);
}
if (els.docsCloseBtn) {
  els.docsCloseBtn.addEventListener("click", closeDocs);
}

els.runBtn.addEventListener("click", () => {
  const mode = String(els.runMode && els.runMode.value ? els.runMode.value : "normal");
  startRun(mode);
});

if (els.runMode) {
  els.runMode.addEventListener("change", () => {
    syncDatedFilterVisibility(els);
    scheduleAutoSave();
  });
}

if (els.datedFilter) {
  els.datedFilter.addEventListener("change", () => {
    syncDatedFilterVisibility(els);
    scheduleAutoSave();
  });
}
if (els.kalanQueryAmount) {
  els.kalanQueryAmount.addEventListener("input", () => {
    scheduleAutoSave();
  });
}
if (els.dosyaHesabiHesapTuru) {
  els.dosyaHesabiHesapTuru.addEventListener("change", () => {
    syncDosyaHesapTuruVisibility(els);
    scheduleAutoSave();
  });
}


document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "hidden") {
    saveConfigSilent();
  }
});

if (els.dosyaRunBtn) {
  els.dosyaRunBtn.addEventListener("click", () => {
    startRun("dosyaHesabi");
  });
}

if (els.talepRunBtn) {
  els.talepRunBtn.addEventListener("click", () => {
    const talepType = String(els.talepType && els.talepType.value ? els.talepType.value : "masrafAvansIadesi");
    if (talepType === "talepEvrakiOlustur") {
      startRun(RUN_MODES.TALEP_EVRAKI_OLUSTUR);
      return;
    }
    if (talepType === "kesinlestirmeTalebi") {
      startRun(RUN_MODES.TALEP_KESINLESTIRME);
      return;
    }
    startRun(talepType === "borcluOdemeAktar" ? RUN_MODES.TALEP_BORCLU_ODEME_AKTAR : RUN_MODES.TALEP_MASRAF_AVANS_IADESI);
  });
}

if (els.talepType) {
  els.talepType.addEventListener("change", () => {
    syncTalepButtonText();
    syncTalepIbanVisibility();
    scheduleAutoSave();
  });
}

if (els.tabQuery) {
  els.tabQuery.addEventListener("click", () => setActivePanel("query"));
}
if (els.tabDosya) {
  els.tabDosya.addEventListener("click", () => setActivePanel("dosya"));
}
if (els.tabTalep) {
  els.tabTalep.addEventListener("click", () => setActivePanel("talep"));
}

if (els.dosyaTakipUploadBtn) {
  els.dosyaTakipUploadBtn.addEventListener("click", async () => {
    const file = els.dosyaTakipUpload && els.dosyaTakipUpload.files ? els.dosyaTakipUpload.files[0] : null;
    if (!file) {
      setStatus("Önce UDF/ZIP veya content.xml dosyası seç.", true);
      return;
    }
    if (!lastResult || !Array.isArray(lastResult.items) || lastResult.items.length === 0 || getEffectiveMode(lastResult, currentRunMode) !== RUN_MODES.DOSYA_HESABI) {
      setStatus("Önce Dosya Hesabı çalıştırıp sonucu oluştur.", true);
      return;
    }
    if (typeof PopupHesap.parseUpload !== "function" || typeof PopupHesap.mergeParsedIntoExistingResult !== "function") {
      setStatus("Takip evrakı parserı yüklenemedi.", true);
      return;
    }
    try {
      setStatus("Takip evrakı parse edilip sonuç güncelleniyor...");
      const payload = await PopupHesap.parseUpload(file);
      const merged = PopupHesap.mergeParsedIntoExistingResult(lastResult, payload, getSettingsFromForm());
      const parsedAsilAlacak = PopupHesap.numberOrNull ? PopupHesap.numberOrNull(payload?.parsed?.asilAlacak) : payload?.parsed?.asilAlacak;
      const parsedGecmisFaiz = PopupHesap.numberOrNull ? PopupHesap.numberOrNull(payload?.parsed?.gecmisGunFaizi) : payload?.parsed?.gecmisGunFaizi;
      currentRunMode = RUN_MODES.DOSYA_HESABI;
      chrome.storage.local.set({ runnerResults: merged }, () => {
        renderResults(merged, currentRunMode);
        persistLiveView();
        setStatus(
          `Takip evrakı uygulandı. Kaynak: ${payload.source} | Asıl Alacak: ${parsedAsilAlacak ?? "-"} | Geçmiş Gün Faizi: ${parsedGecmisFaiz ?? "-"}`
        );
      });
    } catch (error) {
      setStatus(`UDF yükleme hatası: ${error && error.message ? error.message : error}`, true);
    }
  });
}

els.stopBtn.addEventListener("click", () => {
  if (!isRunning && !hacizIsRunning) {
    if (currentUiPanel === "haciz" && resumeHacizState) {
      continueHacizRun();
      return;
    }
    if (currentUiPanel !== "haciz" && resumeQueryState) {
      continueQueryRun();
      return;
    }
  }
  if (currentUiPanel === "haciz") {
    if (!hacizIsRunning) { return; }
    getActiveTab((tab) => {
      ensureContentScriptAndSend(tab.id, { action: "stopHacizInPage" }, () => {
        setHacizStatus("Durdurma istendi...");
      });
    });
    return;
  }
  if (!isRunning) {
    return;
  }
  getActiveTab((tab) => {
    ensureContentScriptAndSend(
      tab.id,
      { action: "stopInPage" },
      () => {
        setStatus("Durdurma istendi...");
      }
    );
  });
});

els.clearBtn.addEventListener("click", () => {
  resetDosyaHesabiOdemeTarihi();
  scheduleAutoSave();
  chrome.storage.local.set({
    runnerHacizResults: null,
    runnerHacizProgress: null,
    runnerHacizResumeState: null,
    hacizQueryCache: null,
    runnerResults: null,
    runnerProgress: null,
    runnerResumeState: null,
    runnerLiveView: null,
    runnerLastRunPanel: null
  }, () => {
    resumeQueryState = null;
    resumeHacizState = null;
    resetStableMatchedRows();
    setHacizMatched(null);
    renderResults(null);
    setHacizRunUiState(false);
    setRunUiState(false);
    hideProgressBar();
    if (currentUiPanel === "haciz") {
      setHacizStatus("Sonuçlar temizlendi.");
    } else {
      setStatus("Sonuçlar temizlendi.");
    }
    updateStopResumeButton();
  });
});


// ═══════════════════════════════════════════════════════════════════════════════
// HACIZ MODULE
// ═══════════════════════════════════════════════════════════════════════════════

const setHacizStatus = (text, isError = false) => {
  els.status.textContent = text;
  els.status.style.color = isError ? "#a02929" : "#205521";
};

const setHacizMatched = (rows) => {
  if (!els.matched) {
    return;
  }
  if (!Array.isArray(rows) || rows.length === 0) {
    els.matched.textContent = "Sonuç bulunamadı.";
    return;
  }
  els.matched.innerHTML = rows.join("<br>");
};

const isHacizProgressCompleted = (progress) => {
  if (!progress) {
    return false;
  }
  if (progress.stopped === true) {
    return true;
  }
  const total     = Number(progress.total);
  const processed = Number(progress.processed);
  return Number.isFinite(total) && Number.isFinite(processed) && total > 0 && processed >= total;
};

const renderHacizProgress = (progress) => {
  if (!progress) {
    return;
  }

  const activeQueryLabel = String(progress.activeQueryLabel || "");
  const activeQueryDosyaNo = String(progress.activeQueryDosyaNo || "");
  const activeQueryKisi = String(progress.activeQueryKisi || "");
  const activeQueryStartedAt = Number(progress.activeQueryStartedAt || 0);
  const pendingTakbisCount = Number(progress.pendingTakbisCount || 0);
  const isWaitingSlow =
    activeQueryLabel &&
    activeQueryStartedAt > 0 &&
    Date.now() - activeQueryStartedAt >= 5000;
  const waitingText = isWaitingSlow
    ? `${activeQueryLabel} için yanıt bekleniyor${activeQueryDosyaNo ? ` (${activeQueryDosyaNo})` : ""}${activeQueryKisi ? ` - ${activeQueryKisi}` : ""}...`
    : "";
  const pendingTakbisText =
    !waitingText && pendingTakbisCount > 0
      ? `Takbis için yanıt bekleniyor... (${pendingTakbisCount})`
      : "";

  updateProgressBar(Number(progress.processed) || 0, Number(progress.total) || 0);

  // Birleşik sorgu + talep aşaması
  if (progress.phase === "full") {
    const matched = Array.isArray(progress.matched) ? progress.matched : [];
    const talepResults = Array.isArray(progress.talepResults) ? progress.talepResults : [];
    const talepRows = talepResults.length > 0 && typeof HacizUtils.getTalepResultRows === "function"
      ? HacizUtils.getTalepResultRows(talepResults)
      : [];
    const queryRows = typeof HacizUtils.getHacizMatchedRows === "function"
      ? HacizUtils.getHacizMatchedRows(matched, "progress")
      : [];
    const allRows = [...talepRows, ...queryRows];
    setHacizMatched(allRows.length > 0 ? allRows : null);

    if (isHacizProgressCompleted(progress)) {
      const ts = Number(progress.talepSuccess) || 0;
      const tp = Number(progress.talepProcessed) || 0;
      setHacizStatus(
        progress.stopped
          ? `Durduruldu. Eşleşen: ${progress.matchCount}/${progress.total} | Talep: ${ts}/${tp}`
          : `Tamamlandı. Eşleşen: ${progress.matchCount}/${progress.total} | Talep: ${ts}/${tp}`
      );
    } else {
      const tp = Number(progress.talepProcessed) || 0;
      setHacizStatus(
        waitingText || pendingTakbisText || `Çalışıyor... ${progress.processed}/${progress.total} | Eşleşen: ${progress.matchCount} | Talep: ${tp}`
      );
    }
    return;
  }

  // Talep gönderme aşaması (eski uyumluluk)
  if (progress.phase === "talep") {
    const talepRows = Array.isArray(progress.talepResults) && typeof HacizUtils.getTalepResultRows === "function"
      ? HacizUtils.getTalepResultRows(progress.talepResults)
      : [];
    setHacizMatched(talepRows.length > 0 ? talepRows : null);

    if (isHacizProgressCompleted(progress)) {
      setHacizStatus(
        progress.stopped
          ? `Durduruldu. Başarılı: ${progress.matchCount}/${progress.total}`
          : `Talepler gönderildi. Başarılı: ${progress.matchCount}/${progress.total}`
      );
    } else {
      setHacizStatus(waitingText || `Talep gönderiliyor... ${progress.processed}/${progress.total} | Başarılı: ${progress.matchCount}`);
    }
    return;
  }

  const matched = Array.isArray(progress.matched) ? progress.matched : [];
  const rows = typeof HacizUtils.getHacizMatchedRows === "function"
    ? HacizUtils.getHacizMatchedRows(matched, "progress")
    : [];
  setHacizMatched(rows.length > 0 ? rows : null);
  if (isHacizProgressCompleted(progress)) {
    setHacizStatus(
      progress.stopped
        ? `Durduruldu. Eşleşen: ${progress.matchCount}/${progress.total}`
        : `Tamamlandı. Eşleşen: ${progress.matchCount}/${progress.total}`
    );
  } else {
    setHacizStatus(
      waitingText || (typeof HacizUtils.formatHacizRunStatus === "function"
        ? HacizUtils.formatHacizRunStatus(progress)
        : `Çalışıyor... ${progress.processed}/${progress.total}`)
    );
  }
};

const renderHacizResults = (resultObj) => {
  const items = (resultObj && Array.isArray(resultObj.items)) ? resultObj.items : [];
  if (items.length === 0) {
    setHacizMatched(null);
    return;
  }
  const talepResults = Array.isArray(resultObj.talepResults) ? resultObj.talepResults : [];
  const talepRows = talepResults.length > 0 && typeof HacizUtils.getTalepResultRows === "function"
    ? HacizUtils.getTalepResultRows(talepResults)
    : [];
  const queryRows = typeof HacizUtils.getHacizMatchedRows === "function"
    ? HacizUtils.getHacizMatchedRows(items, "result")
    : [];
  const allRows = [...talepRows, ...queryRows];
  setHacizMatched(allRows.length > 0 ? allRows : null);
};

const setHacizRunUiState = (running) => {
  const wasRunning = hacizIsRunning;
  hacizIsRunning = running;
  if (hacizEls.hacizRunBtn)  { hacizEls.hacizRunBtn.disabled  =  running; }
  if (els.tabQuery)          { els.tabQuery.disabled           =  running; }
  if (els.tabDosya)          { els.tabDosya.disabled           =  running; }
  if (els.tabTalep)          { els.tabTalep.disabled           =  running; }
  if (hacizEls.tabHaciz)     { hacizEls.tabHaciz.disabled      =  running; }
  if (els.runBtn)            { els.runBtn.disabled             =  running; }
  if (els.dosyaRunBtn)       { els.dosyaRunBtn.disabled        =  running; }
  if (els.talepRunBtn)       { els.talepRunBtn.disabled        =  running; }
  updateStopResumeButton();

  if (running) {
    if (!wasRunning) {
      updateProgressBar(0, 0);
    }
    if (!hacizProgressSyncTimer) {
      hacizProgressSyncTimer = setInterval(() => {
        chrome.storage.local.get({ runnerHacizProgress: null, runnerHacizResults: null }, ({ runnerHacizProgress, runnerHacizResults }) => {
          // Final sonuçlar geldiyse (iş tamamen bitti) — render et ve polling'i durdur
          if (runnerHacizResults) {
            setHacizRunUiState(false);
            activeHacizRequestId = null;
            renderHacizResults(runnerHacizResults);
            const t = runnerHacizResults;
            const ts = Number(t.talepSuccess) || 0;
            const tp = Number(t.talepProcessed) || 0;
            setHacizStatus(
              t.stopped
                ? `Durduruldu. Eşleşen: ${t.matchCount || 0}/${t.total || 0} | Talep: ${ts}/${tp}`
                : `Tamamlandı. Eşleşen: ${t.matchCount || 0}/${t.total || 0} | Talep: ${ts}/${tp}`
            );
            refreshResumeStates();
            return;
          }
          if (!runnerHacizProgress || !runnerHacizProgress.progress) {
            return;
          }
          if (activeHacizRequestId && runnerHacizProgress.requestId && runnerHacizProgress.requestId !== activeHacizRequestId) {
            return;
          }
          if (!activeHacizRequestId && runnerHacizProgress.requestId) {
            activeHacizRequestId = runnerHacizProgress.requestId;
          }
          renderHacizProgress(runnerHacizProgress.progress);
        });
      }, 1000);
    }
  } else if (hacizProgressSyncTimer) {
    clearInterval(hacizProgressSyncTimer);
    hacizProgressSyncTimer = null;
  }
  updateStopResumeButton();
};

const startHacizRun = () => {
  if (hacizIsRunning || isRunning) {
    return;
  }

  const hacizModes = [];
  if (hacizEls.hacizTypeArac   && hacizEls.hacizTypeArac.checked)   { hacizModes.push("arac"); }
  if (hacizEls.hacizTypeBanka  && hacizEls.hacizTypeBanka.checked)  { hacizModes.push("banka"); }
  if (hacizEls.hacizTypeTakbis && hacizEls.hacizTypeTakbis.checked) { hacizModes.push("takbis"); }
  if (hacizEls.hacizTypeIcraDosyasi && hacizEls.hacizTypeIcraDosyasi.checked) { hacizModes.push("icraDosyasi"); }
  if (hacizModes.length === 0) {
    setHacizStatus("En az bir haciz türü seçin.", true);
    return;
  }

  saveConfig(({ settings, inputText }) => {
    const rawRows = parseRowsFromInput(inputText, settings);
    if (rawRows.length === 0) {
      setHacizStatus("Geçerli girdi yok. Format: birimAdi TAB dosyaNo", true);
      return;
    }

    // Banka sorgusu için paramları, talep için tam datayı yükle
    const loadBankaParams = hacizModes.includes("banka")
      ? fetch(chrome.runtime.getURL("assets/data/banka_haciz_params.json"))
          .then((r) => r.json())
          .then((data) => (Array.isArray(data) && Array.isArray(data[0]) ? data[0] : []))
          .catch(() => [])
      : Promise.resolve([]);

    const loadBankaData = fetch(chrome.runtime.getURL("assets/data/banka_haciz_params.json"))
      .then((r) => r.json())
      .catch(() => []);

    Promise.all([loadBirimLookup(), loadBankaParams, loadBankaData]).then(([birimMap, bankaParams, bankaHacizData]) => {
      const prepared = applyBirimLookup(rawRows, birimMap || new Map(), settings);

      const hacizSettings = {
        ...settings,
        hacizModes,
        bankaHacizParams: bankaParams
      };

      getActiveTab((tab) => {
        chrome.storage.local.set({
          runnerLastRunPanel: "haciz",
          runnerHacizResumeState: null
        });
        activeHacizRequestId = null;
        setHacizMatched(null);
        chrome.storage.local.set({
          runnerHacizResults: null,
          runnerHacizProgress: null,
          runnerResults: null,
          runnerProgress: null,
          runnerLiveView: null,
          runnerActivePanel: "haciz"
        });
        setHacizStatus("Çalışıyor...");
        setHacizRunUiState(true);
        ensureContentScriptAndSend(
          tab.id,
          {
            action:         "runHacizFullInPage",
            settings:       hacizSettings,
            inputs:         prepared.inputs,
            bankaHacizData: Array.isArray(bankaHacizData) ? bankaHacizData : []
          },
          ({ err, response }) => {
            if (err) {
              setHacizRunUiState(false);
              activeHacizRequestId = null;
              setHacizStatus(`İletişim hatası: ${err}`, true);
              return;
            }
            if (!response || !response.ok) {
              setHacizRunUiState(false);
              activeHacizRequestId = null;
              setHacizStatus(`Hata: ${response?.error || "Bilinmeyen hata"}`, true);
              return;
            }
            // İşlem başlatıldı — sonuçlar progress polling ile gelecek
            if (response.requestId) {
              activeHacizRequestId = response.requestId;
            }
            setHacizStatus("Çalışıyor...");
          }
        );
      });
    });
  });
};

const continueHacizRun = () => {
  if (hacizIsRunning || isRunning || !resumeHacizState) {
    return;
  }
  const checkpoint = resumeHacizState;
  getActiveTab((tab) => {
    chrome.storage.local.set({ runnerLastRunPanel: "haciz", runnerActivePanel: "haciz" });
    activeHacizRequestId = null;
    setActivePanel("haciz");
    setHacizRunUiState(true);
    setHacizStatus(
      checkpoint.lastProgress && checkpoint.lastProgress.activeQueryDosyaNo
        ? `Devam ediliyor... Son durak: ${checkpoint.lastProgress.activeQueryDosyaNo} / ${checkpoint.lastProgress.activeQueryLabel || "bilinmiyor"}`
        : "Devam ediliyor..."
    );
    ensureContentScriptAndSend(
      tab.id,
      {
        action: "runHacizFullInPage",
        settings: checkpoint.settings,
        inputs: checkpoint.inputs,
        bankaHacizData: Array.isArray(checkpoint.bankaHacizData) ? checkpoint.bankaHacizData : []
      },
      ({ err, response }) => {
        if (err) {
          setHacizRunUiState(false);
          activeHacizRequestId = null;
          setHacizStatus(`İletişim hatası: ${err}`, true);
          return;
        }
        if (!response || !response.ok) {
          setHacizRunUiState(false);
          activeHacizRequestId = null;
          setHacizStatus(`Hata: ${response?.error || "Bilinmeyen hata"}`, true);
          return;
        }
        if (response.requestId) {
          activeHacizRequestId = response.requestId;
        }
        setHacizStatus("Devam ediliyor...");
      }
    );
  });
};

if (hacizEls.hacizRunBtn) {
  hacizEls.hacizRunBtn.addEventListener("click", startHacizRun);
}

if (hacizEls.tabHaciz) {
  hacizEls.tabHaciz.addEventListener("click", () => setActivePanel("haciz"));
}

if (els.updateNoticeClose) {
  els.updateNoticeClose.addEventListener("click", dismissUpdateNotice);
}

// ═══════════════════════════════════════════════════════════════════════════════


const load = () => {
  chrome.storage.local.get({ runnerSettings: DEFAULT_SETTINGS, runnerInputText: "", runnerUiTheme: "auto", runnerResumeState: null, runnerHacizResumeState: null }, (data) => {
    const settings = { ...DEFAULT_SETTINGS, ...(data.runnerSettings || {}) };
    setSettingsToForm(settings);
    currentRunMode = String(settings.queryRunMode || currentRunMode || "normal");
    els.inputs.value = data.runnerInputText || "";
    lastObservedInputText = els.inputs.value;
    resumeQueryState = data.runnerResumeState || null;
    resumeHacizState = data.runnerHacizResumeState || null;
    updateRowCount();
    applyTheme(String(data.runnerUiTheme || "auto"));
    updateStopResumeButton();
  });

  chrome.storage.local.get(
    {
      runnerResults: null,
      runnerProgress: null,
      runnerLiveView: null,
      runnerHacizProgress: null,
      runnerHacizResults: null,
      runnerLastRunPanel: null,
      runnerResumeState: null,
      runnerHacizResumeState: null
    },
    ({ runnerResults, runnerProgress, runnerLiveView, runnerHacizProgress, runnerHacizResults, runnerLastRunPanel, runnerResumeState, runnerHacizResumeState }) => {
      resumeQueryState = runnerResumeState || null;
      resumeHacizState = runnerHacizResumeState || null;
      updateStopResumeButton();
      const preferredPanel = runnerLastRunPanel || null;
      const hasHacizProgress = !!(runnerHacizProgress && runnerHacizProgress.progress);
      const hasHacizResults = !!(runnerHacizResults && Array.isArray(runnerHacizResults.items) && runnerHacizResults.items.length > 0);

      if (preferredPanel === "haciz" && hasHacizProgress) {
        activeHacizRequestId = runnerHacizProgress.requestId || null;
        setHacizRunUiState(true);
        setActivePanel("haciz");
        renderHacizProgress(runnerHacizProgress.progress);
        return;
      }

      if (preferredPanel === "haciz" && hasHacizResults) {
        setActivePanel("haciz");
        renderHacizResults(runnerHacizResults);
        const ts = Number(runnerHacizResults?.talepSuccess) || 0;
        const tp = Number(runnerHacizResults?.talepProcessed) || 0;
        setHacizStatus(
          runnerHacizResults?.stopped
            ? `Durduruldu. Eşleşen: ${runnerHacizResults?.matchCount || 0}/${runnerHacizResults?.total || 0} | Talep: ${ts}/${tp}`
            : `Tamamlandı. Eşleşen: ${runnerHacizResults?.matchCount || 0}/${runnerHacizResults?.total || 0} | Talep: ${ts}/${tp}`
        );
        return;
      }

      if (runnerLiveView && Array.isArray(runnerLiveView.rows) && runnerLiveView.rows.length > 0) {
        currentRunMode = String(runnerLiveView.runMode || currentRunMode);
        if (isYatanParaMode(currentRunMode)) {
          resetStableMatchedRows();
          for (const row of runnerLiveView.rows) {
            const key = String(row || "").trim();
            if (!key || stableMatchedSet.has(key)) {
              continue;
            }
            stableMatchedSet.add(key);
            stableMatchedRows.push(row);
          }
        }
        if (els.runMode && currentRunMode !== RUN_MODES.DOSYA_HESABI && currentRunMode !== RUN_MODES.TALEP_MASRAF_AVANS_IADESI && currentRunMode !== RUN_MODES.TALEP_BORCLU_ODEME_AKTAR && currentRunMode !== RUN_MODES.TALEP_KESINLESTIRME && currentRunMode !== RUN_MODES.TALEP_EVRAKI_OLUSTUR) {
          els.runMode.value = currentRunMode;
          syncDatedFilterVisibility(els);
        }
        setMatched(runnerLiveView.rows);
        if (runnerLiveView.status) {
          setStatus(String(runnerLiveView.status));
        }
      }

      if (runnerProgress && runnerProgress.progress) {
        activeRequestId = runnerProgress.requestId || null;
        currentRunMode = String(runnerProgress.progress.runMode || currentRunMode || "normal");
        setRunUiState(true);
        setActivePanel(getPanelForRunMode(currentRunMode));
        renderProgress(runnerProgress.progress, currentRunMode);
        return;
      }
      if (preferredPanel === "haciz" && resumeHacizState) {
        setActivePanel("haciz");
        setHacizStatus(getHacizResumeStatusText(resumeHacizState));
        return;
      }
      if (resumeQueryState) {
        currentRunMode = String(resumeQueryState.runMode || currentRunMode || RUN_MODES.NORMAL);
        setActivePanel(getPanelForRunMode(currentRunMode));
        setStatus(getQueryResumeStatusText(resumeQueryState));
      }
      const resultMode = runnerResults && runnerResults.runMode ? String(runnerResults.runMode) : currentRunMode;
      setActivePanel(getPanelForRunMode(currentRunMode));
      renderResults(runnerResults, resultMode);
    }
  );
};

chrome.runtime.onMessage.addListener((message) => {
  if (!message || message.action !== "runnerProgress") {
    return;
  }
  if (activeRequestId && message.requestId && message.requestId !== activeRequestId) {
    return;
  }
  if (!activeRequestId && message.requestId) {
    activeRequestId = message.requestId;
  }
  const progress = message.progress || null;
  const mode = String((progress && progress.runMode) || currentRunMode || "normal");
  currentRunMode = mode;
  setActivePanel(getPanelForRunMode(mode));
  renderProgress(progress, mode);
  if (isProgressCompleted(progress)) {
    setRunUiState(false);
    activeRequestId = null;
    refreshResumeStates();
  } else {
    setRunUiState(true);
  }
});

[
  els.inputs,
  els.firstEndpointPath,
  els.firstMethod,
  els.firstHeadersText,
  els.firstBodyTemplate,
  els.secondEndpointPath,
  els.secondMethod,
  els.secondHeadersText,
  els.secondBodyTemplate,
  els.defaultBirimId,
  els.defaultBirimAdi,
  els.dosyaHesabiOdemeTarihi,
  els.dosyaHesabiHesapTuru,
  els.dosyaHesabiDosyaDurumKod,
  els.dosyaHesabiIndirimTutari,
  els.talepType,
  els.talepIbanNo,
  els.datedFilter,
  els.datedFrom,
  els.datedTo,
  els.defaultDosyaDurum
].forEach((el) => {
  if (el) {
    el.addEventListener("input", scheduleAutoSave);
    el.addEventListener("change", scheduleAutoSave);
  }
});

load();
checkForUpdatesOncePerDay();
chrome.storage.local.get(
  { runnerActivePanel: "query", runnerLastRunPanel: null, runnerHacizResults: null, runnerHacizProgress: null, runnerResults: null, runnerProgress: null },
  ({ runnerActivePanel, runnerLastRunPanel, runnerHacizResults, runnerHacizProgress, runnerResults, runnerProgress }) => {
    if (hacizIsRunning || isRunning) {
      return;
    }
    if (runnerLastRunPanel === "haciz" && (runnerHacizResults || runnerHacizProgress)) {
      setActivePanel("haciz");
      return;
    }
    if (runnerProgress && runnerProgress.progress) {
      const mode = String(runnerProgress.progress.runMode || currentRunMode || "normal");
      setActivePanel(getPanelForRunMode(mode));
      return;
    }
    if (runnerResults) {
      const mode = String(runnerResults.runMode || currentRunMode || "normal");
      setActivePanel(getPanelForRunMode(mode));
      return;
    }
    setActivePanel(runnerActivePanel || "query");
  }
);
syncDatedFilterVisibility(els);
syncDosyaHesapTuruVisibility(els);
setRunUiState(false);
setHacizRunUiState(false);
hideProgressBar();
applyTheme("auto");
updateRowCount();
if (els.inputs) {
  els.inputs.addEventListener("input", () => {
    updateRowCount();
    const currentInputText = els.inputs.value;
    if (currentInputText !== lastObservedInputText) {
      lastObservedInputText = currentInputText;
      resetDosyaHesabiOdemeTarihi();
      scheduleAutoSave();
    }
  });
}

const footerYearEl = document.getElementById("currentYear");
if (footerYearEl) {
  footerYearEl.textContent = String(new Date().getFullYear());
}

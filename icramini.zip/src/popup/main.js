(function () {
  "use strict";

  const els = window.MiniIcraPopupDom.getPopupElements();
  const hacizEls = window.MiniIcraHacizDom.getHacizElements();

  const PopupConfig = window.MiniIcraPopupConfig;
  const PopupUtils = window.MiniIcraPopupUtils;
  const PopupQuery = window.MiniIcraPopupQuery;
  const PopupExport = window.MiniIcraPopupExport;
  const PopupHesap = window.MiniIcraPopupHesap;
  const HacizFormat = window.MiniIcraHacizFormat;
  const HacizExport = window.MiniIcraHacizExport;

  const { DEFAULT_SETTINGS } = PopupConfig;
  const { RUN_MODES } = PopupUtils;

  const state = window.MiniIcraPopupState.createAppState();

  const shell = window.MiniIcraPopupShell.createShell({
    els,
    hacizEls,
    state,
    runModes: RUN_MODES
  });

  const theme = window.MiniIcraTheme.createThemeService({ els, state });
  const palette = window.MiniIcraPalette.createPaletteService({ els, state });
  const docsPanel = window.MiniIcraDocsPanel.createDocsPanel({ els, state });
  const versionCheck = window.MiniIcraVersionCheck.createVersionCheck({ els, state });

  const settingsForm = window.MiniIcraPopupSettingsForm.createSettingsForm({
    els,
    state,
    defaults: DEFAULT_SETTINGS,
    deps: {
      normalizeOdemeDateForUi: PopupUtils.normalizeOdemeDateForUi,
      setStatus: shell.setStatus
    }
  });

  const messaging = window.MiniIcraTabMessaging.createTabMessaging({
    onError: shell.setStatus
  });

  const queryController = window.MiniIcraQueryController.createQueryController({
    els,
    hacizEls,
    state,
    shell,
    settingsForm,
    messaging,
    utils: PopupUtils,
    query: PopupQuery,
    exporter: PopupExport,
    hesap: PopupHesap,
    runModes: RUN_MODES
  });

  const hacizController = window.MiniIcraHacizController.createHacizController({
    els,
    hacizEls,
    state,
    shell,
    settingsForm,
    messaging,
    utils: PopupUtils,
    query: PopupQuery,
    hacizFormat: HacizFormat,
    hacizExport: HacizExport
  });

  const getTalepRunMode = (talepType) => {
    if (talepType === "talepEvrakiOlustur") {
      return RUN_MODES.TALEP_EVRAKI_OLUSTUR;
    }
    if (talepType === "kesinlestirmeTalebi") {
      return RUN_MODES.TALEP_KESINLESTIRME;
    }
    if (talepType === "borcluOdemeAktar") {
      return RUN_MODES.TALEP_BORCLU_ODEME_AKTAR;
    }
    return RUN_MODES.TALEP_MASRAF_AVANS_IADESI;
  };

  const onStopOrResume = () => {
    const isIdle = !state.isRunning && !state.hacizIsRunning;
    if (isIdle) {
      if (state.currentUiPanel === "haciz" && state.resumeHacizState) {
        hacizController.continueRun();
        return;
      }
      if (state.currentUiPanel !== "haciz" && state.resumeQueryState) {
        queryController.continueRun();
        return;
      }
    }

    if (state.currentUiPanel === "haciz") {
      hacizController.stopRun();
      return;
    }
    queryController.stopRun();
  };

  const onClearResults = () => {
    settingsForm.resetDosyaHesabiOdemeTarihi();
    settingsForm.scheduleAutoSave();

    chrome.storage.local.set(
      {
        runnerHacizResults: null,
        runnerHacizProgress: null,
        runnerHacizResumeState: null,
        hacizQueryCache: null,
        runnerResults: null,
        runnerProgress: null,
        runnerResumeState: null,
        runnerLiveView: null,
        runnerLastRunPanel: null
      },
      () => {
        state.resumeQueryState = null;
        state.resumeHacizState = null;
        shell.resetStableMatchedRows();
        shell.setHacizMatched(null);
        queryController.renderResults(null);
        hacizController.setRunUiState(false);
        queryController.setRunUiState(false);
        shell.hideProgressBar();

        if (state.currentUiPanel === "haciz") {
          shell.setHacizStatus("Sonuçlar temizlendi.");
        } else {
          shell.setStatus("Sonuçlar temizlendi.");
        }
        shell.updateStopResumeButton();
      }
    );
  };

  const bindEvents = () => {
    els.saveBtn.addEventListener("click", () => settingsForm.save());
    els.runBtn.addEventListener("click", () => {
      queryController.startRun(String(els.runMode?.value || "normal"));
    });
    els.stopBtn.addEventListener("click", onStopOrResume);
    els.clearBtn.addEventListener("click", onClearResults);
    els.exportBtn.addEventListener("click", () => {
      if (state.currentUiPanel === "haciz") {
        hacizController.exportResults();
        return;
      }
      queryController.exportResults();
    });

    if (els.themeToggle) {
      els.themeToggle.addEventListener("click", theme.toggleTheme);
    }
    if (els.paletteBtn) {
      els.paletteBtn.addEventListener("click", (event) => {
        event.stopPropagation();
        palette.togglePicker();
      });
    }
    if (els.palettePicker) {
      els.palettePicker.addEventListener("click", (event) => event.stopPropagation());
    }
    // Seçici dışına tıklanınca kapansın.
    document.addEventListener("click", palette.closePicker);
    if (els.helpBtn) {
      els.helpBtn.addEventListener("click", docsPanel.toggle);
    }
    if (els.docsCloseBtn) {
      els.docsCloseBtn.addEventListener("click", docsPanel.close);
    }
    if (els.updateNoticeClose) {
      els.updateNoticeClose.addEventListener("click", versionCheck.dismiss);
    }

    if (els.dosyaRunBtn) {
      els.dosyaRunBtn.addEventListener("click", () => queryController.startRun(RUN_MODES.DOSYA_HESABI));
    }
    if (els.talepRunBtn) {
      els.talepRunBtn.addEventListener("click", () => {
        queryController.startRun(getTalepRunMode(String(els.talepType?.value || "masrafAvansIadesi")));
      });
    }
    if (els.dosyaTakipUploadBtn) {
      els.dosyaTakipUploadBtn.addEventListener("click", queryController.applyTakipEvraki);
    }
    if (hacizEls.hacizRunBtn) {
      hacizEls.hacizRunBtn.addEventListener("click", hacizController.startRun);
    }

    const tabs = [
      [els.tabQuery, "query"],
      [els.tabDosya, "dosya"],
      [els.tabTalep, "talep"],
      [hacizEls.tabHaciz, "haciz"]
    ];
    for (const [tab, panel] of tabs) {
      if (tab) {
        tab.addEventListener("click", () => shell.setActivePanel(panel));
      }
    }

    if (els.runMode) {
      els.runMode.addEventListener("change", () => {
        settingsForm.syncDatedFilterVisibility();
        settingsForm.scheduleAutoSave();
      });
    }
    if (els.datedFilter) {
      els.datedFilter.addEventListener("change", () => {
        settingsForm.syncDatedFilterVisibility();
        settingsForm.scheduleAutoSave();
      });
    }
    if (els.dosyaHesabiHesapTuru) {
      els.dosyaHesabiHesapTuru.addEventListener("change", () => {
        settingsForm.syncDosyaHesapTuruVisibility();
        settingsForm.scheduleAutoSave();
      });
    }
    if (els.talepType) {
      els.talepType.addEventListener("change", () => {
        settingsForm.syncTalepIbanVisibility();
        settingsForm.scheduleAutoSave();
      });
    }
    if (els.kalanQueryAmount) {
      els.kalanQueryAmount.addEventListener("input", settingsForm.scheduleAutoSave);
    }

    const autoSaveFields = [
      els.inputs,
      els.firstEndpointPath,
      els.firstMethod,
      els.firstHeadersText,
      els.firstBodyTemplate,
      els.secondEndpointPath,
      els.secondMethod,
      els.secondHeadersText,
      els.secondBodyTemplate,
      els.defaultBirimId,
      els.defaultBirimAdi,
      els.dosyaHesabiOdemeTarihi,
      els.dosyaHesabiHesapTuru,
      els.dosyaHesabiDosyaDurumKod,
      els.dosyaHesabiIndirimTutari,
      els.talepType,
      els.talepIbanNo,
      els.datedFilter,
      els.datedFrom,
      els.datedTo,
      els.defaultDosyaDurum
    ];
    for (const field of autoSaveFields) {
      if (field) {
        field.addEventListener("input", settingsForm.scheduleAutoSave);
        field.addEventListener("change", settingsForm.scheduleAutoSave);
      }
    }

    if (els.inputs) {
      els.inputs.addEventListener("input", () => {
        shell.updateRowCount();
        const currentInputText = els.inputs.value;
        if (currentInputText !== state.lastObservedInputText) {
          state.lastObservedInputText = currentInputText;
          settingsForm.resetDosyaHesabiOdemeTarihi();
          settingsForm.scheduleAutoSave();
        }
      });
    }

    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") {
        settingsForm.saveSilently();
      }
    });

    chrome.runtime.onMessage.addListener((message) => {
      if (!message || message.action !== "runnerProgress") {
        return;
      }
      queryController.handleProgressMessage(message);
    });
  };

  const restoreSettings = () => {
    chrome.storage.local.get(
      {
        runnerSettings: DEFAULT_SETTINGS,
        runnerInputText: "",
        runnerUiTheme: "auto",
        runnerUiPalette: window.MiniIcraPalette.DEFAULT_PALETTE,
        runnerResumeState: null,
        runnerHacizResumeState: null
      },
      (data) => {
        const settings = { ...DEFAULT_SETTINGS, ...(data.runnerSettings || {}) };
        settingsForm.write(settings);
        state.currentRunMode = String(settings.queryRunMode || state.currentRunMode || "normal");
        els.inputs.value = data.runnerInputText || "";
        state.lastObservedInputText = els.inputs.value;
        state.resumeQueryState = data.runnerResumeState || null;
        state.resumeHacizState = data.runnerHacizResumeState || null;
        shell.updateRowCount();
        theme.applyTheme(String(data.runnerUiTheme || "auto"));
        palette.applyPalette(String(data.runnerUiPalette || window.MiniIcraPalette.DEFAULT_PALETTE));
        shell.updateStopResumeButton();
      }
    );
  };

  const restoreLiveView = (runnerLiveView) => {
    state.currentRunMode = String(runnerLiveView.runMode || state.currentRunMode);
    if (shell.isYatanParaMode(state.currentRunMode)) {
      shell.resetStableMatchedRows();
      shell.collectStableMatchedRows(runnerLiveView.rows);
    }

    const isQuerySelectable = shell.getPanelForRunMode(state.currentRunMode) === "query";
    if (els.runMode && isQuerySelectable) {
      els.runMode.value = state.currentRunMode;
      settingsForm.syncDatedFilterVisibility();
    }

    shell.setMatched(runnerLiveView.rows);
    if (runnerLiveView.status) {
      shell.setStatus(String(runnerLiveView.status));
    }
  };

  const restoreResults = () => {
    chrome.storage.local.get(
      {
        runnerResults: null,
        runnerProgress: null,
        runnerLiveView: null,
        runnerHacizProgress: null,
        runnerHacizResults: null,
        runnerLastRunPanel: null,
        runnerResumeState: null,
        runnerHacizResumeState: null
      },
      (stored) => {
        state.resumeQueryState = stored.runnerResumeState || null;
        state.resumeHacizState = stored.runnerHacizResumeState || null;
        shell.updateStopResumeButton();

        const preferHaciz = stored.runnerLastRunPanel === "haciz";
        const hacizProgress = stored.runnerHacizProgress;
        const hacizResults = stored.runnerHacizResults;

        if (preferHaciz && hacizProgress && hacizProgress.progress) {
          state.activeHacizRequestId = hacizProgress.requestId || null;
          hacizController.setRunUiState(true);
          shell.setActivePanel("haciz");
          hacizController.renderProgress(hacizProgress.progress);
          return;
        }

        if (preferHaciz && hacizResults && Array.isArray(hacizResults.items) && hacizResults.items.length > 0) {
          shell.setActivePanel("haciz");
          hacizController.renderResults(hacizResults);
          const success = Number(hacizResults.talepSuccess) || 0;
          const processed = Number(hacizResults.talepProcessed) || 0;
          shell.setHacizStatus(
            `${hacizResults.stopped ? "Durduruldu" : "Tamamlandı"}. Eşleşen: ${hacizResults.matchCount || 0}/${
              hacizResults.total || 0
            } | Talep: ${success}/${processed}`
          );
          return;
        }

        const liveView = stored.runnerLiveView;
        if (liveView && Array.isArray(liveView.rows) && liveView.rows.length > 0) {
          restoreLiveView(liveView);
        }

        if (stored.runnerProgress && stored.runnerProgress.progress) {
          state.activeRequestId = stored.runnerProgress.requestId || null;
          state.currentRunMode = String(stored.runnerProgress.progress.runMode || state.currentRunMode || "normal");
          queryController.setRunUiState(true);
          shell.setActivePanel(shell.getPanelForRunMode(state.currentRunMode));
          queryController.renderProgress(stored.runnerProgress.progress, state.currentRunMode);
          return;
        }

        if (preferHaciz && state.resumeHacizState) {
          shell.setActivePanel("haciz");
          shell.setHacizStatus(shell.getHacizResumeStatusText(state.resumeHacizState));
          return;
        }
        if (state.resumeQueryState) {
          state.currentRunMode = String(state.resumeQueryState.runMode || state.currentRunMode || RUN_MODES.NORMAL);
          shell.setActivePanel(shell.getPanelForRunMode(state.currentRunMode));
          shell.setStatus(shell.getQueryResumeStatusText(state.resumeQueryState));
        }

        const resultMode = stored.runnerResults?.runMode ? String(stored.runnerResults.runMode) : state.currentRunMode;
        shell.setActivePanel(shell.getPanelForRunMode(state.currentRunMode));
        queryController.renderResults(stored.runnerResults, resultMode);
      }
    );
  };

  const restoreActivePanel = () => {
    chrome.storage.local.get(
      {
        runnerActivePanel: "query",
        runnerLastRunPanel: null,
        runnerHacizResults: null,
        runnerHacizProgress: null,
        runnerResults: null,
        runnerProgress: null
      },
      (stored) => {
        if (state.hacizIsRunning || state.isRunning) {
          return;
        }
        if (stored.runnerLastRunPanel === "haciz" && (stored.runnerHacizResults || stored.runnerHacizProgress)) {
          shell.setActivePanel("haciz");
          return;
        }
        if (stored.runnerProgress && stored.runnerProgress.progress) {
          const mode = String(stored.runnerProgress.progress.runMode || state.currentRunMode || "normal");
          shell.setActivePanel(shell.getPanelForRunMode(mode));
          return;
        }
        if (stored.runnerResults) {
          const mode = String(stored.runnerResults.runMode || state.currentRunMode || "normal");
          shell.setActivePanel(shell.getPanelForRunMode(mode));
          return;
        }
        shell.setActivePanel(stored.runnerActivePanel || "query");
      }
    );
  };

  bindEvents();
  restoreSettings();
  restoreResults();
  versionCheck.check();
  restoreActivePanel();

  settingsForm.syncDatedFilterVisibility();
  settingsForm.syncDosyaHesapTuruVisibility();
  queryController.setRunUiState(false);
  hacizController.setRunUiState(false);
  shell.hideProgressBar();
  theme.applyTheme("auto");
  palette.buildPicker();
  palette.applyPalette(state.currentPalette);
  shell.updateRowCount();

  const footerYearEl = document.getElementById("currentYear");
  if (footerYearEl) {
    footerYearEl.textContent = String(new Date().getFullYear());
  }

  window.MiniIcraCheckForUpdates = () => {
    chrome.storage.local.set({ miniIcraVersionCheckDismissed: null }, () => {
      versionCheck.check({ force: true });
    });
  };
})();

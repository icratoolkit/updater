(function () {
  "use strict";

  if (window.MiniIcraPopupSettingsForm) {
    return;
  }

  const AUTO_SAVE_DEBOUNCE_MS = 300;
  const IBAN_PATTERN = /^TR\d{24}$/;

  const getTodayForDateInput = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };

  const readTrimmed = (element) => (element ? String(element.value || "").trim() : "");

  const createSettingsForm = ({ els, state, defaults, deps }) => {
    const { normalizeOdemeDateForUi, setStatus } = deps;

    const syncDatedFilterVisibility = () => {
      if (!els.datedFilter || !els.runMode) {
        return;
      }
      const mode = String(els.runMode.value || "normal");
      const isDatedMode = mode === "datedCurrentMonth";
      const isCustomRange = String(els.datedFilter.value || "") === "custom";

      els.datedFilter.style.display = isDatedMode ? "" : "none";
      if (els.datedCustomRange) {
        els.datedCustomRange.style.display = isDatedMode && isCustomRange ? "" : "none";
      }
      if (els.kalanQueryWrap) {
        els.kalanQueryWrap.style.display = mode === "kalan" ? "" : "none";
      }
    };

    const syncDosyaHesapTuruVisibility = () => {
      if (!els.dosyaIndirimWrap || !els.dosyaHesabiHesapTuru) {
        return;
      }
      const isIndirim = String(els.dosyaHesabiHesapTuru.value || "normal") === "indirim";
      els.dosyaIndirimWrap.style.display = isIndirim ? "" : "none";
    };

    const syncTalepIbanVisibility = () => {
      if (!els.talepIbanWrap || !els.talepType) {
        return;
      }
      const isIbanDegisikligi = String(els.talepType.value || "") === "talepEvrakiOlustur";
      els.talepIbanWrap.style.display = isIbanDegisikligi ? "" : "none";
    };

    const syncVisibility = () => {
      syncDatedFilterVisibility();
      syncDosyaHesapTuruVisibility();
      syncTalepIbanVisibility();
    };

    const resetDosyaHesabiOdemeTarihi = () => {
      if (els.dosyaHesabiOdemeTarihi) {
        els.dosyaHesabiOdemeTarihi.value = getTodayForDateInput();
      }
    };

    const read = () => ({
      firstEndpointPath: els.firstEndpointPath.value.trim(),
      firstMethod: (els.firstMethod.value || "POST").toUpperCase(),
      firstHeadersText: els.firstHeadersText.value,
      firstBodyTemplate: els.firstBodyTemplate.value,
      secondEndpointPath: els.secondEndpointPath.value.trim(),
      secondMethod: (els.secondMethod.value || "POST").toUpperCase(),
      secondHeadersText: els.secondHeadersText.value,
      secondBodyTemplate: els.secondBodyTemplate.value,
      defaultBirimId: readTrimmed(els.defaultBirimId),
      defaultBirimAdi: readTrimmed(els.defaultBirimAdi),
      defaultDosyaDurum: readTrimmed(els.defaultDosyaDurum),
      dosyaHesabiOdemeTarihi: readTrimmed(els.dosyaHesabiOdemeTarihi),
      dosyaHesabiHesapTuru: readTrimmed(els.dosyaHesabiHesapTuru) || "normal",
      dosyaHesabiDosyaDurumKod: readTrimmed(els.dosyaHesabiDosyaDurumKod) === "1" ? "1" : "0",
      dosyaHesabiIndirimTutari: readTrimmed(els.dosyaHesabiIndirimTutari),
      faizOranDusuk: readTrimmed(els.faizOranDusuk),
      faizOranYuksek: readTrimmed(els.faizOranYuksek),
      faizBolunmeTarihi: readTrimmed(els.faizBolunmeTarihi),
      faizOranYuksek2: readTrimmed(els.faizOranYuksek2),
      faizBolunmeTarihi2: readTrimmed(els.faizBolunmeTarihi2),
      datedFilter: readTrimmed(els.datedFilter) || "thisMonth",
      kalanQueryAmount: readTrimmed(els.kalanQueryAmount),
      queryRunMode: readTrimmed(els.runMode) || "normal",
      talepType: readTrimmed(els.talepType) || "masrafAvansIadesi",
      talepIbanNo: readTrimmed(els.talepIbanNo) || defaults.talepIbanNo,
      datedFrom: readTrimmed(els.datedFrom),
      datedTo: readTrimmed(els.datedTo)
    });

    const write = (settings) => {
      els.firstEndpointPath.value = settings.firstEndpointPath || defaults.firstEndpointPath;
      els.firstMethod.value = settings.firstMethod || defaults.firstMethod;
      els.firstHeadersText.value = settings.firstHeadersText || defaults.firstHeadersText;
      els.firstBodyTemplate.value = settings.firstBodyTemplate || defaults.firstBodyTemplate;
      els.secondEndpointPath.value = settings.secondEndpointPath || defaults.secondEndpointPath;
      els.secondMethod.value = settings.secondMethod || defaults.secondMethod;
      els.secondHeadersText.value = settings.secondHeadersText || defaults.secondHeadersText;
      els.secondBodyTemplate.value = settings.secondBodyTemplate || defaults.secondBodyTemplate;

      const simpleFields = [
        [els.defaultBirimId, "defaultBirimId"],
        [els.defaultBirimAdi, "defaultBirimAdi"],
        [els.defaultDosyaDurum, "defaultDosyaDurum"],
        [els.dosyaHesabiHesapTuru, "dosyaHesabiHesapTuru"],
        [els.dosyaHesabiIndirimTutari, "dosyaHesabiIndirimTutari"],
        [els.faizOranDusuk, "faizOranDusuk"],
        [els.faizOranYuksek, "faizOranYuksek"],
        [els.faizBolunmeTarihi, "faizBolunmeTarihi"],
        [els.faizOranYuksek2, "faizOranYuksek2"],
        [els.faizBolunmeTarihi2, "faizBolunmeTarihi2"],
        [els.datedFilter, "datedFilter"],
        [els.kalanQueryAmount, "kalanQueryAmount"],
        [els.talepType, "talepType"],
        [els.talepIbanNo, "talepIbanNo"],
        [els.datedFrom, "datedFrom"],
        [els.datedTo, "datedTo"]
      ];

      for (const [element, key] of simpleFields) {
        if (element) {
          element.value = settings[key] || defaults[key] || "";
        }
      }

      if (els.dosyaHesabiOdemeTarihi) {
        const stored = settings.dosyaHesabiOdemeTarihi || defaults.dosyaHesabiOdemeTarihi || "";
        els.dosyaHesabiOdemeTarihi.value = normalizeOdemeDateForUi(stored) || getTodayForDateInput();
      }
      if (els.dosyaHesabiDosyaDurumKod) {
        const kod = String(settings.dosyaHesabiDosyaDurumKod || defaults.dosyaHesabiDosyaDurumKod || "0");
        els.dosyaHesabiDosyaDurumKod.value = kod === "1" ? "1" : "0";
      }
      if (els.runMode) {
        els.runMode.value = settings.queryRunMode || defaults.queryRunMode || "normal";
      }

      syncVisibility();
    };

    const save = (done) => {
      const settings = read();
      const inputText = els.inputs.value;

      chrome.storage.local.set({ runnerSettings: settings, runnerInputText: inputText }, () => {
        if (chrome.runtime.lastError) {
          setStatus(`Kayıt hatası: ${chrome.runtime.lastError.message}`, true);
          return;
        }
        if (typeof done === "function") {
          done({ settings, inputText });
        } else {
          setStatus("Ayarlar kaydedildi.");
        }
      });
    };

    const saveSilently = () => {
      chrome.storage.local.set({ runnerSettings: read(), runnerInputText: els.inputs.value });
    };

    const scheduleAutoSave = () => {
      if (state.autoSaveTimer) {
        clearTimeout(state.autoSaveTimer);
      }
      state.autoSaveTimer = setTimeout(saveSilently, AUTO_SAVE_DEBOUNCE_MS);
    };

    const normalizeIban = (rawIban) => {
      const iban = String(rawIban || defaults.talepIbanNo || "")
        .replace(/\s+/g, "")
        .toUpperCase();
      return { iban, isValid: IBAN_PATTERN.test(iban) };
    };

    return {
      getTodayForDateInput,
      normalizeIban,
      read,
      resetDosyaHesabiOdemeTarihi,
      save,
      saveSilently,
      scheduleAutoSave,
      syncDatedFilterVisibility,
      syncDosyaHesapTuruVisibility,
      syncTalepIbanVisibility,
      syncVisibility,
      write
    };
  };

  window.MiniIcraPopupSettingsForm = {
    createSettingsForm
  };
})();

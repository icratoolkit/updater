(function () {
  "use strict";

  if (window.MiniIcraPopupQuery) {
    return;
  }

  const syncDatedFilterVisibility = (els) => {
    if (!els || !els.datedFilter || !els.runMode) {
      return;
    }
    const mode = String(els.runMode.value || "normal");
    const isDatedMode = mode === "datedCurrentMonth";
    const isKalanMode = mode === "kalan";
    const isCustom = String(els.datedFilter.value || "") === "custom";
    els.datedFilter.style.display = isDatedMode ? "" : "none";
    if (els.datedCustomRange) {
      els.datedCustomRange.style.display = isDatedMode && isCustom ? "" : "none";
    }
    if (els.kalanQueryWrap) {
      els.kalanQueryWrap.style.display = isKalanMode ? "" : "none";
    }
  };

  const isProgressCompleted = (progress) => {
    if (!progress) {
      return false;
    }
    if (progress.stopped === true) {
      return true;
    }
    const total = Number(progress.total);
    const processed = Number(progress.processed);
    return Number.isFinite(total) && Number.isFinite(processed) && total > 0 && processed >= total;
  };

  const getProgressCompletionStatus = (progress) =>
    progress && progress.stopped
      ? `Durduruldu. Eşleşen: ${progress.matchCount}/${progress.total}`
      : `Tamamlandı. Eşleşen: ${progress.matchCount}/${progress.total}`;

  const findBirimMatch = (birimMap, birimAdi, normalizeKey) => {
    const key = normalizeKey(birimAdi);
    if (!key) {
      return null;
    }
    const direct = birimMap.get(key);
    if (direct) {
      return direct;
    }

    const withoutNumbers = key.replace(/\d+/g, "");
    if (withoutNumbers) {
      const byNoNumber = birimMap.get(withoutNumbers);
      if (byNoNumber) {
        return byNoNumber;
      }
    }

    for (const [k, value] of birimMap.entries()) {
      if (!k) {
        continue;
      }
      if (k.startsWith(key) || key.startsWith(k)) {
        const ratio = Math.min(k.length, key.length) / Math.max(k.length, key.length);
        if (ratio >= 0.85) {
          return value;
        }
      }
    }

    return null;
  };

  const applyBirimLookup = (rows, birimMap, settings, normalizeKey) => {
    const out = [];
    let unresolved = 0;
    const unresolvedRows = [];

    for (const row of rows) {
      let birimAdi = row.birimAdi || settings.defaultBirimAdi || "";
      let birimId = row.birimId || settings.defaultBirimId || "";
      if (birimAdi) {
        const found = findBirimMatch(birimMap, birimAdi, normalizeKey);
        if (found) {
          birimAdi = found.birimAdi;
          birimId = found.birimId;
        } else if (!birimId) {
          unresolved += 1;
          unresolvedRows.push(`${row.dosyaNo} -> ${birimAdi}`);
        }
      }
      out.push({ dosyaNo: row.dosyaNo, birimAdi, birimId });
    }

    return { inputs: out, unresolved, unresolvedRows };
  };

  const createBirimLookupService = ({ normalizeKey }) => {
    let birimLookupPromise = null;

    const load = () => {
      if (!birimLookupPromise) {
        birimLookupPromise = fetch(chrome.runtime.getURL("assets/data/birimler.json"))
          .then((r) => r.json())
          .then((arr) => {
            const map = new Map();
            for (const item of arr || []) {
              const birimAdi = String(item.birimAdi || "").trim();
              const birimId = String(item.birimId || "").trim();
              if (!birimAdi || !birimId) {
                continue;
              }
              map.set(normalizeKey(birimAdi), { birimAdi, birimId });
            }
            return map;
          })
          .catch(() => new Map());
      }
      return birimLookupPromise;
    };

    const apply = (rows, birimMap, settings) => applyBirimLookup(rows, birimMap, settings, normalizeKey);

    return { load, apply };
  };

  window.MiniIcraPopupQuery = {
    syncDatedFilterVisibility,
    isProgressCompleted,
    getProgressCompletionStatus,
    createBirimLookupService
  };
})();

(function () {
  "use strict";

  if (window.MiniIcraPopupConfig) {
    return;
  }

  const DEFAULT_SETTINGS = Object.freeze({
    firstEndpointPath: "/search_phrase_detayli.ajx",
    firstMethod: "POST",
    firstHeadersText: "{\n  \"Content-Type\": \"application/json\"\n}",
    firstBodyTemplate: "{\n  \"dosyaDurumKod\": 0,\n  \"pageSize\": 500,\n  \"pageNumber\": 1,\n  \"dosyaYil\": \"{{dosyaYil}}\",\n  \"dosyaSira\": \"{{dosyaSira}}\",\n  \"birimId\": \"{{birimId}}\",\n  \"birimTuru2\": \"1101\",\n  \"birimTuru3\": \"2\"\n}",
    secondEndpointPath: "/dosya_hesap_bilgileri.ajx",
    secondMethod: "POST",
    secondHeadersText: "{\n  \"Content-Type\": \"application/json\",\n  \"X-Borclu\": \"undefined\",\n  \"X-Birim-Id\": \"{{birimId}}\",\n  \"X-Dosya-No\": \"{{inputEncoded}}\",\n  \"X-Birim-Adi\": \"{{birimAdi}}\",\n  \"X-Birim-Turu2\": \"undefined\",\n  \"X-Dosya-Durum\": \"{{dosyaDurum}}\"\n}",
    secondBodyTemplate: "{\n  \"dosyaId\": \"{{dosyaId}}\"\n}",
    dosyaHesabiOdemeTarihi: "",
    dosyaHesabiHesapTuru: "normal",
    dosyaHesabiDosyaDurumKod: "0",
    dosyaHesabiIndirimTutari: "",
    faizOranDusuk: "0.09",
    faizOranYuksek: "0.24",
    faizBolunmeTarihi: "2024-06-01",
    datedFilter: "thisMonth",
    kalanQueryAmount: "",
    queryRunMode: "normal",
    talepType: "masrafAvansIadesi",
    talepIbanNo: "TR620001009010684338705009",
    datedFrom: "",
    datedTo: "",
    defaultBirimId: "",
    defaultBirimAdi: "",
    defaultDosyaDurum: "Acik"
  });

  window.MiniIcraPopupConfig = {
    DEFAULT_SETTINGS
  };
})();

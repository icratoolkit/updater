(function () {
  "use strict";

  if (window.MiniIcraHacizConfig) {
    return;
  }

  const HACIZ_DEFAULT_SETTINGS = Object.freeze({
    borcluListPath: "/dosya_borclu_list.ajx",
    aracSorguPath:  "/borclu_bilgileri_goruntule_egm_brd.ajx",
    bankaSorguPath: "/borclu_bilgileri_goruntule_banka.ajx"
  });

  window.MiniIcraHacizConfig = {
    HACIZ_DEFAULT_SETTINGS
  };
})();

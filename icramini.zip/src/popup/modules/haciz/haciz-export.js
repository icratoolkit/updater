(function () {
  "use strict";

  if (window.MiniIcraHacizExport) {
    return;
  }

  const PopupUtils = window.MiniIcraPopupUtils;
  const HacizFormat = window.MiniIcraHacizFormat;
  const { fixMojibake, formatAmount2, csvEscape } = PopupUtils;
  const { aggregateTalepResultsByDosya, formatTalepDurum } = HacizFormat;

  const SHEETS = Object.freeze({
    arac: {
      rowsKey: "aracRows",
      sheetName: "AracHaciz",
      header: ["Dosya No", "Kişi", "TC Kimlik No", "Plaka", "Marka", "Model", "Ticari Ad", "Renk", "Cins"],
      fieldMap: {
        "Dosya No": "dosyaNo",
        Kişi: "kisi",
        "TC Kimlik No": "tcKimlikNo",
        Plaka: "plaka",
        Marka: "marka",
        Model: "model",
        "Ticari Ad": "ticariAd",
        Renk: "renk",
        Cins: "cins"
      }
    },
    banka: {
      rowsKey: "bankaRows",
      sheetName: "BankaHaciz",
      header: ["Dosya No", "Kişi", "TC Kimlik No", "Banka Adı", "EFT Kodu", "Eşleşen Kurum", "Kurum ID"],
      fieldMap: {
        "Dosya No": "dosyaNo",
        Kişi: "kisi",
        "TC Kimlik No": "tcKimlikNo",
        "Banka Adı": "bankaAdi",
        "EFT Kodu": "eftKodu",
        "Eşleşen Kurum": "matchedIlgili",
        "Kurum ID": "matchedId"
      }
    },
    takbis: {
      rowsKey: "takbisRows",
      sheetName: "TakbisHaciz",
      header: [
        "Dosya No",
        "Kişi",
        "TC Kimlik No",
        "İl",
        "İlçe",
        "Mahalle",
        "Ada",
        "Parsel",
        "Nitelik",
        "Yüzölçüm",
        "Bağımsız Bölüm"
      ],
      fieldMap: {
        "Dosya No": "dosyaNo",
        Kişi: "kisi",
        "TC Kimlik No": "tcKimlikNo",
        İl: "il",
        İlçe: "ilce",
        Mahalle: "mahalle",
        Ada: "ada",
        Parsel: "parsel",
        Nitelik: "nitelik",
        Yüzölçüm: "yuzolcum",
        "Bağımsız Bölüm": "bagimsizBolum"
      }
    },
    talep: {
      rowsKey: "talepRows",
      sheetName: "TalepSonuclari",
      header: [
        "Dosya No",
        "Kişi",
        "Araç Sayısı",
        "Banka Sayısı",
        "Takbis Sayısı",
        "İcra Dosyası Sayısı",
        "Durum",
        "Detay",
        "Masraf (₺)"
      ],
      fieldMap: {
        "Dosya No": "dosyaNo",
        Kişi: "kisi",
        "Araç Sayısı": "aracSayisi",
        "Banka Sayısı": "bankaSayisi",
        "Takbis Sayısı": "takbisSayisi",
        "İcra Dosyası Sayısı": "icraDosyasiSayisi",
        Durum: "durum",
        Detay: "detay",
        "Masraf (₺)": "masraf"
      }
    }
  });

  const SHEET_ORDER = [SHEETS.arac, SHEETS.banka, SHEETS.takbis, SHEETS.talep];

  const getFieldValue = (row, header, fieldMap) => {
    const field = fieldMap[header];
    return field ? (row?.[field] ?? "") : "";
  };

  const getSheetRows = (exportData, sheet) => {
    const rows = exportData[sheet.rowsKey];
    return Array.isArray(rows) ? rows : [];
  };

  const buildTalepTotalRow = (talepRows) => {
    const total = talepRows.reduce((sum, row) => sum + (Number(row.masraf) || 0), 0);
    return total > 0 ? ["", "", "", "", "", "", "", "TOPLAM", total.toFixed(2)] : null;
  };

  const buildSheetDataRows = (exportData, sheet) => {
    const rows = getSheetRows(exportData, sheet).map((row) =>
      sheet.header.map((header) => getFieldValue(row, header, sheet.fieldMap))
    );

    if (sheet === SHEETS.talep && rows.length > 0) {
      const totalRow = buildTalepTotalRow(getSheetRows(exportData, sheet));
      if (totalRow) {
        rows.push(totalRow);
      }
    }

    return rows;
  };

  const getHacizExportRows = (items, talepResults) => {
    const aracRows = [];
    const bankaRows = [];
    const takbisRows = [];

    for (const item of Array.isArray(items) ? items : []) {
      if (!item || !Array.isArray(item.borclular)) {
        continue;
      }

      for (const borclu of item.borclular) {
        const base = {
          dosyaNo: fixMojibake(item.input),
          kisi: fixMojibake(borclu.kisi),
          tcKimlikNo: fixMojibake(borclu.tcKimlikNo)
        };

        for (const arac of Array.isArray(borclu.aracList) ? borclu.aracList : []) {
          aracRows.push({
            ...base,
            plaka: fixMojibake(arac.plaka),
            marka: fixMojibake(arac.marka),
            model: fixMojibake(arac.model),
            ticariAd: fixMojibake(arac.ticariAd),
            renk: fixMojibake(arac.renk),
            cins: fixMojibake(arac.cins)
          });
        }

        for (const banka of Array.isArray(borclu.bankaList) ? borclu.bankaList : []) {
          bankaRows.push({
            ...base,
            bankaAdi: fixMojibake(banka.bankaAdi),
            eftKodu: String(banka.eftKodu ?? ""),
            matchedIlgili: fixMojibake(banka.matchedIlgili || ""),
            matchedId: String(banka.matchedId ?? "")
          });
        }

        for (const takbis of Array.isArray(borclu.takbisList) ? borclu.takbisList : []) {
          takbisRows.push({
            ...base,
            il: fixMojibake(takbis.il),
            ilce: fixMojibake(takbis.ilce),
            mahalle: fixMojibake(takbis.mahalle),
            ada: String(takbis.ada ?? ""),
            parsel: String(takbis.parsel ?? ""),
            nitelik: fixMojibake(takbis.nitelik),
            yuzolcum: String(takbis.yuzolcum ?? ""),
            bagimsizBolum: fixMojibake(takbis.bagimsizBolum)
          });
        }
      }
    }

    const talepRows = aggregateTalepResultsByDosya(talepResults).map((row) => ({
      dosyaNo: row.dosyaNo,
      kisi: row.kisi,
      aracSayisi: String(Number(row.aracCount) || 0),
      bankaSayisi: String(Number(row.bankaCount) || 0),
      takbisSayisi: String(Number(row.takbisCount) || 0),
      icraDosyasiSayisi: String(Number(row.icraDosyasiCount) || 0),
      durum: formatTalepDurum(row.durum),
      detay: row.detay,
      masraf: formatAmount2(Number(row.masraf) || 0)
    }));

    return { aracRows, bankaRows, takbisRows, talepRows };
  };

  const triggerDownload = (blob, fileName) => {
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  };

  const buildTimestamp = () => new Date().toISOString().replace(/[:.]/g, "-");

  const downloadHacizCsv = (exportData) => {
    const lines = [];

    for (const sheet of SHEET_ORDER) {
      const dataRows = buildSheetDataRows(exportData, sheet);
      if (dataRows.length === 0) {
        continue;
      }
      if (lines.length > 0) {
        lines.push("");
      }
      lines.push(sheet.header.map(csvEscape).join(";"));
      for (const row of dataRows) {
        lines.push(row.map(csvEscape).join(";"));
      }
    }

    const content = `\uFEFFsep=;\r\n${lines.join("\r\n")}`;
    triggerDownload(new Blob([content], { type: "text/csv;charset=utf-8;" }), `haciz-${buildTimestamp()}.csv`);
  };

  const downloadHacizXlsx = (exportData) => {
    const xlsx = window.XLSX;
    if (!xlsx || !xlsx.utils || !xlsx.writeFile) {
      downloadHacizCsv(exportData);
      return;
    }

    const workbook = xlsx.utils.book_new();
    for (const sheet of SHEET_ORDER) {
      const dataRows = buildSheetDataRows(exportData, sheet);
      if (dataRows.length === 0) {
        continue;
      }
      const worksheet = xlsx.utils.aoa_to_sheet([sheet.header, ...dataRows]);
      xlsx.utils.book_append_sheet(workbook, worksheet, sheet.sheetName);
    }

    xlsx.writeFile(workbook, `haciz-${buildTimestamp()}.xlsx`, { cellStyles: true });
  };

  window.MiniIcraHacizExport = {
    SHEETS,
    downloadHacizCsv,
    downloadHacizXlsx,
    getHacizExportRows
  };
})();

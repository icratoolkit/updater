(function () {
  "use strict";

  if (window.MiniIcraHacizDom) {
    return;
  }

  const getById = (id) => document.getElementById(id);

  const getHacizElements = () => ({
    hacizPanel:      getById("hacizPanel"),
    tabHaciz:        getById("tabHaciz"),
    hacizRunBtn:     getById("hacizRunBtn"),
    hacizTypeArac:   getById("hacizTypeArac"),
    hacizTypeBanka:  getById("hacizTypeBanka"),
    hacizTypeTakbis: getById("hacizTypeTakbis"),
    hacizTypeIcraDosyasi: getById("hacizTypeIcraDosyasi")
  });

  window.MiniIcraHacizDom = {
    getHacizElements
  };
})();

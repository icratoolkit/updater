﻿(function () {
  "use strict";

  if (window.MiniIcraHacizUtils) {
    return;
  }

  const PopupUtils = window.MiniIcraPopupUtils || {};
  const fixMojibake = PopupUtils.fixMojibake || ((s) => String(s || ""));
  const formatAmount2 =
    PopupUtils.formatAmount2 || ((v) => (Number.isFinite(Number(v)) ? Number(v).toFixed(2) : String(v ?? "")));
  const csvEscape = PopupUtils.csvEscape || ((v) => `"${String(v ?? "").replace(/"/g, '""')}"`);

  const ERROR_CODE_DESCRIPTIONS = Object.freeze({
    PRTL_AVKT_10104: "Borçlu hakkındaki icra takibi kesinleştirilmediği için sorgulama yapamazsınız.",
    PRTL_AVKT_10034: "Dış sistemden sorgulama işlemi sırasında hata oluştu.",
    "PRTL_GNL_1-1": "Bu işlem 60 dakikada 1 defa yapılabilmektedir."
  });

  const escHtml = (s) =>
    String(s || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");

  const formatHacizResultLine = (item) => {
    if (!item || !Array.isArray(item.borclular) || item.borclular.length === 0) {
      return null;
    }
    const lines = [];
    for (const b of item.borclular) {
      const araclar = Array.isArray(b.aracList) ? b.aracList : [];
      if (araclar.length === 0) {
        continue;
      }
      const aracText = araclar
        .map((a) =>
          `${fixMojibake(a.plaka)} ${fixMojibake(a.marka)} ${fixMojibake(a.model)} ${fixMojibake(a.ticariAd)} ${fixMojibake(a.renk)} ${fixMojibake(a.cins)}`.trim()
        )
        .join(" | ");
      lines.push(`${fixMojibake(item.input)} -> ${fixMojibake(b.kisi)} (${fixMojibake(b.tcKimlikNo)}): ${aracText}`);
    }
    return lines.length > 0 ? lines.join("\n") : null;
  };

  const formatHacizErrorHtml = (dosyaNo, kisi, errorCode, errorMessage) => {
    const desc = fixMojibake(errorMessage || ERROR_CODE_DESCRIPTIONS[errorCode] || errorCode);
    return `<span class="haciz-error-row">${escHtml(dosyaNo)} - ${escHtml(kisi)} - <span class="haciz-error-code">${escHtml(errorCode)}<span class="haciz-error-info" title="${escHtml(desc)}">i</span><span class="haciz-tooltip">${escHtml(desc)}</span></span></span>`;
  };

  const getHacizMatchedRows = (items, source, skipKeys) => {
    const safeItems = Array.isArray(items) ? items : [];
    const rows = [];
    for (const item of safeItems) {
      if (!item || !Array.isArray(item.borclular)) {
        continue;
      }
      const dosyaNo = fixMojibake(item.input);
      for (const b of item.borclular) {
        const kisi = fixMojibake(b.kisi);
        if (skipKeys instanceof Set && skipKeys.has(`${item.dosyaNo || item.input || ""}|${b.kisi || ""}`)) {
          continue;
        }

        const araclar = Array.isArray(b.aracList) ? b.aracList : [];
        const bankalar = Array.isArray(b.bankaList) ? b.bankaList : [];
        const takbisler = Array.isArray(b.takbisList) ? b.takbisList : [];
        const icraDosyalari = Array.isArray(b.icraDosyasiList) ? b.icraDosyasiList : [];
        const hasIcraDosyasi = b.icraDosyasiVar === true || icraDosyalari.length > 0;
        const hasData = araclar.length > 0 || bankalar.length > 0 || takbisler.length > 0 || hasIcraDosyasi;
        const hasError = b.aracError || b.bankaError || b.takbisError || b.icraDosyasiError || b.errorCode;

        if (source === "result" && !hasData && !hasError) {
          continue;
        }

        if (b.aracError) {
          rows.push(formatHacizErrorHtml(dosyaNo, `${kisi} [Araç]`, b.aracError.code, b.aracError.message));
        }
        if (b.bankaError) {
          rows.push(formatHacizErrorHtml(dosyaNo, `${kisi} [Banka]`, b.bankaError.code, b.bankaError.message));
        }
        if (b.takbisError) {
          rows.push(formatHacizErrorHtml(dosyaNo, `${kisi} [Takbis]`, b.takbisError.code, b.takbisError.message));
        }
        if (b.icraDosyasiError) {
          rows.push(formatHacizErrorHtml(dosyaNo, `${kisi} [İcra Dosyası]`, b.icraDosyasiError.code, b.icraDosyasiError.message));
        }
        if (b.errorCode && !b.aracError && !b.bankaError && !b.takbisError && !b.icraDosyasiError) {
          rows.push(formatHacizErrorHtml(dosyaNo, kisi, b.errorCode, b.errorMessage));
        }

        if (hasData) {
          const parts = [];
          if (araclar.length > 0) {
            parts.push(`${araclar.length} araç`);
          }
          if (bankalar.length > 0) {
            const matched = bankalar.filter((bk) => bk.matchedId);
            const unmatched = bankalar.filter((bk) => !bk.matchedId);
            if (matched.length > 0) {
              parts.push(`${matched.length} banka`);
            }
            if (unmatched.length > 0) {
              const names = unmatched.map((bk) => bk.bankaAdi || "?").join(", ");
              parts.push(`<span style="color:#b8860b" title="${escHtml(names)}">${unmatched.length} eşleşmeyen banka</span>`);
            }
          }
          if (takbisler.length > 0) {
            parts.push(`${takbisler.length} takbis`);
          }
          if (hasIcraDosyasi) {
            parts.push(`${icraDosyalari.length || 1} icra dosyası`);
          }
          rows.push(`${escHtml(dosyaNo)} -> ${escHtml(kisi)}: ${parts.join(", ")}`);
        }
      }
    }
    return rows;
  };

  const aggregateTalepResultsByDosya = (talepResults) => {
    const grouped = new Map();

    for (const r of Array.isArray(talepResults) ? talepResults : []) {
      const dosyaNo = fixMojibake(r.dosyaNo || "");
      if (!grouped.has(dosyaNo)) {
        grouped.set(dosyaNo, {
          dosyaNo,
          kisiler: [],
          aracCount: 0,
          bankaCount: 0,
          takbisCount: 0,
          icraDosyasiCount: 0,
          masraf: 0,
          hasSuccess: false,
          hasPartial: false,
          hasFailure: false,
          details: []
        });
      }

      const entry = grouped.get(dosyaNo);
      const kisi = fixMojibake(r.kisi || "");

      if (kisi && !entry.kisiler.includes(kisi)) {
        entry.kisiler.push(kisi);
      }

      entry.aracCount += Number(r.aracCount) || 0;
      entry.bankaCount += Number(r.bankaCount) || 0;
      entry.takbisCount += Number(r.takbisCount) || 0;
      entry.icraDosyasiCount += Number(r.icraDosyasiCount) || 0;
      entry.masraf = Math.round((entry.masraf + (Number(r.masraf) || 0)) * 100) / 100;

      if (r.success) {
        entry.hasSuccess = true;
        entry.details.push(`${kisi}: Basarili`);
      } else if (r.partial) {
        entry.hasPartial = true;
        if (Array.isArray(r.subResults) && r.subResults.length > 0) {
          const subText = r.subResults
            .map((s) => {
              const lbl =
                s.type === "AvukatTalepAracHacziDVO"
                  ? "Arac"
                  : s.type === "AvukatTalepGayrimenkulHacziDVO"
                    ? "Takbis"
                    : s.type === "AvukatTalepAlacakliDosyaDVO"
                      ? "İcra Dosyası"
                      : "Banka";
              return `${lbl}: ${s.success ? "Basarili" : "Basarisiz"}`;
            })
            .join(" | ");
          entry.details.push(`${kisi}: ${subText}`);
        } else {
          entry.details.push(`${kisi}: Kismi`);
        }
      } else {
        entry.hasFailure = true;
        entry.details.push(`${kisi}: ${r.error || "Bilinmeyen hata"}`);
      }
    }

    return Array.from(grouped.values()).map((entry) => {
      let durum = "Basarisiz";
      if (!entry.hasFailure && !entry.hasPartial && entry.hasSuccess) {
        durum = "Basarili";
      } else if (entry.hasPartial || (entry.hasSuccess && entry.hasFailure)) {
        durum = "Kismi";
      }

      return {
        dosyaNo: entry.dosyaNo,
        kisi: entry.kisiler.join(", "),
        aracCount: entry.aracCount,
        bankaCount: entry.bankaCount,
        takbisCount: entry.takbisCount,
        icraDosyasiCount: entry.icraDosyasiCount,
        masraf: Math.round(entry.masraf * 100) / 100,
        durum,
        detay: entry.details.join(" || ")
      };
    });
  };

  const formatTalepDurum = (durum) => {
    if (durum === "Basarili") {
      return "Başarılı";
    }
    if (durum === "Kismi") {
      return "Kısmi";
    }
    if (durum === "Basarisiz") {
      return "Başarısız";
    }
    return fixMojibake(durum || "");
  };

  const getHacizExportRows = (items, talepResults) => {
    const aracRows = [];
    const bankaRows = [];
    const takbisRows = [];

    for (const item of Array.isArray(items) ? items : []) {
      if (!item || !Array.isArray(item.borclular)) {
        continue;
      }
      for (const b of item.borclular) {
        const base = {
          dosyaNo: fixMojibake(item.input),
          kisi: fixMojibake(b.kisi),
          tcKimlikNo: fixMojibake(b.tcKimlikNo)
        };

        for (const a of Array.isArray(b.aracList) ? b.aracList : []) {
          aracRows.push({
            ...base,
            plaka: fixMojibake(a.plaka),
            marka: fixMojibake(a.marka),
            model: fixMojibake(a.model),
            ticariAd: fixMojibake(a.ticariAd),
            renk: fixMojibake(a.renk),
            cins: fixMojibake(a.cins)
          });
        }

        for (const bk of Array.isArray(b.bankaList) ? b.bankaList : []) {
          bankaRows.push({
            ...base,
            bankaAdi: fixMojibake(bk.bankaAdi),
            eftKodu: String(bk.eftKodu ?? ""),
            matchedIlgili: fixMojibake(bk.matchedIlgili || ""),
            matchedId: String(bk.matchedId ?? "")
          });
        }

        for (const tk of Array.isArray(b.takbisList) ? b.takbisList : []) {
          takbisRows.push({
            ...base,
            il: fixMojibake(tk.il),
            ilce: fixMojibake(tk.ilce),
            mahalle: fixMojibake(tk.mahalle),
            ada: String(tk.ada ?? ""),
            parsel: String(tk.parsel ?? ""),
            nitelik: fixMojibake(tk.nitelik),
            yuzolcum: String(tk.yuzolcum ?? ""),
            bagimsizBolum: fixMojibake(tk.bagimsizBolum)
          });
        }
      }
    }

    const talepRows = aggregateTalepResultsByDosya(talepResults).map((r) => ({
      dosyaNo: r.dosyaNo,
      kisi: r.kisi,
      aracSayisi: String(Number(r.aracCount) || 0),
      bankaSayisi: String(Number(r.bankaCount) || 0),
      takbisSayisi: String(Number(r.takbisCount) || 0),
      icraDosyasiSayisi: String(Number(r.icraDosyasiCount) || 0),
      durum: formatTalepDurum(r.durum),
      detay: r.detay,
      masraf: formatAmount2(Number(r.masraf) || 0)
    }));

    return { aracRows, bankaRows, takbisRows, talepRows };
  };

  const HACIZ_ARAC_HEADER = Object.freeze([
    "Dosya No", "Kişi", "TC Kimlik No", "Plaka", "Marka", "Model", "Ticari Ad", "Renk", "Cins"
  ]);

  const HACIZ_BANKA_HEADER = Object.freeze([
    "Dosya No", "Kişi", "TC Kimlik No", "Banka Adı", "EFT Kodu", "Eşleşen Kurum", "Kurum ID"
  ]);

  const HACIZ_ARAC_FIELD_MAP = Object.freeze({
    "Dosya No": "dosyaNo",
    "Kişi": "kisi",
    "TC Kimlik No": "tcKimlikNo",
    Plaka: "plaka",
    Marka: "marka",
    Model: "model",
    "Ticari Ad": "ticariAd",
    Renk: "renk",
    Cins: "cins"
  });

  const HACIZ_BANKA_FIELD_MAP = Object.freeze({
    "Dosya No": "dosyaNo",
    "Kişi": "kisi",
    "TC Kimlik No": "tcKimlikNo",
    "Banka Adı": "bankaAdi",
    "EFT Kodu": "eftKodu",
    "Eşleşen Kurum": "matchedIlgili",
    "Kurum ID": "matchedId"
  });

  const HACIZ_TAKBIS_HEADER = Object.freeze([
    "Dosya No", "Kişi", "TC Kimlik No", "İl", "İlçe", "Mahalle", "Ada", "Parsel", "Nitelik", "Yüzölçüm", "Bağımsız Bölüm"
  ]);

  const HACIZ_TAKBIS_FIELD_MAP = Object.freeze({
    "Dosya No": "dosyaNo",
    "Kişi": "kisi",
    "TC Kimlik No": "tcKimlikNo",
    "İl": "il",
    "İlçe": "ilce",
    Mahalle: "mahalle",
    Ada: "ada",
    Parsel: "parsel",
    Nitelik: "nitelik",
    "Yüzölçüm": "yuzolcum",
    "Bağımsız Bölüm": "bagimsizBolum"
  });

  const HACIZ_TALEP_HEADER = Object.freeze([
    "Dosya No", "Kişi", "Araç Sayısı", "Banka Sayısı", "Takbis Sayısı", "İcra Dosyası Sayısı", "Durum", "Detay", "Masraf (₺)"
  ]);

  const HACIZ_TALEP_FIELD_MAP = Object.freeze({
    "Dosya No": "dosyaNo",
    "Kişi": "kisi",
    "Araç Sayısı": "aracSayisi",
    "Banka Sayısı": "bankaSayisi",
    "Takbis Sayısı": "takbisSayisi",
    "İcra Dosyası Sayısı": "icraDosyasiSayisi",
    "Durum": "durum",
    "Detay": "detay",
    "Masraf (₺)": "masraf"
  });

  const getFieldValue = (row, header, fieldMap) => {
    const field = fieldMap[header];
    return field ? (row?.[field] ?? "") : "";
  };

  const downloadHacizCsv = (exportData) => {
    const sections = [];

    if (exportData.aracRows.length > 0) {
      const header = HACIZ_ARAC_HEADER;
      sections.push(header.map(csvEscape).join(";"));
      for (const row of exportData.aracRows) {
        sections.push(header.map((h) => csvEscape(getFieldValue(row, h, HACIZ_ARAC_FIELD_MAP))).join(";"));
      }
    }

    if (exportData.bankaRows.length > 0) {
      if (sections.length > 0) {
        sections.push("");
      }
      const header = HACIZ_BANKA_HEADER;
      sections.push(header.map(csvEscape).join(";"));
      for (const row of exportData.bankaRows) {
        sections.push(header.map((h) => csvEscape(getFieldValue(row, h, HACIZ_BANKA_FIELD_MAP))).join(";"));
      }
    }

    if (exportData.takbisRows && exportData.takbisRows.length > 0) {
      if (sections.length > 0) {
        sections.push("");
      }
      const header = HACIZ_TAKBIS_HEADER;
      sections.push(header.map(csvEscape).join(";"));
      for (const row of exportData.takbisRows) {
        sections.push(header.map((h) => csvEscape(getFieldValue(row, h, HACIZ_TAKBIS_FIELD_MAP))).join(";"));
      }
    }

    if (Array.isArray(exportData.talepRows) && exportData.talepRows.length > 0) {
      if (sections.length > 0) {
        sections.push("");
      }
      const header = HACIZ_TALEP_HEADER;
      sections.push(header.map(csvEscape).join(";"));
      for (const row of exportData.talepRows) {
        sections.push(header.map((h) => csvEscape(getFieldValue(row, h, HACIZ_TALEP_FIELD_MAP))).join(";"));
      }
      const toplamMasraf = exportData.talepRows.reduce((s, r) => s + (Number(r.masraf) || 0), 0);
      if (toplamMasraf > 0) {
        sections.push(["", "", "", "", "", "", "", csvEscape("TOPLAM"), csvEscape(toplamMasraf.toFixed(2))].join(";"));
      }
    }

    const content = `\uFEFF${"sep=;\r\n"}${sections.join("\r\n")}`;
    const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    a.href = url;
    a.download = `haciz-${stamp}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const downloadHacizXlsx = (exportData) => {
    const xlsx = window.XLSX;
    if (!xlsx || !xlsx.utils || !xlsx.writeFile) {
      return;
    }

    const wb = xlsx.utils.book_new();

    if (exportData.aracRows.length > 0) {
      const header = HACIZ_ARAC_HEADER;
      const aoa = [header, ...exportData.aracRows.map((row) => header.map((h) => getFieldValue(row, h, HACIZ_ARAC_FIELD_MAP)))];
      const ws = xlsx.utils.aoa_to_sheet(aoa);
      xlsx.utils.book_append_sheet(wb, ws, "AracHaciz");
    }

    if (exportData.bankaRows.length > 0) {
      const header = HACIZ_BANKA_HEADER;
      const aoa = [header, ...exportData.bankaRows.map((row) => header.map((h) => getFieldValue(row, h, HACIZ_BANKA_FIELD_MAP)))];
      const ws = xlsx.utils.aoa_to_sheet(aoa);
      xlsx.utils.book_append_sheet(wb, ws, "BankaHaciz");
    }

    if (exportData.takbisRows && exportData.takbisRows.length > 0) {
      const header = HACIZ_TAKBIS_HEADER;
      const aoa = [header, ...exportData.takbisRows.map((row) => header.map((h) => getFieldValue(row, h, HACIZ_TAKBIS_FIELD_MAP)))];
      const ws = xlsx.utils.aoa_to_sheet(aoa);
      xlsx.utils.book_append_sheet(wb, ws, "TakbisHaciz");
    }

    if (Array.isArray(exportData.talepRows) && exportData.talepRows.length > 0) {
      const header = HACIZ_TALEP_HEADER;
      const dataRows = exportData.talepRows.map((row) => header.map((h) => getFieldValue(row, h, HACIZ_TALEP_FIELD_MAP)));
      const toplamMasraf = exportData.talepRows.reduce((s, r) => s + (Number(r.masraf) || 0), 0);
      if (toplamMasraf > 0) {
        dataRows.push(["", "", "", "", "", "", "", "TOPLAM", toplamMasraf.toFixed(2)]);
      }
      const aoa = [header, ...dataRows];
      const ws = xlsx.utils.aoa_to_sheet(aoa);
      xlsx.utils.book_append_sheet(wb, ws, "TalepSonuclari");
    }

    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    xlsx.writeFile(wb, `haciz-${stamp}.xlsx`, { cellStyles: true });
  };

  const formatHacizRunStatus = (progress) =>
    `Çalışıyor... ${progress.processed}/${progress.total} | Eşleşen: ${progress.matchCount}`;

  const getTalepResultRows = (talepResults) => {
    if (!Array.isArray(talepResults) || talepResults.length === 0) {
      return [];
    }

    const rows = [];
    let toplamMasraf = 0;

    for (const r of aggregateTalepResultsByDosya(talepResults)) {
      const dosya = escHtml(r.dosyaNo || "");
      const kisi = escHtml(r.kisi || "");
      const aracC = Number(r.aracCount) || 0;
      const bankaC = Number(r.bankaCount) || 0;
      const takbisC = Number(r.takbisCount) || 0;
      const icraDosyasiC = Number(r.icraDosyasiCount) || 0;
      const masraf = Number(r.masraf) || 0;
      const countParts = [];

      if (aracC > 0) {
        countParts.push(`${aracC} araç`);
      }
      if (bankaC > 0) {
        countParts.push(`${bankaC} banka`);
      }
      if (takbisC > 0) {
        countParts.push(`${takbisC} takbis`);
      }
      if (icraDosyasiC > 0) {
        countParts.push(`${icraDosyasiC} icra dosyası`);
      }

      const countStr = countParts.join(", ");
      const masrafStr = masraf > 0 ? ` - ${masraf.toFixed(2)} ₺` : "";
      const durum = formatTalepDurum(r.durum);

      if (durum === "Başarılı") {
        toplamMasraf += masraf;
        rows.push(`<span style="color:#1a7a1a">${dosya} -> ${kisi}: ${countStr} gönderildi${masrafStr}</span>`);
        continue;
      }

      if (durum === "Kısmi") {
        toplamMasraf += masraf;
        rows.push(`${dosya} -> ${kisi}: ${escHtml(r.detay || "Kısmi")}${masrafStr}`);
        continue;
      }

      const errMsg = escHtml(r.detay || "Bilinmeyen hata");
      rows.push(`<span class="haciz-error-row">${dosya} -> ${kisi}: ${countStr} başarısız<span class="haciz-error-code"><span class="haciz-error-info" title="${errMsg}">i</span><span class="haciz-tooltip">${errMsg}</span></span></span>`);
    }

    if (toplamMasraf > 0) {
      rows.push(`<br><strong>Toplam Masraf: ${toplamMasraf.toFixed(2)} ₺</strong>`);
    }

    return rows;
  };

  window.MiniIcraHacizUtils = {
    formatHacizResultLine,
    formatHacizErrorHtml,
    getHacizMatchedRows,
    getHacizExportRows,
    downloadHacizCsv,
    downloadHacizXlsx,
    formatHacizRunStatus,
    getTalepResultRows,
    ERROR_CODE_DESCRIPTIONS,
    HACIZ_ARAC_HEADER,
    HACIZ_BANKA_HEADER,
    HACIZ_ARAC_FIELD_MAP,
    HACIZ_BANKA_FIELD_MAP,
    HACIZ_TAKBIS_HEADER,
    HACIZ_TAKBIS_FIELD_MAP,
    HACIZ_TALEP_HEADER,
    HACIZ_TALEP_FIELD_MAP
  };
})();


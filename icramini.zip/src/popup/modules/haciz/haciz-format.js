(function () {
  "use strict";

  if (window.MiniIcraHacizFormat) {
    return;
  }

  const PopupUtils = window.MiniIcraPopupUtils;
  const { fixMojibake } = PopupUtils;

  const ERROR_CODE_DESCRIPTIONS = Object.freeze({
    PRTL_AVKT_10104: "Borçlu hakkındaki icra takibi kesinleştirilmediği için sorgulama yapamazsınız.",
    PRTL_AVKT_10034: "Dış sistemden sorgulama işlemi sırasında hata oluştu.",
    "PRTL_GNL_1-1": "Bu işlem 60 dakikada 1 defa yapılabilmektedir."
  });

  const TALEP_SUB_TYPE_LABELS = Object.freeze({
    AvukatTalepAracHacziDVO: "Arac",
    AvukatTalepGayrimenkulHacziDVO: "Takbis",
    AvukatTalepAlacakliDosyaDVO: "İcra Dosyası"
  });

  const escHtml = (value) =>
    String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");

  const formatHacizErrorHtml = (dosyaNo, kisi, errorCode, errorMessage) => {
    const description = fixMojibake(errorMessage || ERROR_CODE_DESCRIPTIONS[errorCode] || errorCode);
    return (
      `<span class="haciz-error-row">${escHtml(dosyaNo)} - ${escHtml(kisi)} - ` +
      `<span class="haciz-error-code">${escHtml(errorCode)}` +
      `<span class="haciz-error-info" title="${escHtml(description)}">i</span>` +
      `<span class="haciz-tooltip">${escHtml(description)}</span></span></span>`
    );
  };

  const pushBorcluErrorRows = (rows, dosyaNo, kisi, borclu) => {
    const namedErrors = [
      [borclu.aracError, "Araç"],
      [borclu.bankaError, "Banka"],
      [borclu.takbisError, "Takbis"],
      [borclu.icraDosyasiError, "İcra Dosyası"]
    ];

    let hasNamedError = false;
    for (const [error, label] of namedErrors) {
      if (error) {
        hasNamedError = true;
        rows.push(formatHacizErrorHtml(dosyaNo, `${kisi} [${label}]`, error.code, error.message));
      }
    }

    if (borclu.errorCode && !hasNamedError) {
      rows.push(formatHacizErrorHtml(dosyaNo, kisi, borclu.errorCode, borclu.errorMessage));
    }
  };

  const buildDataSummaryParts = ({ araclar, bankalar, takbisler, icraDosyalari, hasIcraDosyasi }) => {
    const parts = [];

    if (araclar.length > 0) {
      parts.push(`${araclar.length} araç`);
    }
    if (bankalar.length > 0) {
      const matched = bankalar.filter((banka) => banka.matchedId);
      const unmatched = bankalar.filter((banka) => !banka.matchedId);
      if (matched.length > 0) {
        parts.push(`${matched.length} banka`);
      }
      if (unmatched.length > 0) {
        const names = unmatched.map((banka) => banka.bankaAdi || "?").join(", ");
        parts.push(`<span style="color:#b8860b" title="${escHtml(names)}">${unmatched.length} eşleşmeyen banka</span>`);
      }
    }
    if (takbisler.length > 0) {
      parts.push(`${takbisler.length} takbis`);
    }
    if (hasIcraDosyasi) {
      parts.push(`${icraDosyalari.length || 1} icra dosyası`);
    }

    return parts;
  };

  const getHacizMatchedRows = (items, source) => {
    const rows = [];

    for (const item of Array.isArray(items) ? items : []) {
      if (!item || !Array.isArray(item.borclular)) {
        continue;
      }
      const dosyaNo = fixMojibake(item.input);

      for (const borclu of item.borclular) {
        const kisi = fixMojibake(borclu.kisi);
        const araclar = Array.isArray(borclu.aracList) ? borclu.aracList : [];
        const bankalar = Array.isArray(borclu.bankaList) ? borclu.bankaList : [];
        const takbisler = Array.isArray(borclu.takbisList) ? borclu.takbisList : [];
        const icraDosyalari = Array.isArray(borclu.icraDosyasiList) ? borclu.icraDosyasiList : [];
        const hasIcraDosyasi = borclu.icraDosyasiVar === true || icraDosyalari.length > 0;
        const hasData = araclar.length > 0 || bankalar.length > 0 || takbisler.length > 0 || hasIcraDosyasi;
        const hasError =
          borclu.aracError || borclu.bankaError || borclu.takbisError || borclu.icraDosyasiError || borclu.errorCode;

        if (source === "result" && !hasData && !hasError) {
          continue;
        }

        pushBorcluErrorRows(rows, dosyaNo, kisi, borclu);

        if (hasData) {
          const parts = buildDataSummaryParts({ araclar, bankalar, takbisler, icraDosyalari, hasIcraDosyasi });
          rows.push(`${escHtml(dosyaNo)} -> ${escHtml(kisi)}: ${parts.join(", ")}`);
        }
      }
    }

    return rows;
  };

  const formatSubResults = (subResults) =>
    subResults
      .map((sub) => `${TALEP_SUB_TYPE_LABELS[sub.type] || "Banka"}: ${sub.success ? "Basarili" : "Basarisiz"}`)
      .join(" | ");

  const aggregateTalepResultsByDosya = (talepResults) => {
    const grouped = new Map();

    for (const result of Array.isArray(talepResults) ? talepResults : []) {
      const dosyaNo = fixMojibake(result.dosyaNo || "");
      if (!grouped.has(dosyaNo)) {
        grouped.set(dosyaNo, {
          dosyaNo,
          kisiler: [],
          aracCount: 0,
          bankaCount: 0,
          takbisCount: 0,
          icraDosyasiCount: 0,
          masraf: 0,
          hasSuccess: false,
          hasPartial: false,
          hasFailure: false,
          details: []
        });
      }

      const entry = grouped.get(dosyaNo);
      const kisi = fixMojibake(result.kisi || "");

      if (kisi && !entry.kisiler.includes(kisi)) {
        entry.kisiler.push(kisi);
      }

      entry.aracCount += Number(result.aracCount) || 0;
      entry.bankaCount += Number(result.bankaCount) || 0;
      entry.takbisCount += Number(result.takbisCount) || 0;
      entry.icraDosyasiCount += Number(result.icraDosyasiCount) || 0;
      entry.masraf = Math.round((entry.masraf + (Number(result.masraf) || 0)) * 100) / 100;

      if (result.success) {
        entry.hasSuccess = true;
        entry.details.push(`${kisi}: Basarili`);
      } else if (result.partial) {
        entry.hasPartial = true;
        const subResults = Array.isArray(result.subResults) ? result.subResults : [];
        entry.details.push(`${kisi}: ${subResults.length > 0 ? formatSubResults(subResults) : "Kismi"}`);
      } else {
        entry.hasFailure = true;
        entry.details.push(`${kisi}: ${result.error || "Bilinmeyen hata"}`);
      }
    }

    return Array.from(grouped.values()).map((entry) => {
      let durum = "Basarisiz";
      if (!entry.hasFailure && !entry.hasPartial && entry.hasSuccess) {
        durum = "Basarili";
      } else if (entry.hasPartial || (entry.hasSuccess && entry.hasFailure)) {
        durum = "Kismi";
      }

      return {
        dosyaNo: entry.dosyaNo,
        kisi: entry.kisiler.join(", "),
        aracCount: entry.aracCount,
        bankaCount: entry.bankaCount,
        takbisCount: entry.takbisCount,
        icraDosyasiCount: entry.icraDosyasiCount,
        masraf: Math.round(entry.masraf * 100) / 100,
        durum,
        detay: entry.details.join(" || ")
      };
    });
  };

  const formatTalepDurum = (durum) => {
    if (durum === "Basarili") {
      return "Başarılı";
    }
    if (durum === "Kismi") {
      return "Kısmi";
    }
    if (durum === "Basarisiz") {
      return "Başarısız";
    }
    return fixMojibake(durum || "");
  };

  const formatHacizRunStatus = (progress) =>
    `Çalışıyor... ${progress.processed}/${progress.total} | Eşleşen: ${progress.matchCount}`;

  const buildTalepCountText = (row) =>
    [
      [Number(row.aracCount) || 0, "araç"],
      [Number(row.bankaCount) || 0, "banka"],
      [Number(row.takbisCount) || 0, "takbis"],
      [Number(row.icraDosyasiCount) || 0, "icra dosyası"]
    ]
      .filter(([count]) => count > 0)
      .map(([count, label]) => `${count} ${label}`)
      .join(", ");

  const getTalepResultRows = (talepResults) => {
    if (!Array.isArray(talepResults) || talepResults.length === 0) {
      return [];
    }

    const rows = [];
    let toplamMasraf = 0;

    for (const row of aggregateTalepResultsByDosya(talepResults)) {
      const dosya = escHtml(row.dosyaNo || "");
      const kisi = escHtml(row.kisi || "");
      const masraf = Number(row.masraf) || 0;
      const countText = buildTalepCountText(row);
      const masrafText = masraf > 0 ? ` - ${masraf.toFixed(2)} ₺` : "";
      const durum = formatTalepDurum(row.durum);

      if (durum === "Başarılı") {
        toplamMasraf += masraf;
        rows.push(`<span style="color:#1a7a1a">${dosya} -> ${kisi}: ${countText} gönderildi${masrafText}</span>`);
        continue;
      }

      if (durum === "Kısmi") {
        toplamMasraf += masraf;
        rows.push(`${dosya} -> ${kisi}: ${escHtml(row.detay || "Kısmi")}${masrafText}`);
        continue;
      }

      const errorText = escHtml(row.detay || "Bilinmeyen hata");
      rows.push(
        `<span class="haciz-error-row">${dosya} -> ${kisi}: ${countText} başarısız` +
          `<span class="haciz-error-code"><span class="haciz-error-info" title="${errorText}">i</span>` +
          `<span class="haciz-tooltip">${errorText}</span></span></span>`
      );
    }

    if (toplamMasraf > 0) {
      rows.push(`<br><strong>Toplam Masraf: ${toplamMasraf.toFixed(2)} ₺</strong>`);
    }

    return rows;
  };

  window.MiniIcraHacizFormat = {
    ERROR_CODE_DESCRIPTIONS,
    aggregateTalepResultsByDosya,
    escHtml,
    formatHacizErrorHtml,
    formatHacizRunStatus,
    formatTalepDurum,
    getHacizMatchedRows,
    getTalepResultRows
  };
})();

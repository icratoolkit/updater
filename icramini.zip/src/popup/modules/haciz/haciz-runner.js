(function () {
  "use strict";

  if (window.MiniIcraHacizRunner) {
    return;
  }

  /**
   * Araç haciz iş akışını başlatır.
   *
   * @param {number} tabId - Hedef tab
   * @param {object} settings - Form ayarları (firstEndpoint, secondHeadersText vs.)
   * @param {Array}  inputs   - parseRowsFromInput ile hazırlanmış girdi dizisi
   * @param {function} cb     - ({ err, response }) callback
   */
  const startHacizRun = (tabId, settings, inputs, cb) => {
    chrome.tabs.sendMessage(
      tabId,
      {
        action: "runHacizInPage",
        settings,
        inputs
      },
      (response) => {
        const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : null;
        if (typeof cb === "function") {
          cb({ err, response: response || null });
        }
      }
    );
  };

  /**
   * Araç haciz iş akışını durdurur.
   *
   * @param {number} tabId
   * @param {function} [cb]
   */
  const stopHacizRun = (tabId, cb) => {
    chrome.tabs.sendMessage(
      tabId,
      { action: "stopHacizInPage" },
      (response) => {
        const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : null;
        if (typeof cb === "function") {
          cb({ err, response: response || null });
        }
      }
    );
  };

  window.MiniIcraHacizRunner = {
    startHacizRun,
    stopHacizRun
  };
})();

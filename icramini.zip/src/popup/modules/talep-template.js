﻿(function () {
  "use strict";

  if (window.MiniIcraTalepTemplate) {
    return;
  }

  const TEMPLATE_PATH = "assets/templates/iban_degisikligi_talebi.udf";

  const toTurkishUpper = (value) => String(value || "").trim().toLocaleUpperCase("tr-TR");

  const sanitizeFileNamePart = (value) =>
    String(value || "")
      .replace(/[\\/:*?"<>|]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();

  const formatDate = (date = new Date(), separator = ".") => {
    const pad = (value) => String(value).padStart(2, "0");
    return `${pad(date.getDate())}${separator}${pad(date.getMonth() + 1)}${separator}${date.getFullYear()}`;
  };

  const splitBirim = (birimAdi) => {
    const upper = toTurkishUpper(birimAdi);
    const match = upper.match(/^(.+?)\s+((?:\d+\.\s+)?(?:GENEL\s+)?(?:İCRA|ICRA)\s+DAİRESİ)$/u);
    if (match) {
      return {
        ilIlce: match[1].trim(),
        ilgiliIcraMudurlugu: match[2].replace(/\bICRA\b/g, "İCRA").trim()
      };
    }

    const parts = upper.split(/\s+/).filter(Boolean);
    return {
      ilIlce: parts[0] || "",
      ilgiliIcraMudurlugu: (parts.slice(1).join(" ") || upper).replace(/\bICRA\b/g, "İCRA")
    };
  };

  const getContentText = (xmlText) => {
    const s = String(xmlText || "");
    return getTextBetween(s, "<content><![CDATA[", "]]></content>");
  };

  const getTextBetween = (text, start, end) => {
    const s = String(text || "");
    const startIndex = s.indexOf(start);
    if (startIndex < 0) {
      return "";
    }
    const contentStart = startIndex + start.length;
    const endIndex = s.indexOf(end, contentStart);
    if (endIndex < 0) {
      return "";
    }
    return s.slice(contentStart, endIndex);
  };

  const sanitizeCdataValue = (value) => String(value ?? "").replace(/\]\]>/g, "");

  const replaceContentText = (xmlText, contentText) =>
    String(xmlText || "").replace(/<content><!\[CDATA\[[\s\S]*?\]\]><\/content>/, `<content><![CDATA[${contentText}]]></content>`);

  const buildMarkerOps = (contentText, replacements) => {
    const ops = [];
    for (const [marker, value] of Object.entries(replacements)) {
      const markerText = String(marker);
      let searchFrom = 0;
      while (searchFrom < contentText.length) {
        const start = contentText.indexOf(markerText, searchFrom);
        if (start < 0) {
          break;
        }
        const nextValue = sanitizeCdataValue(value);
        ops.push({
          start,
          oldLength: markerText.length,
          newLength: nextValue.length,
          delta: nextValue.length - markerText.length,
          value: nextValue
        });
        searchFrom = start + markerText.length;
      }
    }
    return ops.sort((a, b) => a.start - b.start);
  };

  const applyMarkerOps = (contentText, ops) => {
    let next = String(contentText || "");
    for (let i = ops.length - 1; i >= 0; i -= 1) {
      const op = ops[i];
      next = `${next.slice(0, op.start)}${op.value}${next.slice(op.start + op.oldLength)}`;
    }
    return next;
  };

  const shiftAt = (position, ops) =>
    ops.reduce((sum, op) => sum + (op.start < position ? op.delta : 0), 0);

  const updateElementOffsets = (xmlText, ops) =>
    String(xmlText || "").replace(/startOffset="(\d+)" length="(\d+)"/g, (_, startRaw, lengthRaw) => {
      const start = Number(startRaw);
      const end = start + Number(lengthRaw);
      const nextStart = start + shiftAt(start, ops);
      const nextEnd = end + shiftAt(end, ops);
      return `startOffset="${nextStart}" length="${Math.max(0, nextEnd - nextStart)}"`;
    });

  const buildContentXml = (templateXml, replacements) => {
    const contentText = getContentText(templateXml);
    const ops = buildMarkerOps(contentText, replacements);
    const nextContent = applyMarkerOps(contentText, ops);
    const nextXml = replaceContentText(templateXml, nextContent);
    return updateElementOffsets(nextXml, ops);
  };

  const buildTemplateValues = ({ birimAdi, dosyaNo }) => {
    const birim = splitBirim(birimAdi);
    const tarih = formatDate(new Date(), ".");
    return {
      __ILILCE__: birim.ilIlce,
      __ICRADAIRESI__: birim.ilgiliIcraMudurlugu,
      __DOSYANO__: dosyaNo,
      __TARIH__: tarih
    };
  };

  const downloadBytes = (bytes, fileName, mimeType) => {
    const blob = new Blob([bytes], { type: mimeType || "application/octet-stream" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  const loadTemplateFiles = async () => {
    const fflate = window.fflate;
    if (!fflate || typeof fflate.unzipSync !== "function" || typeof fflate.zipSync !== "function") {
      throw new Error("UDF oluşturmak için fflate yüklenemedi.");
    }
    const templateUrl = (() => {
      try {
        if (chrome && chrome.runtime && typeof chrome.runtime.getURL === "function") {
          return chrome.runtime.getURL(TEMPLATE_PATH);
        }
      } catch {
        
      }
      try {
        const core = window.__EWR_PR_Core || {};
        if (core.__EWR_PAGE_BASE_URL__) {
          return new URL(`../../${TEMPLATE_PATH}`, core.__EWR_PAGE_BASE_URL__).toString();
        }
      } catch {
        
      }
      return TEMPLATE_PATH;
    })();
    const response = await fetch(templateUrl);
    if (!response.ok) {
      throw new Error(`Genel talep şablonu okunamadı (HTTP ${response.status}).`);
    }
    const bytes = new Uint8Array(await response.arrayBuffer());
    const files = fflate.unzipSync(bytes);
    if (!files["content.xml"]) {
      throw new Error("Genel talep şablonunda content.xml bulunamadı.");
    }
    return files;
  };

  const buildUdfFiles = async (rows) => {
    const fflate = window.fflate;
    const files = await loadTemplateFiles();
    const templateXml = fflate.strFromU8(files["content.xml"]);
    const todayForName = formatDate(new Date(), "_");

    return rows.map((row) => {
      const dosyaNo = String(row.dosyaNo || "").trim();
      const birimAdi = String(row.birimAdi || "").trim();
      const contentXml = buildContentXml(templateXml, buildTemplateValues({ birimAdi, dosyaNo }));
      const nextFiles = { ...files, "content.xml": fflate.strToU8(contentXml) };
      const udfBytes = fflate.zipSync(nextFiles, { level: 6 });
      const safeDosya = sanitizeFileNamePart(dosyaNo.replace(/\//g, "_"));
      const safeBirim = sanitizeFileNamePart(birimAdi || "Birim");
      return {
        fileName: `${safeDosya} - ${safeBirim} - Avukat Portal Genel Talebi - ${todayForName}.udf`,
        bytes: udfBytes,
        dosyaNo,
        birimAdi
      };
    });
  };

  const downloadGeneratedUdfs = async (rows) => {
    const fflate = window.fflate;
    const generated = await buildUdfFiles(rows);
    if (generated.length === 0) {
      return { count: 0 };
    }
    if (generated.length === 1) {
      downloadBytes(generated[0].bytes, generated[0].fileName, "application/octet-stream");
      return { count: 1, files: generated };
    }

    const zipFiles = {};
    for (const item of generated) {
      zipFiles[item.fileName] = item.bytes;
    }
    const zipBytes = fflate.zipSync(zipFiles, { level: 6 });
    downloadBytes(zipBytes, `genel-talep-evraklari-${formatDate(new Date(), "_")}.zip`, "application/zip");
    return { count: generated.length, files: generated, zipped: true };
  };

  window.MiniIcraTalepTemplate = {
    downloadGeneratedUdfs,
    buildUdfFiles,
    splitBirim,
    formatDate
  };
})();

(function () {
  "use strict";

  if (window.MiniIcraPopupHesap) {
    return;
  }

  const HesapCore = window.MiniIcraPopupHesapCore || {};
  const HesapParser = window.MiniIcraPopupHesapParser || {};
  const HesapCalculation = window.MiniIcraPopupHesapCalculation || {};

  window.MiniIcraPopupHesap = {
    parseUpload: HesapParser.parseUpload || (async () => ({})),
    parseSupplementText: HesapParser.parseSupplementText || (() => ({})),
    calculateResult: HesapCalculation.calculateResult || (() => null),
    mergeParsedIntoExistingResult: HesapCalculation.mergeParsedIntoExistingResult || (() => null),
    numberOrNull: HesapCore.numberOrNull || (() => null)
  };
})();

﻿(function () {
  "use strict";

  if (window.MiniIcraPopupDosya) {
    return;
  }

  const syncDosyaHesapTuruVisibility = (els) => {
    if (!els || !els.dosyaIndirimWrap || !els.dosyaHesabiHesapTuru) {
      return;
    }
    const isIndirim = String(els.dosyaHesabiHesapTuru.value || "normal") === "indirim";
    els.dosyaIndirimWrap.style.display = isIndirim ? "" : "none";
  };

  window.MiniIcraPopupDosya = {
    syncDosyaHesapTuruVisibility
  };
})();

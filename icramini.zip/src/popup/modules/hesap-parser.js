(function () {
  "use strict";

  if (window.MiniIcraPopupHesapParser) {
    return;
  }

  const HesapCore = window.MiniIcraPopupHesapCore || {};
  const SharedNormalizers = window.MiniIcraHesapNormalizers || {};
  const SharedExtractors = window.MiniIcraHesapExtractors || {};
  const {
    guessDosyaNoFromFilename,
    parseDateFromFilename
  } = HesapCore;
  const { normalizeText, numberOrNull } = SharedNormalizers;
  const { extractTakipTalebiAmountsFromContentXml } = SharedExtractors;

  const readFileAsArrayBuffer = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error || new Error("Dosya okunamadi."));
      reader.readAsArrayBuffer(file);
    });

  const readFileAsText = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ""));
      reader.onerror = () => reject(reader.error || new Error("Dosya okunamadi."));
      reader.readAsText(file, "utf-8");
    });

  const LOCAL_FILE_HEADER_SIGNATURE = 0x04034b50;

  const getUint16Le = (bytes, offset) => bytes[offset] | (bytes[offset + 1] << 8);

  const getUint32Le = (bytes, offset) =>
    ((bytes[offset]) | (bytes[offset + 1] << 8) | (bytes[offset + 2] << 16) | (bytes[offset + 3] << 24)) >>> 0;

  const decodeZipEntryName = (bytes) => {
    try {
      return new TextDecoder("utf-8", { fatal: false }).decode(bytes);
    } catch {
      return String.fromCharCode(...bytes);
    }
  };

  const inflateZipEntryFallback = (compressedBytes) => {
    const inflateSync = window.fflate && typeof window.fflate.inflateSync === "function" ? window.fflate.inflateSync : null;
    if (!inflateSync) {
      throw new Error("ZIP icerigi acilamadi.");
    }

    const trims = [0, 12, 16, 20, 24, 28];
    for (const trim of trims) {
      if (compressedBytes.length <= trim) {
        continue;
      }
      try {
        return inflateSync(compressedBytes.subarray(0, compressedBytes.length - trim));
      } catch {
        
      }
    }

    return inflateSync(compressedBytes);
  };

  const unzipFromLocalHeaders = (bytes) => {
    const files = {};
    const headerOffsets = [];

    for (let offset = 0; offset <= bytes.length - 4; offset += 1) {
      if (getUint32Le(bytes, offset) === LOCAL_FILE_HEADER_SIGNATURE) {
        headerOffsets.push(offset);
      }
    }

    for (let index = 0; index < headerOffsets.length; index += 1) {
      const headerOffset = headerOffsets[index];
      const nameLength = getUint16Le(bytes, headerOffset + 26);
      const extraLength = getUint16Le(bytes, headerOffset + 28);
      const compressionMethod = getUint16Le(bytes, headerOffset + 8);
      const nameStart = headerOffset + 30;
      const nameEnd = nameStart + nameLength;
      const dataStart = nameEnd + extraLength;
      const dataEnd = index + 1 < headerOffsets.length ? headerOffsets[index + 1] : bytes.length;
      const fileName = decodeZipEntryName(bytes.subarray(nameStart, nameEnd));
      const payload = bytes.subarray(dataStart, dataEnd);

      if (!fileName) {
        continue;
      }

      if (compressionMethod === 0) {
        files[fileName] = payload;
      } else if (compressionMethod === 8) {
        files[fileName] = inflateZipEntryFallback(payload);
      }
    }

    return files;
  };

  const extractXmlTextFromFile = async (file) => {
    if (!file) {
      throw new Error("Dosya secilmedi.");
    }

    const fileName = String(file.name || "");
    if (/\.xml$/i.test(fileName)) {
      const xmlText = await readFileAsText(file);
      return { xmlText, source: fileName };
    }

    const unzipSync = window.fflate && typeof window.fflate.unzipSync === "function" ? window.fflate.unzipSync : null;
    if (!unzipSync) {
      throw new Error("ZIP cozumleyici bulunamadi.");
    }

    const fileBuffer = await readFileAsArrayBuffer(file);
    const byteArray = new Uint8Array(fileBuffer);
    let files;
    try {
      files = unzipSync(byteArray);
    } catch (error) {
      files = unzipFromLocalHeaders(byteArray);
      if (!files || Object.keys(files).length === 0) {
        throw error;
      }
    }

    const names = Object.keys(files || {});
    const contentKey = names.find((name) => /(^|\/)content\.xml$/i.test(String(name || "")));
    if (!contentKey) {
      throw new Error("ZIP icinde content.xml bulunamadi.");
    }

    const xmlBytes = files[contentKey];
    const xmlText = new TextDecoder("utf-8", { fatal: false }).decode(xmlBytes);
    return { xmlText, source: contentKey };
  };

  const parseUpload = async (file) => {
    const fileName = String(file?.name || "");
    const { xmlText, source } = await extractXmlTextFromFile(file);
    return {
      fileName,
      source,
      xmlText,
      parsed: extractTakipTalebiAmountsFromContentXml(xmlText),
      dosyaNo: guessDosyaNoFromFilename(fileName),
      talepTarihi: parseDateFromFilename(fileName)
    };
  };

  const FIELD_MATCHERS = [
    { field: "basvurmaHarci", patterns: ["basvuru harci", "basvurma harci"] },
    { field: "tebligatGideri", patterns: ["tebligat gideri"] },
    { field: "vekaletSuretHarci", patterns: ["vekalet suret harci"] },
    { field: "pesinHarc", patterns: ["pesin harc", "pesin harci"] },
    { field: "tahsilHarciHesap", patterns: ["tahsil harci"] },
    { field: "vekaletUcretiDosyaHesap", patterns: ["icra vekalet ucreti", "vekalet ucreti"] },
    { field: "vekaletPulu", patterns: ["vekalet pulu"] },
    { field: "asilAlacak", patterns: ["asil alacak"] },
    { field: "gecmisGunFaizi", patterns: ["gecmis gun faizi"] },
    { field: "mahkemeVekaletUcreti", patterns: ["ilam vekalet ucreti", "mahkeme vekalet ucreti"] },
    { field: "mahkemeVekaletUcretiFaizi", patterns: ["ivu gecmis gun faizi", "mahkeme vekalet ucreti faizi"] },
    { field: "mahkemeYargilamaGiderleri", patterns: ["yargilama gideri", "mahkeme yargilama giderleri"] },
    { field: "mahkemeYargilamaGiderleriFaizi", patterns: ["yg gecmis gun faizi", "mahkeme yargilama giderleri faizi"] },
    { field: "mahkemeHarclari", patterns: ["mahkeme harclari", "harc"] },
    { field: "mahkemeHarclariFaizi", patterns: ["harc gecmis gun faizi", "mahkeme harclari faizi"] }
  ];

  const findFieldForLabel = (label) => {
    const normalized = normalizeText(label);
    for (const matcher of FIELD_MATCHERS) {
      if (matcher.patterns.some((pattern) => normalized.includes(pattern))) {
        return matcher.field;
      }
    }
    return "";
  };

  const parseSupplementText = (rawText) => {
    const output = {};
    const lines = String(rawText || "")
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean);

    for (const line of lines) {
      const parts = line.split(/\t|;|:|\s{2,}/).map((part) => part.trim()).filter(Boolean);
      let label = "";
      let valueText = "";

      if (parts.length >= 2) {
        label = parts.slice(0, -1).join(" ");
        valueText = parts[parts.length - 1];
      } else {
        const match = line.match(/^(.*?)([-]|\d[\d.,]*)\s*$/);
        if (!match) {
          continue;
        }
        label = match[1].trim();
        valueText = match[2].trim();
      }

      const field = findFieldForLabel(label);
      if (!field) {
        continue;
      }
      output[field] = numberOrNull(valueText);
    }

    return output;
  };

  window.MiniIcraPopupHesapParser = {
    extractTakipTalebiAmountsFromContentXml,
    numberOrNull,
    parseSupplementText,
    parseUpload
  };
})();

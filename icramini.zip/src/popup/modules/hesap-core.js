(function () {
  "use strict";

  if (window.MiniIcraPopupHesapCore) {
    return;
  }

  const { fixMojibake, normalizeText } = window.MiniIcraTextUtils;

  const THOUSANDS_SEPARATOR = /\.(?=\d{3}(?:\D|$))/g;

  // Girdi sayı olsa bile metne çevrilip aynı kurallardan geçer; bu yüzden üç
  // ondalıklı değerler (5.678) binlik ayırıcı sayılır. Dosya hesabı çıktılarıyla
  // uyumlu kalsın diye davranış korundu.
  const numberOrNull = (value) => {
    if (value === null || typeof value === "undefined") {
      return null;
    }
    const raw = String(value).trim();
    if (!raw || raw === "-") {
      return null;
    }
    const normalized = raw.replace(/\s+/g, "").replace(THOUSANDS_SEPARATOR, "").replace(",", ".");
    const parsed = Number(normalized);
    return Number.isFinite(parsed) ? Number(parsed.toFixed(2)) : null;
  };

  const sumNumericAmounts = (values) => {
    const numbers = (Array.isArray(values) ? values : []).map(numberOrNull).filter((x) => x !== null);
    if (numbers.length === 0) {
      return null;
    }
    return Number(numbers.reduce((total, x) => total + x, 0).toFixed(2));
  };

  const parseDateFromFilename = (name) => {
    const match = String(name || "").match(/(\d{2})_(\d{2})_(\d{4})/);
    return match ? `${match[3]}-${match[2]}-${match[1]}` : "";
  };

  const guessDosyaNoFromFilename = (name) => {
    const match = String(name || "").match(/(?:^|_)(\d{4})_(\d+)(?:\b|[^0-9])/);
    return match ? `${match[1]}/${match[2]}` : "";
  };

  window.MiniIcraPopupHesapCore = {
    fixMojibake,
    guessDosyaNoFromFilename,
    normalizeText,
    numberOrNull,
    parseDateFromFilename,
    sumNumericAmounts
  };
})();

(function () {
  "use strict";

  if (window.MiniIcraPopupHesapCore) {
    return;
  }

  const PopupUtils = window.MiniIcraPopupUtils || {};
  const TextUtils = window.MiniIcraTextUtils || {};
  const fixMojibake = PopupUtils.fixMojibake || ((value) => String(value || ""));
  const normalizeText =
    typeof TextUtils.normalizeText === "function"
      ? TextUtils.normalizeText
      : ((value) =>
          fixMojibake(value)
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .toLocaleLowerCase("tr-TR")
            .replace(/ı/g, "i")
            .replace(/ÄŸ/g, "g")
            .replace(/ş/g, "s")
            .replace(/ç/g, "c")
            .replace(/ö/g, "o")
            .replace(/Ã¼/g, "u")
            .replace(/\s+/g, " ")
            .trim());

  const numberOrNull = (value) => {
    if (value === null || typeof value === "undefined") {
      return null;
    }
    const raw = String(value).trim();
    if (!raw || raw === "-") {
      return null;
    }
    const normalized = raw
      .replace(/\s+/g, "")
      .replace(/\.(?=\d{3}(?:\D|$))/g, "")
      .replace(",", ".");
    const n = Number(normalized);
    return Number.isFinite(n) ? Number(n.toFixed(2)) : null;
  };

  const sumNumericAmounts = (values) => {
    const nums = (Array.isArray(values) ? values : []).map(numberOrNull).filter((x) => x !== null);
    if (nums.length === 0) {
      return null;
    }
    return Number(nums.reduce((acc, x) => acc + x, 0).toFixed(2));
  };

  const addAmount = (currentValue, nextValue) => {
    const current = numberOrNull(currentValue);
    const next = numberOrNull(nextValue);
    if (next === null) {
      return current;
    }
    if (current === null) {
      return next;
    }
    return Number((current + next).toFixed(2));
  };

  const parseDateFromFilename = (name) => {
    const match = String(name || "").match(/(\d{2})_(\d{2})_(\d{4})/);
    if (!match) {
      return "";
    }
    return `${match[3]}-${match[2]}-${match[1]}`;
  };

  const guessDosyaNoFromFilename = (name) => {
    const match = String(name || "").match(/(?:^|_)(\d{4})_(\d+)(?:\b|[^0-9])/);
    return match ? `${match[1]}/${match[2]}` : "";
  };

  window.MiniIcraPopupHesapCore = {
    addAmount,
    fixMojibake,
    guessDosyaNoFromFilename,
    normalizeText,
    numberOrNull,
    parseDateFromFilename,
    sumNumericAmounts
  };
})();

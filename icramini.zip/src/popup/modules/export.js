﻿(function () {
  "use strict";

  if (window.MiniIcraPopupExport) {
    return;
  }

  const PopupUtils = window.MiniIcraPopupUtils || {};
  const fixMojibake = PopupUtils.fixMojibake || ((s) => String(s || ""));
  const formatAmount2 = PopupUtils.formatAmount2 || ((value) => (Number.isFinite(Number(value)) ? Number(value).toFixed(2) : String(value ?? "")));
  const formatOptionalAmount2 = PopupUtils.formatOptionalAmount2 || ((value) => {
    if (value === null || typeof value === "undefined" || String(value).trim() === "") {
      return "-";
    }
    return formatAmount2(value);
  });
  const buildKesinlestirmeGroups = PopupUtils.buildKesinlestirmeGroups || (() => []);
  const csvEscape = PopupUtils.csvEscape || ((value) => `"${String(value ?? "").replace(/"/g, '""')}"`);
  const getRowValueByHeader = PopupUtils.getRowValueByHeader || (() => "");
  const XLSX_NUMERIC_HEADERS = PopupUtils.XLSX_NUMERIC_HEADERS || new Set();
  const toXlsxNumberIfPossible = PopupUtils.toXlsxNumberIfPossible || ((value) => value);

  const centerSheetCells = (xlsx, ws) => {
    if (!xlsx || !ws || !ws["!ref"]) {
      return;
    }
    const range = xlsx.utils.decode_range(ws["!ref"]);
    for (let r = range.s.r; r <= range.e.r; r += 1) {
      for (let c = range.s.c; c <= range.e.c; c += 1) {
        const cellRef = xlsx.utils.encode_cell({ r, c });
        const cell = ws[cellRef];
        if (!cell) {
          continue;
        }
        cell.s = cell.s || {};
        cell.s.alignment = { horizontal: "center", vertical: "center", wrapText: true };
      }
    }
  };

  const getExportData = (resultObj, mode) => {
    if (!resultObj || !Array.isArray(resultObj.items)) {
      return { mode: String(mode || "normal"), header: [], rows: [] };
    }

    if (mode === "kesinlestirme") {
      const rows = [];
      for (const item of resultObj.items) {
        if (!item || !item.isMatch) {
          continue;
        }
        const dosyaNo = String(item.input || "");
        const birimAdi = fixMojibake(item.birimAdi || "");
        const groups = buildKesinlestirmeGroups(item.tebligDetaylari);
        let kisiNo = 0;
        for (const g of groups) {
          kisiNo += 1;
          let tebligatNo = 0;
          for (const d of g.details) {
            tebligatNo += 1;
            rows.push({
              birimAdi,
              dosyaNo: fixMojibake(dosyaNo),
              kisiNo,
              tebligatNo,
              kisi: fixMojibake(g.kisi || ""),
              tebligTarihi: fixMojibake(d.tebligTarihi || ""),
              barkod: fixMojibake(d.barkod || "")
            });
          }
        }
      }
      return {
        mode,
        header: ["Birim", "Dosya No", "Kişi No", "Tebligat No", "Kişi", "Tebliğ Tarihi", "Barkod"],
        rows
      };
    }

    if (mode === "dosyaHesabi") {
      const matchedRows = resultObj.items.filter((x) => {
        if (!x) {
          return false;
        }
        if (x.isMatch === true) {
          return true;
        }
        return [
          x.talepTarihi,
          x.asilAlacak,
          x.gecmisGunFaizi,
          x.toplamBorcHesap,
          x.mahkemeYargilamaGiderleri,
          x.mahkemeVekaletUcreti,
          x.mahkemeHarclari
        ].some((value) => value !== null && typeof value !== "undefined" && String(value).trim() !== "");
      });
      const includeIndirimFields = matchedRows.some((x) => String(x?.dosyaHesabiHesapTuru || "normal") === "indirim");
      const includeVazgecmeFields = matchedRows.some((x) => String(x?.dosyaHesabiHesapTuru || "normal") === "vazgecme");
      const rows = matchedRows.map((x) => {
        const row = {
          birimAdi: fixMojibake(x.birimAdi || ""),
          dosyaNo: fixMojibake(x.input),
          talepTarihi: fixMojibake(x.talepTarihi),
          tebligTarihi: fixMojibake(x.tebligTarihi || ""),
          asilAlacak: formatOptionalAmount2(x.asilAlacak),
          gecmisGunFaizi: formatOptionalAmount2(x.gecmisGunFaizi),
          vekaletPulu: formatOptionalAmount2(x.vekaletPulu),
          tebligatGideri: formatOptionalAmount2(x.tebligatGideri),
          pesinHarc: formatOptionalAmount2(x.pesinHarc),
          basvurmaHarci: formatOptionalAmount2(x.basvurmaHarci),
          vekaletSuretHarci: formatOptionalAmount2(x.vekaletSuretHarci),
          tahsilHarciHesap: formatOptionalAmount2(x.tahsilHarciHesap),
          takipteKesinlesenMiktar: formatOptionalAmount2(x.takipteKesinlesenMiktar),
          vekaletUcretiDosyaHesap: formatOptionalAmount2(x.vekaletUcretiDosyaHesap),
          icraFaizTutari: formatOptionalAmount2(x.icraFaizTutari),
          danismanlikUcreti: formatOptionalAmount2(x.danismanlikUcreti),
          toplamBorcHesap: formatOptionalAmount2(x.toplamBorcHesap),
          masrafToplami: formatOptionalAmount2(x.masrafToplami),
          anaPara: formatOptionalAmount2((x.anaPara ?? ((Number(x.asilAlacak) || 0) + (Number(x.gecmisGunFaizi) || 0) + (Number(x.icraFaizTutari) || 0)))),
          hakEdis: formatOptionalAmount2((x.hakEdis ?? ((((Number(x.anaPara) || ((Number(x.asilAlacak) || 0) + (Number(x.gecmisGunFaizi) || 0) + (Number(x.icraFaizTutari) || 0)))) - (Number(x.danismanlikUcreti) || 0))))),
          mahkemeVekaletUcreti: formatOptionalAmount2(x.mahkemeVekaletUcreti),
          mahkemeVekaletUcretiFaizi: formatOptionalAmount2(x.mahkemeVekaletUcretiFaizi),
          mahkemeYargilamaGiderleri: formatOptionalAmount2(x.mahkemeYargilamaGiderleri),
          mahkemeYargilamaGiderleriFaizi: formatOptionalAmount2(x.mahkemeYargilamaGiderleriFaizi),
          ygIcraFaiz: formatOptionalAmount2(x.ygIcraFaiz),
          mahkemeHarclari: formatOptionalAmount2(x.mahkemeHarclari),
          mahkemeHarclariFaizi: formatOptionalAmount2(x.mahkemeHarclariFaizi),
          harcIcraFaiz: formatOptionalAmount2(x.harcIcraFaiz),
          ivuIcraFaiz: formatOptionalAmount2(x.ivuIcraFaiz),
          takibinTuruAciklama: fixMojibake(x.takibinTuruAciklama || ""),
          dosyaHesabiHesapTuru: fixMojibake(x.dosyaHesabiHesapTuru || "normal")
        };

        if (includeIndirimFields) {
          row.indirimTutari = formatOptionalAmount2(x.indirimTutari);
          row.indirimYeniAsilAlacak = formatOptionalAmount2(x.indirimYeniAsilAlacak);
          row.indirimYeniDanismanlikUcreti = formatOptionalAmount2(x.indirimYeniDanismanlikUcreti);
          row.indirimliToplamBorc = formatOptionalAmount2(x.indirimliToplamBorc);
        }

        return row;
      });

      return {
        mode,
        header: [
          "Birim",
          "Dosya No",
          "Talep Tarihi",
          "Tebliğ Edildiği Tarih",
          "Asıl Alacak",
          "Geçmiş Gün Faizi",
          "Hesaplanan Faiz (Asıl Alacak)",
          "Danışmanlık Ücreti (%20)",
          "Yargılama Gideri",
          "YG Geçmiş Gün Faizi",
          "YG Hesaplanan Faiz",
          "Harç",
          "Harç Geçmiş Gün Faizi",
          "Harç Hesaplanan Faiz",
          "İlam Vekalet Ücreti",
          "İVÜ Geçmiş Gün Faizi",
          "İVÜ Hesaplanan Faiz",
          "Vekalet Pulu",
          "Tebligat Gideri",
          "Başvurma Harcı",
          "Vekalet Suret Harcı",
          "Peşin Harç",
          "Tahsil Harcı",
          "İcra Vekalet Ücreti",
          "Masraf Toplamı",
          ...(includeVazgecmeFields ? ["Ana Para", "Hakediş"] : []),
          ...(includeIndirimFields ? ["İndirim Tutarı", "Yeni Asıl Alacak", "Yeni Danışmanlık Ücreti", "İndirimli Toplam Borç"] : []),
          "Toplam Borç",
          "Takip Türü"
        ],
        rows
      };
    }

    if (mode === "reddiyat") {
      const rows = [];
      for (const item of resultObj.items) {
        if (!item || !Array.isArray(item.reddiyatKalemleri)) {
          continue;
        }
        for (const kalem of item.reddiyatKalemleri) {
          if (!kalem) {
            continue;
          }
          rows.push({
            birimAdi: fixMojibake(kalem.birimAdi || ""),
            dosyaNo: fixMojibake(kalem.dosyaNo || item.input),
            tahsilatTuru: fixMojibake(kalem.tahsilatTuru || ""),
            kalanMiktar: formatOptionalAmount2(kalem.kalanMiktar)
          });
        }
      }
      return {
        mode,
        header: ["Birim", "Dosya No", "Tahsilat Türü", "Kalan Miktar"],
        rows
      };
    }

    if (mode === "talepKesinlestirme") {
      const rows = [];
      for (const x of resultObj.items) {
        if (!x || !(x.success || x.partialSuccess || x.error)) {
          continue;
        }
        const borcluResults = Array.isArray(x.borcluResults) && x.borcluResults.length > 0
          ? x.borcluResults
          : [{ ok: !!x.success, borclu: x.talepBorclu || x.kisiKurumId || "Borçlu", error: x.error || x.message || "" }];
        for (const r of borcluResults) {
          const ok = !!(r && r.ok);
          rows.push({
            birimAdi: fixMojibake(x.birimAdi || ""),
            dosyaNo: fixMojibake(x.input),
            borclu: fixMojibake((r && (r.borclu || r.kisiKurumId)) || "Borçlu"),
            durum: ok ? "Başarılı" : "Başarısız"
          });
        }
      }
      return {
        mode,
        header: ["Birim", "Dosya No", "Borçlu", "Durum"],
        rows
      };
    }

    if (mode === "talepMasrafAvansIadesi" || mode === "talepBorcluOdemeAktar" || mode === "talepEvrakiOlustur") {
      const rows = resultObj.items
        .filter((x) => x && (x.success || x.error))
        .map((x) => ({
          birimAdi: fixMojibake(x.birimAdi || ""),
          dosyaNo: fixMojibake(x.input),
          talepAdi: fixMojibake(x.talepAdi || "Talep"),
          durum: x.success ? "Gönderildi" : "Hata",
          message: fixMojibake(x.message || x.error || "")
        }));
      return {
        mode,
        header: ["Birim", "Dosya No", "Talep", "Durum", "Mesaj"],
        rows
      };
    }

    if (mode === "kalan") {
      const rows = resultObj.items
        .filter((x) => x && x.isMatch)
        .map((x) => ({
          birimAdi: fixMojibake(x.birimAdi || ""),
          dosyaNo: fixMojibake(x.input),
          kalanBorc: formatOptionalAmount2(x.kalanBorc),
          kalanQueryThreshold: formatOptionalAmount2(x.kalanQueryThreshold),
          yatanPara: formatOptionalAmount2(x.yatanPara)
        }));
      return {
        mode,
        header: ["Birim", "Dosya No", "Kalan Borç", "Üst Sınır", "Yatan Para"],
        rows
      };
    }

    const rows = resultObj.items
      .filter((x) => Number(x.yatanPara) > 0)
      .map((x) => ({
        birimAdi: fixMojibake(x.birimAdi || ""),
        dosyaNo: fixMojibake(x.input),
        yatanPara: formatAmount2(x.yatanPara),
        kalanBorc: formatOptionalAmount2(x.kalanBorc)
      }));
    return {
      mode,
      header: ["Birim", "Dosya No", "Yatan Para", "Kalan Borç"],
      rows
    };
  };

  const downloadExcelCsv = (header, rows, mode) => {
    const lines = ["sep=;", header.map(csvEscape).join(";")];

    for (const row of rows) {
      const values = header.map((h) => getRowValueByHeader(row, h));
      lines.push(values.map(csvEscape).join(";"));
    }

    const content = `\uFEFF${lines.join("\r\n")}`;
    const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    a.href = url;
    a.download = `${mode === "kesinlestirme" ? "kesinlestirme" : mode === "dosyaHesabi" ? "dosya-hesabi" : mode === "reddiyat" ? "reddiyat" : (mode === "talepMasrafAvansIadesi" || mode === "talepBorcluOdemeAktar" || mode === "talepKesinlestirme" || mode === "talepEvrakiOlustur") ? "talep" : "yatan-para"}-${stamp}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const downloadExcelXlsx = (header, rows, mode) => {
    const xlsx = window.XLSX;
    if (!xlsx || !xlsx.utils || !xlsx.writeFile) {
      downloadExcelCsv(header, rows, mode);
      return;
    }

    if (mode === "dosyaHesabi") {
      const includeIndirimFields = Array.isArray(header) && header.includes("İndirim Tutarı");
      const includeVazgecmeFields = Array.isArray(header) && header.includes("Ana Para");
      const aoa = [["Alan", "Değer"]];
      const orderedFields = [
        ["Birim", "birimAdi"],
        ["Dosya No", "dosyaNo"],
        ["Talep Tarihi", "talepTarihi"],
        ["Tebliğ Edildiği Tarih", "tebligTarihi"],
        ["Asıl Alacak", "asilAlacak"],
        ["Geçmiş Gün Faizi", "gecmisGunFaizi"],
        ["Hesaplanan Faiz (Asıl Alacak)", "icraFaizTutari"],
        ["Danışmanlık Ücreti (%20)", "danismanlikUcreti"],
        ["Yargılama Gideri", "mahkemeYargilamaGiderleri"],
        ["YG Geçmiş Gün Faizi", "mahkemeYargilamaGiderleriFaizi"],
        ["YG Hesaplanan Faiz", "ygIcraFaiz"],
        ["Harç", "mahkemeHarclari"],
        ["Harç Geçmiş Gün Faizi", "mahkemeHarclariFaizi"],
        ["Harç Hesaplanan Faiz", "harcIcraFaiz"],
        ["İlam Vekalet Ücreti", "mahkemeVekaletUcreti"],
        ["İVÜ Geçmiş Gün Faizi", "mahkemeVekaletUcretiFaizi"],
        ["İVÜ Hesaplanan Faiz", "ivuIcraFaiz"],
        ["Vekalet Pulu", "vekaletPulu"],
        ["Tebligat Gideri", "tebligatGideri"],
        ["Başvurma Harcı", "basvurmaHarci"],
        ["Vekalet Suret Harcı", "vekaletSuretHarci"],
        ["Peşin Harç", "pesinHarc"],
        ["Tahsil Harcı", "tahsilHarciHesap"],
        ["İcra Vekalet Ücreti", "vekaletUcretiDosyaHesap"],
        ["Masraf Toplamı", "masrafToplami"],
        ["Ana Para", "anaPara"],
        ["Hakediş", "hakEdis"],
        ["Toplam Borç", "toplamBorcHesap"],
        ["Takip Türü", "takibinTuruAciklama"]
      ];

      if (!includeVazgecmeFields) {
        const idx = orderedFields.findIndex((x) => x[0] === "Ana Para");
        if (idx >= 0) {
          orderedFields.splice(idx, 2);
        }
      }

      if (includeIndirimFields) {
        orderedFields.splice(
          orderedFields.findIndex((x) => x[0] === "Toplam Borç"),
          0,
          ["İndirim Tutarı", "indirimTutari"],
          ["Yeni Asıl Alacak", "indirimYeniAsilAlacak"],
          ["Yeni Danışmanlık Ücreti", "indirimYeniDanismanlikUcreti"],
          ["İndirimli Toplam Borç", "indirimliToplamBorc"]
        );
      }

      for (const row of rows) {
        for (const [label, key] of orderedFields) {
          const value = row && Object.prototype.hasOwnProperty.call(row, key) ? row[key] : "";
          const out = XLSX_NUMERIC_HEADERS.has(label) ? toXlsxNumberIfPossible(value) : (value ?? "");
          aoa.push([label, out]);
        }
        aoa.push(["", ""]);
      }

      const ws = xlsx.utils.aoa_to_sheet(aoa);
      ws["!cols"] = [{ wch: 34 }, { wch: 24 }];
      const wb = xlsx.utils.book_new();
      centerSheetCells(xlsx, ws);
      xlsx.utils.book_append_sheet(wb, ws, "DosyaHesabi");
      const stamp = new Date().toISOString().replace(/[:.]/g, "-");
      xlsx.writeFile(wb, `dosya-hesabi-${stamp}.xlsx`, { cellStyles: true });
      return;
    }

    const aoa = [header];
    for (const row of rows) {
      aoa.push(
        header.map((h) => {
          const value = getRowValueByHeader(row, h);
          return XLSX_NUMERIC_HEADERS.has(h) ? toXlsxNumberIfPossible(value) : value;
        })
      );
    }

    const ws = xlsx.utils.aoa_to_sheet(aoa);
    centerSheetCells(xlsx, ws);
    if (mode === "talepKesinlestirme") {
      for (let i = 0; i < rows.length; i += 1) {
        if (String(rows[i]?.durum || "").toLocaleLowerCase("tr-TR") !== "başarısız") {
          continue;
        }
        for (let c = 0; c < header.length; c += 1) {
          const cellRef = xlsx.utils.encode_cell({ r: i + 1, c });
          const cell = ws[cellRef];
          if (!cell) {
            continue;
          }
          cell.s = cell.s || {};
          cell.s.fill = { patternType: "solid", fgColor: { rgb: "FEE4E2" } };
          cell.s.font = { color: { rgb: "B42318" }, bold: true };
          cell.s.alignment = { horizontal: "center", vertical: "center", wrapText: true };
        }
      }
    }
    const wb = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, mode === "kesinlestirme" ? "Kesinlestirme" : mode === "dosyaHesabi" ? "DosyaHesabi" : mode === "reddiyat" ? "Reddiyat" : (mode === "talepMasrafAvansIadesi" || mode === "talepBorcluOdemeAktar" || mode === "talepKesinlestirme" || mode === "talepEvrakiOlustur") ? "Talep" : "YatanPara");
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    const file = `${mode === "kesinlestirme" ? "kesinlestirme" : mode === "dosyaHesabi" ? "dosya-hesabi" : mode === "reddiyat" ? "reddiyat" : (mode === "talepMasrafAvansIadesi" || mode === "talepBorcluOdemeAktar" || mode === "talepKesinlestirme" || mode === "talepEvrakiOlustur") ? "talep" : "yatan-para"}-${stamp}.xlsx`;
    xlsx.writeFile(wb, file, { cellStyles: true });
  };

  window.MiniIcraPopupExport = {
    getExportData,
    downloadExcelXlsx
  };
})();

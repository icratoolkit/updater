(function () {
  "use strict";

  if (window.MiniIcraPopupHesapCalculation) {
    return;
  }

  const HesapCore = window.MiniIcraPopupHesapCore || {};
  const Classifiers = window.MiniIcraHesapClassifiers || {};
  const Vekalet = window.MiniIcraHesapVekalet || {};
  const Normalizers = window.MiniIcraHesapNormalizers || {};
  const { normalizeText, numberOrNull, sumNumericAmounts } = HesapCore;
  const hasMahkemeKalemi = Classifiers.hasMahkemeKalemi || (() => false);
  const resolveIcraVekaletUcreti = Vekalet.resolveIcraVekaletUcreti || (() => ({ value: null, uyari: null }));
  const truncateMoney = Normalizers.truncateMoney || ((value) => value);

  const parseTrDateToTime = (value) => {
    const raw = String(value || "").trim();
    const match = raw.match(/^(\d{2})\/(\d{2})\/(\d{4})(?:\s+(\d{2}):(\d{2}))?$/);
    if (!match) {
      return 0;
    }
    const day = Number(match[1]);
    const month = Number(match[2]);
    const year = Number(match[3]);
    const hour = Number(match[4] || 0);
    const minute = Number(match[5] || 0);
    return Date.UTC(year, month - 1, day, hour, minute);
  };

  const parseOdemeDateInput = (value) => {
    const raw = String(value || "").trim();
    if (!raw) {
      return new Date();
    }

    const tr = raw.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (tr) {
      return new Date(Date.UTC(Number(tr[3]), Number(tr[2]) - 1, Number(tr[1])));
    }

    const iso = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (iso) {
      return new Date(Date.UTC(Number(iso[1]), Number(iso[2]) - 1, Number(iso[3])));
    }

    return null;
  };

  const computeIcraFaizTutari = (asilAlacak, icraAcilisTarihiTr, odemeDate, faizAyarlari) => {
    const principal = numberOrNull(asilAlacak);
    const startMs = parseTrDateToTime(icraAcilisTarihiTr);
    if (principal === null || !startMs || !(odemeDate instanceof Date)) {
      return null;
    }

    const paymentMs = Date.UTC(odemeDate.getUTCFullYear(), odemeDate.getUTCMonth(), odemeDate.getUTCDate());
    const rateLow = Number(faizAyarlari && faizAyarlari.faizOranDusuk) || 0.09;
    const rateMid = Number(faizAyarlari && faizAyarlari.faizOranYuksek) || 0.24;
    const rateHigh = Number(faizAyarlari && faizAyarlari.faizOranYuksek2) || 0.31;
    const parseSplitDate = (value, fallbackMs) => {
      const match = String(value || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
      return match ? Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])) : fallbackMs;
    };
    const split1Ms = parseSplitDate(
      (faizAyarlari && faizAyarlari.faizBolunmeTarihi) || "2024-06-01",
      Date.UTC(2024, 5, 1)
    );
    const split2Ms = parseSplitDate(
      (faizAyarlari && faizAyarlari.faizBolunmeTarihi2) || "2026-07-31",
      Date.UTC(2026, 6, 31)
    );
    const dayMs = 24 * 60 * 60 * 1000;
    const daysBetween = (fromMs, toMs) => {
      const d = Math.floor((toMs - fromMs) / dayMs);
      return d > 0 ? d : 0;
    };
    const lowEnd = Math.min(paymentMs, split1Ms);
    const midStart = Math.max(startMs, split1Ms);
    const midEnd = Math.min(paymentMs, split2Ms);
    const highStart = Math.max(startMs, split2Ms);
    const lowDays = daysBetween(startMs, lowEnd);
    const midDays = daysBetween(midStart, midEnd);
    const highDays = daysBetween(highStart, paymentMs);
    return truncateMoney(
      principal * rateLow * (lowDays / 365) +
        principal * rateMid * (midDays / 365) +
        principal * rateHigh * (highDays / 365)
    );
  };

  const buildToplamKalemler = (row, isIlamli) => {
    const toplamKalemler = [
      row.asilAlacak,
      row.gecmisGunFaizi,
      row.icraFaizTutari,
      row.pesinHarc,
      row.basvurmaHarci,
      row.vekaletSuretHarci,
      row.tahsilHarciHesap,
      row.vekaletPulu,
      row.tebligatGideri,
      row.vekaletUcretiDosyaHesap
    ];

    if (isIlamli) {
      toplamKalemler.push(
        row.mahkemeVekaletUcreti,
        row.mahkemeVekaletUcretiFaizi,
        row.mahkemeYargilamaGiderleri,
        row.mahkemeYargilamaGiderleriFaizi,
        row.mahkemeHarclari,
        row.mahkemeHarclariFaizi,
        row.ygIcraFaiz,
        row.harcIcraFaiz,
        row.ivuIcraFaiz
      );
    }

    return toplamKalemler;
  };

  const calculateMasrafToplami = (row) =>
    sumNumericAmounts([
      row.vekaletPulu,
      row.tebligatGideri,
      row.basvurmaHarci,
      row.vekaletSuretHarci,
      row.pesinHarc,
      row.tahsilHarciHesap
    ]);

  const recalculateDosyaHesabiRow = (row, settings) => {
    const next = { ...row };
    // Mahkeme kalemi (yargılama gideri / ilam vekalet ücreti / mahkeme harcı)
    // varsa takip ilamlıdır; takip türü açıklaması "İlamsız" kalmış olsa bile
    // bu kalemler ve faizleri toplam borçtan düşmemeli.
    const isIlamli = normalizeText(next.takibinTuruAciklama || "").includes("ilamli") || hasMahkemeKalemi(next);
    if (isIlamli && !normalizeText(next.takibinTuruAciklama || "").includes("ilamli")) {
      next.takibinTuruAciklama = "İlamlı";
    }
    const odemeDate = parseOdemeDateInput(settings && settings.dosyaHesabiOdemeTarihi);
    const dosyaHesabiHesapTuru = String(
      next.dosyaHesabiHesapTuru || (settings && settings.dosyaHesabiHesapTuru) || "normal"
    );
    const indirimTutari = numberOrNull(next.indirimTutari ?? (settings && settings.dosyaHesabiIndirimTutari)) ?? 0;

    next.dosyaHesabiHesapTuru = dosyaHesabiHesapTuru;
    next.indirimTutari = indirimTutari;
    next.danismanlikUcreti = null;
    next.ygIcraFaiz = null;
    next.harcIcraFaiz = null;
    next.ivuIcraFaiz = null;
    next.anaPara = null;
    next.hakEdis = null;
    next.vazgecmeHesabi = null;
    next.indirimYeniAsilAlacak = null;
    next.indirimYeniDanismanlikUcreti = null;
    next.indirimliToplamBorc = null;
    next.icraFaizTutari = odemeDate
      ? computeIcraFaizTutari(next.asilAlacak, next.talepTarihi, odemeDate, settings)
      : null;

    // Danışmanlık ücreti ana paranın (asıl alacak + geçmiş gün faizi +
    // hesaplanan faiz) %20'sidir. İlamlı/ilamsız ayrımı yapılmaz; ödeme tarihi
    // girilmediği için hesaplanan faiz boşsa mevcut kalemler üzerinden hesaplanır.
    next.anaPara = sumNumericAmounts([next.asilAlacak, next.gecmisGunFaizi, next.icraFaizTutari]);
    if (next.anaPara !== null) {
      next.danismanlikUcreti = truncateMoney((next.anaPara * 20) / 100);
    }

    if (isIlamli && odemeDate) {
      next.ygIcraFaiz =
        next.mahkemeYargilamaGiderleri !== null
          ? computeIcraFaizTutari(next.mahkemeYargilamaGiderleri, next.talepTarihi, odemeDate, settings)
          : null;
      next.harcIcraFaiz =
        next.mahkemeHarclari !== null
          ? computeIcraFaizTutari(next.mahkemeHarclari, next.talepTarihi, odemeDate, settings)
          : null;
      next.ivuIcraFaiz =
        next.mahkemeVekaletUcreti !== null
          ? computeIcraFaizTutari(next.mahkemeVekaletUcreti, next.talepTarihi, odemeDate, settings)
          : null;
    }

    // İcra vekalet ücreti: hesap tarihi bugünse UYAP'ın dosya hesabındaki değeri
    // birebir; ileri/geri tarihte kesinleşme tarihine göre 4/4-3/4 seçilir.
    {
      const odemeMs = odemeDate
        ? Date.UTC(odemeDate.getUTCFullYear(), odemeDate.getUTCMonth(), odemeDate.getUTCDate())
        : 0;
      const bugun = new Date();
      const bugunMs = Date.UTC(bugun.getUTCFullYear(), bugun.getUTCMonth(), bugun.getUTCDate());
      const kesinlesmeMs = Number(next.dosyaKesinlesmeMs) || 0;
      const cozum = resolveIcraVekaletUcreti(next, {
        isIlamli,
        odemeMs,
        bugunMs,
        kesinlesmeMs,
        uyapBugunValue: next.vekaletUcretiUyapBugun
      });
      if (cozum.value !== null) {
        next.vekaletUcretiDosyaHesap = cozum.value;
      }
      next.vekaletUcretiUyari = cozum.uyari;
    }

    next.masrafToplami = calculateMasrafToplami(next);
    next.hakEdis =
      next.anaPara !== null && next.danismanlikUcreti !== null
        ? Number((next.anaPara - next.danismanlikUcreti).toFixed(2))
        : null;
    // Vazgeçme hesabı: danışmanlık ücreti + masraf kalemleri + icra vekalet
    // ücreti. Asıl alacak ve faizleri girmez; ilamlı dosyada mahkeme kalemleri
    // (yargılama gideri, harç, ilam vekalet ücreti) ve faizleri eklenir.
    const vazgecmeKalemleri = [
      next.vekaletUcretiDosyaHesap,
      next.danismanlikUcreti,
      next.tahsilHarciHesap,
      next.vekaletPulu,
      next.tebligatGideri,
      next.pesinHarc,
      next.basvurmaHarci,
      next.vekaletSuretHarci
    ];

    if (isIlamli) {
      vazgecmeKalemleri.push(
        next.mahkemeYargilamaGiderleri,
        next.mahkemeYargilamaGiderleriFaizi,
        next.ygIcraFaiz,
        next.mahkemeHarclari,
        next.mahkemeHarclariFaizi,
        next.harcIcraFaiz,
        next.mahkemeVekaletUcreti,
        next.mahkemeVekaletUcretiFaizi,
        next.ivuIcraFaiz
      );
    }

    next.vazgecmeHesabi = sumNumericAmounts(vazgecmeKalemleri);

    const indirimBaz = next.anaPara;
    const indirimEkKalemler = sumNumericAmounts([
      next.mahkemeYargilamaGiderleri,
      next.mahkemeYargilamaGiderleriFaizi,
      next.ygIcraFaiz,
      next.mahkemeHarclari,
      next.mahkemeHarclariFaizi,
      next.harcIcraFaiz,
      next.mahkemeVekaletUcreti,
      next.mahkemeVekaletUcretiFaizi,
      next.ivuIcraFaiz,
      next.vekaletPulu,
      next.tebligatGideri,
      next.basvurmaHarci,
      next.vekaletSuretHarci,
      next.pesinHarc,
      next.tahsilHarciHesap,
      next.vekaletUcretiDosyaHesap
    ]);
    next.indirimYeniAsilAlacak = indirimBaz !== null ? truncateMoney((indirimBaz * 0.8 - indirimTutari) * 1.25) : null;
    next.indirimYeniDanismanlikUcreti =
      next.indirimYeniAsilAlacak !== null && next.danismanlikUcreti !== null
        ? truncateMoney(next.danismanlikUcreti - next.indirimYeniAsilAlacak * 0.2)
        : null;
    next.indirimliToplamBorc = sumNumericAmounts([
      next.indirimYeniAsilAlacak,
      next.indirimYeniDanismanlikUcreti,
      indirimEkKalemler
    ]);

    next.toplamBorcHesap = sumNumericAmounts(buildToplamKalemler(next, isIlamli));
    if (dosyaHesabiHesapTuru === "vazgecme" && next.vazgecmeHesabi !== null) {
      next.toplamBorcHesap = next.vazgecmeHesabi;
    }
    if (dosyaHesabiHesapTuru === "indirim" && next.indirimliToplamBorc !== null) {
      next.toplamBorcHesap = next.indirimliToplamBorc;
    }

    return next;
  };

  const calculateResult = (values) => {
    const isIlamli =
      String(values.takipTuru || "auto") === "ilamli" ||
      (String(values.takipTuru || "auto") !== "ilamsiz" && hasMahkemeKalemi(values));

    const row = {
      input: String(values.dosyaNo || values.fileName || "Yedek Hesap"),
      talepTarihi: String(values.talepTarihi || "-"),
      tebligTarihi: "",
      asilAlacak: numberOrNull(values.asilAlacak),
      gecmisGunFaizi: numberOrNull(values.gecmisGunFaizi),
      icraFaizTutari: null,
      danismanlikUcreti: null,
      mahkemeVekaletUcreti: numberOrNull(values.mahkemeVekaletUcreti),
      mahkemeVekaletUcretiFaizi: numberOrNull(values.mahkemeVekaletUcretiFaizi),
      mahkemeYargilamaGiderleri: numberOrNull(values.mahkemeYargilamaGiderleri),
      mahkemeYargilamaGiderleriFaizi: numberOrNull(values.mahkemeYargilamaGiderleriFaizi),
      ygIcraFaiz: null,
      mahkemeHarclari: numberOrNull(values.mahkemeHarclari),
      mahkemeHarclariFaizi: numberOrNull(values.mahkemeHarclariFaizi),
      harcIcraFaiz: null,
      ivuIcraFaiz: null,
      vekaletPulu: numberOrNull(values.vekaletPulu),
      tebligatGideri: numberOrNull(values.tebligatGideri),
      basvurmaHarci: numberOrNull(values.basvurmaHarci),
      vekaletSuretHarci: numberOrNull(values.vekaletSuretHarci),
      pesinHarc: numberOrNull(values.pesinHarc),
      tahsilHarciHesap: numberOrNull(values.tahsilHarciHesap),
      vekaletUcretiDosyaHesap: numberOrNull(values.vekaletUcretiDosyaHesap),
      dosyaHesabiHesapTuru: "normal",
      takibinTuruAciklama: isIlamli ? "İlamlı" : "İlamsız",
      isMatch: true
    };

    row.masrafToplami = calculateMasrafToplami(row);
    row.toplamBorcHesap = sumNumericAmounts(buildToplamKalemler(row, isIlamli));

    return {
      runMode: "hesaplamaYedek",
      stopped: false,
      total: 1,
      processed: 1,
      matchCount: 1,
      items: [row]
    };
  };

  const mergeParsedIntoExistingResult = (resultObj, payload, settings) => {
    if (!resultObj || !Array.isArray(resultObj.items) || resultObj.items.length !== 1) {
      throw new Error("UDF yükleme şu an tek dosyalık sonuç üzerinde kullanılabilir.");
    }

    const current = resultObj.items[0] || {};
    const parsed = payload && payload.parsed ? payload.parsed : null;
    if (!parsed) {
      throw new Error("Yüklenen dosyadan takip evrakı kalemi okunamadı.");
    }

    const nextItem = {
      ...current,
      talepTarihi: String(current.talepTarihi || "").trim() || String(payload.talepTarihi || "").trim(),
      asilAlacak: numberOrNull(parsed.asilAlacak),
      gecmisGunFaizi: numberOrNull(parsed.gecmisGunFaizi),
      mahkemeVekaletUcreti: numberOrNull(parsed.mahkemeVekaletUcreti),
      mahkemeVekaletUcretiFaizi: numberOrNull(parsed.mahkemeVekaletUcretiFaizi),
      mahkemeYargilamaGiderleri: numberOrNull(parsed.mahkemeYargilamaGiderleri),
      mahkemeYargilamaGiderleriFaizi: numberOrNull(parsed.mahkemeYargilamaGiderleriFaizi),
      mahkemeHarclari: numberOrNull(parsed.mahkemeHarclari),
      mahkemeHarclariFaizi: numberOrNull(parsed.mahkemeHarclariFaizi)
    };
    const recalculated = recalculateDosyaHesabiRow(nextItem, settings || {});

    return {
      ...resultObj,
      runMode: "dosyaHesabi",
      items: [recalculated]
    };
  };

  window.MiniIcraPopupHesapCalculation = {
    calculateResult,
    mergeParsedIntoExistingResult
  };
})();

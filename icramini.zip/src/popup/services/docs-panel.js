(function () {
  "use strict";

  if (window.MiniIcraDocsPanel) {
    return;
  }

  const DOCS_SOURCE_PATH = "README.md";

  const RELATIVE_SRC_PATTERN = /src="(?!https?:\/\/|data:)([^"]+)"/g;

  const createDocsPanel = ({ els, state }) => {
    const bindAnchorNavigation = () => {
      els.docsContent.addEventListener("click", (event) => {
        const anchor = event.target.closest("a.md-anchor");
        if (!anchor) {
          return;
        }
        event.preventDefault();
        const id = anchor.getAttribute("href").slice(1);
        const target = els.docsContent.querySelector(`#${CSS.escape(id)}`);
        if (target) {
          target.scrollIntoView({ behavior: "smooth", block: "start" });
        }
      });
    };

    const loadDocs = () => {
      fetch(chrome.runtime.getURL(DOCS_SOURCE_PATH))
        .then((response) => (response.ok ? response.text() : Promise.reject(response.status)))
        .then((markdown) => {
          if (els.docsContent) {
            const html = window.MiniIcraMarkdown.mdToHtml(markdown).replace(
              RELATIVE_SRC_PATTERN,
              (_, path) => `src="${chrome.runtime.getURL(path)}"`
            );
            els.docsContent.innerHTML = html;
            bindAnchorNavigation();
          }
          state.docsLoaded = true;
        })
        .catch((error) => {
          if (els.docsContent) {
            els.docsContent.textContent = `Dokümantasyon yüklenemedi: ${error}`;
          }
        });
    };

    const toggle = () => {
      if (!els.docsPanel) {
        return;
      }
      const isOpen = els.docsPanel.classList.toggle("open");
      if (els.helpBtn) {
        els.helpBtn.classList.toggle("active", isOpen);
      }
      if (isOpen && !state.docsLoaded) {
        loadDocs();
      }
    };

    const close = () => {
      if (els.docsPanel) {
        els.docsPanel.classList.remove("open");
      }
      if (els.helpBtn) {
        els.helpBtn.classList.remove("active");
      }
    };

    return { toggle, close };
  };

  window.MiniIcraDocsPanel = {
    createDocsPanel
  };
})();

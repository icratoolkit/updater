(function () {
  "use strict";

  if (window.MiniIcraPalette) {
    return;
  }

  const DEFAULT_PALETTE = "varsayilan";

  // swatch renkleri yalnızca seçicideki önizleme içindir; asıl renkler
  // popup.css'teki body[data-palette="..."] bloklarında tanımlı.
  const PALETTES = [
    { id: DEFAULT_PALETTE, label: "Varsayılan", swatch: ["#2f6dff", "#14b8a6"] },
    { id: "pembe", label: "Pembe", swatch: ["#e0338a", "#b45cd6"] },
    { id: "yesil", label: "Yeşil", swatch: ["#12915c", "#0f9aa4"] },
    { id: "gri", label: "Gri", swatch: ["#4a5568", "#7a8697"] },
    { id: "kirmizi", label: "Kırmızı", swatch: ["#c62828", "#d9622a"] }
  ];

  const isKnown = (id) => PALETTES.some((palette) => palette.id === id);

  const createPaletteService = ({ els, state }) => {
    const applyPalette = (id) => {
      const next = isKnown(id) ? id : DEFAULT_PALETTE;
      state.currentPalette = next;

      // Varsayılanda öznitelik hiç yazılmaz; :root değerleri geçerli kalır.
      if (next === DEFAULT_PALETTE) {
        document.body.removeAttribute("data-palette");
      } else {
        document.body.setAttribute("data-palette", next);
      }

      if (els.palettePicker) {
        for (const option of els.palettePicker.querySelectorAll(".palette-option")) {
          option.setAttribute("aria-checked", option.dataset.palette === next ? "true" : "false");
        }
      }
    };

    const closePicker = () => {
      if (!els.palettePicker) {
        return;
      }
      els.palettePicker.classList.remove("open");
      if (els.paletteBtn) {
        els.paletteBtn.classList.remove("active");
        els.paletteBtn.setAttribute("aria-expanded", "false");
      }
    };

    const togglePicker = () => {
      if (!els.palettePicker) {
        return;
      }
      const isOpen = els.palettePicker.classList.toggle("open");
      if (els.paletteBtn) {
        els.paletteBtn.classList.toggle("active", isOpen);
        els.paletteBtn.setAttribute("aria-expanded", isOpen ? "true" : "false");
      }
    };

    const selectPalette = (id) => {
      applyPalette(id);
      closePicker();
      try {
        chrome.storage.local.set({ runnerUiPalette: state.currentPalette });
      } catch {}
    };

    const buildPicker = () => {
      if (!els.palettePicker) {
        return;
      }

      els.palettePicker.textContent = "";
      for (const palette of PALETTES) {
        const option = document.createElement("button");
        option.type = "button";
        option.className = "palette-option";
        option.dataset.palette = palette.id;
        option.setAttribute("role", "menuitemradio");
        option.setAttribute("aria-checked", "false");

        const swatch = document.createElement("span");
        swatch.className = "palette-swatch";
        swatch.style.setProperty("--swatch-1", palette.swatch[0]);
        swatch.style.setProperty("--swatch-2", palette.swatch[1]);

        const name = document.createElement("span");
        name.className = "palette-option-name";
        name.textContent = palette.label;

        const check = document.createElement("span");
        check.className = "palette-option-check";
        check.textContent = "✓";

        option.append(swatch, name, check);
        option.addEventListener("click", () => selectPalette(palette.id));
        els.palettePicker.appendChild(option);
      }
    };

    return { applyPalette, buildPicker, closePicker, togglePicker, PALETTES };
  };

  window.MiniIcraPalette = {
    DEFAULT_PALETTE,
    PALETTES,
    createPaletteService
  };
})();

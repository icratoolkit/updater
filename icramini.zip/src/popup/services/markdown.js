(function () {
  "use strict";

  if (window.MiniIcraMarkdown) {
    return;
  }

  const escapeHtml = (value) =>
    String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

  const HEADING_EMOJI = /[📋📌🔍📅🔄📜🧮💾]/gu;

  const HTML_BLOCK_TAGS =
    /^<(?:p|h[1-6]|div|section|article|header|footer|nav|main|aside|figure|figcaption|details|summary|pre|blockquote|hr|br|sub|sup|small)\b/i;

  const renderInline = (text) => {
    let html = escapeHtml(text);

    html = html.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img src="$2" alt="$1" class="md-img">');
    html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_, label, href) =>
      href.startsWith("#")
        ? `<a href="${href}" class="md-anchor">${label}</a>`
        : `<a href="${href}" target="_blank" rel="noopener">${label}</a>`
    );
    html = html.replace(/\*\*\*(.+?)\*\*\*/g, "<strong><em>$1</em></strong>");
    html = html.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
    html = html.replace(/(?<!\w)\*(.+?)\*(?!\w)/g, "<em>$1</em>");
    html = html.replace(/(?<!\w)_(.+?)_(?!\w)/g, "<em>$1</em>");
    html = html.replace(/~~(.+?)~~/g, "<del>$1</del>");
    html = html.replace(/`([^`]+)`/g, "<code>$1</code>");
    html = html.replace(/&amp;nbsp;/g, "&nbsp;");

    return html;
  };

  const slugify = (text) =>
    text
      .toLowerCase()
      .replace(/[`*_~[\]()]/g, "")
      .replace(/[^\w\sÀ-ɏ-]/g, "")
      .trim()
      .replace(/\s+/g, "-");

  const mdToHtml = (markdown) => {
    const lines = String(markdown || "").split("\n");
    const out = [];

    let inCode = false;
    let codeLang = "";
    let codeLines = [];
    let inTable = false;
    let inBlockquote = false;
    let blockquoteLines = [];
    let inHtmlBlock = false;
    const listStack = [];

    const flushBlockquote = () => {
      if (!inBlockquote) {
        return;
      }
      out.push(`<blockquote>${blockquoteLines.map(renderInline).join("<br>")}</blockquote>`);
      blockquoteLines = [];
      inBlockquote = false;
    };

    const flushCode = () => {
      if (!inCode) {
        return;
      }
      const langClass = codeLang ? ` class="language-${codeLang}"` : "";
      out.push(`<pre><code${langClass}>${codeLines.join("\n")}</code></pre>`);
      codeLines = [];
      codeLang = "";
      inCode = false;
    };

    const closeTable = () => {
      if (!inTable) {
        return;
      }
      out.push("</tbody></table></div>");
      inTable = false;
    };

    const closeList = () => {
      const item = listStack.pop();
      out.push(item.type === "ol" ? "</ol>" : "</ul>");
    };

    const closeAllLists = () => {
      while (listStack.length > 0) {
        closeList();
      }
    };

    const openList = (type, indent) => {
      out.push(type === "ol" ? "<ol>" : "<ul>");
      listStack.push({ type, indent });
    };

    const handleListItem = (indent, type, content) => {
      while (listStack.length > 0 && listStack[listStack.length - 1].indent > indent) {
        closeList();
      }

      const current = listStack[listStack.length - 1];
      if (!current || current.indent < indent) {
        openList(type, indent);
      } else if (current.type !== type) {
        closeList();
        openList(type, indent);
      }

      out.push(`<li>${renderInline(content)}</li>`);
    };

    const closeAllBlocks = () => {
      flushBlockquote();
      closeTable();
      closeAllLists();
    };

    for (const raw of lines) {
      if (raw.trimStart().startsWith("```")) {
        flushBlockquote();
        closeTable();
        if (inCode) {
          flushCode();
        } else {
          closeAllLists();
          codeLang = raw.trim().slice(3).trim();
          inCode = true;
        }
        continue;
      }
      if (inCode) {
        codeLines.push(escapeHtml(raw));
        continue;
      }

      const trimmed = raw.trim();

      if (inHtmlBlock) {
        if (!trimmed) {
          inHtmlBlock = false;
        } else {
          out.push(raw);
          continue;
        }
      }

      if (!trimmed) {
        closeAllBlocks();
        continue;
      }

      if (HTML_BLOCK_TAGS.test(trimmed)) {
        closeAllBlocks();
        out.push(raw);
        const selfClosing = /\/>\s*$/.test(trimmed) || /<\/[a-z][a-z0-9]*>\s*$/i.test(trimmed);
        if (!selfClosing) {
          inHtmlBlock = true;
        }
        continue;
      }

      if (/^(-{3,}|\*{3,}|_{3,})$/.test(trimmed)) {
        closeAllBlocks();
        out.push("<hr>");
        continue;
      }

      const heading = trimmed.match(/^(#{1,6})\s+(.+)/);
      if (heading) {
        closeAllBlocks();
        const level = heading[1].length;
        const text = heading[2].replace(/\s*#+\s*$/, "");
        const id = slugify(text.replace(HEADING_EMOJI, "").trim());
        out.push(`<h${level} id="${id}">${renderInline(text)}</h${level}>`);
        continue;
      }

      if (trimmed.startsWith("> ") || trimmed === ">") {
        closeTable();
        closeAllLists();
        inBlockquote = true;
        blockquoteLines.push(trimmed.replace(/^>\s?/, ""));
        continue;
      }
      flushBlockquote();

      if (trimmed.startsWith("|") && trimmed.endsWith("|")) {
        closeAllLists();
        const cells = trimmed
          .split("|")
          .slice(1, -1)
          .map((cell) => cell.trim());

        if (cells.every((cell) => /^[-:]+$/.test(cell))) {
          continue;
        }
        if (inTable) {
          out.push(`<tr>${cells.map((cell) => `<td>${renderInline(cell)}</td>`).join("")}</tr>`);
        } else {
          out.push(
            `<div class="table-wrap"><table><thead><tr>${cells
              .map((cell) => `<th>${renderInline(cell)}</th>`)
              .join("")}</tr></thead><tbody>`
          );
          inTable = true;
        }
        continue;
      }
      closeTable();

      const leadingSpaces = raw.match(/^(\s*)/)[1].length;
      const unordered = trimmed.match(/^[-*+]\s+(.+)/);
      if (unordered) {
        handleListItem(leadingSpaces, "ul", unordered[1]);
        continue;
      }
      const ordered = trimmed.match(/^\d+[.)]\s+(.+)/);
      if (ordered) {
        handleListItem(leadingSpaces, "ol", ordered[1]);
        continue;
      }
      closeAllLists();

      out.push(`<p>${renderInline(trimmed)}</p>`);
    }

    closeAllBlocks();
    flushCode();
    return out.join("\n");
  };

  window.MiniIcraMarkdown = {
    mdToHtml
  };
})();

(function () {
  "use strict";

  if (window.MiniIcraVersionCheck) {
    return;
  }

  const VERSION_CHECK_URL =
    "https://raw.githubusercontent.com/icratoolkit/updater/refs/heads/main/version.json";
  const VERSION_CHECK_INTERVAL_MS = 24 * 60 * 60 * 1000;
  const VERSION_CHECK_FORCE_PARAM = "forceVersionCheck";
  const VERSION_CHECK_STORAGE_DEFAULTS = {
    miniIcraVersionCheckLastAt: 0,
    miniIcraVersionCheckLatest: null,
    miniIcraVersionCheckDismissed: null
  };
  const MIN_VERSION_SEGMENTS = 4;

  const parseVersionParts = (version) =>
    String(version || "")
      .trim()
      .split(".")
      .map((part) => {
        const match = String(part).match(/^\d+/);
        return match ? Number(match[0]) : 0;
      });

  const compareVersions = (left, right) => {
    const a = parseVersionParts(left);
    const b = parseVersionParts(right);
    const length = Math.max(a.length, b.length, MIN_VERSION_SEGMENTS);
    for (let i = 0; i < length; i += 1) {
      const av = Number.isFinite(a[i]) ? a[i] : 0;
      const bv = Number.isFinite(b[i]) ? b[i] : 0;
      if (av > bv) {
        return 1;
      }
      if (av < bv) {
        return -1;
      }
    }
    return 0;
  };

  const fetchJson = async (url) => {
    const response = await fetch(url, { cache: "no-store" });
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    return response.json();
  };

  const createVersionCheck = ({ els, state }) => {
    const hideNotice = () => {
      if (!els.updateNotice) {
        return;
      }
      els.updateNotice.classList.remove("show");
      const target = els.updateNoticeText || els.updateNotice;
      target.textContent = "";
    };

    const showNotice = (latestVersion, currentVersion, dismissedVersion = "") => {
      if (!els.updateNotice) {
        return;
      }

      const latest = String(latestVersion || "").trim();
      state.latestUpdateNoticeVersion = latest;

      const isDismissed = latest === String(dismissedVersion || "").trim();
      if (!latest || isDismissed || compareVersions(latest, currentVersion) <= 0) {
        hideNotice();
        return;
      }

      const target = els.updateNoticeText || els.updateNotice;
      target.textContent = `${latest} yeni sürümü mevcut. Güncelleme yapabilirsiniz.`;
      els.updateNotice.classList.add("show");
    };

    const dismiss = () => {
      const dismissed = String(state.latestUpdateNoticeVersion || "").trim();
      hideNotice();
      if (dismissed && chrome?.storage?.local) {
        chrome.storage.local.set({ miniIcraVersionCheckDismissed: dismissed });
      }
    };

    const shouldForceCheck = () => {
      try {
        return new URLSearchParams(window.location.search).has(VERSION_CHECK_FORCE_PARAM);
      } catch {
        return false;
      }
    };

    const check = async (options = {}) => {
      if (!els.updateNotice || !chrome?.storage?.local) {
        return;
      }

      const force = options.force === true || shouldForceCheck();
      const currentVersion = String(chrome.runtime.getManifest?.().version || "0.0.0").trim();

      chrome.storage.local.get(VERSION_CHECK_STORAGE_DEFAULTS, async (stored) => {
        const now = Date.now();
        const lastAt = Number(stored.miniIcraVersionCheckLastAt || 0);
        const cachedLatest = stored.miniIcraVersionCheckLatest;
        const dismissedVersion = stored.miniIcraVersionCheckDismissed;

        if (!force && cachedLatest && now - lastAt < VERSION_CHECK_INTERVAL_MS) {
          showNotice(cachedLatest, currentVersion, dismissedVersion);
          return;
        }

        try {
          const remote = await fetchJson(`${VERSION_CHECK_URL}?t=${now}`);
          const latestVersion = String(remote?.version || "").trim();
          chrome.storage.local.set({
            miniIcraVersionCheckLastAt: now,
            miniIcraVersionCheckLatest: latestVersion || null
          });
          showNotice(latestVersion, currentVersion, dismissedVersion);
        } catch {
          chrome.storage.local.set({ miniIcraVersionCheckLastAt: now });
          showNotice(cachedLatest, currentVersion, dismissedVersion);
        }
      });
    };

    return { check, dismiss };
  };

  window.MiniIcraVersionCheck = {
    compareVersions,
    createVersionCheck
  };
})();

(function () {
  "use strict";

  if (window.MiniIcraTheme) {
    return;
  }

  const SUN_ICON = String.fromCodePoint(0x2600);
  const MOON_ICON = String.fromCodePoint(0x1f319);

  const createThemeService = ({ els, state }) => {
    const resolveTheme = (mode) => {
      if (mode === "dark" || mode === "light") {
        return mode;
      }
      try {
        return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
      } catch {
        return "light";
      }
    };

    const applyTheme = (mode) => {
      state.currentThemeMode = mode === "dark" || mode === "light" ? mode : "auto";
      const resolved = resolveTheme(state.currentThemeMode);
      document.body.setAttribute("data-theme", resolved);
      if (els.themeToggle) {
        els.themeToggle.textContent = resolved === "dark" ? SUN_ICON : MOON_ICON;
        els.themeToggle.title = resolved === "dark" ? "Açık mod" : "Koyu mod";
      }
    };

    const toggleTheme = () => {
      const next = resolveTheme(state.currentThemeMode) === "dark" ? "light" : "dark";
      applyTheme(next);
      try {
        chrome.storage.local.set({ runnerUiTheme: next });
      } catch {}
    };

    return { applyTheme, toggleTheme };
  };

  window.MiniIcraTheme = {
    createThemeService
  };
})();

(function () {
  "use strict";

  if (window.MiniIcraTabMessaging) {
    return;
  }

  const CONTENT_SCRIPT_PATH = "src/content/content-script.js";

  const isInjectableUrl = (url) => /^https?:\/\//i.test(String(url || ""));

  const createTabMessaging = ({ onError }) => {
    const withActiveTab = (callback) => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (chrome.runtime.lastError) {
          onError(`Tab hatası: ${chrome.runtime.lastError.message}`, true);
          return;
        }

        const tab = tabs && tabs[0] ? tabs[0] : null;
        if (!tab || !tab.id) {
          onError("Aktif tab bulunamadı.", true);
          return;
        }

        if (!isInjectableUrl(tab.url)) {
          onError("Bu sayfada çalışmaz. Hedef sitede http/https bir sekme aç.", true);
          return;
        }

        callback(tab);
      });
    };

    const sendToPage = (tabId, payload, callback) => {
      chrome.scripting.executeScript({ target: { tabId }, files: [CONTENT_SCRIPT_PATH] }, () => {
        if (chrome.runtime.lastError) {
          callback({ err: chrome.runtime.lastError.message, response: null });
          return;
        }
        chrome.tabs.sendMessage(tabId, payload, (response) => {
          const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : null;
          callback({ err, response });
        });
      });
    };

    return { withActiveTab, sendToPage };
  };

  window.MiniIcraTabMessaging = {
    createTabMessaging,
    isInjectableUrl
  };
})();

(function () {
  "use strict";

  if (window.MiniIcraHacizController) {
    return;
  }

  const PROGRESS_POLL_INTERVAL_MS = 1000;
  const SLOW_QUERY_NOTICE_MS = 5000;
  const BANKA_HACIZ_PARAMS_PATH = "assets/data/banka_haciz_params.json";

  const HACIZ_MODE_CHECKBOXES = [
    ["hacizTypeArac", "arac"],
    ["hacizTypeBanka", "banka"],
    ["hacizTypeTakbis", "takbis"],
    ["hacizTypeIcraDosyasi", "icraDosyasi"]
  ];

  const createHacizController = (ctx) => {
    const { els, hacizEls, state, shell, settingsForm, messaging, utils, query, hacizFormat, hacizExport } = ctx;

    const birimLookup = query.createBirimLookupService({ normalizeKey: utils.normalizeKey });

    const isProgressCompleted = (progress) => {
      if (!progress) {
        return false;
      }
      if (progress.stopped === true) {
        return true;
      }
      const total = Number(progress.total);
      const processed = Number(progress.processed);
      return Number.isFinite(total) && Number.isFinite(processed) && total > 0 && processed >= total;
    };

    const formatTalepSummary = (result) => {
      const success = Number(result.talepSuccess) || 0;
      const processed = Number(result.talepProcessed) || 0;
      const prefix = result.stopped ? "Durduruldu" : "Tamamlandı";
      return `${prefix}. Eşleşen: ${result.matchCount || 0}/${result.total || 0} | Talep: ${success}/${processed}`;
    };

    const buildWaitingText = (progress) => {
      const label = String(progress.activeQueryLabel || "");
      const dosyaNo = String(progress.activeQueryDosyaNo || "");
      const kisi = String(progress.activeQueryKisi || "");
      const startedAt = Number(progress.activeQueryStartedAt || 0);

      if (!label || startedAt <= 0 || Date.now() - startedAt < SLOW_QUERY_NOTICE_MS) {
        return "";
      }
      return `${label} için yanıt bekleniyor${dosyaNo ? ` (${dosyaNo})` : ""}${kisi ? ` - ${kisi}` : ""}...`;
    };

    const buildResultRows = (items, talepResults, source) => {
      const talepRows =
        Array.isArray(talepResults) && talepResults.length > 0 ? hacizFormat.getTalepResultRows(talepResults) : [];
      const queryRows = hacizFormat.getHacizMatchedRows(Array.isArray(items) ? items : [], source);
      return [...talepRows, ...queryRows];
    };

    const renderProgress = (progress) => {
      if (!progress) {
        return;
      }

      const waitingText = buildWaitingText(progress);
      const pendingTakbisCount = Number(progress.pendingTakbisCount || 0);
      const pendingTakbisText =
        !waitingText && pendingTakbisCount > 0 ? `Takbis için yanıt bekleniyor... (${pendingTakbisCount})` : "";

      shell.updateProgressBar(Number(progress.processed) || 0, Number(progress.total) || 0);

      // Birleşik sorgu + talep aşaması
      if (progress.phase === "full") {
        const rows = buildResultRows(progress.matched, progress.talepResults, "progress");
        shell.setHacizMatched(rows.length > 0 ? rows : null);

        if (isProgressCompleted(progress)) {
          shell.setHacizStatus(formatTalepSummary(progress));
        } else {
          const talepProcessed = Number(progress.talepProcessed) || 0;
          shell.setHacizStatus(
            waitingText ||
              pendingTakbisText ||
              `Çalışıyor... ${progress.processed}/${progress.total} | Eşleşen: ${progress.matchCount} | Talep: ${talepProcessed}`
          );
        }
        return;
      }

      if (progress.phase === "talep") {
        const talepRows = Array.isArray(progress.talepResults)
          ? hacizFormat.getTalepResultRows(progress.talepResults)
          : [];
        shell.setHacizMatched(talepRows.length > 0 ? talepRows : null);

        if (isProgressCompleted(progress)) {
          shell.setHacizStatus(
            progress.stopped
              ? `Durduruldu. Başarılı: ${progress.matchCount}/${progress.total}`
              : `Talepler gönderildi. Başarılı: ${progress.matchCount}/${progress.total}`
          );
        } else {
          shell.setHacizStatus(
            waitingText ||
              `Talep gönderiliyor... ${progress.processed}/${progress.total} | Başarılı: ${progress.matchCount}`
          );
        }
        return;
      }

      const rows = hacizFormat.getHacizMatchedRows(Array.isArray(progress.matched) ? progress.matched : [], "progress");
      shell.setHacizMatched(rows.length > 0 ? rows : null);
      shell.setHacizStatus(
        isProgressCompleted(progress)
          ? `${progress.stopped ? "Durduruldu" : "Tamamlandı"}. Eşleşen: ${progress.matchCount}/${progress.total}`
          : waitingText || hacizFormat.formatHacizRunStatus(progress)
      );
    };

    const renderResults = (resultObj) => {
      const items = resultObj && Array.isArray(resultObj.items) ? resultObj.items : [];
      if (items.length === 0) {
        shell.setHacizMatched(null);
        return;
      }
      const rows = buildResultRows(items, resultObj.talepResults, "result");
      shell.setHacizMatched(rows.length > 0 ? rows : null);
    };

    const stopProgressPolling = () => {
      if (state.hacizProgressSyncTimer) {
        clearInterval(state.hacizProgressSyncTimer);
        state.hacizProgressSyncTimer = null;
      }
    };

    const startProgressPolling = () => {
      if (state.hacizProgressSyncTimer) {
        return;
      }
      state.hacizProgressSyncTimer = setInterval(() => {
        chrome.storage.local.get(
          { runnerHacizProgress: null, runnerHacizResults: null },
          ({ runnerHacizProgress, runnerHacizResults }) => {
            if (runnerHacizResults) {
              setRunUiState(false);
              state.activeHacizRequestId = null;
              renderResults(runnerHacizResults);
              shell.setHacizStatus(formatTalepSummary(runnerHacizResults));
              shell.refreshResumeStates();
              return;
            }
            if (!runnerHacizProgress || !runnerHacizProgress.progress) {
              return;
            }
            if (
              state.activeHacizRequestId &&
              runnerHacizProgress.requestId &&
              runnerHacizProgress.requestId !== state.activeHacizRequestId
            ) {
              return;
            }
            if (!state.activeHacizRequestId && runnerHacizProgress.requestId) {
              state.activeHacizRequestId = runnerHacizProgress.requestId;
            }
            renderProgress(runnerHacizProgress.progress);
          }
        );
      }, PROGRESS_POLL_INTERVAL_MS);
    };

    const setRunUiState = (running) => {
      const wasRunning = state.hacizIsRunning;
      state.hacizIsRunning = running;

      const lockedControls = [
        hacizEls.hacizRunBtn,
        hacizEls.tabHaciz,
        els.tabQuery,
        els.tabDosya,
        els.tabTalep,
        els.runBtn,
        els.dosyaRunBtn,
        els.talepRunBtn
      ];
      for (const control of lockedControls) {
        if (control) {
          control.disabled = running;
        }
      }
      shell.updateStopResumeButton();

      if (running) {
        if (!wasRunning) {
          shell.updateProgressBar(0, 0);
        }
        startProgressPolling();
      } else {
        stopProgressPolling();
      }
      shell.updateStopResumeButton();
    };

    const getSelectedHacizModes = () =>
      HACIZ_MODE_CHECKBOXES.filter(([elementKey]) => hacizEls[elementKey]?.checked).map(([, mode]) => mode);

    const loadBankaHacizData = () =>
      fetch(chrome.runtime.getURL(BANKA_HACIZ_PARAMS_PATH))
        .then((response) => response.json())
        .catch(() => []);

    const reportRunFailure = ({ err, response }) => {
      if (err) {
        setRunUiState(false);
        state.activeHacizRequestId = null;
        shell.setHacizStatus(`İletişim hatası: ${err}`, true);
        return true;
      }
      if (!response || !response.ok) {
        setRunUiState(false);
        state.activeHacizRequestId = null;
        shell.setHacizStatus(`Hata: ${response?.error || "Bilinmeyen hata"}`, true);
        return true;
      }
      return false;
    };

    const startRun = () => {
      if (state.hacizIsRunning || state.isRunning) {
        return;
      }

      const hacizModes = getSelectedHacizModes();
      if (hacizModes.length === 0) {
        shell.setHacizStatus("En az bir haciz türü seçin.", true);
        return;
      }

      settingsForm.save(({ settings, inputText }) => {
        const rawRows = utils.parseRowsFromInput(inputText, settings);
        if (rawRows.length === 0) {
          shell.setHacizStatus("Geçerli girdi yok. Format: birimAdi TAB dosyaNo", true);
          return;
        }

        Promise.all([birimLookup.load(), loadBankaHacizData()]).then(([birimMap, bankaHacizData]) => {
          const prepared = birimLookup.apply(rawRows, birimMap || new Map(), settings);
          const bankaHacizParams =
            hacizModes.includes("banka") && Array.isArray(bankaHacizData) && Array.isArray(bankaHacizData[0])
              ? bankaHacizData[0]
              : [];

          messaging.withActiveTab((tab) => {
            chrome.storage.local.set({
              runnerLastRunPanel: "haciz",
              runnerHacizResumeState: null,
              runnerHacizResults: null,
              runnerHacizProgress: null,
              runnerResults: null,
              runnerProgress: null,
              runnerLiveView: null,
              runnerActivePanel: "haciz"
            });
            state.activeHacizRequestId = null;
            shell.setHacizMatched(null);
            shell.setHacizStatus("Çalışıyor...");
            setRunUiState(true);

            messaging.sendToPage(
              tab.id,
              {
                action: "runHacizFullInPage",
                settings: { ...settings, hacizModes, bankaHacizParams },
                inputs: prepared.inputs,
                bankaHacizData: Array.isArray(bankaHacizData) ? bankaHacizData : []
              },
              (outcome) => {
                if (reportRunFailure(outcome)) {
                  return;
                }
                if (outcome.response.requestId) {
                  state.activeHacizRequestId = outcome.response.requestId;
                }
                shell.setHacizStatus("Çalışıyor...");
              }
            );
          });
        });
      });
    };

    const continueRun = () => {
      const checkpoint = state.resumeHacizState;
      if (state.hacizIsRunning || state.isRunning || !checkpoint) {
        return;
      }

      messaging.withActiveTab((tab) => {
        chrome.storage.local.set({ runnerLastRunPanel: "haciz", runnerActivePanel: "haciz" });
        state.activeHacizRequestId = null;
        shell.setActivePanel("haciz");
        setRunUiState(true);
        shell.setHacizStatus(
          checkpoint.lastProgress && checkpoint.lastProgress.activeQueryDosyaNo
            ? `Devam ediliyor... Son durak: ${checkpoint.lastProgress.activeQueryDosyaNo} / ${
                checkpoint.lastProgress.activeQueryLabel || "bilinmiyor"
              }`
            : "Devam ediliyor..."
        );

        messaging.sendToPage(
          tab.id,
          {
            action: "runHacizFullInPage",
            settings: checkpoint.settings,
            inputs: checkpoint.inputs,
            bankaHacizData: Array.isArray(checkpoint.bankaHacizData) ? checkpoint.bankaHacizData : []
          },
          (outcome) => {
            if (reportRunFailure(outcome)) {
              return;
            }
            if (outcome.response.requestId) {
              state.activeHacizRequestId = outcome.response.requestId;
            }
            shell.setHacizStatus("Devam ediliyor...");
          }
        );
      });
    };

    const stopRun = () => {
      if (!state.hacizIsRunning) {
        return;
      }
      messaging.withActiveTab((tab) => {
        messaging.sendToPage(tab.id, { action: "stopHacizInPage" }, () => {
          shell.setHacizStatus("Durdurma istendi...");
        });
      });
    };

    const exportResults = () => {
      chrome.storage.local.get({ runnerHacizResults: null }, ({ runnerHacizResults }) => {
        const items = runnerHacizResults && Array.isArray(runnerHacizResults.items) ? runnerHacizResults.items : [];
        const talepResults =
          runnerHacizResults && Array.isArray(runnerHacizResults.talepResults) ? runnerHacizResults.talepResults : [];
        const exportData = hacizExport.getHacizExportRows(items, talepResults);
        const takbisRows = exportData.takbisRows || [];
        const totalRows =
          exportData.aracRows.length + exportData.bankaRows.length + takbisRows.length + exportData.talepRows.length;

        if (totalRows === 0) {
          shell.setHacizStatus("Aktarılacak kayıt yok.", true);
          return;
        }

        hacizExport.downloadHacizXlsx(exportData);
        shell.setHacizStatus(
          `${totalRows} kayıt dışa aktarıldı (${exportData.aracRows.length} araç, ${exportData.bankaRows.length} banka, ${takbisRows.length} takbis, ${exportData.talepRows.length} talep).`
        );
      });
    };

    return {
      continueRun,
      exportResults,
      renderProgress,
      renderResults,
      setRunUiState,
      startRun,
      stopRun
    };
  };

  window.MiniIcraHacizController = {
    createHacizController
  };
})();

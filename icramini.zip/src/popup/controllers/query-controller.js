(function () {
  "use strict";

  if (window.MiniIcraQueryController) {
    return;
  }

  const PROGRESS_POLL_INTERVAL_MS = 1000;

  const createQueryController = (ctx) => {
    const { els, hacizEls, state, shell, settingsForm, messaging, utils, query, exporter, hesap, runModes } = ctx;
    const RUN_MODES = runModes;

    const birimLookup = query.createBirimLookupService({ normalizeKey: utils.normalizeKey });

    const IBAN_REQUIRED_MODES = new Set([
      RUN_MODES.TALEP_MASRAF_AVANS_IADESI,
      RUN_MODES.TALEP_BORCLU_ODEME_AKTAR,
      RUN_MODES.TALEP_EVRAKI_OLUSTUR
    ]);

    const getEffectiveMode = (resultObj, modeOverride) =>
      String(modeOverride || (resultObj && resultObj.runMode) || state.currentRunMode || RUN_MODES.NORMAL);

    const formatCompletionStatus = (result) =>
      result.stopped
        ? `Durduruldu. Eşleşen: ${result.matchCount}/${result.total}`
        : `Tamamlandı. Eşleşen: ${result.matchCount}/${result.total}`;

    const renderResults = (resultObj, modeOverride) => {
      state.lastResult = resultObj || null;
      const mode = getEffectiveMode(resultObj, modeOverride);

      if (!resultObj || !Array.isArray(resultObj.items) || resultObj.items.length === 0) {
        shell.setMatched([]);
        return;
      }

      const matchedRows = utils.getMatchedRowsForMode(resultObj.items, mode, "result");
      if (shell.isYatanParaMode(mode)) {
        shell.resetStableMatchedRows();
        shell.collectStableMatchedRows(matchedRows);
        shell.setMatched(state.stableMatchedRows.slice());
      } else {
        shell.setMatched(matchedRows);
      }
      shell.persistLiveView();
    };

    const inferProgressMode = (progress, modeOverride) => {
      if (modeOverride || progress.runMode || state.currentRunMode) {
        return String(modeOverride || progress.runMode || state.currentRunMode);
      }
      const matched = Array.isArray(progress.matched) ? progress.matched : [];
      const hasTebligRows = matched.some(
        (row) =>
          row &&
          ((typeof row.tebligTarihi === "string" && row.tebligTarihi.trim()) ||
            (Array.isArray(row.tebligDetaylari) && row.tebligDetaylari.some((d) => d && d.tebligTarihi)))
      );
      return hasTebligRows ? RUN_MODES.KESINLESTIRME : RUN_MODES.NORMAL;
    };

    const renderProgress = (progress, modeOverride) => {
      if (!progress) {
        return;
      }

      shell.updateProgressBar(Number(progress.processed) || 0, Number(progress.total) || 0);

      const matched = Array.isArray(progress.matched) ? progress.matched : [];
      const mode = inferProgressMode(progress, modeOverride);
      const rows = utils.getMatchedRowsForMode(matched, mode, "progress");
      shell.setMatched(shell.mergeStableMatchedRows(rows, mode));
      shell.setStatus(
        query.isProgressCompleted(progress)
          ? query.getProgressCompletionStatus(progress)
          : utils.formatRunStatus(progress)
      );
      shell.persistLiveView();
    };

    const stopProgressPolling = () => {
      if (state.progressSyncTimer) {
        clearInterval(state.progressSyncTimer);
        state.progressSyncTimer = null;
      }
    };

    const setRunUiState = (running) => {
      const wasRunning = state.isRunning;
      state.isRunning = running;

      const lockedControls = [
        els.runBtn,
        els.dosyaRunBtn,
        els.talepRunBtn,
        els.talepType,
        els.talepIbanNo,
        els.runMode,
        els.tabQuery,
        els.tabDosya,
        els.tabTalep,
        hacizEls.tabHaciz,
        hacizEls.hacizRunBtn
      ];
      for (const control of lockedControls) {
        if (control) {
          control.disabled = running;
        }
      }
      shell.updateStopResumeButton();

      if (running) {
        if (!wasRunning) {
          shell.updateProgressBar(0, 0);
        }
        startProgressPolling();
      } else {
        stopProgressPolling();
      }
      shell.updateStopResumeButton();
    };

    const startProgressPolling = () => {
      if (state.progressSyncTimer) {
        return;
      }
      state.progressSyncTimer = setInterval(() => {
        chrome.storage.local.get({ runnerProgress: null }, ({ runnerProgress }) => {
          if (!runnerProgress || !runnerProgress.progress) {
            return;
          }
          if (state.activeRequestId && runnerProgress.requestId && runnerProgress.requestId !== state.activeRequestId) {
            return;
          }
          if (!state.activeRequestId && runnerProgress.requestId) {
            state.activeRequestId = runnerProgress.requestId;
          }

          const mode = String(runnerProgress.progress.runMode || state.currentRunMode || "normal");
          state.currentRunMode = mode;
          shell.setActivePanel(shell.getPanelForRunMode(mode));
          renderProgress(runnerProgress.progress, mode);

          if (query.isProgressCompleted(runnerProgress.progress)) {
            setRunUiState(false);
            state.activeRequestId = null;
            shell.refreshResumeStates();
          }
        });
      }, PROGRESS_POLL_INTERVAL_MS);
    };

    const handleProgressMessage = (message) => {
      if (state.activeRequestId && message.requestId && message.requestId !== state.activeRequestId) {
        return;
      }
      if (!state.activeRequestId && message.requestId) {
        state.activeRequestId = message.requestId;
      }

      const progress = message.progress || null;
      const mode = String((progress && progress.runMode) || state.currentRunMode || "normal");
      state.currentRunMode = mode;
      shell.setActivePanel(shell.getPanelForRunMode(mode));
      renderProgress(progress, mode);

      if (query.isProgressCompleted(progress)) {
        setRunUiState(false);
        state.activeRequestId = null;
        shell.refreshResumeStates();
      } else {
        setRunUiState(true);
      }
    };

    const validateRunMode = (mode, settings) => {
      if (mode === RUN_MODES.KALAN) {
        const threshold = Number(String(settings.kalanQueryAmount || "").replace(",", "."));
        if (!Number.isFinite(threshold) || threshold < 0) {
          return "Kalan Sorgulama için geçerli bir tutar gir.";
        }
      }
      if (IBAN_REQUIRED_MODES.has(mode) && !settingsForm.normalizeIban(settings.talepIbanNo).isValid) {
        return "Talep için geçerli bir IBAN gir.";
      }
      return "";
    };

    const applyFinalResult = (result, mode) => {
      shell.setStatus(formatCompletionStatus(result));
      chrome.storage.local.set({ runnerResults: result }, () => {
        renderResults(result, mode);
        shell.persistLiveView();
        shell.refreshResumeStates();
      });
    };

    const reportRunFailure = ({ err, response }) => {
      if (err) {
        shell.setStatus(`İletişim hatası: ${err}`, true);
        return true;
      }
      if (!response || !response.ok) {
        shell.setStatus(`Çalıştırma hatası: ${response?.error || "Bilinmeyen hata"}`, true);
        return true;
      }
      return false;
    };

    const startRun = (runMode) => {
      if (state.isRunning) {
        return;
      }
      state.currentRunMode = String(runMode || "normal");

      settingsForm.save(({ settings, inputText }) => {
        const rawRows = utils.parseRowsFromInput(inputText, settings);
        if (rawRows.length === 0) {
          shell.setStatus("Geçerli girdi yok. Format: birimAdi TAB dosyaNo", true);
          return;
        }

        const validationError = validateRunMode(state.currentRunMode, settings);
        if (validationError) {
          shell.setStatus(validationError, true);
          return;
        }

        birimLookup.load().then((birimMap) => {
          const prepared = birimLookup.apply(rawRows, birimMap || new Map(), settings);
          shell.setUnresolvedBirimRows(prepared.unresolvedRows);

          messaging.withActiveTab((tab) => {
            chrome.storage.local.set({
              runnerLastRunPanel: shell.getPanelForRunMode(state.currentRunMode),
              runnerResumeState: null
            });
            state.activeRequestId = null;
            shell.resetStableMatchedRows();
            shell.setMatched([]);
            setRunUiState(true);
            shell.setStatus(
              prepared.unresolved > 0
                ? `Çalışıyor... ${prepared.unresolved} birim eşleşmedi (varsayılan kullanıldı).`
                : "Çalışıyor..."
            );
            shell.persistLiveView();

            messaging.sendToPage(
              tab.id,
              {
                action: "runInPage",
                settings,
                inputs: prepared.inputs,
                runMode,
                enableBarcode: runMode === RUN_MODES.KESINLESTIRME
              },
              (outcome) => {
                setRunUiState(false);
                state.activeRequestId = null;
                if (reportRunFailure(outcome)) {
                  return;
                }
                const result = outcome.response.result;
                applyFinalResult(result, getEffectiveMode(result, runMode));
              }
            );
          });
        });
      });
    };

    const mergeResumedResult = (result, checkpoint) => {
      const completedItems = Array.isArray(checkpoint.resumeCompletedItems) ? checkpoint.resumeCompletedItems : [];
      const items = [...completedItems, ...(Array.isArray(result.items) ? result.items : [])];
      const originalInputs = Array.isArray(checkpoint.resumeOriginalInputs) ? checkpoint.resumeOriginalInputs : null;

      return {
        ...result,
        total: originalInputs ? originalInputs.length : completedItems.length + (result.total || 0),
        processed: items.length,
        successCount: items.filter((x) => x && x.success).length,
        matchCount: items.filter((x) => x && x.isMatch).length,
        barcodeCount: items.filter((x) => x && x.barcode).length,
        matchedInputs: items.filter((x) => x && x.isMatch).map((x) => x.input),
        items
      };
    };

    const continueRun = () => {
      const checkpoint = state.resumeQueryState;
      if (state.isRunning || !checkpoint || !Array.isArray(checkpoint.inputs) || checkpoint.inputs.length === 0) {
        return;
      }
      state.currentRunMode = String(checkpoint.runMode || "normal");

      messaging.withActiveTab((tab) => {
        state.activeRequestId = null;
        setRunUiState(true);
        shell.setStatus(
          checkpoint.lastProgress && checkpoint.lastProgress.activeInput
            ? `Devam ediliyor... Son durak: ${checkpoint.lastProgress.activeInput} / ${
                checkpoint.lastProgress.activeStepLabel || "bilinmiyor"
              }`
            : "Devam ediliyor..."
        );

        messaging.sendToPage(
          tab.id,
          {
            action: "runInPage",
            settings: checkpoint.settings,
            inputs: checkpoint.inputs,
            runMode: checkpoint.runMode,
            enableBarcode: !!checkpoint.enableBarcode,
            resumeOriginalInputs: checkpoint.resumeOriginalInputs,
            resumeCompletedItems: checkpoint.resumeCompletedItems
          },
          (outcome) => {
            setRunUiState(false);
            state.activeRequestId = null;
            if (reportRunFailure(outcome)) {
              return;
            }
            const merged = mergeResumedResult(outcome.response.result || {}, checkpoint);
            applyFinalResult(merged, getEffectiveMode(merged, checkpoint.runMode));
          }
        );
      });
    };

    const stopRun = () => {
      if (!state.isRunning) {
        return;
      }
      messaging.withActiveTab((tab) => {
        messaging.sendToPage(tab.id, { action: "stopInPage" }, () => {
          shell.setStatus("Durdurma istendi...");
        });
      });
    };

    const tryExport = (resultObj, fallbackMode) => {
      const mode = getEffectiveMode(resultObj, fallbackMode || state.currentRunMode);
      const data = exporter.getExportData(resultObj, mode);
      if (!data.rows || data.rows.length === 0) {
        shell.setStatus("Aktarılacak kayıt yok.", true);
        return false;
      }
      exporter.downloadExcelXlsx(data.header, data.rows, data.mode);
      shell.setStatus(`${data.rows.length} kayıt Excel formatında dışa aktarıldı.`);
      return true;
    };

    const exportResults = () => {
      if (tryExport(state.lastResult, state.currentRunMode)) {
        return;
      }

      chrome.storage.local.get({ runnerResults: null, runnerLiveView: null }, ({ runnerResults, runnerLiveView }) => {
        if (runnerResults && Array.isArray(runnerResults.items) && runnerResults.items.length > 0) {
          state.lastResult = runnerResults;
          tryExport(runnerResults, runnerResults.runMode || state.currentRunMode);
          return;
        }

        if (runnerLiveView && Array.isArray(runnerLiveView.rows) && runnerLiveView.rows.length > 0) {
          shell.setStatus(
            "Görünen satırlar var ama dışa aktarılabilir ham sonuç bulunamadı. Hesabı yeniden çalıştırıp tekrar deneyin.",
            true
          );
          return;
        }

        shell.setStatus("Aktarılacak kayıt yok.", true);
      });
    };

    const applyTakipEvraki = async () => {
      const file = els.dosyaTakipUpload && els.dosyaTakipUpload.files ? els.dosyaTakipUpload.files[0] : null;
      if (!file) {
        shell.setStatus("Önce UDF/ZIP veya content.xml dosyası seç.", true);
        return;
      }

      const hasDosyaHesabiResult =
        state.lastResult &&
        Array.isArray(state.lastResult.items) &&
        state.lastResult.items.length > 0 &&
        getEffectiveMode(state.lastResult, state.currentRunMode) === RUN_MODES.DOSYA_HESABI;
      if (!hasDosyaHesabiResult) {
        shell.setStatus("Önce Dosya Hesabı çalıştırıp sonucu oluştur.", true);
        return;
      }

      try {
        shell.setStatus("Takip evrakı parse edilip sonuç güncelleniyor...");
        const payload = await hesap.parseUpload(file);
        const merged = hesap.mergeParsedIntoExistingResult(state.lastResult, payload, settingsForm.read());
        const parsedAsilAlacak = hesap.numberOrNull(payload?.parsed?.asilAlacak);
        const parsedGecmisFaiz = hesap.numberOrNull(payload?.parsed?.gecmisGunFaizi);

        state.currentRunMode = RUN_MODES.DOSYA_HESABI;
        chrome.storage.local.set({ runnerResults: merged }, () => {
          renderResults(merged, state.currentRunMode);
          shell.persistLiveView();
          shell.setStatus(
            `Takip evrakı uygulandı. Kaynak: ${payload.source} | Asıl Alacak: ${
              parsedAsilAlacak ?? "-"
            } | Geçmiş Gün Faizi: ${parsedGecmisFaiz ?? "-"}`
          );
        });
      } catch (error) {
        shell.setStatus(`UDF yükleme hatası: ${error && error.message ? error.message : error}`, true);
      }
    };

    return {
      applyTakipEvraki,
      continueRun,
      exportResults,
      getEffectiveMode,
      handleProgressMessage,
      renderProgress,
      renderResults,
      setRunUiState,
      startRun,
      stopRun
    };
  };

  window.MiniIcraQueryController = {
    createQueryController
  };
})();

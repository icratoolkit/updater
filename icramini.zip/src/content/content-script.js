(() => {
  const runtimeReady = () => {
    try {
      return !!(chrome && chrome.runtime && chrome.runtime.id);
    } catch {
      return false;
    }
  };

  if (!runtimeReady()) {
    return;
  }

  if (window.__EWR_CONTENT_LOADED__ === true) {
    return;
  }
  window.__EWR_CONTENT_LOADED__ = true;

  const isLikelyTargetFrame = () => {
    const href = String(window.location.href || "").toLowerCase();
    const path = String(window.location.pathname || "").toLowerCase();
    if (href.includes("/dosya-sorgulama") || path.includes("/dosya-sorgulama")) {
      return true;
    }
    return window === window.top;
  };

  // Bağımlılık sırası. script.async = false olduğu için tarayıcı bu sırayı korur;
  // her betik kendinden öncekilerin ad alanlarına güvenebilir. Yeni dosya
  // eklerken manifest.json web_accessible_resources'a da yazmayı unutma.
  const INJECTED_SCRIPTS = [
    "assets/vendor/fflate.min.js",
    "src/shared/text-utils.js",
    "src/shared/hesap/normalizers.js",
    "src/shared/hesap/classifiers.js",
    "src/shared/hesap/scoring.js",
    "src/shared/hesap/vekalet.js",
    "src/shared/hesap/extractors.js",
    "src/injected/page-runner-core.js",
    "src/popup/modules/talep-template.js",
    "src/injected/extract/evrak.js",
    "src/injected/extract/taraf.js",
    "src/injected/extract/tahsilat.js",
    "src/injected/extract/binary.js",
    "src/injected/extract/pdf.js",
    "src/injected/extract/takip-talebi.js",
    "src/injected/page-runner-extract.js",
    "src/injected/query/progress.js",
    "src/injected/query/talep-sender.js",
    "src/injected/query/dosya-hesabi.js",
    "src/injected/query/kesinlestirme.js",
    "src/injected/haciz/core.js",
    "src/injected/haciz/sorgu.js",
    "src/injected/haciz/talep.js",
    "src/injected/page-runner.js",
    "src/injected/haciz/page-runner-haciz.js"
  ];

  const inject = (fileName) => {
    const script = document.createElement("script");
    try {
      const version = chrome.runtime.getManifest().version || "0";
      // Sürüm + zaman damgası: uzantı güncellenince tarayıcı eski betiği sunmasın.
      script.src = `${chrome.runtime.getURL(fileName)}?v=${encodeURIComponent(version)}&ts=${Date.now()}`;
    } catch {
      return false;
    }
    script.async = false;
    (document.head || document.documentElement).appendChild(script);
    script.remove();
    return true;
  };

  for (const fileName of INJECTED_SCRIPTS) {
    if (!inject(fileName)) {
      return;
    }
  }

  const pending = new Map();
  const requestMeta = new Map();
  const lastProgressByRequestId = new Map();

  const newRequestId = (prefix) => `${prefix}${Date.now()}_${Math.random().toString(36).slice(2)}`;

  const postToPage = (type, payload = {}) => {
    window.postMessage({ __EWR_EXT__: true, type, ...payload }, "*");
  };

  const buildHacizInputKeyFromItems = (items) =>
    (Array.isArray(items) ? items : [])
      .map((item) => `${String(item.birimId || item.birimAdi || "")}|${String(item.dosyaNo || item.input || "")}`)
      .join("|");

  const buildHacizInputKeyFromInputs = (inputs) =>
    (Array.isArray(inputs) ? inputs : [])
      .map((input) =>
        typeof input === "object"
          ? `${String(input.birimId || input.birimAdi || "")}|${String(input.dosyaNo || "")}`
          : String(input || "")
      )
      .join("|");

  // Önbellek yalnızca istenen sorgu türlerinin tamamı içinde varsa kullanılabilir.
  const isModeSuperset = (cachedModes, currentModes) => {
    const cached = new Set(Array.isArray(cachedModes) ? cachedModes : []);
    return (Array.isArray(currentModes) ? currentModes : []).every((mode) => cached.has(mode));
  };

  const mergeHacizBorclu = (prev, next, selectedModes) => {
    const modeSet = new Set(Array.isArray(selectedModes) ? selectedModes : []);
    const merged = { ...(prev || {}), ...(next || {}) };

    if (!prev) {
      return merged;
    }

    const listFields = [
      ["arac", "aracList", "aracError"],
      ["banka", "bankaList", "bankaError"],
      ["takbis", "takbisList", "takbisError"]
    ];
    for (const [mode, listKey, errorKey] of listFields) {
      if (!modeSet.has(mode)) {
        merged[listKey] = Array.isArray(prev[listKey]) ? prev[listKey] : [];
        merged[errorKey] = prev[errorKey] || null;
      }
    }
    if (!modeSet.has("icraDosyasi")) {
      merged.icraDosyasiVar = prev.icraDosyasiVar === true;
      merged.icraDosyasiError = prev.icraDosyasiError || null;
    }

    return merged;
  };

  const mergeHacizItems = (prevItems, nextItems, selectedModes) => {
    const itemKey = (item) => `${item.dosyaNo || item.input || ""}`;
    const borcluKey = (borclu) => `${borclu.kisiKurumId || ""}|${borclu.kisi || ""}`;
    const prevMap = new Map((Array.isArray(prevItems) ? prevItems : []).map((item) => [itemKey(item), item]));

    return (Array.isArray(nextItems) ? nextItems : []).map((item) => {
      const prev = prevMap.get(itemKey(item));
      if (!prev || !Array.isArray(item.borclular)) {
        return item;
      }

      const prevBorcluMap = new Map(
        (Array.isArray(prev.borclular) ? prev.borclular : []).map((borclu) => [borcluKey(borclu), borclu])
      );
      const borclular = item.borclular.map((borclu) =>
        mergeHacizBorclu(prevBorcluMap.get(borcluKey(borclu)), borclu, selectedModes)
      );

      const hasData =
        borclular.some((b) => Array.isArray(b.aracList) && b.aracList.length > 0) ||
        borclular.some((b) => Array.isArray(b.bankaList) && b.bankaList.length > 0) ||
        borclular.some((b) => Array.isArray(b.takbisList) && b.takbisList.length > 0) ||
        borclular.some((b) => b.icraDosyasiVar === true);

      return { ...prev, ...item, borclular, isMatch: hasData };
    });
  };

  const mergeTalepResults = (prevResults, nextResults) => {
    const merged = new Map();
    for (const result of [
      ...(Array.isArray(prevResults) ? prevResults : []),
      ...(Array.isArray(nextResults) ? nextResults : [])
    ]) {
      merged.set(`${result.dosyaNo || ""}|${result.kisi || ""}`, result);
    }
    return Array.from(merged.values());
  };

  const cacheHacizQueryResults = (result) => {
    if (!Array.isArray(result.items) || result.items.length === 0) {
      return;
    }
    const inputKey = buildHacizInputKeyFromItems(result.items);
    const modes = Array.isArray(result.modes) ? result.modes : [];

    chrome.storage.local.get({ hacizQueryCache: null }, ({ hacizQueryCache }) => {
      const sameInput = hacizQueryCache && hacizQueryCache.inputKey === inputKey;
      chrome.storage.local.set({
        hacizQueryCache: {
          inputKey,
          items: sameInput ? mergeHacizItems(hacizQueryCache.items, result.items, modes) : result.items,
          modes: Array.from(
            new Set([...(Array.isArray(hacizQueryCache?.modes) ? hacizQueryCache.modes : []), ...modes])
          ),
          talepResults: sameInput
            ? mergeTalepResults(hacizQueryCache.talepResults, result.talepResults)
            : Array.isArray(result.talepResults)
              ? result.talepResults
              : [],
          ts: Date.now()
        }
      });
    });
  };

  const handlePageFetch = (data) => {
    const requestId = String(data.requestId || "");
    if (!requestId) {
      return;
    }

    const reply = (fields) => {
      window.postMessage({ __EWR_EXT_FETCH_RES__: true, requestId, ...fields }, "*");
    };

    try {
      chrome.runtime.sendMessage(
        {
          action: "externalFetch",
          url: data.url,
          method: data.method,
          headers: data.headers,
          body: data.body
        },
        (response) => {
          const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : null;
          reply({
            ok: !!(response && response.ok),
            status: response && typeof response.status === "number" ? response.status : 0,
            text: response ? response.text : null,
            json: response ? response.json : null,
            error: err || (response && response.error) || null
          });
        }
      );
    } catch (error) {
      reply({
        ok: false,
        status: 0,
        text: null,
        json: null,
        error: String(error && error.message ? error.message : error)
      });
    }
  };

  const handleQueryProgress = (data) => {
    lastProgressByRequestId.set(String(data.requestId || ""), data.progress || null);

    try {
      if (chrome?.storage?.local) {
        chrome.storage.local.set({
          runnerProgress: {
            requestId: data.requestId,
            progress: data.progress,
            updatedAt: new Date().toISOString()
          },
          runnerLastRunPanel: data.progress?.runMode === "dosyaHesabi" ? "dosya" : "query"
        });
      }
    } catch {}

    try {
      if (runtimeReady()) {
        chrome.runtime.sendMessage({
          action: "runnerProgress",
          requestId: data.requestId,
          progress: data.progress
        });
      }
    } catch {}
  };

  const handleHacizProgress = (data) => {
    lastProgressByRequestId.set(String(data.requestId || ""), data.progress || null);

    try {
      if (chrome?.storage?.local) {
        chrome.storage.local.set({
          runnerHacizProgress: {
            requestId: data.requestId,
            progress: data.progress,
            updatedAt: new Date().toISOString()
          },
          runnerLastRunPanel: "haciz"
        });
      }
    } catch {}
  };

  const persistHacizResult = (result, meta, lastProgress) => {
    chrome.storage.local.set({
      runnerHacizProgress: null,
      runnerHacizResults: result,
      runnerLastRunPanel: "haciz"
    });

    if (result.stopped && meta && meta.type === "hacizFull") {
      chrome.storage.local.set({
        runnerHacizResumeState: { ...meta, stoppedAt: new Date().toISOString(), lastProgress }
      });
    } else {
      chrome.storage.local.set({ runnerHacizResumeState: null });
    }

    try {
      cacheHacizQueryResults(result);
    } catch {}
  };

  const persistQueryResult = (result, meta, lastProgress) => {
    chrome.storage.local.set({
      runnerProgress: null,
      runnerResults: result,
      runnerLastRunPanel: result?.runMode === "dosyaHesabi" ? "dosya" : "query"
    });

    if (!result.stopped || !meta || meta.type !== "query") {
      chrome.storage.local.set({ runnerResumeState: null });
      return;
    }

    const completedItems = [
      ...(Array.isArray(meta.resumeCompletedItems) ? meta.resumeCompletedItems : []),
      ...(Array.isArray(result.items) ? result.items : [])
    ];
    const originalInputs = Array.isArray(meta.resumeOriginalInputs)
      ? meta.resumeOriginalInputs
      : Array.isArray(meta.inputs)
        ? meta.inputs
        : [];

    chrome.storage.local.set({
      runnerResumeState: {
        type: "query",
        settings: meta.settings,
        runMode: meta.runMode,
        enableBarcode: !!meta.enableBarcode,
        inputs: originalInputs.slice(completedItems.length),
        resumeOriginalInputs: originalInputs,
        resumeCompletedItems: completedItems,
        stoppedAt: new Date().toISOString(),
        lastProgress
      }
    });
  };

  const handlePageResult = (payload) => {
    if (!payload.requestId || !pending.has(payload.requestId)) {
      return;
    }

    const requestId = String(payload.requestId || "");
    const meta = requestMeta.get(requestId) || null;
    const lastProgress = lastProgressByRequestId.get(requestId) || null;

    try {
      if (chrome?.storage?.local) {
        if (payload.ok && payload.result) {
          if (payload.result.runMode === "haciz") {
            persistHacizResult(payload.result, meta, lastProgress);
          } else {
            persistQueryResult(payload.result, meta, lastProgress);
          }
        } else {
          chrome.storage.local.set({ runnerProgress: null, runnerHacizProgress: null });
        }
      }
    } catch {}

    requestMeta.delete(requestId);
    lastProgressByRequestId.delete(requestId);

    const done = pending.get(payload.requestId);
    pending.delete(payload.requestId);
    done(payload);
  };

  window.addEventListener("message", (event) => {
    if (event.source !== window || !event.data) {
      return;
    }

    const data = event.data;
    if (data.__EWR_PAGE_FETCH__ === true) {
      handlePageFetch(data);
      return;
    }
    if (data.__EWR_PAGE_PROGRESS__ === true) {
      handleQueryProgress(data);
      return;
    }
    if (data.__EWR_HACIZ_PROGRESS__ === true) {
      handleHacizProgress(data);
      return;
    }
    if (data.__EWR_PAGE__ === true) {
      handlePageResult(data);
    }
  });

  const KNOWN_ACTIONS = [
    "runInPage",
    "stopInPage",
    "runHacizInPage",
    "stopHacizInPage",
    "sendHacizTalepInPage",
    "runHacizFullInPage"
  ];

  const replyWithResult = (sendResponse) => (payload) => {
    if (payload.ok) {
      sendResponse({ ok: true, result: payload.result });
    } else {
      sendResponse({ ok: false, error: payload.error || "Bilinmeyen hata" });
    }
  };

  const readHacizCache = (message, hacizQueryCache) => {
    try {
      if (!hacizQueryCache || !Array.isArray(hacizQueryCache.items) || hacizQueryCache.items.length === 0) {
        return { cachedItems: null, cachedTalepResults: null };
      }
      const inputKey = buildHacizInputKeyFromInputs(message.inputs || []);
      const currentModes = Array.isArray(message.settings.hacizModes) ? message.settings.hacizModes : [];
      if (hacizQueryCache.inputKey !== inputKey || !isModeSuperset(hacizQueryCache.modes, currentModes)) {
        return { cachedItems: null, cachedTalepResults: null };
      }
      return {
        cachedItems: hacizQueryCache.items,
        cachedTalepResults: Array.isArray(hacizQueryCache.talepResults) ? hacizQueryCache.talepResults : null
      };
    } catch {
      return { cachedItems: null, cachedTalepResults: null };
    }
  };

  const handlePopupCommand = (message, sendResponse) => {
    if (message.action === "stopInPage") {
      postToPage("STOP_WORKFLOW");
      sendResponse({ ok: true });
      return undefined;
    }

    if (message.action === "stopHacizInPage") {
      postToPage("STOP_HACIZ");
      sendResponse({ ok: true });
      return undefined;
    }

    if (message.action === "runHacizInPage") {
      const requestId = newRequestId("haciz_");
      requestMeta.set(requestId, { type: "haciz", settings: message.settings, inputs: message.inputs });
      pending.set(requestId, replyWithResult(sendResponse));
      postToPage("RUN_HACIZ", { requestId, settings: message.settings, inputs: message.inputs });
      return true;
    }

    if (message.action === "sendHacizTalepInPage") {
      const requestId = newRequestId("haciz_talep_");
      requestMeta.set(requestId, { type: "hacizTalep", settings: message.settings, items: message.items });
      pending.set(requestId, () => {});
      postToPage("SEND_HACIZ_TALEP", {
        requestId,
        settings: message.settings,
        items: message.items,
        bankaHacizData: message.bankaHacizData
      });
      sendResponse({ ok: true, started: true, requestId });
      return undefined;
    }

    if (message.action === "runHacizFullInPage") {
      const requestId = newRequestId("haciz_full_");
      requestMeta.set(requestId, {
        type: "hacizFull",
        settings: message.settings,
        inputs: message.inputs,
        bankaHacizData: message.bankaHacizData
      });
      pending.set(requestId, () => {});

      chrome.storage.local.get({ hacizQueryCache: null }, ({ hacizQueryCache }) => {
        const { cachedItems, cachedTalepResults } = readHacizCache(message, hacizQueryCache);
        postToPage("RUN_HACIZ_FULL", {
          requestId,
          settings: message.settings,
          inputs: message.inputs,
          bankaHacizData: message.bankaHacizData,
          cachedQueryItems: cachedItems,
          cachedTalepResults
        });
      });

      sendResponse({ ok: true, started: true, requestId });
      return undefined;
    }

    // runInPage
    const requestId = newRequestId("");
    requestMeta.set(requestId, {
      type: "query",
      settings: message.settings,
      inputs: message.inputs,
      runMode: message.runMode || "normal",
      enableBarcode: !!message.enableBarcode,
      resumeOriginalInputs: message.resumeOriginalInputs,
      resumeCompletedItems: message.resumeCompletedItems
    });
    pending.set(requestId, replyWithResult(sendResponse));
    postToPage("RUN_WORKFLOW", {
      requestId,
      settings: message.settings,
      inputs: message.inputs,
      runMode: message.runMode || "normal",
      enableBarcode: !!message.enableBarcode
    });
    return true;
  };

  try {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (!runtimeReady() || !message || !KNOWN_ACTIONS.includes(message.action)) {
        return undefined;
      }
      if (!isLikelyTargetFrame()) {
        return undefined;
      }
      return handlePopupCommand(message, sendResponse);
    });
  } catch {}
})();

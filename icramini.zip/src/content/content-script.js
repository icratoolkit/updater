﻿(() => {
  const runtimeReady = () => {
    try {
      return !!(chrome && chrome.runtime && chrome.runtime.id);
    } catch {
      return false;
    }
  };

  if (!runtimeReady()) {
    return;
  }

  if (window.__EWR_CONTENT_LOADED__ === true) {
    return;
  }
  window.__EWR_CONTENT_LOADED__ = true;

  const isLikelyTargetFrame = () => {
    const href = String(window.location.href || "").toLowerCase();
    const path = String(window.location.pathname || "").toLowerCase();
    if (href.includes("/dosya-sorgulama") || path.includes("/dosya-sorgulama")) {
      return true;
    }

    return window === window.top;
  };

  const inject = (fileName) => {
    const script = document.createElement("script");
    try {
      const ver = chrome.runtime.getManifest().version || "0";
      script.src = `${chrome.runtime.getURL(fileName)}?v=${encodeURIComponent(ver)}&ts=${Date.now()}`;
    } catch {
      return false;
    }
    script.async = false;
    (document.head || document.documentElement).appendChild(script);
    script.remove();
    return true;
  };

  if (!inject("src/shared/text-utils.js")) {
    return;
  }
  if (!inject("src/shared/hesap/normalizers.js")) {
    return;
  }
  if (!inject("src/shared/hesap/classifiers.js")) {
    return;
  }
  if (!inject("src/shared/hesap/scoring.js")) {
    return;
  }
  if (!inject("src/shared/hesap/extractors.js")) {
    return;
  }
  if (!inject("assets/vendor/fflate.min.js")) {
    return;
  }
  if (!inject("src/injected/page-runner-core.js")) {
    return;
  }
  if (!inject("src/popup/modules/talep-template.js")) {
    return;
  }
  if (!inject("src/injected/page-runner-extract.js")) {
    return;
  }
  inject("src/injected/page-runner.js");
  inject("src/injected/haciz/page-runner-haciz.js");

  const pending = new Map();
  const requestMeta = new Map();
  const lastProgressByRequestId = new Map();

  const buildHacizInputKeyFromItems = (items) =>
    (Array.isArray(items) ? items : [])
      .map((it) => `${String(it.birimId || it.birimAdi || "")}|${String(it.dosyaNo || it.input || "")}`)
      .join("|");

  const buildHacizInputKeyFromInputs = (inputs) =>
    (Array.isArray(inputs) ? inputs : [])
      .map((i) => typeof i === "object"
        ? `${String(i.birimId || i.birimAdi || "")}|${String(i.dosyaNo || "")}`
        : String(i || ""))
      .join("|");

  const isModeSuperset = (cachedModes, currentModes) => {
    const cached = new Set(Array.isArray(cachedModes) ? cachedModes : []);
    for (const mode of (Array.isArray(currentModes) ? currentModes : [])) {
      if (!cached.has(mode)) {
        return false;
      }
    }
    return true;
  };

  const mergeHacizBorclu = (prev, next, selectedModes) => {
    const modeSet = new Set(Array.isArray(selectedModes) ? selectedModes : []);
    const merged = {
      ...(prev || {}),
      ...(next || {})
    };

    if (!modeSet.has("arac") && prev) {
      merged.aracList = Array.isArray(prev.aracList) ? prev.aracList : [];
      merged.aracError = prev.aracError || null;
    }
    if (!modeSet.has("banka") && prev) {
      merged.bankaList = Array.isArray(prev.bankaList) ? prev.bankaList : [];
      merged.bankaError = prev.bankaError || null;
    }
    if (!modeSet.has("takbis") && prev) {
      merged.takbisList = Array.isArray(prev.takbisList) ? prev.takbisList : [];
      merged.takbisError = prev.takbisError || null;
    }
    if (!modeSet.has("icraDosyasi") && prev) {
      merged.icraDosyasiVar = prev.icraDosyasiVar === true;
      merged.icraDosyasiError = prev.icraDosyasiError || null;
    }

    return merged;
  };

  const mergeHacizItems = (prevItems, nextItems, selectedModes) => {
    const prevMap = new Map((Array.isArray(prevItems) ? prevItems : []).map((item) => [`${item.dosyaNo || item.input || ""}`, item]));

    return (Array.isArray(nextItems) ? nextItems : []).map((item) => {
      const prev = prevMap.get(`${item.dosyaNo || item.input || ""}`);
      if (!prev || !Array.isArray(item.borclular)) {
        return item;
      }

      const prevBorcluMap = new Map((Array.isArray(prev.borclular) ? prev.borclular : []).map((b) => [`${b.kisiKurumId || ""}|${b.kisi || ""}`, b]));
      const borclular = item.borclular.map((borclu) =>
        mergeHacizBorclu(prevBorcluMap.get(`${borclu.kisiKurumId || ""}|${borclu.kisi || ""}`), borclu, selectedModes)
      );

      const hasArac = borclular.some((b) => Array.isArray(b.aracList) && b.aracList.length > 0);
      const hasBanka = borclular.some((b) => Array.isArray(b.bankaList) && b.bankaList.length > 0);
      const hasTakbis = borclular.some((b) => Array.isArray(b.takbisList) && b.takbisList.length > 0);
      const hasIcraDosyasi = borclular.some((b) => b.icraDosyasiVar === true);

      return {
        ...prev,
        ...item,
        borclular,
        isMatch: hasArac || hasBanka || hasTakbis || hasIcraDosyasi
      };
    });
  };

  const mergeTalepResults = (prevResults, nextResults) => {
    const merged = new Map();
    for (const result of (Array.isArray(prevResults) ? prevResults : [])) {
      merged.set(`${result.dosyaNo || ""}|${result.kisi || ""}`, result);
    }
    for (const result of (Array.isArray(nextResults) ? nextResults : [])) {
      merged.set(`${result.dosyaNo || ""}|${result.kisi || ""}`, result);
    }
    return Array.from(merged.values());
  };

  window.addEventListener("message", (event) => {
    if (event.source !== window || !event.data) {
      return;
    }

    if (event.data.__EWR_PAGE_FETCH__ === true) {
      const payload = event.data || {};
      const requestId = String(payload.requestId || "");
      if (!requestId) {
        return;
      }

      try {
        chrome.runtime.sendMessage(
          {
            action: "externalFetch",
            url: payload.url,
            method: payload.method,
            headers: payload.headers,
            body: payload.body
          },
          (response) => {
            const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : null;
            window.postMessage(
              {
                __EWR_EXT_FETCH_RES__: true,
                requestId,
                ok: !!(response && response.ok),
                status: response && typeof response.status === "number" ? response.status : 0,
                text: response ? response.text : null,
                json: response ? response.json : null,
                error: err || (response && response.error) || null
              },
              "*"
            );
          }
        );
      } catch (e) {
        window.postMessage(
          {
            __EWR_EXT_FETCH_RES__: true,
            requestId,
            ok: false,
            status: 0,
            text: null,
            json: null,
            error: String(e && e.message ? e.message : e)
          },
          "*"
        );
      }
      return;
    }

    if (event.data.__EWR_PAGE_PROGRESS__ === true) {
      const progressPayload = {
        requestId: event.data.requestId,
        progress: event.data.progress,
        updatedAt: new Date().toISOString()
      };
      lastProgressByRequestId.set(String(event.data.requestId || ""), event.data.progress || null);
      try {
        if (chrome?.storage?.local) {
          chrome.storage.local.set({ runnerProgress: progressPayload, runnerLastRunPanel: event.data.progress?.runMode === "dosyaHesabi" ? "dosya" : "query" });
        }
      } catch {
      }

      try {
        if (runtimeReady()) {
          chrome.runtime.sendMessage({
            action: "runnerProgress",
            requestId: event.data.requestId,
            progress: event.data.progress
          });
        }
      } catch {
      }
      return;
    }

    if (event.data.__EWR_HACIZ_PROGRESS__ === true) {
      lastProgressByRequestId.set(String(event.data.requestId || ""), event.data.progress || null);
      try {
        if (chrome?.storage?.local) {
          chrome.storage.local.set({
            runnerHacizProgress: {
              requestId:  event.data.requestId,
              progress:   event.data.progress,
              updatedAt:  new Date().toISOString()
            },
            runnerLastRunPanel: "haciz"
          });
        }
      } catch {
      }
      return;
    }

    if (event.data.__EWR_PAGE__ !== true) {
      return;
    }

    const payload = event.data;
    if (!payload.requestId || !pending.has(payload.requestId)) {
      return;
    }

    try {
      if (chrome?.storage?.local) {
        if (payload.ok && payload.result) {
          const isHacizResult = payload.result && payload.result.runMode === "haciz";
          const meta = requestMeta.get(String(payload.requestId || "")) || null;
          const lastProgress = lastProgressByRequestId.get(String(payload.requestId || "")) || null;
          if (isHacizResult) {
            chrome.storage.local.set({
              runnerHacizProgress: null,
              runnerHacizResults: payload.result,
              runnerLastRunPanel: "haciz"
            });
            if (payload.result.stopped && meta && meta.type === "hacizFull") {
              chrome.storage.local.set({
                runnerHacizResumeState: {
                  ...meta,
                  stoppedAt: new Date().toISOString(),
                  lastProgress
                }
              });
            } else {
              chrome.storage.local.set({ runnerHacizResumeState: null });
            }
            // Sorgu sonuçlarını cache'le (talep tekrarında sorgu atlamak için)
            try {
              if (Array.isArray(payload.result.items) && payload.result.items.length > 0) {
                const inputKey = buildHacizInputKeyFromItems(payload.result.items);
                const modes = Array.isArray(payload.result.modes) ? payload.result.modes : [];
                chrome.storage.local.get({ hacizQueryCache: null }, ({ hacizQueryCache }) => {
                  const sameInput = hacizQueryCache && hacizQueryCache.inputKey === inputKey;
                  const mergedModes = Array.from(new Set([
                    ...(Array.isArray(hacizQueryCache?.modes) ? hacizQueryCache.modes : []),
                    ...modes
                  ]));
                  chrome.storage.local.set({
                    hacizQueryCache: {
                      inputKey,
                      items: sameInput
                        ? mergeHacizItems(hacizQueryCache.items, payload.result.items, modes)
                        : payload.result.items,
                      modes: mergedModes,
                      talepResults: sameInput
                        ? mergeTalepResults(hacizQueryCache.talepResults, payload.result.talepResults)
                        : (Array.isArray(payload.result.talepResults) ? payload.result.talepResults : []),
                      ts: Date.now()
                    }
                  });
                });
              }
            } catch { /* cache kayıt hatası önemsiz */ }
          } else {
            chrome.storage.local.set({
              runnerProgress: null,
              runnerResults: payload.result,
              runnerLastRunPanel: payload.result?.runMode === "dosyaHesabi" ? "dosya" : "query"
            });
            if (payload.result.stopped && meta && meta.type === "query") {
              const completedItems = [
                ...(Array.isArray(meta.resumeCompletedItems) ? meta.resumeCompletedItems : []),
                ...(Array.isArray(payload.result.items) ? payload.result.items : [])
              ];
              const originalInputs = Array.isArray(meta.resumeOriginalInputs) ? meta.resumeOriginalInputs : (Array.isArray(meta.inputs) ? meta.inputs : []);
              const remainingInputs = originalInputs.slice(completedItems.length);
              chrome.storage.local.set({
                runnerResumeState: {
                  type: "query",
                  settings: meta.settings,
                  runMode: meta.runMode,
                  enableBarcode: !!meta.enableBarcode,
                  inputs: remainingInputs,
                  resumeOriginalInputs: originalInputs,
                  resumeCompletedItems: completedItems,
                  stoppedAt: new Date().toISOString(),
                  lastProgress
                }
              });
            } else {
              chrome.storage.local.set({ runnerResumeState: null });
            }
          }
        } else {
          // Hata durumunda hem normal hem haciz progress temizle
          chrome.storage.local.set({
            runnerProgress: null,
            runnerHacizProgress: null
          });
        }
      }
    } catch {
    }

    requestMeta.delete(String(payload.requestId || ""));
    lastProgressByRequestId.delete(String(payload.requestId || ""));

    const done = pending.get(payload.requestId);
    pending.delete(payload.requestId);
    done(payload);
  });

  try {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (!runtimeReady()) {
        return;
      }

      const knownActions = ["runInPage", "stopInPage", "runHacizInPage", "stopHacizInPage", "sendHacizTalepInPage", "runHacizFullInPage"];
      if (!message || !knownActions.includes(message.action)) {
        return;
      }

      if (!isLikelyTargetFrame()) {
        return;
      }

      if (message.action === "stopInPage") {
        window.postMessage(
          {
            __EWR_EXT__: true,
            type: "STOP_WORKFLOW"
          },
          "*"
        );
        sendResponse({ ok: true });
        return;
      }

      if (message.action === "stopHacizInPage") {
        window.postMessage(
          {
            __EWR_EXT__: true,
            type: "STOP_HACIZ"
          },
          "*"
        );
        sendResponse({ ok: true });
        return;
      }

      if (message.action === "runHacizInPage") {
        const requestId = `haciz_${Date.now()}_${Math.random().toString(36).slice(2)}`;
        requestMeta.set(requestId, {
          type: "haciz",
          settings: message.settings,
          inputs: message.inputs
        });

        pending.set(requestId, (payload) => {
          if (payload.ok) {
            sendResponse({ ok: true, result: payload.result });
          } else {
            sendResponse({ ok: false, error: payload.error || "Bilinmeyen hata" });
          }
        });

        window.postMessage(
          {
            __EWR_EXT__: true,
            type: "RUN_HACIZ",
            requestId,
            settings: message.settings,
            inputs:   message.inputs
          },
          "*"
        );

        return true;
      }

      if (message.action === "sendHacizTalepInPage") {
        const requestId = `haciz_talep_${Date.now()}_${Math.random().toString(36).slice(2)}`;
        requestMeta.set(requestId, {
          type: "hacizTalep",
          settings: message.settings,
          items: message.items
        });

        // Talep uzun sürebilir; port kapanmasını önlemek için hemen yanıt ver.
        // Sonuç chrome.storage.local üzerinden (runnerHacizResults) popup'a ulaşır.
        pending.set(requestId, () => {});

        window.postMessage(
          {
            __EWR_EXT__: true,
            type: "SEND_HACIZ_TALEP",
            requestId,
            settings:       message.settings,
            items:          message.items,
            bankaHacizData: message.bankaHacizData
          },
          "*"
        );

        sendResponse({ ok: true, started: true, requestId });
        return;
      }

      if (message.action === "runHacizFullInPage") {
        const requestId = `haciz_full_${Date.now()}_${Math.random().toString(36).slice(2)}`;
        requestMeta.set(requestId, {
          type: "hacizFull",
          settings: message.settings,
          inputs: message.inputs,
          bankaHacizData: message.bankaHacizData
        });

        // Sorgu + talep birleşik akış — uzun sürer, hemen yanıt ver.
        pending.set(requestId, () => {});

        // Cache kontrolü: input değişmediyse önceki sorgu sonuçlarını ilet
        chrome.storage.local.get({ hacizQueryCache: null }, ({ hacizQueryCache }) => {
          let cachedItems = null;
          let cachedTalepResults = null;
          try {
            if (hacizQueryCache && Array.isArray(hacizQueryCache.items) && hacizQueryCache.items.length > 0) {
              const inputs = message.inputs || [];
              const inputKey = buildHacizInputKeyFromInputs(inputs);
              const currentModes = Array.isArray(message.settings.hacizModes) ? message.settings.hacizModes : [];
              if (hacizQueryCache.inputKey === inputKey && isModeSuperset(hacizQueryCache.modes, currentModes)) {
                cachedItems = hacizQueryCache.items;
                cachedTalepResults = Array.isArray(hacizQueryCache.talepResults) ? hacizQueryCache.talepResults : null;
              }
            }
          } catch { /* cache okuma başarısız olursa temiz sorgu */ }

          window.postMessage(
            {
              __EWR_EXT__: true,
              type: "RUN_HACIZ_FULL",
              requestId,
              settings:        message.settings,
              inputs:          message.inputs,
              bankaHacizData:  message.bankaHacizData,
              cachedQueryItems: cachedItems,
              cachedTalepResults: cachedTalepResults
            },
            "*"
          );
        });

        sendResponse({ ok: true, started: true, requestId });
        return;
      }

      // runInPage
      const requestId = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
      requestMeta.set(requestId, {
        type: "query",
        settings: message.settings,
        inputs: message.inputs,
        runMode: message.runMode || "normal",
        enableBarcode: !!message.enableBarcode,
        resumeOriginalInputs: message.resumeOriginalInputs,
        resumeCompletedItems: message.resumeCompletedItems
      });

      pending.set(requestId, (payload) => {
        if (payload.ok) {
          sendResponse({ ok: true, result: payload.result });
        } else {
          sendResponse({ ok: false, error: payload.error || "Bilinmeyen hata" });
        }
      });

      window.postMessage(
      {
        __EWR_EXT__: true,
        type: "RUN_WORKFLOW",
        requestId,
        settings: message.settings,
        inputs: message.inputs,
        runMode: message.runMode || "normal",
        enableBarcode: !!message.enableBarcode
      },
      "*"
    );

      return true;
    });
  } catch {
  }
})();


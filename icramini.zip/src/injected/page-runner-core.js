(() => {
  const __EWR_PAGE_TOKEN__ = (() => {
    try {
      const src = (document.currentScript && document.currentScript.src) || "";
      return new URL(src, window.location.href).searchParams.get("ts") || "";
    } catch {
      return "";
    }
  })();

  const __EWR_PAGE_BASE_URL__ = (() => {
    try {
      const src = (document.currentScript && document.currentScript.src) || "";
      return src ? new URL(".", new URL(src, window.location.href)).toString() : "";
    } catch {
      return "";
    }
  })();

  const handledRequestIds = new Set();
  const runState = {
    isRunning: false,
    stopRequested: false,
    activeController: null
  };

  const DEFAULT_SETTINGS = {
    firstEndpointPath: "/search_phrase_detayli.ajx",
    firstMethod: "POST",
    firstHeadersText: "{\n  \"Content-Type\": \"application/json\"\n}",
    firstBodyTemplate: "{\n  \"dosyaDurumKod\": 0,\n  \"pageSize\": 500,\n  \"pageNumber\": 1,\n  \"dosyaYil\": \"{{dosyaYil}}\",\n  \"dosyaSira\": \"{{dosyaSira}}\",\n  \"birimId\": \"{{birimId}}\",\n  \"birimTuru2\": \"1101\",\n  \"birimTuru3\": \"2\"\n}",
    secondEndpointPath: "/dosya_hesap_bilgileri.ajx",
    secondMethod: "POST",
    secondHeadersText: "{\n  \"Content-Type\": \"application/json\",\n  \"X-Borclu\": \"undefined\",\n  \"X-Birim-Id\": \"{{birimId}}\",\n  \"X-Dosya-No\": \"{{inputEncoded}}\",\n  \"X-Birim-Adi\": \"{{birimAdi}}\",\n  \"X-Birim-Turu2\": \"undefined\",\n  \"X-Dosya-Durum\": \"{{dosyaDurum}}\"\n}",
    secondBodyTemplate: "{\n  \"dosyaId\": \"{{dosyaId}}\"\n}",
    thirdEndpointPath: "/list_dosya_evraklar.ajx",
    thirdMethod: "POST",
    thirdHeadersText:
      "{\n  \"Content-Type\": \"application/json\",\n  \"X-Borclu\": \"undefined\",\n  \"X-Birim-Id\": \"{{birimId}}\",\n  \"X-Dosya-No\": \"{{inputEncoded}}\",\n  \"X-Birim-Adi\": \"{{birimAdi}}\",\n  \"X-Birim-Turu2\": \"undefined\",\n  \"X-Dosya-Durum\": \"{{dosyaDurum}}\"\n}",
    thirdBodyTemplate: "{\n  \"dosyaId\": \"{{dosyaId}}\",\n  \"pageNumber\": 1\n}",
    fourthEndpointPath:
      "/view_document_brd.uyap?evrakId={{evrakIdEncoded}}&dosyaId={{dosyaIdEncoded}}&dosyaNo={{inputEncoded}}&birimAdi={{birimAdiEncoded}}&evrak={{evrakEncoded}}&tarih={{tarihEncoded}}&sira=undefined",
    fourthMethod: "GET",
    fourthHeadersText:
      "{\n  \"Content-Type\": \"application/octet-stream\",\n  \"X-Borclu\": \"undefined\",\n  \"X-Birim-Id\": \"{{birimId}}\",\n  \"X-Dosya-No\": \"{{inputEncoded}}\",\n  \"X-Birim-Adi\": \"{{birimAdi}}\",\n  \"X-Birim-Turu2\": \"undefined\",\n  \"X-Dosya-Durum\": \"{{dosyaDurum}}\"\n}",
    defaultBirimId: "",
    defaultBirimAdi: "",
    defaultDosyaDurum: "Acik",
    dosyaHesabiDosyaDurumKod: "0",
    dosyaHesabiIndirimTutari: ""
  };

  const parseInput = (value) => {
    const rawObj = value && typeof value === "object" ? value : null;
    const raw = String(rawObj ? rawObj.dosyaNo : value || "").trim();
    const m = raw.match(/^(\d{4})\s*\/\s*(\d+)$/);
    if (!m) {
      throw new Error(`Girdi formatı geçersizs: ${raw}. Beklenen: YYYY/NNN`);
    }
    return {
      raw,
      dosyaYil: m[1],
      dosyaSira: m[2],
      birimAdi: rawObj ? String(rawObj.birimAdi || "").trim() : "",
      birimId: rawObj ? String(rawObj.birimId || "").trim() : ""
    };
  };

  const applyTemplate = (template, ctx) =>
    String(template || "").replace(/{{\s*([a-zA-Z0-9_]+)\s*}}/g, (_, key) =>
      key in ctx ? String(ctx[key]) : ""
    );

  const escapeJsonTemplateValue = (value) =>
    JSON.stringify(String(value ?? ""))
      .slice(1, -1)
      .replace(/\u2028/g, "\\u2028")
      .replace(/\u2029/g, "\\u2029");

  const normalizeJsonBodyValue = (value) => {
    const raw = String(value ?? "");
    if (!raw || !raw.includes("%")) {
      return raw;
    }
    try {
      return decodeURIComponent(raw);
    } catch {
      return raw.replace(/%22/gi, "\"");
    }
  };

  const applyJsonTemplate = (template, ctx) =>
    String(template || "").replace(/{{\s*([a-zA-Z0-9_]+)\s*}}/g, (_, key) =>
      key in ctx ? escapeJsonTemplateValue(ctx[key]) : ""
    );

  const applyJsonBodyTemplate = (template, ctx) =>
    String(template || "").replace(/{{\s*([a-zA-Z0-9_]+)\s*}}/g, (_, key) =>
      key in ctx ? escapeJsonTemplateValue(normalizeJsonBodyValue(ctx[key])) : ""
    );

  const stripWrappingQuotes = (value) => String(value ?? "").trim().replace(/^"+|"+$/g, "");

  const applyDosyaDurumKodToRequestBody = (bodyText, dosyaDurumKod) => {
    const raw = String(bodyText || "");
    const code = String(dosyaDurumKod || "0") === "1" ? 1 : 0;
    try {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
        parsed.dosyaDurumKod = code;
        return JSON.stringify(parsed);
      }
    } catch {
    }
    return raw.replace(/("dosyaDurumKod"\s*:\s*)\d+/i, `$1${code}`);
  };

  const parseJsonSafe = (text) => {
    try {
      return JSON.parse(text);
    } catch {
      return null;
    }
  };

  const parseHeaders = (headersText, ctx) => {
    const raw = applyJsonTemplate(headersText || "{}", ctx);
    const parsed = parseJsonSafe(raw);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      throw new Error("Headers JSON geçersiz.");
    }
    const toSafeHeaderValue = (value) => {
      const s = String(value);
      for (let i = 0; i < s.length; i += 1) {
        if (s.charCodeAt(i) > 255) {
          return encodeURIComponent(s);
        }
      }
      return s;
    };

    return Object.fromEntries(
      Object.entries(parsed).map(([k, v]) => [String(k), toSafeHeaderValue(v)])
    );
  };

  const toAbsoluteUrl = (pathOrUrl) => {
    const raw = String(pathOrUrl || "").trim();
    if (!raw) {
      throw new Error("Endpoint boş.");
    }
    return new URL(raw, window.location.origin).toString();
  };

  const findByKeyDeep = (value, keyName) => {
    if (value == null) {
      return undefined;
    }
    if (Array.isArray(value)) {
      for (const item of value) {
        const found = findByKeyDeep(item, keyName);
        if (typeof found !== "undefined") {
          return found;
        }
      }
      return undefined;
    }
    if (typeof value === "object") {
      if (keyName in value) {
        return value[keyName];
      }
      for (const key of Object.keys(value)) {
        const found = findByKeyDeep(value[key], keyName);
        if (typeof found !== "undefined") {
          return found;
        }
      }
    }
    return undefined;
  };

  const collectObjectsDeep = (value, output) => {
    if (value == null) {
      return;
    }
    if (Array.isArray(value)) {
      for (const item of value) {
        collectObjectsDeep(item, output);
      }
      return;
    }
    if (typeof value === "object") {
      output.push(value);
      for (const key of Object.keys(value)) {
        collectObjectsDeep(value[key], output);
      }
    }
  };

  const numberOrNull = (value) => {
    if (typeof value === "number") {
      return Number.isFinite(value) ? value : null;
    }

    if (typeof value !== "string") {
      return null;
    }

    const s = value.trim();
    if (!s) {
      return null;
    }

    const compact = s.replace(/\s+/g, "");
    const direct = Number(compact);
    if (Number.isFinite(direct)) {
      return direct;
    }

    const match = compact.match(/-?\d[\d.,]*/);
    if (!match) {
      return null;
    }

    let candidate = match[0];
    const negative = candidate.startsWith("-");
    if (negative) {
      candidate = candidate.slice(1);
    }

    const commas = (candidate.match(/,/g) || []).length;
    const dots = (candidate.match(/\./g) || []).length;
    let normalized = candidate;

    if (commas > 0 && dots > 0) {
      const lastComma = candidate.lastIndexOf(",");
      const lastDot = candidate.lastIndexOf(".");
      const decimalSep = lastComma > lastDot ? "," : ".";
      const thousandsSep = decimalSep === "," ? "." : ",";
      normalized = candidate.split(thousandsSep).join("");
      if (decimalSep === ",") {
        normalized = normalized.replace(",", ".");
      }
    } else if (commas > 0) {
      if (commas === 1) {
        normalized = candidate.replace(",", ".");
      } else {
        normalized = candidate.split(",").join("");
      }
    } else if (dots > 0) {
      if (dots === 1) {
        normalized = candidate;
      } else {
        normalized = candidate.split(".").join("");
      }
    }

    if (negative) {
      normalized = `-${normalized}`;
    }

    const parsed = Number(normalized);
    return Number.isFinite(parsed) ? parsed : null;
  };

  const isYatanParaText = (textAlan) => {
    const text = String(textAlan || "")
      .trim()
      .toLocaleLowerCase("tr-TR");
    if (!text.startsWith("yatan para")) {
      return false;
    }
    if (text.includes("oran") || text.includes("%")) {
      return false;
    }
    return true;
  };

  let pdfJsLoadPromise = null;
  const getInjectedAssetUrl = (fileName) => {
    try {
      return new URL(fileName, __EWR_PAGE_BASE_URL__ || window.location.href).toString();
    } catch {
      return String(fileName || "");
    }
  };
  const ensurePdfJsLib = async () => {
    const existing = window.pdfjsLib || window["pdfjs-dist/build/pdf"];
    if (existing && typeof existing.getDocument === "function") {
      return existing;
    }

    if (pdfJsLoadPromise) {
      return pdfJsLoadPromise;
    }

    pdfJsLoadPromise = import(getInjectedAssetUrl("assets/vendor/pdf.min.mjs"))
      .then((mod) => {
        const lib =
          (mod && typeof mod.getDocument === "function" && mod) ||
          (mod && mod.default && typeof mod.default.getDocument === "function" && mod.default) ||
          null;
        if (lib && lib.GlobalWorkerOptions) {
          lib.GlobalWorkerOptions.workerSrc = getInjectedAssetUrl("assets/vendor/pdf.worker.min.mjs");
        }
        if (lib) {
          window["pdfjs-dist/build/pdf"] = lib;
        }
        return lib;
      })
      .catch(() => null);

    return pdfJsLoadPromise;
  };

  const parseYatanParaDateEntries = (textAlan) => {
    const text = String(textAlan || "");
    const regex = /(\d{2})\/(\d{2})\/(\d{4})\s*-\s*([0-9.,]+)/g;
    const out = [];
    let m;
    while ((m = regex.exec(text)) !== null) {
      const day = Number(m[1]);
      const month = Number(m[2]);
      const year = Number(m[3]);
      const amount = numberOrNull(m[4]);
      if (!Number.isFinite(day) || !Number.isFinite(month) || !Number.isFinite(year)) {
        continue;
      }
      out.push({ day, month, year, amount });
    }
    return out;
  };

  const parseIsoDateOnly = (value) => {
    const s = String(value || "").trim();
    const m = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!m) {
      return null;
    }
    const d = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])));
    return Number.isFinite(d.getTime()) ? d : null;
  };

  const utcMidnight = (year, month0, day) => new Date(Date.UTC(year, month0, day));

  const isEntryInDatedFilter = (entry, filterMode, now, settings) => {
    const date = utcMidnight(entry.year, entry.month - 1, entry.day);
    const today = utcMidnight(now.getFullYear(), now.getMonth(), now.getDate());

    if (filterMode === "today") {
      return date.getTime() === today.getTime();
    }

    if (filterMode === "thisWeek") {
      const dow = today.getUTCDay();
      const mondayOffset = dow === 0 ? -6 : 1 - dow;
      const weekStartMs = today.getTime() + mondayOffset * 86400000;
      const weekEndMs = weekStartMs + 6 * 86400000;
      const t = date.getTime();
      return t >= weekStartMs && t <= weekEndMs;
    }

    if (filterMode === "custom") {
      const from = parseIsoDateOnly(settings && settings.datedFrom);
      const to = parseIsoDateOnly(settings && settings.datedTo);
      if (!from && !to) {
        return false;
      }

      const fromDate = from || to;
      const toDate = to || from;
      const start = fromDate <= toDate ? fromDate : toDate;
      const end = fromDate <= toDate ? toDate : fromDate;
      return date >= start && date <= end;
    }

    
    return date.getUTCFullYear() === today.getUTCFullYear() && date.getUTCMonth() === today.getUTCMonth();
  };

  const extractYatanPara = (json, runMode, settings) => {
    const allObjects = [];
    collectObjectsDeep(json, allObjects);
    let max = null;
    const now = new Date();
    const datedFilterMode = String((settings && settings.datedFilter) || "thisMonth");

    for (const obj of allObjects) {
      if (isYatanParaText(obj.textAlan) && "degerAlan" in obj) {
        let n = null;
        if (runMode === "datedCurrentMonth" || runMode === "reddiyat") {
          const degerAlanNumber = numberOrNull(obj.degerAlan);
          const entries = parseYatanParaDateEntries(obj.textAlan);
          if (entries.length > 0) {
            const matchedEntries = entries
              .filter((e) => isEntryInDatedFilter(e, datedFilterMode, now, settings))
              .map((e) => e.amount)
              .filter((e) => e !== null);
            if (matchedEntries.length > 0) {
              
              n = degerAlanNumber !== null ? degerAlanNumber : Math.max(...matchedEntries);
            } else {
              n = null;
            }
          } else {
            
            n = degerAlanNumber;
          }
        } else {
          n = numberOrNull(obj.degerAlan);
        }

        if (n !== null) {
          max = max === null ? n : Math.max(max, n);
        }
      }
    }

    return max;
  };

  const extractDosyaHesapSummary = (json) => {
    const out = {
      takipteKesinlesenMiktar: null,
      vekaletUcreti: null,
      bakiyeBorcMiktari: null
    };

    const allObjects = [];
    collectObjectsDeep(json, allObjects);

    for (const obj of allObjects) {
      if (!obj || typeof obj !== "object") {
        continue;
      }
      const text = normalizeText(obj.textAlan).replace(/\s+/g, " ").trim();
      if (!("degerAlan" in obj)) {
        continue;
      }
      const amount = numberOrNull(obj.degerAlan);
      if (amount === null) {
        continue;
      }

      if (text.includes("takipte kesinlesen miktar")) {
        out.takipteKesinlesenMiktar = amount;
      } else if (text.includes("vekalet ucreti")) {
        out.vekaletUcreti = amount;
      } else if (text.includes("bakiye borc miktari")) {
        out.bakiyeBorcMiktari = amount;
      }
    }

    return out;
  };

  const parseOdemeDateInput = (value) => {
    const raw = String(value || "").trim();
    if (!raw) {
      return new Date();
    }

    const tr = raw.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (tr) {
      const day = Number(tr[1]);
      const month = Number(tr[2]);
      const year = Number(tr[3]);
      if (day >= 1 && day <= 31 && month >= 1 && month <= 12 && year >= 1900) {
        return new Date(Date.UTC(year, month - 1, day));
      }
      return null;
    }

    const isoDateTime = raw.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::\d{2})?$/);
    if (isoDateTime) {
      const year = Number(isoDateTime[1]);
      const month = Number(isoDateTime[2]);
      const day = Number(isoDateTime[3]);
      if (day >= 1 && day <= 31 && month >= 1 && month <= 12 && year >= 1900) {
        return new Date(Date.UTC(year, month - 1, day));
      }
      return null;
    }

    const iso = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (iso) {
      const year = Number(iso[1]);
      const month = Number(iso[2]);
      const day = Number(iso[3]);
      if (day >= 1 && day <= 31 && month >= 1 && month <= 12 && year >= 1900) {
        return new Date(Date.UTC(year, month - 1, day));
      }
      return null;
    }

    return null;
  };

  const computeIcraFaizTutari = (asilAlacak, icraAcilisTarihiTr, odemeDate, faizAyarlari) => {
    const principal = numberOrNull(asilAlacak);
    const startMs = parseTrDateToTime(icraAcilisTarihiTr);
    if (principal === null || !Number.isFinite(startMs) || startMs <= 0 || !(odemeDate instanceof Date)) {
      return null;
    }

    const paymentMs = Date.UTC(
      odemeDate.getUTCFullYear(),
      odemeDate.getUTCMonth(),
      odemeDate.getUTCDate()
    );
    if (!Number.isFinite(paymentMs)) {
      return null;
    }

    const rateLow = Number(faizAyarlari && faizAyarlari.faizOranDusuk) || 0.09;
    const rateMid = Number(faizAyarlari && faizAyarlari.faizOranYuksek) || 0.24;
    const rateHigh = Number(faizAyarlari && faizAyarlari.faizOranYuksek2) || 0.31;
    const parseSplitDate = (value, fallbackMs) => {
      const match = String(value || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
      return match ? Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])) : fallbackMs;
    };
    const split1Ms = parseSplitDate((faizAyarlari && faizAyarlari.faizBolunmeTarihi) || "2024-06-01", Date.UTC(2024, 5, 1));
    const split2Ms = parseSplitDate((faizAyarlari && faizAyarlari.faizBolunmeTarihi2) || "2026-07-31", Date.UTC(2026, 6, 31));

    const dayMs = 24 * 60 * 60 * 1000;

    const daysBetween = (fromMs, toMs) => {
      const d = Math.floor((toMs - fromMs) / dayMs);
      return d > 0 ? d : 0;
    };

    const lowEnd = Math.min(paymentMs, split1Ms);
    const midStart = Math.max(startMs, split1Ms);
    const midEnd = Math.min(paymentMs, split2Ms);
    const highStart = Math.max(startMs, split2Ms);

    const lowDays = daysBetween(startMs, lowEnd);
    const midDays = daysBetween(midStart, midEnd);
    const highDays = daysBetween(highStart, paymentMs);

    const lowFaiz = principal * rateLow * (lowDays / 365);
    const midFaiz = principal * rateMid * (midDays / 365);
    const highFaiz = principal * rateHigh * (highDays / 365);
    return Number((lowFaiz + midFaiz + highFaiz).toFixed(2));
  };

  const sumNumericAmounts = (values) => {
    let total = 0;
    let hasAny = false;
    for (const v of Array.isArray(values) ? values : []) {
      const n = numberOrNull(v);
      if (n === null) {
        continue;
      }
      total += n;
      hasAny = true;
    }
    return hasAny ? Number(total.toFixed(2)) : null;
  };

  const addAmount = (currentValue, amount) => {
    const current = numberOrNull(currentValue) ?? 0;
    const next = numberOrNull(amount);
    if (next === null) {
      return currentValue ?? null;
    }
    return Number((current + next).toFixed(2));
  };

  const API_TIMEOUT_MS = 5000;
  const API_MAX_RETRIES = 2;

  const fetchWithTimeout = (url, options, timeoutMs) => {
    const controller = options.signal ? undefined : new AbortController();
    const signal = options.signal || (controller && controller.signal);
    const timer = setTimeout(() => { if (controller) controller.abort(); }, timeoutMs);
    return fetch(url, { ...options, signal }).finally(() => clearTimeout(timer));
  };

  const runRequest = async (url, method, headers, body, requestOptions = {}) => {
    if (runState.stopRequested) {
      throw new Error("STOP_REQUESTED");
    }

    const timeoutMsRaw = Number(requestOptions && requestOptions.timeoutMs);
    const shouldUseTimeout = Number.isFinite(timeoutMsRaw) ? timeoutMsRaw > 0 : true;
    const effectiveTimeoutMs = shouldUseTimeout ? timeoutMsRaw || API_TIMEOUT_MS : 0;
    let lastError = null;
    for (let attempt = 0; attempt <= API_MAX_RETRIES; attempt++) {
      if (attempt > 0) {
        await new Promise((r) => setTimeout(r, 500 * attempt));
        if (runState.stopRequested) throw new Error("STOP_REQUESTED");
      }

      const controller = new AbortController();
      runState.activeController = controller;
      const timer = shouldUseTimeout ? setTimeout(() => controller.abort(), effectiveTimeoutMs) : null;

      try {
        const response = await fetch(url, {
          method,
          headers,
          body,
          credentials: "include",
          signal: controller.signal
        });
        if (timer) {
          clearTimeout(timer);
        }
        const text = await response.text();
        return {
          ok: response.ok,
          status: response.status,
          text,
          json: parseJsonSafe(text)
        };
      } catch (error) {
        if (timer) {
          clearTimeout(timer);
        }
        if (runState.stopRequested) {
          throw new Error("STOP_REQUESTED");
        }
        lastError = error;
        if (error && error.name === "AbortError" && attempt < API_MAX_RETRIES) {
          continue;
        }
        if (error && error.name === "AbortError") {
          throw new Error("STOP_REQUESTED");
        }
        if (attempt >= API_MAX_RETRIES) throw error;
      } finally {
        if (runState.activeController === controller) {
          runState.activeController = null;
        }
      }
    }
    throw lastError || new Error("Request failed");
  };

  const extFetchPending = new Map();
  const EXT_FETCH_MAX_AGE_MS = 30000;

  window.addEventListener("message", (event) => {
    if (event.source !== window || !event.data || event.data.__EWR_EXT_FETCH_RES__ !== true) {
      return;
    }
    const requestId = String(event.data.requestId || "");
    if (!requestId || !extFetchPending.has(requestId)) {
      return;
    }
    const entry = extFetchPending.get(requestId);
    extFetchPending.delete(requestId);
    if (entry.timer) clearTimeout(entry.timer);
    entry.resolve({
      ok: !!event.data.ok,
      status: Number(event.data.status || 0),
      text: event.data.text,
      json: event.data.json,
      error: event.data.error || null
    });
  });

  const sweepExtFetchPending = () => {
    const now = Date.now();
    for (const [id, entry] of extFetchPending) {
      if (now - entry.createdAt > EXT_FETCH_MAX_AGE_MS) {
        extFetchPending.delete(id);
        if (entry.timer) clearTimeout(entry.timer);
        entry.resolve({ ok: false, status: 0, text: null, json: null, error: "Extension fetch expired" });
      }
    }
  };
  setInterval(sweepExtFetchPending, 15000);

  const runRequestViaExtension = async (url, method, headers, body) =>
    new Promise((resolve) => {
      if (runState.stopRequested) {
        resolve({ ok: false, status: 0, text: null, json: null, error: "STOP_REQUESTED" });
        return;
      }

      const requestId = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
      const timer = setTimeout(() => {
        extFetchPending.delete(requestId);
        resolve({ ok: false, status: 0, text: null, json: null, error: "Extension fetch timeout" });
      }, 20000);

      extFetchPending.set(requestId, {
        resolve,
        timer,
        createdAt: Date.now()
      });

      window.postMessage(
        {
          __EWR_PAGE_FETCH__: true,
          requestId,
          url,
          method,
          headers,
          body
        },
        "*"
      );
    });

  const runRequestBinary = async (url, method, headers, body) => {
    if (runState.stopRequested) {
      throw new Error("STOP_REQUESTED");
    }

    let lastError = null;
    for (let attempt = 0; attempt <= API_MAX_RETRIES; attempt++) {
      if (attempt > 0) {
        await new Promise((r) => setTimeout(r, 500 * attempt));
        if (runState.stopRequested) throw new Error("STOP_REQUESTED");
      }

      const controller = new AbortController();
      runState.activeController = controller;
      const timer = setTimeout(() => controller.abort(), API_TIMEOUT_MS);

      try {
        const response = await fetch(url, {
          method,
          headers,
          body,
          credentials: "include",
          signal: controller.signal
        });
        clearTimeout(timer);
        const arrayBuffer = await response.arrayBuffer();
        return {
          ok: response.ok,
          status: response.status,
          contentType: String(response.headers.get("content-type") || ""),
          bytes: new Uint8Array(arrayBuffer)
        };
      } catch (error) {
        clearTimeout(timer);
        if (runState.stopRequested) {
          throw new Error("STOP_REQUESTED");
        }
        lastError = error;
        if (error && error.name === "AbortError" && attempt < API_MAX_RETRIES) {
          continue;
        }
        if (error && error.name === "AbortError") {
          throw new Error("STOP_REQUESTED");
        }
        if (attempt >= API_MAX_RETRIES) throw error;
      } finally {
        if (runState.activeController === controller) {
          runState.activeController = null;
        }
      }
    }
    throw lastError || new Error("Request failed");
  };

  const TextUtils = window.MiniIcraTextUtils || {};
  const SharedHesapNormalizers = window.MiniIcraHesapNormalizers || {};
  const SharedHesapClassifiers = window.MiniIcraHesapClassifiers || {};
  const SharedHesapScoring = window.MiniIcraHesapScoring || {};
  const SharedHesapExtractors = window.MiniIcraHesapExtractors || {};
  const fixMojibake = (value) =>
    typeof TextUtils.fixMojibake === "function" ? TextUtils.fixMojibake(value) : String(value || "");

  const normalizeText = (value) =>
    typeof TextUtils.normalizeText === "function"
      ? TextUtils.normalizeText(value)
      : fixMojibake(value)
          .toLocaleLowerCase("tr-TR")
          .trim();

  const parseTrDateToTime = (value) =>
    typeof TextUtils.parseTrDateToTime === "function"
      ? TextUtils.parseTrDateToTime(value)
      : 0;

  window.__EWR_PR_Core = {
    __EWR_PAGE_TOKEN__,
    __EWR_PAGE_BASE_URL__,
    handledRequestIds,
    runState,
    DEFAULT_SETTINGS,
    parseInput,
    applyTemplate,
    escapeJsonTemplateValue,
    normalizeJsonBodyValue,
    applyJsonTemplate,
    applyJsonBodyTemplate,
    stripWrappingQuotes,
    applyDosyaDurumKodToRequestBody,
    parseJsonSafe,
    parseHeaders,
    toAbsoluteUrl,
    findByKeyDeep,
    collectObjectsDeep,
    numberOrNull,
    isYatanParaText,
    ensurePdfJsLib,
    getInjectedAssetUrl,
    parseYatanParaDateEntries,
    parseIsoDateOnly,
    utcMidnight,
    isEntryInDatedFilter,
    extractYatanPara,
    extractDosyaHesapSummary,
    parseOdemeDateInput,
    computeIcraFaizTutari,
    sumNumericAmounts,
    addAmount,
    API_TIMEOUT_MS,
    API_MAX_RETRIES,
    runRequest,
    runRequestBinary,
    runRequestViaExtension,
    TextUtils,
    SharedHesapNormalizers,
    SharedHesapClassifiers,
    SharedHesapScoring,
    SharedHesapExtractors,
    fixMojibake,
    normalizeText,
    parseTrDateToTime
  };
})();

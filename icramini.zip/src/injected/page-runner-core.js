(() => {
  const __EWR_PAGE_TOKEN__ = (() => {
    try {
      const src = (document.currentScript && document.currentScript.src) || "";
      return new URL(src, window.location.href).searchParams.get("ts") || "";
    } catch {
      return "";
    }
  })();

  const __EWR_PAGE_BASE_URL__ = (() => {
    try {
      const src = (document.currentScript && document.currentScript.src) || "";
      return src ? new URL(".", new URL(src, window.location.href)).toString() : "";
    } catch {
      return "";
    }
  })();

  // Varlık yolları depo kökünden verilir (assets/vendor/...), betiğin bulunduğu
  // dizinden değil. Taban olarak PAGE_BASE_URL kullanılırsa
  // .../src/injected/assets/... gibi var olmayan bir adrese çözülür.
  const __EWR_EXTENSION_ROOT_URL__ = (() => {
    try {
      const src = (document.currentScript && document.currentScript.src) || "";
      return src ? new URL("/", new URL(src, window.location.href)).toString() : "";
    } catch {
      return "";
    }
  })();

  const handledRequestIds = new Set();

  const runState = {
    isRunning: false,
    stopRequested: false,
    activeController: null
  };

  const TextUtils = window.MiniIcraTextUtils;
  const SharedHesapNormalizers = window.MiniIcraHesapNormalizers;
  const SharedHesapClassifiers = window.MiniIcraHesapClassifiers;
  const SharedHesapScoring = window.MiniIcraHesapScoring;
  const SharedHesapVekalet = window.MiniIcraHesapVekalet;
  const truncateMoney = (SharedHesapNormalizers && SharedHesapNormalizers.truncateMoney) || ((value) => value);
  const SharedHesapExtractors = window.MiniIcraHesapExtractors;
  const { fixMojibake, normalizeText, parseTrDateToTime } = TextUtils;

  const DEFAULT_SETTINGS = {
    firstEndpointPath: "/search_phrase_detayli.ajx",
    firstMethod: "POST",
    firstHeadersText: '{\n  "Content-Type": "application/json"\n}',
    firstBodyTemplate:
      '{\n  "dosyaDurumKod": 0,\n  "pageSize": 500,\n  "pageNumber": 1,\n  "dosyaYil": "{{dosyaYil}}",\n  "dosyaSira": "{{dosyaSira}}",\n  "birimId": "{{birimId}}",\n  "birimTuru2": "1101",\n  "birimTuru3": "2"\n}',
    secondEndpointPath: "/dosya_hesap_bilgileri.ajx",
    secondMethod: "POST",
    secondHeadersText:
      '{\n  "Content-Type": "application/json",\n  "X-Borclu": "undefined",\n  "X-Birim-Id": "{{birimId}}",\n  "X-Dosya-No": "{{inputEncoded}}",\n  "X-Birim-Adi": "{{birimAdi}}",\n  "X-Birim-Turu2": "undefined",\n  "X-Dosya-Durum": "{{dosyaDurum}}"\n}',
    secondBodyTemplate: '{\n  "dosyaId": "{{dosyaId}}"\n}',
    thirdEndpointPath: "/list_dosya_evraklar.ajx",
    thirdMethod: "POST",
    thirdHeadersText:
      '{\n  "Content-Type": "application/json",\n  "X-Borclu": "undefined",\n  "X-Birim-Id": "{{birimId}}",\n  "X-Dosya-No": "{{inputEncoded}}",\n  "X-Birim-Adi": "{{birimAdi}}",\n  "X-Birim-Turu2": "undefined",\n  "X-Dosya-Durum": "{{dosyaDurum}}"\n}',
    thirdBodyTemplate: '{\n  "dosyaId": "{{dosyaId}}",\n  "pageNumber": 1\n}',
    fourthEndpointPath:
      "/view_document_brd.uyap?evrakId={{evrakIdEncoded}}&dosyaId={{dosyaIdEncoded}}&dosyaNo={{inputEncoded}}&birimAdi={{birimAdiEncoded}}&evrak={{evrakEncoded}}&tarih={{tarihEncoded}}&sira=undefined",
    fourthMethod: "GET",
    fourthHeadersText:
      '{\n  "Content-Type": "application/octet-stream",\n  "X-Borclu": "undefined",\n  "X-Birim-Id": "{{birimId}}",\n  "X-Dosya-No": "{{inputEncoded}}",\n  "X-Birim-Adi": "{{birimAdi}}",\n  "X-Birim-Turu2": "undefined",\n  "X-Dosya-Durum": "{{dosyaDurum}}"\n}',
    defaultBirimId: "",
    defaultBirimAdi: "",
    defaultDosyaDurum: "Acik",
    dosyaHesabiDosyaDurumKod: "0",
    dosyaHesabiIndirimTutari: ""
  };

  // Girdi hem düz metin hem { dosyaNo, birimAdi, birimId } olabilir.
  const parseInput = (value) => {
    const rawObj = value && typeof value === "object" ? value : null;
    const raw = String(rawObj ? rawObj.dosyaNo : value || "").trim();
    const match = raw.match(/^(\d{4})\s*\/\s*(\d+)$/);
    if (!match) {
      throw new Error(`Girdi formatı geçersiz: ${raw}. Beklenen: YYYY/NNN`);
    }
    return {
      raw,
      dosyaYil: match[1],
      dosyaSira: match[2],
      birimAdi: rawObj ? String(rawObj.birimAdi || "").trim() : "",
      birimId: rawObj ? String(rawObj.birimId || "").trim() : ""
    };
  };

  const applyTemplate = (template, ctx) =>
    String(template || "").replace(/{{\s*([a-zA-Z0-9_]+)\s*}}/g, (_, key) => (key in ctx ? String(ctx[key]) : ""));

  const escapeJsonTemplateValue = (value) =>
    JSON.stringify(String(value ?? ""))
      .slice(1, -1)
      // U+2028/2029 JSON'da geçerli ama JS kaynağında satır sonu sayılır.
      .replace(/\u2028/g, "\\u2028")
      .replace(/\u2029/g, "\\u2029");

  const normalizeJsonBodyValue = (value) => {
    const raw = String(value ?? "");
    if (!raw || !raw.includes("%")) {
      return raw;
    }
    try {
      return decodeURIComponent(raw);
    } catch {
      return raw.replace(/%22/gi, '"');
    }
  };

  const applyJsonTemplate = (template, ctx) =>
    String(template || "").replace(/{{\s*([a-zA-Z0-9_]+)\s*}}/g, (_, key) =>
      key in ctx ? escapeJsonTemplateValue(ctx[key]) : ""
    );

  const applyJsonBodyTemplate = (template, ctx) =>
    String(template || "").replace(/{{\s*([a-zA-Z0-9_]+)\s*}}/g, (_, key) =>
      key in ctx ? escapeJsonTemplateValue(normalizeJsonBodyValue(ctx[key])) : ""
    );

  const applyDosyaDurumKodToRequestBody = (bodyText, dosyaDurumKod) => {
    const raw = String(bodyText || "");
    const code = String(dosyaDurumKod || "0") === "1" ? 1 : 0;
    try {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
        parsed.dosyaDurumKod = code;
        return JSON.stringify(parsed);
      }
    } catch {}
    return raw.replace(/("dosyaDurumKod"\s*:\s*)\d+/i, `$1${code}`);
  };

  const parseJsonSafe = (text) => {
    try {
      return JSON.parse(text);
    } catch {
      return null;
    }
  };

  const parseHeaders = (headersText, ctx) => {
    const parsed = parseJsonSafe(applyJsonTemplate(headersText || "{}", ctx));
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      throw new Error("Headers JSON geçersiz.");
    }

    // Header değeri latin1 dışına çıkamaz; Türkçe karakterli birim adları için.
    const toSafeHeaderValue = (value) => {
      const text = String(value);
      for (let i = 0; i < text.length; i += 1) {
        if (text.charCodeAt(i) > 255) {
          return encodeURIComponent(text);
        }
      }
      return text;
    };

    return Object.fromEntries(Object.entries(parsed).map(([key, value]) => [String(key), toSafeHeaderValue(value)]));
  };

  const toAbsoluteUrl = (pathOrUrl) => {
    const raw = String(pathOrUrl || "").trim();
    if (!raw) {
      throw new Error("Endpoint boş.");
    }
    return new URL(raw, window.location.origin).toString();
  };

  const findByKeyDeep = (value, keyName) => {
    if (value == null) {
      return undefined;
    }
    if (Array.isArray(value)) {
      for (const item of value) {
        const found = findByKeyDeep(item, keyName);
        if (typeof found !== "undefined") {
          return found;
        }
      }
      return undefined;
    }
    if (typeof value === "object") {
      if (keyName in value) {
        return value[keyName];
      }
      for (const key of Object.keys(value)) {
        const found = findByKeyDeep(value[key], keyName);
        if (typeof found !== "undefined") {
          return found;
        }
      }
    }
    return undefined;
  };

  const collectObjectsDeep = (value, output) => {
    if (value == null) {
      return;
    }
    if (Array.isArray(value)) {
      for (const item of value) {
        collectObjectsDeep(item, output);
      }
      return;
    }
    if (typeof value === "object") {
      output.push(value);
      for (const key of Object.keys(value)) {
        collectObjectsDeep(value[key], output);
      }
    }
  };

  const numberOrNull = (value) => {
    if (typeof value === "number") {
      return Number.isFinite(value) ? value : null;
    }
    if (typeof value !== "string") {
      return null;
    }

    const trimmed = value.trim();
    if (!trimmed) {
      return null;
    }

    const compact = trimmed.replace(/\s+/g, "");
    const direct = Number(compact);
    if (Number.isFinite(direct)) {
      return direct;
    }

    const match = compact.match(/-?\d[\d.,]*/);
    if (!match) {
      return null;
    }

    let candidate = match[0];
    const negative = candidate.startsWith("-");
    if (negative) {
      candidate = candidate.slice(1);
    }

    const commas = (candidate.match(/,/g) || []).length;
    const dots = (candidate.match(/\./g) || []).length;
    let normalized = candidate;

    // İki ayırıcı da varsa sonda gelen ondalıktır: 1.234,56 / 1,234.56
    if (commas > 0 && dots > 0) {
      const decimalSep = candidate.lastIndexOf(",") > candidate.lastIndexOf(".") ? "," : ".";
      const thousandsSep = decimalSep === "," ? "." : ",";
      normalized = candidate.split(thousandsSep).join("");
      if (decimalSep === ",") {
        normalized = normalized.replace(",", ".");
      }
    } else if (commas > 0) {
      normalized = commas === 1 ? candidate.replace(",", ".") : candidate.split(",").join("");
    } else if (dots > 1) {
      normalized = candidate.split(".").join("");
    }

    if (negative) {
      normalized = `-${normalized}`;
    }

    const parsed = Number(normalized);
    return Number.isFinite(parsed) ? parsed : null;
  };

  const sumNumericAmounts = (values) => {
    let total = 0;
    let hasAny = false;
    for (const value of Array.isArray(values) ? values : []) {
      const number = numberOrNull(value);
      if (number === null) {
        continue;
      }
      total += number;
      hasAny = true;
    }
    return hasAny ? Number(total.toFixed(2)) : null;
  };

  const addAmount = (currentValue, amount) => {
    const current = numberOrNull(currentValue) ?? 0;
    const next = numberOrNull(amount);
    if (next === null) {
      return currentValue ?? null;
    }
    return Number((current + next).toFixed(2));
  };

  const isYatanParaText = (textAlan) => {
    const text = String(textAlan || "")
      .trim()
      .toLocaleLowerCase("tr-TR");
    if (!text.startsWith("yatan para")) {
      return false;
    }
    return !text.includes("oran") && !text.includes("%");
  };

  const parseYatanParaDateEntries = (textAlan) => {
    const text = String(textAlan || "");
    const regex = /(\d{2})\/(\d{2})\/(\d{4})\s*-\s*([0-9.,]+)/g;
    const out = [];
    let match;
    while ((match = regex.exec(text)) !== null) {
      const day = Number(match[1]);
      const month = Number(match[2]);
      const year = Number(match[3]);
      if (!Number.isFinite(day) || !Number.isFinite(month) || !Number.isFinite(year)) {
        continue;
      }
      out.push({ day, month, year, amount: numberOrNull(match[4]) });
    }
    return out;
  };

  const parseIsoDateOnly = (value) => {
    const match = String(value || "")
      .trim()
      .match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match) {
      return null;
    }
    const date = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
    return Number.isFinite(date.getTime()) ? date : null;
  };

  const utcMidnight = (year, month0, day) => new Date(Date.UTC(year, month0, day));

  const DAY_MS = 24 * 60 * 60 * 1000;

  const isEntryInDatedFilter = (entry, filterMode, now, settings) => {
    const date = utcMidnight(entry.year, entry.month - 1, entry.day);
    const today = utcMidnight(now.getFullYear(), now.getMonth(), now.getDate());

    if (filterMode === "today") {
      return date.getTime() === today.getTime();
    }

    if (filterMode === "thisWeek") {
      // Hafta pazartesi başlar, getUTCDay() pazar için 0 döner.
      const dayOfWeek = today.getUTCDay();
      const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
      const weekStartMs = today.getTime() + mondayOffset * DAY_MS;
      const weekEndMs = weekStartMs + 6 * DAY_MS;
      return date.getTime() >= weekStartMs && date.getTime() <= weekEndMs;
    }

    if (filterMode === "custom") {
      const from = parseIsoDateOnly(settings && settings.datedFrom);
      const to = parseIsoDateOnly(settings && settings.datedTo);
      if (!from && !to) {
        return false;
      }
      const fromDate = from || to;
      const toDate = to || from;
      const start = fromDate <= toDate ? fromDate : toDate;
      const end = fromDate <= toDate ? toDate : fromDate;
      return date >= start && date <= end;
    }

    return date.getUTCFullYear() === today.getUTCFullYear() && date.getUTCMonth() === today.getUTCMonth();
  };

  const extractYatanPara = (json, runMode, settings) => {
    const allObjects = [];
    collectObjectsDeep(json, allObjects);

    const now = new Date();
    const datedFilterMode = String((settings && settings.datedFilter) || "thisMonth");
    const isFilteredMode = runMode === "datedCurrentMonth" || runMode === "reddiyat";
    let max = null;

    for (const obj of allObjects) {
      if (!isYatanParaText(obj.textAlan) || !("degerAlan" in obj)) {
        continue;
      }

      let amount = null;
      if (isFilteredMode) {
        const degerAlanNumber = numberOrNull(obj.degerAlan);
        const entries = parseYatanParaDateEntries(obj.textAlan);
        if (entries.length === 0) {
          amount = degerAlanNumber;
        } else {
          const matchedAmounts = entries
            .filter((entry) => isEntryInDatedFilter(entry, datedFilterMode, now, settings))
            .map((entry) => entry.amount)
            .filter((value) => value !== null);
          amount = matchedAmounts.length > 0 ? (degerAlanNumber ?? Math.max(...matchedAmounts)) : null;
        }
      } else {
        amount = numberOrNull(obj.degerAlan);
      }

      if (amount !== null) {
        max = max === null ? amount : Math.max(max, amount);
      }
    }

    return max;
  };

  const extractDosyaHesapSummary = (json) => {
    const out = {
      takipteKesinlesenMiktar: null,
      vekaletUcreti: null,
      bakiyeBorcMiktari: null
    };

    const allObjects = [];
    collectObjectsDeep(json, allObjects);

    for (const obj of allObjects) {
      if (!obj || typeof obj !== "object" || !("degerAlan" in obj)) {
        continue;
      }
      const amount = numberOrNull(obj.degerAlan);
      if (amount === null) {
        continue;
      }

      const text = normalizeText(obj.textAlan).replace(/\s+/g, " ").trim();
      if (text.includes("takipte kesinlesen miktar")) {
        out.takipteKesinlesenMiktar = amount;
      } else if (text.includes("vekalet ucreti")) {
        out.vekaletUcreti = amount;
      } else if (text.includes("bakiye borc miktari")) {
        out.bakiyeBorcMiktari = amount;
      }
    }

    return out;
  };

  const parseOdemeDateInput = (value) => {
    const raw = String(value || "").trim();
    if (!raw) {
      return new Date();
    }

    const toUtcDate = (year, month, day) =>
      day >= 1 && day <= 31 && month >= 1 && month <= 12 && year >= 1900
        ? new Date(Date.UTC(year, month - 1, day))
        : null;

    const tr = raw.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (tr) {
      return toUtcDate(Number(tr[3]), Number(tr[2]), Number(tr[1]));
    }

    const isoDateTime = raw.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::\d{2})?$/);
    if (isoDateTime) {
      return toUtcDate(Number(isoDateTime[1]), Number(isoDateTime[2]), Number(isoDateTime[3]));
    }

    const iso = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (iso) {
      return toUtcDate(Number(iso[1]), Number(iso[2]), Number(iso[3]));
    }

    return null;
  };

  // Faiz üç dilimde işler: ilk bölünme tarihine kadar düşük, arada yüksek,
  // ikinci bölünmeden sonra en yüksek oran. Oran ve tarihler popup ayarlarından.
  const computeIcraFaizTutari = (asilAlacak, icraAcilisTarihiTr, odemeDate, faizAyarlari) => {
    const principal = numberOrNull(asilAlacak);
    const startMs = parseTrDateToTime(icraAcilisTarihiTr);
    if (principal === null || !Number.isFinite(startMs) || startMs <= 0 || !(odemeDate instanceof Date)) {
      return null;
    }

    const paymentMs = Date.UTC(odemeDate.getUTCFullYear(), odemeDate.getUTCMonth(), odemeDate.getUTCDate());
    if (!Number.isFinite(paymentMs)) {
      return null;
    }

    const rateLow = Number(faizAyarlari && faizAyarlari.faizOranDusuk) || 0.09;
    const rateMid = Number(faizAyarlari && faizAyarlari.faizOranYuksek) || 0.24;
    const rateHigh = Number(faizAyarlari && faizAyarlari.faizOranYuksek2) || 0.31;

    const parseSplitDate = (value, fallbackMs) => {
      const match = String(value || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
      return match ? Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])) : fallbackMs;
    };
    const split1Ms = parseSplitDate(
      (faizAyarlari && faizAyarlari.faizBolunmeTarihi) || "2024-06-01",
      Date.UTC(2024, 5, 1)
    );
    const split2Ms = parseSplitDate(
      (faizAyarlari && faizAyarlari.faizBolunmeTarihi2) || "2026-07-31",
      Date.UTC(2026, 6, 31)
    );

    const daysBetween = (fromMs, toMs) => Math.max(0, Math.floor((toMs - fromMs) / DAY_MS));

    const lowDays = daysBetween(startMs, Math.min(paymentMs, split1Ms));
    const midDays = daysBetween(Math.max(startMs, split1Ms), Math.min(paymentMs, split2Ms));
    const highDays = daysBetween(Math.max(startMs, split2Ms), paymentMs);

    const total =
      principal * rateLow * (lowDays / 365) +
      principal * rateMid * (midDays / 365) +
      principal * rateHigh * (highDays / 365);
    return truncateMoney(total);
  };

  const getInjectedAssetUrl = (fileName) => {
    const base = __EWR_EXTENSION_ROOT_URL__ || __EWR_PAGE_BASE_URL__ || window.location.href;
    try {
      return new URL(fileName, base).toString();
    } catch {
      return String(fileName || "");
    }
  };

  let pdfJsLoadPromise = null;

  const ensurePdfJsLib = async () => {
    const existing = window.pdfjsLib || window["pdfjs-dist/build/pdf"];
    if (existing && typeof existing.getDocument === "function") {
      return existing;
    }
    if (pdfJsLoadPromise) {
      return pdfJsLoadPromise;
    }

    pdfJsLoadPromise = import(getInjectedAssetUrl("assets/vendor/pdf.min.mjs"))
      .then((mod) => {
        const lib =
          (mod && typeof mod.getDocument === "function" && mod) ||
          (mod && mod.default && typeof mod.default.getDocument === "function" && mod.default) ||
          null;
        if (lib && lib.GlobalWorkerOptions) {
          lib.GlobalWorkerOptions.workerSrc = getInjectedAssetUrl("assets/vendor/pdf.worker.min.mjs");
        }
        if (lib) {
          window["pdfjs-dist/build/pdf"] = lib;
        }
        return lib;
      })
      .catch(() => null);

    return pdfJsLoadPromise;
  };

  const API_TIMEOUT_MS = 5000;
  const API_MAX_RETRIES = 2;
  const RETRY_BACKOFF_MS = 500;

  const waitBeforeRetry = async (attempt) => {
    await new Promise((resolve) => setTimeout(resolve, RETRY_BACKOFF_MS * attempt));
    if (runState.stopRequested) {
      throw new Error("STOP_REQUESTED");
    }
  };

  // Zaman aşımı yalnız yanıt başlıklarını kapsar: perform, başlıkları alır almaz
  // stopTimeout() çağırır. Aksi halde büyük PDF gövdeleri süre sınırına takılıp
  // boşuna yeniden denenir.
  const withRetries = async (perform, timeoutMs) => {
    if (runState.stopRequested) {
      throw new Error("STOP_REQUESTED");
    }

    let lastError = null;
    for (let attempt = 0; attempt <= API_MAX_RETRIES; attempt += 1) {
      if (attempt > 0) {
        await waitBeforeRetry(attempt);
      }

      const controller = new AbortController();
      runState.activeController = controller;
      let timer = timeoutMs > 0 ? setTimeout(() => controller.abort(), timeoutMs) : null;
      const stopTimeout = () => {
        if (timer) {
          clearTimeout(timer);
          timer = null;
        }
      };

      try {
        return await perform(controller.signal, stopTimeout);
      } catch (error) {
        if (runState.stopRequested) {
          throw new Error("STOP_REQUESTED");
        }
        lastError = error;
        const isAbort = error && error.name === "AbortError";
        if (isAbort && attempt < API_MAX_RETRIES) {
          continue;
        }
        if (isAbort) {
          throw new Error("STOP_REQUESTED");
        }
        if (attempt >= API_MAX_RETRIES) {
          throw error;
        }
      } finally {
        stopTimeout();
        if (runState.activeController === controller) {
          runState.activeController = null;
        }
      }
    }

    throw lastError || new Error("Request failed");
  };

  const resolveTimeoutMs = (requestOptions) => {
    const raw = Number(requestOptions && requestOptions.timeoutMs);
    if (!Number.isFinite(raw)) {
      return API_TIMEOUT_MS;
    }
    return raw > 0 ? raw : 0;
  };

  const runRequest = async (url, method, headers, body, requestOptions = {}) =>
    withRetries(async (signal, stopTimeout) => {
      const response = await fetch(url, { method, headers, body, credentials: "include", signal });
      stopTimeout();
      const text = await response.text();
      return { ok: response.ok, status: response.status, text, json: parseJsonSafe(text) };
    }, resolveTimeoutMs(requestOptions));

  const runRequestBinary = async (url, method, headers, body) =>
    withRetries(async (signal, stopTimeout) => {
      const response = await fetch(url, { method, headers, body, credentials: "include", signal });
      stopTimeout();
      const arrayBuffer = await response.arrayBuffer();
      return {
        ok: response.ok,
        status: response.status,
        contentType: String(response.headers.get("content-type") || ""),
        bytes: new Uint8Array(arrayBuffer)
      };
    }, API_TIMEOUT_MS);

  const EXT_FETCH_TIMEOUT_MS = 20000;
  const EXT_FETCH_MAX_AGE_MS = 30000;
  const EXT_FETCH_SWEEP_INTERVAL_MS = 15000;

  const extFetchPending = new Map();

  window.addEventListener("message", (event) => {
    if (event.source !== window || !event.data || event.data.__EWR_EXT_FETCH_RES__ !== true) {
      return;
    }
    const requestId = String(event.data.requestId || "");
    const entry = extFetchPending.get(requestId);
    if (!requestId || !entry) {
      return;
    }

    extFetchPending.delete(requestId);
    if (entry.timer) {
      clearTimeout(entry.timer);
    }
    entry.resolve({
      ok: !!event.data.ok,
      status: Number(event.data.status || 0),
      text: event.data.text,
      json: event.data.json,
      error: event.data.error || null
    });
  });

  // Yanıtı hiç gelmeyen istekler bellekte birikmesin.
  const sweepExtFetchPending = () => {
    const now = Date.now();
    for (const [requestId, entry] of extFetchPending) {
      if (now - entry.createdAt <= EXT_FETCH_MAX_AGE_MS) {
        continue;
      }
      extFetchPending.delete(requestId);
      if (entry.timer) {
        clearTimeout(entry.timer);
      }
      entry.resolve({ ok: false, status: 0, text: null, json: null, error: "Extension fetch expired" });
    }
  };
  setInterval(sweepExtFetchPending, EXT_FETCH_SWEEP_INTERVAL_MS);

  // Sayfa bağlamından çapraz kökene istek atılamaz (PTT). İçerik betiği üzerinden
  // servis çalışanına devredilir. Hiçbir zaman reject etmez, hata `error` alanında.
  const runRequestViaExtension = async (url, method, headers, body) =>
    new Promise((resolve) => {
      if (runState.stopRequested) {
        resolve({ ok: false, status: 0, text: null, json: null, error: "STOP_REQUESTED" });
        return;
      }

      const requestId = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
      const timer = setTimeout(() => {
        extFetchPending.delete(requestId);
        resolve({ ok: false, status: 0, text: null, json: null, error: "Extension fetch timeout" });
      }, EXT_FETCH_TIMEOUT_MS);

      extFetchPending.set(requestId, { resolve, timer, createdAt: Date.now() });

      window.postMessage({ __EWR_PAGE_FETCH__: true, requestId, url, method, headers, body }, "*");
    });

  window.__EWR_PR_Core = {
    __EWR_PAGE_TOKEN__,
    __EWR_PAGE_BASE_URL__,
    __EWR_EXTENSION_ROOT_URL__,
    handledRequestIds,
    runState,
    DEFAULT_SETTINGS,
    parseInput,
    applyTemplate,
    escapeJsonTemplateValue,
    normalizeJsonBodyValue,
    applyJsonTemplate,
    applyJsonBodyTemplate,
    applyDosyaDurumKodToRequestBody,
    parseJsonSafe,
    parseHeaders,
    toAbsoluteUrl,
    findByKeyDeep,
    collectObjectsDeep,
    numberOrNull,
    isYatanParaText,
    ensurePdfJsLib,
    getInjectedAssetUrl,
    parseYatanParaDateEntries,
    parseIsoDateOnly,
    utcMidnight,
    isEntryInDatedFilter,
    extractYatanPara,
    extractDosyaHesapSummary,
    parseOdemeDateInput,
    computeIcraFaizTutari,
    sumNumericAmounts,
    addAmount,
    truncateMoney,
    API_TIMEOUT_MS,
    API_MAX_RETRIES,
    runRequest,
    runRequestBinary,
    runRequestViaExtension,
    TextUtils,
    SharedHesapNormalizers,
    SharedHesapClassifiers,
    SharedHesapScoring,
    SharedHesapVekalet,
    SharedHesapExtractors,
    fixMojibake,
    normalizeText,
    parseTrDateToTime
  };
})();


(() => {
  const C = window.__EWR_PR_Core;
  if (!C) { console.error("page-runner-core.js must load first"); return; }

  const {
    numberOrNull, fixMojibake, normalizeText, parseTrDateToTime,
    collectObjectsDeep, ensurePdfJsLib, getInjectedAssetUrl,
    sumNumericAmounts, addAmount,
    SharedHesapNormalizers, SharedHesapClassifiers, SharedHesapScoring, SharedHesapExtractors
  } = C;
  const extractTebligDateFromPtt = (pttJson) => {
    const rows = pttJson && Array.isArray(pttJson.dongu) ? pttJson.dongu : [];
    let selectedDate = null;
    let selectedTime = Number.POSITIVE_INFINITY;

    for (const row of rows) {
      const islemRaw = String((row && row.ISLEM) || "");
      const islem = normalizeText(islemRaw).replace(/\s+/g, " ").trim();
      const tarih = String((row && row.ITARIH) || "").trim();
      if (!tarih) {
        continue;
      }
      
      // "TESLIM EDILDI", "TESLIM EDILDI MUHATABA ...", etc.
      
      if (/\bteslim\s+edildi\b/i.test(islem) && !/\biade\b/i.test(islem)) {
        const t = parseTrDateToTime(tarih);
        if (t > 0 && t < selectedTime) {
          selectedTime = t;
          selectedDate = tarih;
        }
      }
    }
    return selectedDate;
  };

  const toTrDateFromCompact = (raw) => {
    const s = String(raw || "").trim();
    const m = s.match(/^(\d{4})(\d{2})(\d{2})$/);
    if (!m) {
      return null;
    }
    return `${m[3]}/${m[2]}/${m[1]}`;
  };

  const extractTebligDateFromPttApi = (apiJson) => {
    const rows = Array.isArray(apiJson) ? apiJson : [];
    for (const item of rows) {
      if (!item || typeof item !== "object") {
        continue;
      }
      const sonDurum = item.sondurum && typeof item.sondurum === "object" ? item.sondurum : null;
      if (!sonDurum) {
        continue;
      }
      const durum = normalizeText(sonDurum.son_durum_aciklama || sonDurum.teslim_durum_aciklama || "");
      if (!/\bteslim\s+edildi\b/i.test(durum) || /\biade\b/i.test(durum)) {
        continue;
      }
      const rawDate = sonDurum.teslim_tarihi || sonDurum.son_islem_tarihi || "";
      const trDate = toTrDateFromCompact(rawDate);
      if (trDate) {
        return trDate;
      }
    }
    return null;
  };

  const collectEvrakItems = (payload) => {
    const out = [];
    const add = (arr) => {
      if (!Array.isArray(arr)) {
        return;
      }
      for (const item of arr) {
        if (item && typeof item === "object" && item.evrakId) {
          out.push(item);
        }
      }
    };

    if (payload && typeof payload === "object") {
      if (payload.tumEvraklar && typeof payload.tumEvraklar === "object") {
        for (const key of Object.keys(payload.tumEvraklar)) {
          add(payload.tumEvraklar[key]);
        }
      }
      add(payload.son20Evrak);
    }
    return out;
  };

  const collectTumEvraklarItems = (payload) => {
    const out = [];
    if (!payload || typeof payload !== "object" || !payload.tumEvraklar || typeof payload.tumEvraklar !== "object") {
      return out;
    }
    for (const key of Object.keys(payload.tumEvraklar)) {
      const arr = payload.tumEvraklar[key];
      if (!Array.isArray(arr)) {
        continue;
      }
      for (const item of arr) {
        if (item && typeof item === "object" && item.evrakId) {
          out.push(item);
        }
      }
    }
    return out;
  };

  const dedupeByEvrakId = (items) => {
    const seen = new Set();
    const out = [];
    for (const item of items) {
      const id = String(item.evrakId || "");
      if (!id || seen.has(id)) {
        continue;
      }
      seen.add(id);
      out.push(item);
    }
    return out;
  };

  const isBarcodeEvrak = (item) => {
    const tur = normalizeText(item.tur);
    return (
      tur.includes("kapali tebligat") ||
      tur.includes("kapali e-teblig mazbatasi") ||
      tur.includes("teblig mazbatasi")
    );
  };

  const selectBarcodeCandidates = (items) =>
    dedupeByEvrakId(items.filter((item) => isBarcodeEvrak(item)))
      .sort((a, b) => {
        const dateDiff = parseTrDateToTime(b.onaylandigiTarih) - parseTrDateToTime(a.onaylandigiTarih);
        if (dateDiff !== 0) {
          return dateDiff;
        }
        return String(b.evrakId || "").localeCompare(String(a.evrakId || ""), "tr");
      })
      .slice(0, 30);

  const extractLatestTakipTalebiDate = (items) => {
    let bestDate = "";
    let bestMs = 0;
    for (const item of Array.isArray(items) ? items : []) {
      if (!item || typeof item !== "object") {
        continue;
      }
      const tur = normalizeText(item.tur);
      if (!tur.includes("takip talebi")) {
        continue;
      }
      const tarih = String(item.onaylandigiTarih || "").trim();
      if (!tarih) {
        continue;
      }
      const ms = parseTrDateToTime(tarih);
      if (ms > bestMs) {
        bestMs = ms;
        bestDate = tarih;
      }
    }
    return bestDate || null;
  };

  const hasAvukatPortalHacizTalebi = (items) =>
    (Array.isArray(items) ? items : []).some((item) =>
      normalizeText(item && item.tur).includes("avukat portal haciz talebi")
    );

  const estimateDosyaKesinlesmeInfoFromEvrakList = (items) => {
    const rows = Array.isArray(items) ? items : [];
    let bestPriority = 99;
    let earliestTeslimMs = 0;
    let earliestTeslimTarih = null;

    for (const item of rows) {
      if (!item || typeof item !== "object") {
        continue;
      }

      const tur = normalizeText(item.tur);
      const aciklama = normalizeText(item.aciklama).replace(/\s+/g, " ").trim();
      const isBorcluTebligi = aciklama.includes("borclu") || aciklama.includes("muflis");
      const isTeslim = /\bteblig edildi\b/i.test(aciklama) && !/\biade\b/i.test(aciklama);
      const isOdemeIcraEmri = aciklama.includes("odeme icra emri") || aciklama.includes("odeme emri");
      if (!isTeslim || !isBorcluTebligi || !isOdemeIcraEmri) {
        continue;
      }

      
      let priority = 99;
      if (tur.includes("kapali e-teblig mazbatasi") || tur.includes("teblig mazbatasi")) {
        priority = 1;
      } else if (tur.includes("kapali tebligat")) {
        priority = 2;
      } else {
        continue;
      }

      const teslimTarih = String(item.onaylandigiTarih || item.sistemeGonderildigiTarih || "").trim();
      const teslimMs = parseTrDateToTime(teslimTarih);
      if (teslimMs <= 0) {
        continue;
      }

      if (priority < bestPriority || (priority === bestPriority && (earliestTeslimMs <= 0 || teslimMs < earliestTeslimMs))) {
        bestPriority = priority;
        earliestTeslimMs = teslimMs;
        earliestTeslimTarih = teslimTarih || null;
      }
    }

    if (earliestTeslimMs <= 0) {
      return { tebligTarihi: null, kesinlesmeMs: 0 };
    }

    // Dosyada borclulardan herhangi biri teslim oldugunda 8. gunde kesinlesme kabul edilir.
    return {
      tebligTarihi: earliestTeslimTarih,
      kesinlesmeMs: earliestTeslimMs + 8 * 24 * 60 * 60 * 1000
    };
  };

  const selectTakipTalebiCandidates = (items) =>
    dedupeByEvrakId(
      (Array.isArray(items) ? items : []).filter((item) => {
        const tur = normalizeText(item && item.tur);
        return tur.includes("takip talebi") || (tur.includes("takip") && tur.includes("talep"));
      })
    )
      .sort((a, b) => {
        const dateDiff = parseTrDateToTime(b.onaylandigiTarih) - parseTrDateToTime(a.onaylandigiTarih);
        if (dateDiff !== 0) {
          return dateDiff;
        }
        return String(b.evrakId || "").localeCompare(String(a.evrakId || ""), "tr");
      })
      .slice(0, 30);

  const selectOdemeIcraEmriCandidates = (items) =>
    dedupeByEvrakId((Array.isArray(items) ? items : []).filter((item) => normalizeText(item && item.tur).includes("odeme icra emri")))
      .sort((a, b) => {
        const dateDiff = parseTrDateToTime(b.onaylandigiTarih) - parseTrDateToTime(a.onaylandigiTarih);
        if (dateDiff !== 0) {
          return dateDiff;
        }
        return String(b.evrakId || "").localeCompare(String(a.evrakId || ""), "tr");
      })
      .slice(0, 1);

  const selectVekaletPuluCandidates = (items) =>
    dedupeByEvrakId((Array.isArray(items) ? items : []).filter((item) => normalizeText(item && item.tur).includes("vekalet pulu makbuzu")))
      .sort((a, b) => {
        const dateDiff = parseTrDateToTime(b.onaylandigiTarih) - parseTrDateToTime(a.onaylandigiTarih);
        if (dateDiff !== 0) {
          return dateDiff;
        }
        return String(b.evrakId || "").localeCompare(String(a.evrakId || ""), "tr");
      })
      .slice(0, 6);

  const extractTakipTalebiAmountsFromText = (inputText) => {
    const norm = normalizeText(inputText)
      .replace(/[^a-z0-9.,/%\s]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    if (!norm) {
      return { asilAlacak: null, gecmisGunFaizi: null };
    }

    const parseAmountToken = (token) => {
      const compact = String(token || "")
        .replace(/\s+/g, "")
        .replace(/(?<=\d)[^\d.,-]+(?=\d)/g, "");
      const n = numberOrNull(compact);
      return Number.isFinite(n) ? n : null;
    };

    const collectCandidates = (segment) => {
      const candidates = [];
      const regex = /[0-9][0-9\s.,]*/g;
      let match;

      while ((match = regex.exec(segment)) !== null) {
        const token = match[0];
        const trimmedToken = String(token).trim();
        const amount = parseAmountToken(token);
        if (amount === null) {
          continue;
        }

        const start = match.index;
        const end = start + token.length;
        const before = segment.slice(Math.max(0, start - 8), start);
        const after = segment.slice(end, Math.min(segment.length, end + 12));
        const around = `${before} ${token} ${after}`;
        let score = 0;

        if (/[.,]\d{2}$/.test(trimmedToken) || /\d+\.\d{3}(?:,\d{2})?$/.test(trimmedToken)) {
          score += 4;
        }
        if (/\btl\b/i.test(around)) {
          score += 3;
        }
        if (/%\s*$/.test(before) || /^\s*%/.test(after)) {
          score -= 6;
        }
        if (/^\d{1,2}$/.test(trimmedToken)) {
          score -= 4;
        }
        if (amount < 100 && !/[.,]\d{2}$/.test(trimmedToken)) {
          score -= 3;
        }
        if (/^\d{1,2}$/.test(trimmedToken) && !/\btl\b/i.test(around) && !/[.,]\d{2}$/.test(trimmedToken)) {
          score -= 3;
        }

        candidates.push({ amount, score, index: start });
      }

      return candidates;
    };

    const pickBestAmount = (candidates) => {
      const viable = candidates.filter((candidate) => candidate.score > 0);
      const pool = viable.length > 0 ? viable : candidates;
      if (pool.length === 0) {
        return null;
      }
      pool.sort((a, b) => {
        if (b.score !== a.score) {
          return b.score - a.score;
        }
        return b.index - a.index;
      });
      return pool[0].amount;
    };

    const findAmountNearKeyword = (sourceText, keywordRegex) => {
      const mKey = sourceText.match(keywordRegex);
      if (!mKey || typeof mKey.index !== "number") {
        return null;
      }

      const left = sourceText.slice(Math.max(0, mKey.index - 260), mKey.index);
      const leftAmount = pickBestAmount(collectCandidates(left));
      if (leftAmount !== null) {
        return leftAmount;
      }

      const right = sourceText.slice(mKey.index, Math.min(sourceText.length, mKey.index + 160));
      return pickBestAmount(collectCandidates(right));
    };

    const emptyIlamli = {
      aracMahrumiyetBedeli: null,
      aracMahrumiyetFaizi: null,
      mahkemeVekaletUcreti: null,
      mahkemeVekaletUcretiFaizi: null,
      mahkemeYargilamaGiderleri: null,
      mahkemeYargilamaGiderleriFaizi: null,
      mahkemeHarclari: null,
      mahkemeHarclariFaizi: null
    };

    const narrativeAggregated = aggregateTakipEntries(parseNarrativeEntriesFromPlainText(inputText));
    if (
      narrativeAggregated.asilAlacak !== null ||
      narrativeAggregated.gecmisGunFaizi !== null ||
      narrativeAggregated.mahkemeYargilamaGiderleri !== null ||
      narrativeAggregated.mahkemeHarclari !== null ||
      narrativeAggregated.mahkemeVekaletUcreti !== null
    ) {
      return narrativeAggregated;
    }

    const degerKaybiBedeli =
      findAmountNearKeyword(norm, /deger[a-z\s]{0,10}kaybi[a-z\s]{0,25}(?:alacag|alacak|bedel|tazminat|tazminati)/i) ||
      null;
    const ikameAracBedeli =
      findAmountNearKeyword(norm, /ikame[a-z\s]{0,10}arac[a-z\s]{0,25}(?:alacag|alacak|bedel|tazminat|tazminati)/i) ||
      null;
    const degerKaybiFaizi =
      findAmountNearKeyword(norm, /deger[a-z\s]{0,10}kaybi[a-z\s]{0,20}(?:islemis|gecmis)[a-z\s]{0,20}faiz/i) ||
      null;
    const ikameAracFaizi =
      findAmountNearKeyword(norm, /ikame[a-z\s]{0,10}arac[a-z\s]{0,20}(?:islemis|gecmis)[a-z\s]{0,20}faiz/i) ||
      null;
    const degerIkameBedelToplami = sumNumericAmounts([degerKaybiBedeli, ikameAracBedeli]);
    const degerIkameFaizToplami = sumNumericAmounts([degerKaybiFaizi, ikameAracFaizi]);

    let gecmisGunFaizi =
      degerIkameFaizToplami ||
      findAmountNearKeyword(norm, /inkar[a-z\s]{0,20}tazminat[a-z\s]{0,30}(?:islemis|gecmis)[a-z\s]{0,20}faiz/i) ||
      findAmountNearKeyword(norm, /gecmis[a-z\s]{0,15}gun[a-z\s]{0,15}faiz/i) ||
      null;
    const toplamAlacak =
      findAmountNearKeyword(norm, /toplam\s*alacak/i) ||
      null;

    const inkarTazminati =
      findAmountNearKeyword(norm, /(?:icra|icda)?[a-z\s]{0,8}inkar[a-z\s]{0,20}tazminat/i) ||
      null;

    let asilAlacak =
      inkarTazminati ||
      degerIkameBedelToplami ||
      findAmountNearKeyword(norm, /kazanc[a-z\s]{0,10}kaybi[a-z\s]{0,25}(?:alacag|alacak|bedel|tazminat|tazminati)/i) ||
      findAmountNearKeyword(norm, /hak\s*mahrum[a-z\s]{0,30}(?:alacag|alacak|bedel|tazminat|tazminati)/i) ||
      findAmountNearKeyword(norm, /asil\s*alacak/i) ||
      null;

    
    
    if (toplamAlacak !== null && (gecmisGunFaizi === null || asilAlacak === null)) {
      const topIndex = norm.search(/toplam\s*alacak/i);
      if (topIndex >= 0) {
        const left = norm.slice(Math.max(0, topIndex - 260), topIndex);
        const previousAmount = pickBestAmount(collectCandidates(left));
        if (previousAmount !== null && gecmisGunFaizi === null) {
          gecmisGunFaizi = previousAmount;
        }
      }
    }

    if (asilAlacak === null && toplamAlacak !== null && gecmisGunFaizi !== null) {
      asilAlacak = Number((toplamAlacak - gecmisGunFaizi).toFixed(2));
    }

    const ilamli = {
      aracMahrumiyetBedeli:
        degerIkameBedelToplami ||
        findAmountNearKeyword(norm, /(?:(?:hak|arac)[a-z\s]{0,12}mahrum[a-z\s]{0,30}|deger[a-z\s]{0,10}kaybi[a-z\s]{0,20}|kazanc[a-z\s]{0,10}kaybi[a-z\s]{0,20}|ikame[a-z\s]{0,10}arac[a-z\s]{0,20})(?:bedel|tazminat|tazminati|alacag|alacak)/i) || null,
      aracMahrumiyetFaizi:
        degerIkameFaizToplami ||
        findAmountNearKeyword(norm, /(?:(?:hak|arac)[a-z\s]{0,12}mahrum[a-z\s]{0,30}|deger[a-z\s]{0,10}kaybi[a-z\s]{0,20}|kazanc[a-z\s]{0,10}kaybi[a-z\s]{0,20}|ikame[a-z\s]{0,10}arac[a-z\s]{0,20})(?:islemis|gecmis)[a-z\s]{0,20}faiz/i) || null,
      mahkemeVekaletUcreti:
        findAmountNearKeyword(norm, /(mahkeme|ilam)[a-z\s]{0,20}vekalet[a-z\s]{0,10}ucret/i) || null,
      mahkemeVekaletUcretiFaizi:
        findAmountNearKeyword(norm, /(mahkeme|ilam)[a-z\s]{0,20}vekalet[a-z\s]{0,20}ucret[a-z\s]{0,20}(?:islemis|gecmis)[a-z\s]{0,15}faiz/i) || null,
      mahkemeYargilamaGiderleri:
        findAmountNearKeyword(norm, /(mahkeme[a-z\s]{0,10})?yargilama[a-z\s]{0,10}gider/i) || null,
      mahkemeYargilamaGiderleriFaizi:
        findAmountNearKeyword(norm, /(mahkeme[a-z\s]{0,10})?yargilama[a-z\s]{0,20}gider[a-z\s]{0,20}(?:islemis|gecmis)[a-z\s]{0,15}faiz/i) || null,
      mahkemeHarclari:
        findAmountNearKeyword(norm, /mahkeme[a-z\s]{0,10}harc/i) || null,
      mahkemeHarclariFaizi:
        findAmountNearKeyword(norm, /mahkeme[a-z\s]{0,20}harc[a-z\s]{0,20}(?:islemis|gecmis)[a-z\s]{0,15}faiz/i) || null
    };

    return { asilAlacak, gecmisGunFaizi, ...emptyIlamli, ...ilamli };
  };

  const normalizePersonKey = (value) =>
    normalizeText(value)
      .replace(/\[[^\]]*\]/g, " ")
      .replace(/[^a-z0-9\s]/g, " ")
      .replace(/\s+/g, " ")
      .trim();

  const extractNamesFromBracketText = (value) => {
    const raw = fixMojibake(value || "");
    if (!raw) {
      return [];
    }
    const out = [];
    const reNames = /\[([^\]]+)\]/g;
    let m;
    while ((m = reNames.exec(raw)) !== null) {
      const name = String(m[1] || "").trim();
      if (name) {
        out.push(name);
      }
    }
    if (out.length === 0) {
      const t = raw.trim();
      if (t) {
        out.push(t);
      }
    }
    return out;
  };

  const collectAlacakliNameKeys = (tarafJson) => {
    const rows = Array.isArray(tarafJson) ? tarafJson : [];
    const keys = new Set();

    const addName = (value) => {
      const key = normalizePersonKey(value);
      if (key) {
        keys.add(key);
      }
    };

    for (const row of rows) {
      if (!row || typeof row !== "object") {
        continue;
      }
      const rol = normalizeText(row.rol).replace(/\s+/g, " ").trim();
      if (!rol.includes("alacakli")) {
        continue;
      }
      addName(row.adi);
      const vekilNames = extractNamesFromBracketText(row.vekil);
      for (const v of vekilNames) {
        addName(v);
      }
    }

    return keys;
  };

  const collectBorcluHeaderCandidates = (tarafJson) => {
    const rows = Array.isArray(tarafJson) ? tarafJson : [];
    const candidates = [];

    const pickKimlikNo = (row) => {
      if (!row || typeof row !== "object") {
        return "";
      }
      const preferredKeys = [
        "kimlikNo",
        "tcKimlikNo",
        "tcNo",
        "tckimlikNo",
        "tckn",
        "mkk",
        "vkn",
        "vergiNo",
        "vergiKimlikNo"
      ];
      for (const key of preferredKeys) {
        const value = row[key];
        const digits = String(value || "").replace(/\D+/g, "");
        if (digits.length >= 10) {
          return digits;
        }
      }
      for (const [key, value] of Object.entries(row)) {
        if (!/kimlik|tc|tckn|vergi|vkn/i.test(String(key || ""))) {
          continue;
        }
        const digits = String(value || "").replace(/\D+/g, "");
        if (digits.length >= 10) {
          return digits;
        }
      }
      return "";
    };

    for (const row of rows) {
      if (!row || typeof row !== "object") {
        continue;
      }
      const rol = normalizeText(row.rol).replace(/\s+/g, " ").trim();
      if (!rol.includes("borclu") && !rol.includes("muflis")) {
        continue;
      }
      const ad = fixMojibake(row.adi || "").replace(/\s+/g, " ").trim();
      if (!ad) {
        continue;
      }
      const kimlikNo = pickKimlikNo(row);
      candidates.push(kimlikNo ? `${ad} - ${kimlikNo}` : ad);
    }

    return candidates;
  };

  const pickBorcluHeaderValue = (tarafJson) => {
    const candidates = collectBorcluHeaderCandidates(tarafJson);
    return candidates.length > 0 ? candidates[0] : "undefined";
  };

  const matchIslemYapanToAlacakli = (islemYapan, alacakliNameKeys) => {
    if (!(alacakliNameKeys instanceof Set) || alacakliNameKeys.size === 0) {
      return true;
    }

    const source = normalizePersonKey(islemYapan);
    if (!source) {
      return false;
    }

    for (const key of alacakliNameKeys) {
      if (!key) {
        continue;
      }
      if (source === key || source.includes(key) || key.includes(source)) {
        return true;
      }
    }
    return false;
  };

  const extractIslemYapanFromVekaletHtml = (rawHtml) => {
    const raw = fixMojibake(rawHtml || "");
    if (!raw) {
      return "";
    }

    const plain = raw
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/gi, " ")
      .replace(/\s+/g, " ")
      .trim();

    if (!plain) {
      return "";
    }

    const plainNorm = normalizeText(plain).replace(/\s+/g, " ").trim();
    const m = plainNorm.match(
      /islemi\s*gerceklestirenin\s*adi,?\s*soyadi\s*:?\s*(.+?)(?=\s*islemi\s*gerceklestirenin\s*tc|\s*birim\s*adi\s*\/\s*dosya\s*no|\s*islem\s*tarihi|$)/i
    );
    if (m && m[1]) {
      return m[1].replace(/\s+/g, " ").trim();
    }

    return "";
  };

  const extractVekaletPuluInfoFromHtmlText = (htmlText) => {
    const raw = fixMojibake(htmlText || "");
    if (!raw) {
      return { tutar: null, islemYapan: "" };
    }

    const islemYapan = extractIslemYapanFromVekaletHtml(raw);

    const rowMatch = raw.match(/<tr[\s\S]{0,1200}?toplam[\s\S]*?<\/tr>/i);
    if (rowMatch && rowMatch[0]) {
      const nums = rowMatch[0].match(/[0-9][0-9.,]*/g) || [];
      const parsed = nums.map((n) => numberOrNull(n)).filter((n) => n !== null);
      if (parsed.length > 0) {
        return { tutar: parsed[parsed.length - 1], islemYapan };
      }
    }

    const norm = normalizeText(raw).replace(/\s+/g, " ").trim();
    if (!norm) {
      return { tutar: null, islemYapan };
    }

    const m = norm.match(/toplam[^0-9]{0,80}([0-9][0-9.,]*)/i);
    if (m && m[1]) {
      return { tutar: numberOrNull(m[1]), islemYapan };
    }

    return { tutar: null, islemYapan };
  };

  const extractVekaletPuluFromHtmlText = (htmlText) => extractVekaletPuluInfoFromHtmlText(htmlText).tutar;

  const normalizeDosyaNo = (value) => String(value || "").replace(/\s+/g, "").trim();

  const extractDosyaMasrafBilgileri = (payload, expectedDosyaNo, alacakliNameKeys) => {
    const out = {
      tebligatGideri: null,
      pesinHarc: null,
      basvurmaHarci: null,
      vekaletSuretHarci: null
    };

    if (!payload || typeof payload !== "object") {
      return out;
    }

    out.tebligatGideri = numberOrNull(payload.haricen);
    const harcList = Array.isArray(payload.harcList) ? payload.harcList : [];
    const dosyaNoKey = normalizeDosyaNo(expectedDosyaNo);

    const collect = (requireNameMatch) => {
      let pesin = 0;
      let basvurma = 0;
      let vekaletSuret = 0;
      let pesinHit = false;
      let basvurmaHit = false;
      let vekaletHit = false;

      for (const row of harcList) {
        if (!row || typeof row !== "object") {
          continue;
        }
        if (dosyaNoKey && normalizeDosyaNo(row.dosyaNo) !== dosyaNoKey) {
          continue;
        }
        if (requireNameMatch && !matchIslemYapanToAlacakli(row.odeyenKisi, alacakliNameKeys)) {
          continue;
        }

        const tur = normalizeText(row.tahsilatTuru).replace(/\s+/g, " ").trim();
        const miktar = numberOrNull(row.miktar);
        if (miktar === null) {
          continue;
        }

        if (tur.includes("pesin harc")) {
          pesin += miktar;
          pesinHit = true;
          continue;
        }
        if (tur.includes("basvurma harci")) {
          basvurma += miktar;
          basvurmaHit = true;
          continue;
        }
        if (tur.includes("vekalet suret harci")) {
          vekaletSuret += miktar;
          vekaletHit = true;
        }
      }

      return {
        pesinHarc: pesinHit ? Number(pesin.toFixed(2)) : null,
        basvurmaHarci: basvurmaHit ? Number(basvurma.toFixed(2)) : null,
        vekaletSuretHarci: vekaletHit ? Number(vekaletSuret.toFixed(2)) : null,
        any: pesinHit || basvurmaHit || vekaletHit
      };
    };

    let fees = collect(true);
    if (!fees.any) {
      
      fees = collect(false);
    }

    out.pesinHarc = fees.pesinHarc;
    out.basvurmaHarci = fees.basvurmaHarci;
    out.vekaletSuretHarci = fees.vekaletSuretHarci;
    return out;
  };

  const extractReddiyatKalanMiktari = (payload, expectedDosyaNo) => {
    if (!payload || typeof payload !== "object") {
      return null;
    }

    const tahsilatList = Array.isArray(payload.tahsilatList) ? payload.tahsilatList : [];
    const dosyaNoKey = normalizeDosyaNo(expectedDosyaNo);
    let best = null;

    for (const row of tahsilatList) {
      if (!row || typeof row !== "object") {
        continue;
      }
      if (dosyaNoKey && normalizeDosyaNo(row.dosyaNo) !== dosyaNoKey) {
        continue;
      }
      const tahsilatTuru = normalizeText(row.tahsilatTuru).replace(/\s+/g, " ").trim();
      if (!tahsilatTuru.includes("borc tahsilati")) {
        continue;
      }
      const kalanMiktar = numberOrNull(row.kalanMiktar);
      if (kalanMiktar === null || kalanMiktar <= 0) {
        continue;
      }
      best = best === null ? kalanMiktar : Math.max(best, kalanMiktar);
    }

    return best;
  };

  const extractReddiyatTahsilatKalemleri = (payload, expectedDosyaNo, alacakliNameKeys, options) => {
    if (!payload || typeof payload !== "object") {
      return [];
    }
    const tahsilatList = Array.isArray(payload.tahsilatList) ? payload.tahsilatList : [];
    const dosyaNoKey = normalizeDosyaNo(expectedDosyaNo);
    const isDosyaKapali = !!(options && options.isDosyaKapali);
    const out = [];
    const matchingRows = tahsilatList.filter((row) => {
      if (!row || typeof row !== "object") {
        return false;
      }
      return !dosyaNoKey || normalizeDosyaNo(row.dosyaNo) === dosyaNoKey;
    });
    const hasBorcTahsilati = matchingRows.some(
      (row) => normalizeText(row.tahsilatTuru).replace(/\s+/g, " ").trim() === "borc tahsilati"
    );
    const hasAlacakliKeys = alacakliNameKeys instanceof Set && alacakliNameKeys.size > 0;

    for (const row of matchingRows) {
      if (!row || typeof row !== "object") {
        continue;
      }
      const tahsilatTuru = String(row.tahsilatTuru || "").trim();
      const normalizedTahsilatTuru = normalizeText(tahsilatTuru).replace(/\s+/g, " ").trim();
      const kalanMiktar = numberOrNull(row.kalanMiktar);
      if (isDosyaKapali) {
        out.push({
          birimAdi: String(row.birimAdi || "").trim(),
          dosyaNo: String(row.dosyaNo || expectedDosyaNo || "").trim(),
          tahsilatTuru,
          kalanMiktar
        });
        continue;
      }

      const isMasrafAvansi = normalizedTahsilatTuru === "masraf avansi tahsilati";
      const isBorcTahsilati = normalizedTahsilatTuru === "borc tahsilati";
      if (!isMasrafAvansi && !isBorcTahsilati) {
        continue;
      }
      if (kalanMiktar === null || kalanMiktar <= 0) {
        continue;
      }
      if (isMasrafAvansi && (!hasBorcTahsilati || !hasAlacakliKeys || !matchIslemYapanToAlacakli(row.odeyenKisi, alacakliNameKeys))) {
        continue;
      }
      out.push({
        birimAdi: String(row.birimAdi || "").trim(),
        dosyaNo: String(row.dosyaNo || expectedDosyaNo || "").trim(),
        tahsilatTuru,
        kalanMiktar
      });
    }

    return out;
  };

  const tryDecodeBase64ToBytes = (b64) => {
    try {
      const clean = String(b64 || "").replace(/\s+/g, "");
      if (!clean || clean.length < 20) {
        return null;
      }
      const bin = atob(clean);
      const out = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i += 1) {
        out[i] = bin.charCodeAt(i) & 0xff;
      }
      return out;
    } catch {
      return null;
    }
  };

  const unwrapPdfLikeBytes = (bytes) => {
    if (!(bytes instanceof Uint8Array) || bytes.length < 5) {
      return null;
    }
    const sig = new TextDecoder("latin1").decode(bytes.slice(0, 8));
    if (sig.includes("%PDF-")) {
      return bytes;
    }

    const asUtf8 = new TextDecoder("utf-8", { fatal: false }).decode(bytes);
    const asLatin = new TextDecoder("latin1").decode(bytes);

    const findPdfStart = (s) => {
      const idx = s.indexOf("%PDF-");
      if (idx >= 0) {
        const tail = s.slice(idx);
        const arr = new Uint8Array(tail.length);
        for (let i = 0; i < tail.length; i += 1) {
          arr[i] = tail.charCodeAt(i) & 0xff;
        }
        return arr;
      }
      return null;
    };

    const directUtf = findPdfStart(asUtf8);
    if (directUtf) {
      return directUtf;
    }
    const directLatin = findPdfStart(asLatin);
    if (directLatin) {
      return directLatin;
    }

    const b64Patterns = [
      /data:application\/pdf;base64,([A-Za-z0-9+/=\s]{200,})/i,
      /"([A-Za-z0-9+/=\s]{400,})"/g,
      /(JVBERi0[A-Za-z0-9+/=\s]{200,})/g
    ];

    for (const pattern of b64Patterns) {
      if (pattern.global) {
        pattern.lastIndex = 0;
        let m;
        while ((m = pattern.exec(asUtf8)) !== null) {
          const candidate = m[1] || m[0];
          const decoded = tryDecodeBase64ToBytes(candidate);
          if (!decoded) {
            continue;
          }
          const dsig = new TextDecoder("latin1").decode(decoded.slice(0, 8));
          if (dsig.includes("%PDF-")) {
            return decoded;
          }
        }
      } else {
        const m = asUtf8.match(pattern);
        if (m && m[1]) {
          const decoded = tryDecodeBase64ToBytes(m[1]);
          if (decoded) {
            const dsig = new TextDecoder("latin1").decode(decoded.slice(0, 8));
            if (dsig.includes("%PDF-")) {
              return decoded;
            }
          }
        }
      }
    }

    return null;
  };

  const decodeEscapedTextVariants = (input) => {
    const out = [];
    const push = (v) => {
      const s = String(v || "");
      if (s && !out.includes(s)) {
        out.push(s);
      }
    };

    const raw = String(input || "");
    push(raw);

    try {
      const uni = raw
        .replace(/\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16)))
        .replace(/\\x([0-9a-fA-F]{2})/g, (_, h) => String.fromCharCode(parseInt(h, 16)))
        .replace(/\\n/g, "\n")
        .replace(/\\r/g, "\r")
        .replace(/\\t/g, "\t");
      push(uni);
    } catch {
      
    }

    try {
      const ta = document.createElement("textarea");
      ta.innerHTML = raw;
      push(ta.value || ta.textContent || "");
    } catch {
      
    }

    try {
      push(decodeURIComponent(raw));
    } catch {
      
    }

    return out;
  };

  const extractInnerDocumentUrls = (bodyText, baseUrl) => {
    const out = [];
    const s = String(bodyText || "");
    if (!s) {
      return out;
    }

    const add = (u) => {
      const raw = String(u || "").trim();
      if (!raw) {
        return;
      }
      try {
        const abs = new URL(raw, baseUrl || window.location.href).toString();
        if (!/^https?:/i.test(abs)) {
          return;
        }
        if (!out.includes(abs)) {
          out.push(abs);
        }
      } catch {
        
      }
    };

    const patterns = [
      /(?:href|src)=["']([^"']+)["']/gi,
      /https?:\/\/[^"'\s<>]+/gi,
      /\/(?:view_document(?:_brd)?\.uyap[^"'\s<>]*)/gi,
      /[^"'\s<>]+\.pdf(?:\?[^"'\s<>]*)?/gi
    ];

    for (const re of patterns) {
      re.lastIndex = 0;
      let m;
      while ((m = re.exec(s)) !== null) {
        add(m[1] || m[0]);
      }
    }

    return out.slice(0, 8);
  };

  const LOCAL_FILE_HEADER_SIGNATURE = 0x04034b50;

  const getUint16Le = (bytes, offset) => bytes[offset] | (bytes[offset + 1] << 8);

  const getUint32Le = (bytes, offset) =>
    ((bytes[offset]) | (bytes[offset + 1] << 8) | (bytes[offset + 2] << 16) | (bytes[offset + 3] << 24)) >>> 0;

  const decodeZipEntryName = (bytes) => {
    try {
      return new TextDecoder("utf-8", { fatal: false }).decode(bytes);
    } catch {
      return String.fromCharCode(...bytes);
    }
  };

  const inflateZipEntryFallback = (compressedBytes) => {
    const inflateSync = window.fflate && typeof window.fflate.inflateSync === "function" ? window.fflate.inflateSync : null;
    if (!inflateSync) {
      throw new Error("ZIP icerigi acilamadi.");
    }

    const trims = [0, 12, 16, 20, 24, 28];
    for (const trim of trims) {
      if (compressedBytes.length <= trim) {
        continue;
      }
      try {
        return inflateSync(compressedBytes.subarray(0, compressedBytes.length - trim));
      } catch {
        
      }
    }

    return inflateSync(compressedBytes);
  };

  const unzipFromLocalHeaders = (bytes) => {
    const files = {};
    const headerOffsets = [];

    for (let offset = 0; offset <= bytes.length - 4; offset += 1) {
      if (getUint32Le(bytes, offset) === LOCAL_FILE_HEADER_SIGNATURE) {
        headerOffsets.push(offset);
      }
    }

    for (let index = 0; index < headerOffsets.length; index += 1) {
      const headerOffset = headerOffsets[index];
      const nameLength = getUint16Le(bytes, headerOffset + 26);
      const extraLength = getUint16Le(bytes, headerOffset + 28);
      const compressionMethod = getUint16Le(bytes, headerOffset + 8);
      const nameStart = headerOffset + 30;
      const nameEnd = nameStart + nameLength;
      const dataStart = nameEnd + extraLength;
      const dataEnd = index + 1 < headerOffsets.length ? headerOffsets[index + 1] : bytes.length;
      const fileName = decodeZipEntryName(bytes.subarray(nameStart, nameEnd));
      const payload = bytes.subarray(dataStart, dataEnd);

      if (!fileName) {
        continue;
      }

      if (compressionMethod === 0) {
        files[fileName] = payload;
        continue;
      }

      if (compressionMethod === 8) {
        files[fileName] = inflateZipEntryFallback(payload);
      }
    }

    return files;
  };

  const buildCustomFaizKey = (desc) =>
    typeof SharedHesapNormalizers.buildCustomFaizKey === "function"
      ? SharedHesapNormalizers.buildCustomFaizKey(desc)
      : String(desc || "")
          .replace(/\([^)]*\)/g, " ")
          .replace(/\b(?:tl|istenen|yillik|adi|kanuni|faiz|gecmis|gun|islemis|bedel|tazminat|tazminati|alacagi|alacag|alacak)\b/g, " ")
          .replace(/\s+/g, " ")
          .trim();

  const fixMojibakeMultiline = (value) =>
    typeof SharedHesapNormalizers.fixMojibakeMultiline === "function"
      ? SharedHesapNormalizers.fixMojibakeMultiline(value)
      : String(value || "")
          .replace(/\r\n/g, "\n")
          .split("\n")
          .map((line) => fixMojibake(line))
          .join("\n");

  const parseStructuredEntriesFromXml = (xmlText) => {
    if (typeof SharedHesapExtractors.parseStructuredEntriesFromXml === "function") {
      return SharedHesapExtractors.parseStructuredEntriesFromXml(xmlText);
    }
    const rows = String(xmlText || "").match(/<rowXbXb[\s\S]*?<\/rowXbXb>/gi) || [];
    const entries = [];

    for (const row of rows) {
      const amountRaw = ((row.match(/<takipTalebiDortMaddeAlacaginTlOlarakKarsiligiFaizMiktari>([\s\S]*?)<\/takipTalebiDortMaddeAlacaginTlOlarakKarsiligiFaizMiktari>/i) || [])[1] || "").trim();
      const descRaw = ((row.match(/<faizinIslemeyeBasladigiGun>([\s\S]*?)<\/faizinIslemeyeBasladigiGun>/i) || [])[1] || "").trim();
      const amount = numberOrNull(amountRaw);
      const desc = normalizeText(descRaw);
      if (amount === null || !desc) {
        continue;
      }
      entries.push({ amount, desc, source: "structured" });
    }

    return entries;
  };

  const parseFieldEntriesFromXml = (xmlText) => {
    if (typeof SharedHesapExtractors.parseFieldEntriesFromXml === "function") {
      return SharedHesapExtractors.parseFieldEntriesFromXml(xmlText);
    }
    const entries = [];
    const pairRegex =
      /<takipTalebiDortMaddeAlacaginTlOlarakKarsiligiFaizMiktari>([\s\S]*?)<\/takipTalebiDortMaddeAlacaginTlOlarakKarsiligiFaizMiktari>[\s\S]*?<faizinIslemeyeBasladigiGun>([\s\S]*?)<\/faizinIslemeyeBasladigiGun>/gi;
    let match;

    while ((match = pairRegex.exec(String(xmlText || ""))) !== null) {
      const amount = numberOrNull((match[1] || "").trim());
      const desc = normalizeText((match[2] || "").trim());
      if (amount === null || !desc) {
        continue;
      }
      entries.push({ amount, desc, source: "field-pair" });
    }

    return entries;
  };

  const extractCdataText = (xmlText) => {
    if (typeof SharedHesapExtractors.extractCdataText === "function") {
      return SharedHesapExtractors.extractCdataText(xmlText);
    }
    const match = String(xmlText || "").match(/<content><!\[CDATA\[([\s\S]*?)\]\]>\s*<\/content>/i);
    return match ? fixMojibakeMultiline(match[1]) : "";
  };

  const isTakipUcuncuMaddeHeader = (line) => {
    if (typeof SharedHesapExtractors.isTakipUcuncuMaddeHeader === "function") {
      return SharedHesapExtractors.isTakipUcuncuMaddeHeader(line);
    }
    const raw = fixMojibake(line || "").toLocaleLowerCase("tr-TR");
    return /^3\s*[-.)]/.test(raw) && (raw.includes("alacağ") || raw.includes("alacag") || raw.includes("teminat"));
  };

  const isTakipDorduncuMaddeHeader = (line) => {
    if (typeof SharedHesapExtractors.isTakipDorduncuMaddeHeader === "function") {
      return SharedHesapExtractors.isTakipDorduncuMaddeHeader(line);
    }
    const raw = fixMojibake(line || "").toLocaleLowerCase("tr-TR");
    return /^4\s*[-.)]/.test(raw) && (raw.includes("senet") || raw.includes("borcun sebebi"));
  };

  const extractNarrativeSection = (xmlText) => {
    if (typeof SharedHesapExtractors.extractNarrativeSection === "function") {
      return SharedHesapExtractors.extractNarrativeSection(xmlText);
    }
    const cdataText = extractCdataText(xmlText);
    if (!cdataText) {
      return "";
    }

    const lines = cdataText
      .split(/\r?\n/)
      .map((line) => String(line || "").trim())
      .filter(Boolean);

    let startIndex = -1;
    let endIndex = lines.length;

    for (let index = 0; index < lines.length; index += 1) {
      if (startIndex === -1 && isTakipUcuncuMaddeHeader(lines[index])) {
        startIndex = index + 1;
        continue;
      }
      if (startIndex !== -1 && isTakipDorduncuMaddeHeader(lines[index])) {
        endIndex = index;
        break;
      }
    }

    if (startIndex === -1) {
      return "";
    }

    return lines.slice(startIndex, endIndex).join("\n");
  };

  const parseNarrativeEntriesFromXml = (xmlText) => {
    if (typeof SharedHesapExtractors.parseNarrativeEntriesFromXml === "function") {
      return SharedHesapExtractors.parseNarrativeEntriesFromXml(xmlText);
    }
    const sectionText = extractNarrativeSection(xmlText);
    if (!sectionText) {
      return [];
    }

    const lines = sectionText
      .split(/\r?\n/)
      .map((line) => fixMojibake(line).replace(/\s+/g, " ").trim())
      .filter(Boolean);

    const entries = [];
    let pendingAmount = null;

    const tryParseStandaloneAmount = (line) => {
      const match = line.match(/^(\d[\d.\s]*,\d{2}|\d[\d.\s]*)$/);
      return match ? numberOrNull(match[1]) : null;
    };

    const tryParseInlineAmount = (line) => {
      const match = line.match(/(\d[\d.\s]*,\d{2}|\d[\d.\s]*)\s*(?:TL)?\s*$/i);
      return match ? numberOrNull(match[1]) : null;
    };

    const stripTrailingAmount = (line) =>
      line
        .replace(/(\d[\d.\s]*,\d{2}|\d[\d.\s]*)\s*(?:TL)?\s*$/i, "")
        .replace(/[.:;,]+$/g, "")
        .trim();

    for (const line of lines) {
      const standaloneAmount = tryParseStandaloneAmount(line);
      if (standaloneAmount !== null) {
        pendingAmount = standaloneAmount;
        continue;
      }

      if (pendingAmount !== null) {
        const desc = normalizeText(line);
        if (desc) {
          entries.push({ amount: pendingAmount, desc, source: "cdata" });
          pendingAmount = null;
          continue;
        }
      }

      const inlineAmount = tryParseInlineAmount(line);
      if (inlineAmount === null) {
        continue;
      }

      const desc = normalizeText(stripTrailingAmount(line));
      if (!desc) {
        continue;
      }
      entries.push({ amount: inlineAmount, desc, source: "cdata-inline" });
    }

    return entries;
  };

  const classifyTakipEntry = (desc) => {
    if (typeof SharedHesapClassifiers.classifyTakipEntry === "function") {
      return SharedHesapClassifiers.classifyTakipEntry(desc);
    }
    const normalized = normalizeText(desc);
    const isExplicitPrimaryGecmisGunFaizi =
      normalized === "gecmis gun faizi" ||
      normalized.startsWith("gecmis gun faizi ");
    const hasExplicitFaizLabel =
      /\bfaizi\b/.test(normalized) ||
      /\bfaizidir\b/.test(normalized) ||
      ((normalized.includes("gecmis") || normalized.includes("islemis")) && normalized.includes("faiz"));
    const isFaiz = hasExplicitFaizLabel || isExplicitPrimaryGecmisGunFaizi;
    const hasMahrumAnahtar = normalized.includes("hak mahrum") || normalized.includes("arac mahrum");
    const hasDegerKaybiAnahtar = normalized.includes("deger kaybi");
    const hasKazancKaybiAnahtar = normalized.includes("kazanc kaybi");
    const hasIkameAracAnahtar = normalized.includes("ikame arac");
    const hasCekiciAnahtar = normalized.includes("cekici");
    const hasHasarAnahtar = normalized.includes("hasar");
    const hasMahrumAlacakEtiketi =
      normalized.includes("bedel") ||
      normalized.includes("tazminat") ||
      normalized.includes("tazminati") ||
      normalized.includes("zarar") ||
      normalized.includes("zarari") ||
      normalized.includes("alacagi") ||
      normalized.includes("alacag") ||
      normalized.includes("alacak");
    const isHakMahrum = normalized.includes("hak mahrum") && hasMahrumAlacakEtiketi && !isFaiz;
    const isAracMahrum = normalized.includes("arac mahrum") && hasMahrumAlacakEtiketi && !isFaiz;
    const isDegerKaybi = hasDegerKaybiAnahtar && hasMahrumAlacakEtiketi && !isFaiz;
    const isKazancKaybi = hasKazancKaybiAnahtar && hasMahrumAlacakEtiketi && !isFaiz;
    const isIkameArac = hasIkameAracAnahtar && hasMahrumAlacakEtiketi && !isFaiz;
    const isCekiciBedeli = hasCekiciAnahtar && hasMahrumAlacakEtiketi && !isFaiz;
    const isHasarBedeli = hasHasarAnahtar && hasMahrumAlacakEtiketi && !isFaiz;
    const isInkarTazminati = normalized.includes("inkar") && normalized.includes("tazminat") && !isFaiz;
    const isAsil = normalized.includes("asil alacak") && !isFaiz;
    const isToplam = normalized.includes("toplam") && normalized.includes("alacak");
    const hasGecmisFaiz = hasExplicitFaizLabel;

    let asilType = "";
    let field = "";

    if (isHakMahrum) {
      asilType = "hak_mahrum";
      field = "asilAlacak";
    } else if (isAracMahrum) {
      asilType = "arac_mahrum";
      field = "asilAlacak";
    } else if (isDegerKaybi) {
      asilType = "deger_kaybi";
      field = "asilAlacak";
    } else if (isKazancKaybi) {
      asilType = "kazanc_kaybi";
      field = "asilAlacak";
    } else if (isIkameArac) {
      asilType = "ikame_arac";
      field = "asilAlacak";
    } else if (isCekiciBedeli) {
      asilType = "cekici_bedeli";
      field = "asilAlacak";
    } else if (isHasarBedeli) {
      asilType = "hasar_bedeli";
      field = "asilAlacak";
    } else if (isInkarTazminati) {
      asilType = "inkar_tazminat";
      field = "asilAlacak";
    } else if (isAsil) {
      asilType = "asil_alacak";
      field = "asilAlacak";
    } else if ((hasMahrumAnahtar || hasDegerKaybiAnahtar || hasKazancKaybiAnahtar || hasIkameAracAnahtar || hasCekiciAnahtar || hasHasarAnahtar) && hasMahrumAlacakEtiketi) {
      field = hasGecmisFaiz ? "gecmisGunFaizi" : "asilAlacak";
    } else if (
      normalized.includes("vekalet") &&
      normalized.includes("ucret") &&
      !normalized.includes("icra vekalet")
    ) {
      field = hasGecmisFaiz ? "mahkemeVekaletUcretiFaizi" : "mahkemeVekaletUcreti";
    } else if (normalized.includes("yargilama") && normalized.includes("gider")) {
      field = hasGecmisFaiz ? "mahkemeYargilamaGiderleriFaizi" : "mahkemeYargilamaGiderleri";
    } else if (normalized.includes("harc")) {
      field = hasGecmisFaiz ? "mahkemeHarclariFaizi" : "mahkemeHarclari";
    } else if (isToplam) {
      field = "toplamAlacak";
    } else if (isExplicitPrimaryGecmisGunFaizi) {
      field = "gecmisGunFaizi";
    } else if (isFaiz) {
      field = "gecmisGunFaizi";
    }

    return {
      normalized,
      isFaiz,
      asilType,
      field,
      customFaizKey: isAsil ? buildCustomFaizKey(normalized) : ""
    };
  };

  const isGenericPrimaryFaizCandidate = (desc) => {
    const normalizedDesc = normalizeText(desc);
    if (!normalizedDesc || !normalizedDesc.includes("faiz")) {
      return false;
    }
    if (normalizedDesc === "gecmis gun faizi" || normalizedDesc.startsWith("gecmis gun faizi ")) {
      return true;
    }
    if (
      normalizedDesc.includes("vekalet") ||
      normalizedDesc.includes("yargilama") ||
      normalizedDesc.includes("gider") ||
      normalizedDesc.includes("harc")
    ) {
      return false;
    }
    return (
      normalizedDesc === "faiz" ||
      normalizedDesc === "faizi" ||
      normalizedDesc.includes("gecmis gun faizi") ||
      normalizedDesc.includes("islemis faiz") ||
      normalizedDesc.includes("gecmis faiz")
    );
  };

  const aggregateTakipEntries = (entries) => {
    if (typeof SharedHesapExtractors.aggregateTakipEntries === "function") {
      return SharedHesapExtractors.aggregateTakipEntries(entries);
    }
    const result = {
      asilAlacak: null,
      gecmisGunFaizi: null,
      toplamAlacak: null,
      aracMahrumiyetBedeli: null,
      aracMahrumiyetFaizi: null,
      mahkemeVekaletUcreti: null,
      mahkemeVekaletUcretiFaizi: null,
      mahkemeYargilamaGiderleri: null,
      mahkemeYargilamaGiderleriFaizi: null,
      mahkemeHarclari: null,
      mahkemeHarclariFaizi: null
    };
    let asilBedelType = "";
    let asilCustomFaizKey = "";
    let hasPrimaryDebtContext = false;
    const faizCandidates = [];

    for (const entry of Array.isArray(entries) ? entries : []) {
      const amount = numberOrNull(entry && entry.amount);
      const desc = normalizeText(entry && entry.desc);
      if (amount === null || !desc) {
        continue;
      }

      const classification = classifyTakipEntry(desc);

      if (classification.field === "asilAlacak") {
        hasPrimaryDebtContext = true;
        result.asilAlacak = addAmount(result.asilAlacak, amount);
        if (classification.asilType && classification.asilType !== "asil_alacak") {
          asilBedelType = classification.asilType;
        }
        if (classification.customFaizKey) {
          asilCustomFaizKey = classification.customFaizKey;
        }
      } else if (classification.field === "toplamAlacak") {
        result.toplamAlacak = addAmount(result.toplamAlacak, amount);
      } else if (classification.field) {
        result[classification.field] = addAmount(result[classification.field], amount);
      }

      if (classification.isFaiz) {
        faizCandidates.push({ amount, desc });
      }

      if (classification.asilType === "hak_mahrum" || classification.asilType === "arac_mahrum" || classification.asilType === "deger_kaybi" || classification.asilType === "kazanc_kaybi" || classification.asilType === "ikame_arac" || classification.asilType === "cekici_bedeli" || classification.asilType === "hasar_bedeli") {
        result.aracMahrumiyetBedeli = addAmount(result.aracMahrumiyetBedeli, amount);
      }
      if (classification.isFaiz && (desc.includes("hak mahrum") || desc.includes("arac mahrum") || desc.includes("deger kaybi") || desc.includes("kazanc kaybi") || desc.includes("ikame arac") || desc.includes("cekici") || desc.includes("hasar"))) {
        result.aracMahrumiyetFaizi = addAmount(result.aracMahrumiyetFaizi, amount);
      }
    }

    if (result.gecmisGunFaizi === null && faizCandidates.length > 0 && (hasPrimaryDebtContext || !!asilBedelType || !!asilCustomFaizKey)) {
      const explicitPrimaryFaizCandidates = faizCandidates.filter((candidate) => {
        const normalizedDesc = normalizeText(candidate.desc);
        return normalizedDesc === "gecmis gun faizi" || normalizedDesc.startsWith("gecmis gun faizi ");
      });
      if (explicitPrimaryFaizCandidates.length > 0) {
        result.gecmisGunFaizi = sumNumericAmounts(explicitPrimaryFaizCandidates.map((candidate) => candidate.amount));
        return result;
      }

      let matchedFaizCandidates = faizCandidates.filter((candidate) => {
        if (asilBedelType === "hak_mahrum") {
          return candidate.desc.includes("hak mahrum");
        }
        if (asilBedelType === "arac_mahrum") {
          return candidate.desc.includes("arac mahrum");
        }
        if (asilBedelType === "deger_kaybi") {
          return candidate.desc.includes("deger kaybi");
        }
        if (asilBedelType === "kazanc_kaybi") {
          return candidate.desc.includes("kazanc kaybi");
        }
        if (asilBedelType === "ikame_arac") {
          return candidate.desc.includes("ikame arac");
        }
        if (asilBedelType === "cekici_bedeli") {
          return candidate.desc.includes("cekici");
        }
        if (asilBedelType === "hasar_bedeli") {
          return candidate.desc.includes("hasar");
        }
        if (asilBedelType === "inkar_tazminat") {
          return candidate.desc.includes("inkar") && candidate.desc.includes("tazminat");
        }
        if (asilCustomFaizKey) {
          return candidate.desc.includes(asilCustomFaizKey);
        }
        return true;
      });
      if (matchedFaizCandidates.length === 0) {
        matchedFaizCandidates = faizCandidates.filter((candidate) => isGenericPrimaryFaizCandidate(candidate.desc));
      }
      result.gecmisGunFaizi = sumNumericAmounts(matchedFaizCandidates.map((candidate) => candidate.amount));
    }

    if (result.asilAlacak === null && result.toplamAlacak !== null && result.gecmisGunFaizi !== null && (hasPrimaryDebtContext || !!asilBedelType || !!asilCustomFaizKey)) {
      result.asilAlacak = Number((result.toplamAlacak - result.gecmisGunFaizi).toFixed(2));
    }

    return result;
  };

  const extractNarrativeSectionFromPlainText = (inputText) => {
    if (typeof SharedHesapExtractors.extractNarrativeSectionFromPlainText === "function") {
      return SharedHesapExtractors.extractNarrativeSectionFromPlainText(inputText);
    }
    const raw = fixMojibakeMultiline(inputText || "");
    if (!raw) {
      return "";
    }

    const lines = raw
      .split(/\r?\n/)
      .map((line) => String(line || "").trim())
      .filter(Boolean);

    let startIndex = -1;
    let endIndex = lines.length;

    for (let index = 0; index < lines.length; index += 1) {
      if (startIndex === -1 && isTakipUcuncuMaddeHeader(lines[index])) {
        startIndex = index + 1;
        continue;
      }
      if (startIndex !== -1 && isTakipDorduncuMaddeHeader(lines[index])) {
        endIndex = index;
        break;
      }
    }

    if (startIndex === -1) {
      return "";
    }

    return lines.slice(startIndex, endIndex).join("\n");
  };

  const parseNarrativeEntriesFromPlainText = (inputText) => {
    if (typeof SharedHesapExtractors.parseNarrativeEntriesFromPlainText === "function") {
      return SharedHesapExtractors.parseNarrativeEntriesFromPlainText(inputText);
    }
    const sectionText = extractNarrativeSectionFromPlainText(inputText);
    if (!sectionText) {
      return [];
    }

    const lines = sectionText
      .split(/\r?\n/)
      .map((line) => fixMojibake(line).replace(/\s+/g, " ").trim())
      .filter(Boolean);

    const entries = [];
    let pendingAmount = null;

    const tryParseStandaloneAmount = (line) => {
      const match = line.match(/^(\d[\d.\s]*,\d{2}|\d[\d.\s]*)$/);
      return match ? numberOrNull(match[1]) : null;
    };

    const tryParseInlineAmount = (line) => {
      const match = line.match(/(\d[\d.\s]*,\d{2}|\d[\d.\s]*)\s*(?:TL)?\s*$/i);
      return match ? numberOrNull(match[1]) : null;
    };

    const stripTrailingAmount = (line) =>
      line
        .replace(/(\d[\d.\s]*,\d{2}|\d[\d.\s]*)\s*(?:TL)?\s*$/i, "")
        .replace(/[.:;,]+$/g, "")
        .trim();

    for (const line of lines) {
      const standaloneAmount = tryParseStandaloneAmount(line);
      if (standaloneAmount !== null) {
        pendingAmount = standaloneAmount;
        continue;
      }

      if (pendingAmount !== null) {
        const desc = normalizeText(line);
        if (desc) {
          entries.push({ amount: pendingAmount, desc, source: "plain-text" });
          pendingAmount = null;
          continue;
        }
      }

      const inlineAmount = tryParseInlineAmount(line);
      if (inlineAmount === null) {
        continue;
      }

      const desc = normalizeText(stripTrailingAmount(line));
      if (!desc) {
        continue;
      }
      entries.push({ amount: inlineAmount, desc, source: "plain-text-inline" });
    }

    return entries;
  };

  const extractTakipTalebiAmountsFromContentXml = (xmlText) => {
    if (typeof SharedHesapExtractors.extractTakipTalebiAmountsFromContentXml === "function") {
      return SharedHesapExtractors.extractTakipTalebiAmountsFromContentXml(xmlText);
    }
    const candidates = [];
    const structuredEntries = parseStructuredEntriesFromXml(xmlText);
    const fieldEntries = parseFieldEntriesFromXml(xmlText);
    const narrativeEntries = parseNarrativeEntriesFromXml(xmlText);

    if (structuredEntries.length > 0) {
      candidates.push(aggregateTakipEntries(structuredEntries));
    }
    if (fieldEntries.length > 0) {
      candidates.push(aggregateTakipEntries(fieldEntries));
    }
    if (narrativeEntries.length > 0) {
      candidates.push(aggregateTakipEntries(narrativeEntries));
    }

    let aggregated = null;
    let bestScore = -1;

    for (const candidate of candidates) {
      const score = getTakipParseQualityScore(candidate);
      if (score > bestScore) {
        aggregated = candidate;
        bestScore = score;
      }
    }

    if (aggregated && bestScore >= 0) {
      return aggregated;
    }

    const fallback = extractTakipTalebiAmountsFromText(xmlText);
    return fallback;
  };

  const getTakipParseQualityScore = (parsed) => {
    if (typeof SharedHesapScoring.getTakipParseQualityScore === "function") {
      return SharedHesapScoring.getTakipParseQualityScore(parsed);
    }
    if (!parsed || typeof parsed !== "object") {
      return -1;
    }
    let score = 0;
    if (numberOrNull(parsed.asilAlacak) !== null) {
      score += 5;
    }
    if (numberOrNull(parsed.gecmisGunFaizi) !== null) {
      score += 5;
    }
    if (numberOrNull(parsed.toplamAlacak) !== null) {
      score += 2;
    }
    if (numberOrNull(parsed.aracMahrumiyetBedeli) !== null) {
      score += 2;
    }
    if (numberOrNull(parsed.aracMahrumiyetFaizi) !== null) {
      score += 2;
    }
    if (numberOrNull(parsed.mahkemeYargilamaGiderleri) !== null) {
      score += 1;
    }
    if (numberOrNull(parsed.mahkemeHarclari) !== null) {
      score += 1;
    }
    if (numberOrNull(parsed.mahkemeVekaletUcreti) !== null) {
      score += 1;
    }
    return score;
  };

  const extractTakipTalebiAmountsFromUdfBytes = (bytes) => {
    try {
      const fflate = window.fflate;
      if (!fflate || typeof fflate.unzipSync !== "function") {
        return { asilAlacak: null, gecmisGunFaizi: null, aracMahrumiyetBedeli: null, aracMahrumiyetFaizi: null, mahkemeVekaletUcreti: null, mahkemeVekaletUcretiFaizi: null, mahkemeYargilamaGiderleri: null, mahkemeYargilamaGiderleriFaizi: null, mahkemeHarclari: null, mahkemeHarclariFaizi: null };
      }
      let files;
      try {
        files = fflate.unzipSync(bytes);
      } catch (error) {
        files = unzipFromLocalHeaders(bytes);
        if (!files || Object.keys(files).length === 0) {
          throw error;
        }
      }
      const names = Object.keys(files || {});
      const contentKey = names.find((n) => /(^|\/)content\.xml$/i.test(String(n || "")));
      if (!contentKey) {
        return { asilAlacak: null, gecmisGunFaizi: null, aracMahrumiyetBedeli: null, aracMahrumiyetFaizi: null, mahkemeVekaletUcreti: null, mahkemeVekaletUcretiFaizi: null, mahkemeYargilamaGiderleri: null, mahkemeYargilamaGiderleriFaizi: null, mahkemeHarclari: null, mahkemeHarclariFaizi: null };
      }
      const xmlBytes = files[contentKey];
      const xmlText = new TextDecoder("utf-8", { fatal: false }).decode(xmlBytes);
      return extractTakipTalebiAmountsFromContentXml(xmlText);
    } catch {
      return { asilAlacak: null, gecmisGunFaizi: null, aracMahrumiyetBedeli: null, aracMahrumiyetFaizi: null, mahkemeVekaletUcreti: null, mahkemeVekaletUcretiFaizi: null, mahkemeYargilamaGiderleri: null, mahkemeYargilamaGiderleriFaizi: null, mahkemeHarclari: null, mahkemeHarclariFaizi: null };
    }
  };

  const extractTakipTalebiAmountsFromPdfBytes = async (bytes) => {
    const texts = await collectPdfTextCandidates(bytes);
    let bestParsed = null;
    let bestScore = -1;

    for (const rawText of texts) {
      const parsed = extractTakipTalebiAmountsFromText(rawText);
      const score = getTakipParseQualityScore(parsed);
      if (score > bestScore) {
        bestParsed = parsed;
        bestScore = score;
      }
      if (score >= 10) {
        break;
      }
    }

    return bestParsed || { asilAlacak: null, gecmisGunFaizi: null };
  };

  const extractKisiFromAciklama = (aciklama) => {
    const raw = fixMojibake(aciklama).trim();
    if (!raw) {
      return "";
    }
    const m = raw.match(/\[([^\]]+)\]/);
    const inside = (m && m[1] ? m[1] : raw).trim();
    return inside
      .replace(/^BORÇLU VE MÜFLİS\s*/i, "")
      .replace(/^BORCLU VE MUFLIS\s*/i, "")
      .trim();
  };

  const normalizeNameKey = (value) =>
    normalizeText(value)
      .replace(/[^a-z0-9\s]/g, " ")
      .replace(/\s+/g, " ")
      .trim();

  const cleanupKisiName = (value) => {
    let s = fixMojibake(value || "");
    s = s.replace(/\bve\s+di[ğg]erleri\b.*$/i, "");
    s = s.replace(/\bvekili\b.*$/i, "");
    s = s.replace(/\bav\.\b.*$/i, "");
    s = s.replace(/\bavukat\b.*$/i, "");
    s = s.replace(/\s+/g, " ").trim();
    return s;
  };

  const pickBestKisiName = (candidates, fallback) => {
    const cleanCandidates = (Array.isArray(candidates) ? candidates : [])
      .map((x) => cleanupKisiName(x))
      .filter((x) => !!x);
    const fb = cleanupKisiName(fallback || "");
    if (cleanCandidates.length === 0) {
      return fb;
    }
    if (!fb) {
      return cleanCandidates[0];
    }

    const fbKey = normalizeNameKey(fb);
    let best = cleanCandidates[0];
    let bestScore = -1;

    for (const c of cleanCandidates) {
      const ck = normalizeNameKey(c);
      let score = 0;
      if (ck === fbKey) {
        score += 100;
      }
      if (ck && fbKey && (ck.includes(fbKey) || fbKey.includes(ck))) {
        score += 50;
      }
      const fbTokens = new Set(fbKey.split(" ").filter(Boolean));
      const cTokens = ck.split(" ").filter(Boolean);
      for (const t of cTokens) {
        if (fbTokens.has(t)) {
          score += 5;
        }
      }
      if (score > bestScore) {
        bestScore = score;
        best = c;
      }
    }

    return best || fb;
  };

  const countBorcaItirazBefore = (evraklarFromTum, cutoffMsUtc) => {
    if (!Array.isArray(evraklarFromTum) || !Number.isFinite(cutoffMsUtc) || cutoffMsUtc <= 0) {
      return 0;
    }
    const unique = dedupeByEvrakId(evraklarFromTum);
    let count = 0;
    for (const evrak of unique) {
      const tur = normalizeText(evrak && evrak.tur);
      if (!tur.includes("borca itiraz talebi")) {
        continue;
      }
      const tarih = String((evrak && evrak.sistemeGonderildigiTarih) || "").trim();
      const t = parseTrDateToTime(tarih);
      if (t > 0 && t <= cutoffMsUtc) {
        count += 1;
      }
    }
    return count;
  };

  const getEvrakDateMs = (evrak) => {
    if (!evrak || typeof evrak !== "object") {
      return 0;
    }
    const candidates = [
      String(evrak.onaylandigiTarih || "").trim(),
      String(evrak.sistemeGonderildigiTarih || "").trim()
    ].filter(Boolean);
    for (const tarih of candidates) {
      const ms = parseTrDateToTime(tarih);
      if (ms > 0) {
        return ms;
      }
    }
    return 0;
  };

  const shouldTreatAsIlamliByItirazSonrasiOdemeEmri = (evraklarFromTum) => {
    const rows = Array.isArray(evraklarFromTum) ? evraklarFromTum : [];
    let latestItirazMs = 0;
    let latestOdemeIcraEmriMs = 0;

    for (const evrak of rows) {
      const tur = normalizeText(evrak && evrak.tur);
      if (!tur) {
        continue;
      }
      const ms = getEvrakDateMs(evrak);
      if (ms <= 0) {
        continue;
      }
      if (tur.includes("borca itiraz talebi") && ms > latestItirazMs) {
        latestItirazMs = ms;
      }
      if (tur.includes("odeme icra emri") && ms > latestOdemeIcraEmriMs) {
        latestOdemeIcraEmriMs = ms;
      }
    }

    return {
      value: latestItirazMs > 0 && latestOdemeIcraEmriMs > latestItirazMs,
      latestItirazMs,
      latestOdemeIcraEmriMs
    };
  };

  const extractBarcodeFromText = (text, depth = 0) => {
    const raw = String(text || "");
    const candidates = [];
    const seen = new Set();

    
    const pickFromChunk = (chunk) => {
      const onlyDigits = String(chunk || "").replace(/\D+/g, "");
      if (onlyDigits.length === 13 && !onlyDigits.startsWith("0")) {
        return onlyDigits;
      }
      return null;
    };
    const addCandidate = (value, score) => {
      const v = String(value || "");
      if (!v || seen.has(v)) {
        return;
      }
      seen.add(v);
      candidates.push({ value: v, score: Number(score) || 0 });
    };

    
    const exactStarRe = /\*(\d{13})\*/g;
    let m;
    while ((m = exactStarRe.exec(raw)) !== null) {
      addCandidate(m[1], 100);
    }

    
    const starChunkRe = /\*([^*\r\n]{1,200})\*/g;
    while ((m = starChunkRe.exec(raw)) !== null) {
      const picked = pickFromChunk(m[1]);
      if (picked) {
        addCandidate(picked, 90);
      }
    }

    
    const taahhutluRe = /taahh[uü]tl[uü][\s\S]{0,180}/gi;
    while ((m = taahhutluRe.exec(raw)) !== null) {
      const local = m[0];
      const localSeqRe = /(\d(?:[^\d]{0,4}\d){12})/g;
      let lm;
      while ((lm = localSeqRe.exec(local)) !== null) {
        const picked = pickFromChunk(lm[1]);
        if (picked) {
          addCandidate(picked, 80);
        }
      }
    }

    
    const ornekNoRe = /[oö]rnek\s*no[\s\S]{0,220}/gi;
    while ((m = ornekNoRe.exec(raw)) !== null) {
      const local = m[0];
      const localStarRe = /\*([^*\r\n]{1,200})\*/g;
      let lm;
      while ((lm = localStarRe.exec(local)) !== null) {
        const picked = pickFromChunk(lm[1]);
        if (picked) {
          addCandidate(picked, 95);
        }
      }

      const localSeqRe = /(\d(?:[^\d]{0,4}\d){12})/g;
      while ((lm = localSeqRe.exec(local)) !== null) {
        const picked = pickFromChunk(lm[1]);
        if (picked) {
          addCandidate(picked, 85);
        }
      }
    }

    
    

    
    if (depth < 2) {
      const hexChunkRe = /<([0-9a-fA-F\s]{24,800})>/g;
      while ((m = hexChunkRe.exec(raw)) !== null) {
        const hex = String(m[1] || "").replace(/[^0-9a-fA-F]/g, "");
        if (hex.length < 26 || hex.length % 2 !== 0) {
          continue;
        }

        const bytes = new Uint8Array(hex.length / 2);
        for (let i = 0; i < bytes.length; i += 1) {
          const part = hex.slice(i * 2, i * 2 + 2);
          bytes[i] = Number.parseInt(part, 16);
        }

        
        let utf16beText = "";
        if (bytes.length % 2 === 0) {
          for (let i = 0; i < bytes.length; i += 2) {
            utf16beText += String.fromCharCode((bytes[i] << 8) | bytes[i + 1]);
          }
        }
      const utf16Match = extractBarcodeFromText(utf16beText, depth + 1);
      if (utf16Match) {
        addCandidate(utf16Match, 70);
      }

        
        const singleByteText = new TextDecoder("latin1").decode(bytes);
      const singleByteMatch = extractBarcodeFromText(singleByteText, depth + 1);
      if (singleByteMatch) {
        addCandidate(singleByteMatch, 60);
      }
      }
    }

    if (candidates.length === 0) {
      return null;
    }

    candidates.sort((a, b) => b.score - a.score);
    return candidates[0].value;
  };

  const tryExtractWithPdfJs = async (bytes) => {
    try {
      const lib = await ensurePdfJsLib();
      if (!lib || typeof lib.getDocument !== "function") {
        return null;
      }

      const task = lib.getDocument({ data: bytes });
      const pdf = await task.promise;
      try {
        for (let i = 1; i <= pdf.numPages; i += 1) {
          const page = await pdf.getPage(i);
          const textContent = await page.getTextContent();
          const joined = (textContent.items || []).map((x) => String(x.str || "")).join(" ");
          const found = extractBarcodeFromText(joined);
          if (found) {
            return found;
          }
        }
      } finally {
        if (pdf && typeof pdf.destroy === "function") {
          pdf.destroy();
        }
      }
    } catch {
      
    }
    return null;
  };

  const indexOfBytes = (haystack, needle, fromIndex) => {
    if (!haystack || !needle || needle.length === 0) {
      return -1;
    }
    outer: for (let i = Math.max(0, fromIndex || 0); i <= haystack.length - needle.length; i += 1) {
      for (let j = 0; j < needle.length; j += 1) {
        if (haystack[i + j] !== needle[j]) {
          continue outer;
        }
      }
      return i;
    }
    return -1;
  };

  const collectPdfStreams = (bytes) => {
    const streamWord = new Uint8Array([115, 116, 114, 101, 97, 109]); 
    const endWord = new Uint8Array([101, 110, 100, 115, 116, 114, 101, 97, 109]); 
    const streams = [];
    let cursor = 0;

    while (cursor < bytes.length) {
      const streamAt = indexOfBytes(bytes, streamWord, cursor);
      if (streamAt < 0) {
        break;
      }

      let dataStart = streamAt + streamWord.length;
      if (bytes[dataStart] === 13 && bytes[dataStart + 1] === 10) {
        dataStart += 2;
      } else if (bytes[dataStart] === 10 || bytes[dataStart] === 13) {
        dataStart += 1;
      }

      const endAt = indexOfBytes(bytes, endWord, dataStart);
      if (endAt < 0) {
        break;
      }

      if (endAt > dataStart) {
        streams.push(bytes.slice(dataStart, endAt));
      }

      cursor = endAt + endWord.length;
    }

    return streams;
  };

  const tryDecompressDeflate = async (bytes) => {
    const formats = ["deflate", "deflate-raw"];

    for (const format of formats) {
      try {
        if (typeof DecompressionStream === "undefined") {
          throw new Error("DecompressionStream unavailable");
        }
        const ds = new DecompressionStream(format);
        const decompressed = await new Response(new Blob([bytes]).stream().pipeThrough(ds)).arrayBuffer();
        return new Uint8Array(decompressed);
      } catch {
        
      }
    }

    
    try {
      const fflate = window.fflate;
      if (fflate && typeof fflate.decompressSync === "function") {
        return fflate.decompressSync(bytes);
      }
    } catch {
      
    }

    return null;
  };

  const collectPdfTextCandidates = async (bytes) => {
    const out = [];
    const pushText = (t) => {
      const s = String(t || "");
      if (!s || s.length < 20) {
        return;
      }
      out.push(fixMojibake(s));
    };

    if (!(bytes instanceof Uint8Array) || bytes.length === 0) {
      return out;
    }

    pushText(new TextDecoder("latin1").decode(bytes));
    pushText(new TextDecoder("utf-8", { fatal: false }).decode(bytes));

    const streams = collectPdfStreams(bytes);
    for (const stream of streams) {
      pushText(new TextDecoder("latin1").decode(stream));
      const inflated = await tryDecompressDeflate(stream);
      if (inflated) {
        pushText(new TextDecoder("latin1").decode(inflated));
      }
    }

    try {
      const lib = await ensurePdfJsLib();
      if (lib && typeof lib.getDocument === "function") {
        const task = lib.getDocument({ data: bytes });
        const pdf = await task.promise;
        try {
          const parts = [];
          for (let i = 1; i <= pdf.numPages; i += 1) {
            const page = await pdf.getPage(i);
            const tc = await page.getTextContent();
            parts.push((tc.items || []).map((x) => String(x.str || "")).join(" "));
          }
          pushText(parts.join("\n"));
        } finally {
          if (pdf && typeof pdf.destroy === "function") {
            pdf.destroy();
          }
        }
      }
    } catch {
      
    }

    return out;
  };

  const pdfContainsOdemeIcraEmri = async (bytes) => {
    const texts = await collectPdfTextCandidates(bytes);
    return texts.some((t) => {
      const normalized = normalizeText(t).replace(/\s+/g, " ").trim();
      if (!normalized) {
        return false;
      }
      
      // "BU ZARFTA Ödeme İcra Emri VARDIR."
      // "BU ZARFTA Ödeme İcra Emri Takibin Dayanagi Belge VARDIR."
      
      return /\bodeme\s+icra\s+emri\b/.test(normalized);
    });
  };
  const extractBarcodeFromPdfBytes = async (bytes) => {
    if (!(bytes instanceof Uint8Array) || bytes.length === 0) {
      return null;
    }

    const latin1 = new TextDecoder("latin1").decode(bytes);
    const direct = extractBarcodeFromText(latin1);
    if (direct) {
      return direct;
    }

    const utf8 = new TextDecoder("utf-8", { fatal: false }).decode(bytes);
    const utf8Match = extractBarcodeFromText(utf8);
    if (utf8Match) {
      return utf8Match;
    }

    const streams = collectPdfStreams(bytes);
    for (const stream of streams) {
      const rawText = new TextDecoder("latin1").decode(stream);
      const rawMatch = extractBarcodeFromText(rawText);
      if (rawMatch) {
        return rawMatch;
      }

      const inflated = await tryDecompressDeflate(stream);
      if (!inflated) {
        continue;
      }

      const inflatedText = new TextDecoder("latin1").decode(inflated);
      const inflatedMatch = extractBarcodeFromText(inflatedText);
      if (inflatedMatch) {
        return inflatedMatch;
      }
    }

    const pdfJsMatch = await tryExtractWithPdfJs(bytes);
    if (pdfJsMatch) {
      return pdfJsMatch;
    }

    const textCandidates = await collectPdfTextCandidates(bytes);
    for (const candidateText of textCandidates) {
      const found = extractBarcodeFromText(candidateText);
      if (found) {
        return found;
      }
    }

    return null;
  };

  const extractETebligInfoFromPdfBytes = async (bytes, fallbackKisi) => {
    if (!(bytes instanceof Uint8Array) || bytes.length === 0) {
      return null;
    }

    const textCandidates = [];
    const pushText = (t) => {
      const s = String(t || "");
      if (!s || s.length < 20) {
        return;
      }
      textCandidates.push(fixMojibake(s));
    };

    pushText(new TextDecoder("latin1").decode(bytes));
    pushText(new TextDecoder("utf-8", { fatal: false }).decode(bytes));

    const streams = collectPdfStreams(bytes);
    for (const stream of streams) {
      pushText(new TextDecoder("latin1").decode(stream));
      const inflated = await tryDecompressDeflate(stream);
      if (inflated) {
        pushText(new TextDecoder("latin1").decode(inflated));
      }
    }

    const pdfJsText = await (async () => {
      try {
        const lib = await ensurePdfJsLib();
        if (!lib || typeof lib.getDocument !== "function") {
          return "";
        }
        const task = lib.getDocument({ data: bytes });
        const pdf = await task.promise;
        try {
          const parts = [];
          for (let i = 1; i <= pdf.numPages; i += 1) {
            const page = await pdf.getPage(i);
            const tc = await page.getTextContent();
            parts.push((tc.items || []).map((x) => String(x.str || "")).join(" "));
          }
          return parts.join("\n");
        } finally {
          if (pdf && typeof pdf.destroy === "function") {
            pdf.destroy();
          }
        }
      } catch {
        return "";
      }
    })();
    pushText(pdfJsText);

    const foundKisiCandidates = [];
    let bestDateMs = 0;
    let bestDateStr = null;

    for (const raw of textCandidates) {
      const text = raw.replace(/\s+/g, " ");
      const nameLine = text.match(/Ad[ıi]\s*ve\s*Soyad[ıi]\s*:\s*([^)\n\r]{2,220})/i);
      const name1 = text.match(/UETS\s+Hesap\s+Sahibi:\s*([^)]+?)(?:\)|$)/i);
      const name2 = text.match(/Bor[çc]lu\s+([^)]+?)(?:\)|$)/i);
      const extracted = [
        nameLine && nameLine[1] ? nameLine[1] : "",
        name1 && name1[1] ? name1[1] : "",
        name2 && name2[1] ? name2[1] : ""
      ].filter(Boolean);
      for (const n of extracted) {
        foundKisiCandidates.push(n);
      }

      const dateRegex = /(\d{2})\/(\d{2})\/(\d{4})(?:\s+(\d{2}):(\d{2})(?::(\d{2}))?)?/g;
      let m;
      while ((m = dateRegex.exec(text)) !== null) {
        const day = Number(m[1]);
        const month = Number(m[2]);
        const year = Number(m[3]);
        const hour = Number(m[4] || "0");
        const minute = Number(m[5] || "0");
        const second = Number(m[6] || "0");
        if (!Number.isFinite(day) || !Number.isFinite(month) || !Number.isFinite(year)) {
          continue;
        }
        if (year < 2000 || year > 2100 || month < 1 || month > 12 || day < 1 || day > 31) {
          continue;
        }
        const ms = Date.UTC(year, month - 1, day, hour, minute, second);
        if (ms > bestDateMs) {
          bestDateMs = ms;
          bestDateStr = `${String(day).padStart(2, "0")}/${String(month).padStart(2, "0")}/${year}`;
        }
      }
    }

    if (!bestDateStr) {
      return null;
    }

    const kisi = pickBestKisiName(foundKisiCandidates, fallbackKisi);
    return {
      kisi: fixMojibake(kisi),
      tebligTarihi: bestDateStr
    };
  };

  window.__EWR_PR_Extract = {
    extractTebligDateFromPtt,
    extractTebligDateFromPttApi,
    toTrDateFromCompact,
    collectEvrakItems,
    collectTumEvraklarItems,
    dedupeByEvrakId,
    isBarcodeEvrak,
    selectBarcodeCandidates,
    extractLatestTakipTalebiDate,
    hasAvukatPortalHacizTalebi,
    estimateDosyaKesinlesmeInfoFromEvrakList,
    selectTakipTalebiCandidates,
    selectOdemeIcraEmriCandidates,
    selectVekaletPuluCandidates,
    extractTakipTalebiAmountsFromText,
    normalizePersonKey,
    extractNamesFromBracketText,
    collectAlacakliNameKeys,
    collectBorcluHeaderCandidates,
    pickBorcluHeaderValue,
    matchIslemYapanToAlacakli,
    extractIslemYapanFromVekaletHtml,
    extractVekaletPuluInfoFromHtmlText,
    extractVekaletPuluFromHtmlText,
    normalizeDosyaNo,
    extractDosyaMasrafBilgileri,
    extractReddiyatKalanMiktari,
    extractReddiyatTahsilatKalemleri,
    tryDecodeBase64ToBytes,
    unwrapPdfLikeBytes,
    decodeEscapedTextVariants,
    extractInnerDocumentUrls,
    unzipFromLocalHeaders,
    buildCustomFaizKey,
    fixMojibakeMultiline,
    parseStructuredEntriesFromXml,
    parseFieldEntriesFromXml,
    extractCdataText,
    isTakipUcuncuMaddeHeader,
    isTakipDorduncuMaddeHeader,
    extractNarrativeSection,
    parseNarrativeEntriesFromXml,
    classifyTakipEntry,
    aggregateTakipEntries,
    extractNarrativeSectionFromPlainText,
    parseNarrativeEntriesFromPlainText,
    extractTakipTalebiAmountsFromContentXml,
    getTakipParseQualityScore,
    extractTakipTalebiAmountsFromUdfBytes,
    extractTakipTalebiAmountsFromPdfBytes,
    extractKisiFromAciklama,
    normalizeNameKey,
    cleanupKisiName,
    pickBestKisiName,
    countBorcaItirazBefore,
    getEvrakDateMs,
    shouldTreatAsIlamliByItirazSonrasiOdemeEmri,
    extractBarcodeFromText,
    tryExtractWithPdfJs,
    indexOfBytes,
    collectPdfStreams,
    tryDecompressDeflate,
    collectPdfTextCandidates,
    pdfContainsOdemeIcraEmri,
    extractBarcodeFromPdfBytes,
    extractETebligInfoFromPdfBytes
  };
})();

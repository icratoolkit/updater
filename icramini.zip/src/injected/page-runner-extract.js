(() => {
  const parts = [
    window.__EWR_PR_ExtractEvrak,
    window.__EWR_PR_ExtractTaraf,
    window.__EWR_PR_ExtractTahsilat,
    window.__EWR_PR_ExtractBinary,
    window.__EWR_PR_ExtractPdf,
    window.__EWR_PR_ExtractTakipTalebi
  ];

  const missing = parts.some((part) => !part);
  if (missing) {
    console.error("page-runner-extract.js: extract/ modüllerinin tamamı yüklenmeden birleştirilemez.");
    return;
  }

  window.__EWR_PR_Extract = Object.assign({}, ...parts);
})();

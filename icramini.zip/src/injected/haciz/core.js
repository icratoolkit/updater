(() => {
  "use strict";

  if (window.__EWR_PR_HacizCore) {
    return;
  }

  // ─── Shared helpers from page-runner-core ──────────────────────────────
  const getCore = () => window.__EWR_PR_Core || {};

  const runRequest = (...a) =>
    getCore().runRequest ? getCore().runRequest(...a) : Promise.reject(new Error("Core y\u00fcklenmedi."));
  const parseInput = (...a) => {
    const fn = getCore().parseInput;
    if (!fn) {
      throw new Error("Core y\u00fcklenmedi.");
    }
    return fn(...a);
  };
  const applyTemplate = (...a) => (getCore().applyTemplate ? getCore().applyTemplate(...a) : String(a[0] || ""));
  const applyJsonBodyTemplate = (...a) =>
    getCore().applyJsonBodyTemplate ? getCore().applyJsonBodyTemplate(...a) : String(a[0] || "");
  const parseHeaders = (...a) => (getCore().parseHeaders ? getCore().parseHeaders(...a) : {});
  const toAbsoluteUrl = (...a) => (getCore().toAbsoluteUrl ? getCore().toAbsoluteUrl(...a) : String(a[0] || ""));
  const normalizeJsonBodyValue = (...a) =>
    getCore().normalizeJsonBodyValue ? getCore().normalizeJsonBodyValue(...a) : String(a[0] || "");
  const findByKeyDeep = (...a) => (getCore().findByKeyDeep ? getCore().findByKeyDeep(...a) : undefined);

  // ─── Run state ─────────────────────────────────────────────────────────
  const hacizRunState = {
    isRunning: false,
    stopRequested: false,
    activeRequestController: null,
    pendingTakbisControllers: new Set(),
    pendingTakbisCount: 0,
    activeQueryLabel: "",
    activeQueryDosyaNo: "",
    activeQueryKisi: "",
    activeQueryStartedAt: 0
  };

  const setHacizActiveQuery = (label, dosyaNo = "", kisi = "") => {
    hacizRunState.activeQueryLabel = String(label || "");
    hacizRunState.activeQueryDosyaNo = String(dosyaNo || "");
    hacizRunState.activeQueryKisi = String(kisi || "");
    hacizRunState.activeQueryStartedAt = Date.now();
  };

  const clearHacizActiveQuery = () => {
    hacizRunState.activeQueryLabel = "";
    hacizRunState.activeQueryDosyaNo = "";
    hacizRunState.activeQueryKisi = "";
    hacizRunState.activeQueryStartedAt = 0;
  };

  const setPendingTakbisCount = (count) => {
    hacizRunState.pendingTakbisCount = Math.max(0, Number(count) || 0);
  };

  const parseJsonSafe = (text) => {
    try {
      return JSON.parse(text);
    } catch {
      return null;
    }
  };

  // ─── Helpers ───────────────────────────────────────────────────────────

  // ─── Bank name matching ────────────────────────────────────────────────
  const BANK_SUFFIXES =
    /\s*(T\u00dcRK ANON\u0130M \u015e\u0130RKET\u0130|ANON\u0130M \u015e\u0130RKET\u0130|T\.A\.\u015e\.|A\.\u015e\.|T\.A\.O\.|T\u00dcRK ANON\u0130M ORTAKLI\u011eI|GENEL M\u00dcD\u00dcRL\u00dc\u011e\u00dc)\s*/gi;
  const BANK_PREFIXES = /\s*(T\u00dcRK\u0130YE CUMHUR\u0130YET\u0130|T\.C\.)\s*/gi;
  const normalizeBank = (s) =>
    String(s || "")
      .toUpperCase()
      .replace(BANK_SUFFIXES, "")
      .replace(BANK_PREFIXES, " ")
      .replace(/\s+/g, " ")
      .trim();

  const buildBankMap = (bankParams) => {
    if (!Array.isArray(bankParams) || bankParams.length === 0) {
      return { exactMap: new Map(), entries: [] };
    }
    const exactMap = new Map();
    const entries = [];
    for (const bp of bankParams) {
      const key = normalizeBank(bp.ilgili);
      if (key) {
        exactMap.set(key, bp);
        entries.push({ key, bp });
      }
    }
    return { exactMap, entries };
  };

  const matchBankFromMap = (bankaAdi, bankMap) => {
    if (!bankMap) {
      return null;
    }
    const key = normalizeBank(bankaAdi);
    if (!key) {
      return null;
    }
    const exact = bankMap.exactMap.get(key);
    if (exact) {
      return exact;
    }
    for (const { key: bpKey, bp } of bankMap.entries) {
      if (bpKey.startsWith(key) || key.startsWith(bpKey)) {
        return bp;
      }
    }
    return null;
  };

  /**
   * borçlu nesnesinden ad bilgisini çıkarır (kişi veya kurum).
   */
  const getBorcluAdi = (borclu) => {
    if (borclu && borclu.kisi) {
      return String(borclu.kisi).trim();
    }
    const kisi = borclu.kisiTumDVO || {};
    const ad = [kisi.adi, kisi.soyadi].filter(Boolean).join(" ");
    if (ad) {
      return ad;
    }
    const kurum = borclu.kurumDVO || {};
    if (kurum.kurumAdi) {
      return String(kurum.kurumAdi).trim();
    }
    return "Bilinmeyen";
  };

  /**
   * borçlu listesinden X-Borclu header değerini oluşturur.
   * Format: "{adi} {soyadi} - {tcKimlikNo}" veya "{kurumAdi} - {vergiNo}"
   */
  const buildBorcluHeaderValue = (borclu) => {
    if (!borclu) {
      return "undefined";
    }
    if (borclu.borcluHeaderValue) {
      return String(borclu.borcluHeaderValue);
    }
    const kisi = borclu.kisiTumDVO || {};
    const adi = String(kisi.adi || "").trim();
    const soyadi = String(kisi.soyadi || "").trim();
    const tc = String(kisi.tcKimlikNo || "").trim();
    if (adi || soyadi) {
      const name = [adi, soyadi].filter(Boolean).join(" ");
      return tc ? `${name} - ${tc}` : name;
    }
    const kurum = borclu.kurumDVO || {};
    if (kurum.kurumAdi) {
      const vergi = String(kurum.vergiNo || "").trim();
      return vergi ? `${kurum.kurumAdi} - ${vergi}` : String(kurum.kurumAdi);
    }
    return "undefined";
  };

  // Sorgular dış sistemlere gidiyor (EGM, banka, TAKBİS); dördü de aynı süreyi kullanır.
  const HACIZ_QUERY_TIMEOUT_MS = 60 * 1000;

  // Zaman aşımı 'sorgu başarısız' demek değil, dış sistemde hâlâ sürüyor olabilir
  // (hata kodları bu yüzden ..._TIMEOUT_PENDING). Hemen tekrar sormak UYAP kotasına
  // takılma riski doğurur: PRTL_GNL_1-1 = 'Bu işlem 60 dakikada 1 defa yapılabilir'.
  const HACIZ_QUERY_COOLDOWN_MS = 3 * 60 * 1000;

  const getModeMeta = (mode) => ({
    doneKey: mode === "icraDosyasi" ? "icraDosyasiQueryDone" : `${mode}QueryDone`,
    errorKey:
      mode === "arac"
        ? "aracError"
        : mode === "banka"
          ? "bankaError"
          : mode === "takbis"
            ? "takbisError"
            : "icraDosyasiError",
    cooldownKey: mode === "icraDosyasi" ? "icraDosyasiCooldownUntil" : `${mode}CooldownUntil`
  });

  const getModeCooldownUntil = (mode, borclu) => {
    const meta = getModeMeta(mode);
    const value = Number(borclu && borclu[meta.cooldownKey]);
    return Number.isFinite(value) ? value : 0;
  };

  // PRTL_AVKT_10104 = takip kesinleşmemiş. Kalıcı durum, tekrar denemenin anlamı yok.
  const isRetryableQueryError = (errorCode) => !!errorCode && String(errorCode) !== "PRTL_AVKT_10104";

  const shouldReuseCachedMode = (mode, borclu) => {
    const meta = getModeMeta(mode);
    if (getModeCooldownUntil(mode, borclu) > Date.now()) {
      return true;
    }
    if (borclu && borclu[meta.doneKey] === true) {
      const error =
        mode === "arac"
          ? borclu.aracError
          : mode === "banka"
            ? borclu.bankaError
            : mode === "takbis"
              ? borclu.takbisError
              : borclu.icraDosyasiError;
      return !isRetryableQueryError(error && error.code);
    }
    return false;
  };

  const TIMEOUT_SECONDS = Math.round(HACIZ_QUERY_TIMEOUT_MS / 1000);
  const COOLDOWN_MINUTES = Math.round(HACIZ_QUERY_COOLDOWN_MS / 60000);

  // Metinler sabitlerden türetilir ki süre değişince mesaj da değişsin.
  const buildQueryMessages = (label, codePrefix) => ({
    emptyResponseErrorCode: `${codePrefix}_EMPTY_RESPONSE`,
    emptyResponseErrorMessage: `${label} sorgusunda servis boş yanıt döndü.`,
    timeoutErrorCode: `${codePrefix}_TIMEOUT_PENDING`,
    timeoutErrorMessage:
      `${label} sorgusunda ${TIMEOUT_SECONDS} saniye içinde yanıt gelmedi. ` +
      `Aynı sorgu ${COOLDOWN_MINUTES} dakika boyunca otomatik yeniden denenmeyecek.`
  });

  const runHacizQueryRequest = async (url, headers, body, { label, codePrefix }) => {
    const { emptyResponseErrorCode, emptyResponseErrorMessage, timeoutErrorCode, timeoutErrorMessage } =
      buildQueryMessages(label, codePrefix);
    const timeoutMs = HACIZ_QUERY_TIMEOUT_MS;

    if (hacizRunState.stopRequested) {
      throw new Error("STOP_REQUESTED");
    }

    const controller = new AbortController();
    hacizRunState.activeRequestController = controller;
    let didTimeout = false;
    const timer =
      timeoutMs > 0
        ? setTimeout(() => {
            didTimeout = true;
            controller.abort();
          }, timeoutMs)
        : null;

    try {
      const response = await fetch(url, {
        method: "POST",
        headers,
        body,
        credentials: "include",
        signal: controller.signal
      });
      const text = await response.text();
      const res = {
        ok: response.ok,
        status: response.status,
        text,
        json: parseJsonSafe(text)
      };
      const hasBody = typeof text === "string" && text.trim().length > 0;
      if (!hasBody) {
        return {
          response: res,
          emptyResponseExhausted: true,
          emptyResponseErrorCode,
          emptyResponseErrorMessage,
          timedOut: false,
          cooldownUntil: 0
        };
      }
      return {
        response: res,
        emptyResponseExhausted: false,
        timedOut: false,
        cooldownUntil: 0
      };
    } catch (error) {
      if (hacizRunState.stopRequested) {
        throw new Error("STOP_REQUESTED");
      }
      if (error && error.name === "AbortError" && didTimeout) {
        return {
          response: { ok: false, status: 0, text: null, json: null, error: "REQUEST_TIMEOUT", timeout: true },
          emptyResponseExhausted: false,
          timedOut: true,
          timeoutErrorCode,
          timeoutErrorMessage,
          cooldownUntil: Date.now() + HACIZ_QUERY_COOLDOWN_MS
        };
      }
      throw error;
    } finally {
      if (timer) {
        clearTimeout(timer);
      }
      if (hacizRunState.activeRequestController === controller) {
        hacizRunState.activeRequestController = null;
      }
    }
  };

  window.__EWR_PR_HacizCore = {
    HACIZ_QUERY_COOLDOWN_MS,
    HACIZ_QUERY_TIMEOUT_MS,
    applyJsonBodyTemplate,
    applyTemplate,
    buildBankMap,
    buildBorcluHeaderValue,
    clearHacizActiveQuery,
    findByKeyDeep,
    getBorcluAdi,
    hacizRunState,
    matchBankFromMap,
    normalizeJsonBodyValue,
    parseHeaders,
    parseInput,
    parseJsonSafe,
    runHacizQueryRequest,
    runRequest,
    setHacizActiveQuery,
    setPendingTakbisCount,
    shouldReuseCachedMode,
    toAbsoluteUrl
  };
})();

(() => {
  "use strict";

  if (window.__EWR_HACIZ_LOADED__) {
    return;
  }
  window.__EWR_HACIZ_LOADED__ = true;

  const Core = window.__EWR_PR_HacizCore;
  const Sorgu = window.__EWR_PR_HacizSorgu;
  const Talep = window.__EWR_PR_HacizTalep;
  if (!Core || !Sorgu || !Talep) {
    console.error("page-runner-haciz.js: haciz/core.js, haciz/sorgu.js ve haciz/talep.js önce yüklenmeli.");
    return;
  }

  const { clearHacizActiveQuery, hacizRunState, setHacizActiveQuery, setPendingTakbisCount } = Core;
  const { processOneDosyaHaciz, refreshCachedDosyaHaciz } = Sorgu;
  const { getLimitedHacizCount, isTalepImzaErrorMessage, sendTalepForBorclu } = Talep;

  // ─── Ana workflow ──────────────────────────────────────────────────────
  const runHacizWorkflow = async (requestId, settings, inputs) => {
    if (hacizRunState.isRunning) {
      window.postMessage({ __EWR_PAGE__: true, requestId, ok: false, error: "İşlem zaten çalışıyor." }, "*");
      return;
    }
    hacizRunState.isRunning = true;
    hacizRunState.stopRequested = false;
    setPendingTakbisCount(0);

    const total = inputs.length;
    const items = [];
    let processed = 0;

    try {
      for (const input of inputs) {
        if (hacizRunState.stopRequested) {
          break;
        }

        let result;
        try {
          result = await processOneDosyaHaciz(settings, input, {
            setActiveQuery: (label, dosyaNo, kisi) => {
              setHacizActiveQuery(label, dosyaNo, kisi);
              emitHacizProgress(requestId, total, items, false);
            },
            clearActiveQuery: () => {
              clearHacizActiveQuery();
              emitHacizProgress(requestId, total, items, false);
            },
            notifyProgress: () => {
              emitHacizProgress(requestId, total, items, false);
            }
          });
        } catch (err) {
          result = {
            runMode: "haciz",
            input: typeof input === "object" ? input.dosyaNo || "" : String(input || ""),
            success: false,
            error: String(err && err.message ? err.message : err),
            borclular: []
          };
        }

        items.push(result);
        processed += 1;

        emitHacizProgress(requestId, total, items, hacizRunState.stopRequested);
      }
    } finally {
      hacizRunState.isRunning = false;
      hacizRunState.stopRequested = false;
      clearHacizActiveQuery();
      setPendingTakbisCount(0);
    }

    const stopped = processed < total;
    emitHacizProgress(requestId, total, items, stopped);

    window.postMessage(
      {
        __EWR_PAGE__: true,
        requestId,
        ok: true,
        result: {
          runMode: "haciz",
          total,
          processed,
          matchCount: items.filter((x) => x.isMatch).length,
          stopped,
          items
        }
      },
      "*"
    );
  };

  const emitHacizProgress = (requestId, total, items, stopped = false) => {
    const hasErrorOrMatch = (x) =>
      x.isMatch ||
      (Array.isArray(x.borclular) &&
        x.borclular.some((b) => b.errorCode || b.aracError || b.bankaError || b.takbisError || b.icraDosyasiError));
    const relevant = items.filter(hasErrorOrMatch).map((x) => ({
      input: x.input,
      borclular: x.borclular
    }));

    window.postMessage(
      {
        __EWR_HACIZ_PROGRESS__: true,
        requestId,
        progress: {
          runMode: "haciz",
          total,
          processed: items.length,
          matchCount: items.filter((x) => x.isMatch).length,
          matched: relevant,
          stopped,
          activeQueryLabel: hacizRunState.activeQueryLabel,
          activeQueryDosyaNo: hacizRunState.activeQueryDosyaNo,
          activeQueryKisi: hacizRunState.activeQueryKisi,
          activeQueryStartedAt: hacizRunState.activeQueryStartedAt,
          pendingTakbisCount: hacizRunState.pendingTakbisCount
        }
      },
      "*"
    );
  };

  const runHacizTalepWorkflow = async (requestId, settings, items, bankaHacizData) => {
    if (hacizRunState.isRunning) {
      window.postMessage({ __EWR_PAGE__: true, requestId, ok: false, error: "İşlem zaten çalışıyor." }, "*");
      return;
    }
    hacizRunState.isRunning = true;
    hacizRunState.stopRequested = false;

    const modes = Array.isArray(settings.hacizModes) ? settings.hacizModes : ["arac"];
    const results = [];
    let totalBorclu = 0;
    let processed = 0;
    let successCount = 0;

    for (const item of items) {
      if (item.success && item.dosyaId && Array.isArray(item.borclular)) {
        totalBorclu += item.borclular.filter((b) => {
          const hasA = modes.includes("arac") && Array.isArray(b.aracList) && b.aracList.length > 0;
          const hasB =
            modes.includes("banka") &&
            Array.isArray(b.bankaList) &&
            b.bankaList.filter((bk) => bk.matchedId).length > 0;
          const hasT = modes.includes("takbis") && Array.isArray(b.takbisList) && b.takbisList.length > 0;
          const hasI =
            modes.includes("icraDosyasi") && Array.isArray(b.icraDosyasiList) && b.icraDosyasiList.length > 0;
          return hasA || hasB || hasT || hasI;
        }).length;
      }
    }

    const emitTalepProgress = () => {
      window.postMessage(
        {
          __EWR_HACIZ_PROGRESS__: true,
          requestId,
          progress: {
            runMode: "haciz",
            phase: "talep",
            total: totalBorclu,
            processed,
            matchCount: successCount,
            stopped: false,
            talepResults: results
          }
        },
        "*"
      );
    };

    try {
      for (const item of items) {
        if (hacizRunState.stopRequested) {
          break;
        }
        if (!item.success || !item.dosyaId || !Array.isArray(item.borclular)) {
          continue;
        }

        for (const borclu of item.borclular) {
          if (hacizRunState.stopRequested) {
            break;
          }

          const hasA = modes.includes("arac") && Array.isArray(borclu.aracList) && borclu.aracList.length > 0;
          const hasB =
            modes.includes("banka") &&
            Array.isArray(borclu.bankaList) &&
            borclu.bankaList.filter((bk) => bk.matchedId).length > 0;
          const hasT = modes.includes("takbis") && Array.isArray(borclu.takbisList) && borclu.takbisList.length > 0;
          if (!hasA && !hasB && !hasT) {
            continue;
          }

          const result = await sendTalepForBorclu(item, borclu, settings, bankaHacizData, modes);
          processed++;
          if (result.success) {
            successCount++;
          }

          results.push({
            dosyaNo: item.dosyaNo || item.input,
            kisi: borclu.kisi,
            success: result.success,
            partial: !!result.partial,
            error: result.error || null,
            message: result.message || null,
            talepCount: result.talepCount,
            aracCount: Array.isArray(borclu.aracList) ? getLimitedHacizCount(borclu.aracList.length) : 0,
            bankaCount: Array.isArray(borclu.bankaList)
              ? getLimitedHacizCount(borclu.bankaList.filter((bk) => bk.matchedId).length)
              : 0,
            takbisCount: Array.isArray(borclu.takbisList) ? getLimitedHacizCount(borclu.takbisList.length) : 0,
            icraDosyasiCount: Array.isArray(borclu.icraDosyasiList)
              ? getLimitedHacizCount(borclu.icraDosyasiList.length)
              : 0,
            masraf: result.masraf || 0,
            subResults: result.subResults || null
          });

          emitTalepProgress();
        }
      }
    } finally {
      hacizRunState.isRunning = false;
      hacizRunState.stopRequested = false;
    }

    const stopped = processed < totalBorclu;

    window.postMessage(
      {
        __EWR_PAGE__: true,
        requestId,
        ok: true,
        result: {
          runMode: "haciz",
          phase: "talep",
          total: totalBorclu,
          processed,
          matchCount: successCount,
          stopped,
          talepResults: results
        }
      },
      "*"
    );
  };

  // ─── Birleşik Sorgu + Talep Workflow ───────────────────────────────────
  const runHacizFullWorkflow = async (
    requestId,
    settings,
    inputs,
    bankaHacizData,
    cachedQueryItems,
    cachedTalepResults
  ) => {
    if (hacizRunState.isRunning) {
      window.postMessage({ __EWR_PAGE__: true, requestId, ok: false, error: "İşlem zaten çalışıyor." }, "*");
      return;
    }
    hacizRunState.isRunning = true;
    hacizRunState.stopRequested = false;
    setPendingTakbisCount(0);

    const modes = Array.isArray(settings.hacizModes) ? settings.hacizModes : ["arac"];
    const total = inputs.length;
    const talepResults = [];
    let processed = 0;
    let queryMatch = 0;
    let talepSuccess = 0;
    let talepProcessed = 0;
    const pendingTakbisTasks = [];

    // ─── Cache kullan veya yeni sorgu at ─────────────────────────────────
    const useCache = Array.isArray(cachedQueryItems) && cachedQueryItems.length === inputs.length;
    const queryItems = [];
    const hasCoveredRequestedTalepModes = (prev, selectedModes) => {
      if (!prev || !Array.isArray(selectedModes) || selectedModes.length === 0) {
        return false;
      }
      const aracOk = !selectedModes.includes("arac") || (Number(prev.aracCount) || 0) > 0;
      const bankaOk = !selectedModes.includes("banka") || (Number(prev.bankaCount) || 0) > 0;
      const takbisOk = !selectedModes.includes("takbis") || (Number(prev.takbisCount) || 0) > 0;
      const icraDosyasiOk = !selectedModes.includes("icraDosyasi") || (Number(prev.icraDosyasiCount) || 0) > 0;
      return aracOk && bankaOk && takbisOk && icraDosyasiOk;
    };

    // ─── Önceki başarılı talepleri takip et (tekrar göndermeyi önlemek için) ───
    const succeededTalepKeys = new Set();
    if (useCache && Array.isArray(cachedTalepResults)) {
      for (const prev of cachedTalepResults) {
        if (prev.success) {
          succeededTalepKeys.add(`${prev.dosyaNo || ""}|${prev.kisi || ""}`);
        }
      }
    }

    const emitFullProgress = () => {
      const hasErrorOrMatch = (x) =>
        x.isMatch ||
        (Array.isArray(x.borclular) &&
          x.borclular.some((b) => b.errorCode || b.aracError || b.bankaError || b.takbisError || b.icraDosyasiError));
      const relevant = queryItems
        .filter(hasErrorOrMatch)
        .map((x) => ({ input: x.input, dosyaNo: x.dosyaNo, borclular: x.borclular }));

      window.postMessage(
        {
          __EWR_HACIZ_PROGRESS__: true,
          requestId,
          progress: {
            runMode: "haciz",
            phase: "full",
            total,
            processed,
            matchCount: queryMatch,
            stopped: false,
            matched: relevant,
            talepTotal: talepProcessed + talepResults.length,
            talepProcessed,
            talepSuccess,
            talepResults,
            activeQueryLabel: hacizRunState.activeQueryLabel,
            activeQueryDosyaNo: hacizRunState.activeQueryDosyaNo,
            activeQueryKisi: hacizRunState.activeQueryKisi,
            activeQueryStartedAt: hacizRunState.activeQueryStartedAt,
            pendingTakbisCount: hacizRunState.pendingTakbisCount
          }
        },
        "*"
      );
    };

    const runTalepPass = async (selectedModes) => {
      for (const result of queryItems) {
        if (hacizRunState.stopRequested) {
          break;
        }
        if (!(result.success && result.dosyaId && Array.isArray(result.borclular))) {
          continue;
        }

        for (const borclu of result.borclular) {
          if (hacizRunState.stopRequested) {
            break;
          }
          if (borclu.takbisPending) {
            continue;
          }

          const hasA = selectedModes.includes("arac") && Array.isArray(borclu.aracList) && borclu.aracList.length > 0;
          const hasB =
            selectedModes.includes("banka") &&
            Array.isArray(borclu.bankaList) &&
            borclu.bankaList.filter((bk) => bk.matchedId).length > 0;
          const hasT =
            selectedModes.includes("takbis") && Array.isArray(borclu.takbisList) && borclu.takbisList.length > 0;
          const hasI =
            selectedModes.includes("icraDosyasi") &&
            Array.isArray(borclu.icraDosyasiList) &&
            borclu.icraDosyasiList.length > 0;
          if (!hasA && !hasB && !hasT && !hasI) {
            continue;
          }

          const talepKey = `${result.dosyaNo || result.input}|${borclu.kisi || ""}`;
          if (succeededTalepKeys.has(talepKey)) {
            const prev = [...talepResults, ...(Array.isArray(cachedTalepResults) ? cachedTalepResults : [])]
              .filter((p) => p.success && `${p.dosyaNo || ""}|${p.kisi || ""}` === talepKey)
              .slice(-1)[0];
            if (prev && hasCoveredRequestedTalepModes(prev, selectedModes)) {
              talepResults.push(prev);
              talepProcessed++;
              talepSuccess++;
              emitFullProgress();
              continue;
            }
          }

          let retryModes = selectedModes;
          const prevPartial = [...talepResults, ...(Array.isArray(cachedTalepResults) ? cachedTalepResults : [])]
            .filter((p) => p.partial && `${p.dosyaNo || ""}|${p.kisi || ""}` === talepKey)
            .slice(-1)[0];
          if (prevPartial && Array.isArray(prevPartial.subResults)) {
            const succeededTypes = new Set(
              prevPartial.subResults
                .filter((s) => s.success)
                .map((s) =>
                  s.type === "AvukatTalepAracHacziDVO"
                    ? "arac"
                    : s.type === "AvukatTalepGayrimenkulHacziDVO"
                      ? "takbis"
                      : s.type === "AvukatTalepAlacakliDosyaDVO"
                        ? "icraDosyasi"
                        : "banka"
                )
            );
            retryModes = selectedModes.filter((m) => !succeededTypes.has(m));
            if (retryModes.length === 0) {
              talepResults.push(prevPartial);
              talepProcessed++;
              emitFullProgress();
              continue;
            }
          }

          const talepResult = await sendTalepForBorclu(result, borclu, settings, bankaHacizData, retryModes);
          talepProcessed++;

          const shouldMergePrevPartial = !(
            isTalepImzaErrorMessage(talepResult.error) || isTalepImzaErrorMessage(talepResult.message)
          );
          let mergedSubResults = talepResult.subResults || [];
          let mergedMasraf = talepResult.masraf || 0;
          let mergedTalepCount = talepResult.talepCount || 0;
          if (shouldMergePrevPartial && prevPartial && Array.isArray(prevPartial.subResults)) {
            const prevSucceeded = prevPartial.subResults.filter((s) => s.success);
            mergedSubResults = [...prevSucceeded, ...mergedSubResults];
            mergedMasraf += prevPartial.masraf || 0;
            mergedTalepCount += prevPartial.talepCount || 0;
          }
          const allSub = mergedSubResults.length > 0 && mergedSubResults.every((s) => s.success);
          const mergedSuccess = talepResult.success || allSub;
          if (mergedSuccess) {
            talepSuccess++;
            succeededTalepKeys.add(talepKey);
          }

          talepResults.push({
            dosyaNo: result.dosyaNo || result.input,
            kisi: borclu.kisi,
            success: mergedSuccess,
            partial: !mergedSuccess && mergedSubResults.some((s) => s.success),
            error: talepResult.error || null,
            message: talepResult.message || null,
            talepCount: mergedTalepCount,
            aracCount: hasA ? getLimitedHacizCount(borclu.aracList.length) : 0,
            bankaCount: hasB ? getLimitedHacizCount(borclu.bankaList.filter((bk) => bk.matchedId).length) : 0,
            takbisCount: hasT ? getLimitedHacizCount(borclu.takbisList.length) : 0,
            icraDosyasiCount: hasI ? getLimitedHacizCount(borclu.icraDosyasiList.length) : 0,
            masraf: mergedMasraf,
            subResults: mergedSubResults
          });
          emitFullProgress();
        }
      }
    };

    try {
      // ─── Sorgu aşaması (cache yoksa) ───────────────────────────────────
      if (!useCache) {
        let isFirstInput = true;
        for (const input of inputs) {
          if (hacizRunState.stopRequested) {
            break;
          }
          if (!isFirstInput) {
            await new Promise((r) => setTimeout(r, 3000));
            if (hacizRunState.stopRequested) {
              break;
            }
          }
          isFirstInput = false;

          let result;
          try {
            result = await processOneDosyaHaciz(settings, input, {
              setActiveQuery: (label, dosyaNo, kisi) => {
                setHacizActiveQuery(label, dosyaNo, kisi);
                emitFullProgress();
              },
              clearActiveQuery: () => {
                clearHacizActiveQuery();
                emitFullProgress();
              },
              notifyProgress: () => emitFullProgress(),
              allowBackgroundTakbis: true
            });
          } catch (err) {
            result = {
              runMode: "haciz",
              input: typeof input === "object" ? input.dosyaNo || "" : String(input || ""),
              success: false,
              error: String(err && err.message ? err.message : err),
              borclular: []
            };
          }

          queryItems.push(result);
          if (Array.isArray(result.pendingTasks) && result.pendingTasks.length > 0) {
            pendingTakbisTasks.push(...result.pendingTasks);
          }
          delete result.pendingTasks;
          processed += 1;
          if (result.isMatch) {
            queryMatch++;
          }
          emitFullProgress();
        }
      } else {
        const cachedMap = new Map(cachedQueryItems.map((item) => [`${item.dosyaNo || item.input || ""}`, item]));
        let isFirstInput = true;
        for (const input of inputs) {
          if (hacizRunState.stopRequested) {
            break;
          }
          if (!isFirstInput) {
            await new Promise((r) => setTimeout(r, 3000));
            if (hacizRunState.stopRequested) {
              break;
            }
          }
          isFirstInput = false;

          const inputKey = typeof input === "object" ? input.dosyaNo || "" : String(input || "");
          const cachedItem = cachedMap.get(inputKey) || null;
          let result;
          try {
            result = cachedItem
              ? await refreshCachedDosyaHaciz(settings, input, cachedItem, {
                  setActiveQuery: (label, dosyaNo, kisi) => {
                    setHacizActiveQuery(label, dosyaNo, kisi);
                    emitFullProgress();
                  },
                  clearActiveQuery: () => {
                    clearHacizActiveQuery();
                    emitFullProgress();
                  },
                  notifyProgress: () => emitFullProgress(),
                  allowBackgroundTakbis: true
                })
              : await processOneDosyaHaciz(settings, input, {
                  setActiveQuery: (label, dosyaNo, kisi) => {
                    setHacizActiveQuery(label, dosyaNo, kisi);
                    emitFullProgress();
                  },
                  clearActiveQuery: () => {
                    clearHacizActiveQuery();
                    emitFullProgress();
                  },
                  notifyProgress: () => emitFullProgress(),
                  allowBackgroundTakbis: true
                });
          } catch (err) {
            result = {
              runMode: "haciz",
              input: inputKey,
              success: false,
              error: String(err && err.message ? err.message : err),
              borclular: []
            };
          }

          queryItems.push(result);
          if (Array.isArray(result.pendingTasks) && result.pendingTasks.length > 0) {
            pendingTakbisTasks.push(...result.pendingTasks);
          }
          delete result.pendingTasks;
          processed += 1;
          if (result.isMatch) {
            queryMatch++;
          }
          emitFullProgress();
        }
      }

      await runTalepPass(modes.filter((mode) => mode !== "takbis"));
      if (pendingTakbisTasks.length > 0) {
        await Promise.allSettled(pendingTakbisTasks);
        for (const item of queryItems) {
          item.isMatch =
            Array.isArray(item.borclular) &&
            item.borclular.some(
              (b) =>
                (Array.isArray(b.aracList) && b.aracList.length > 0) ||
                (Array.isArray(b.bankaList) && b.bankaList.length > 0) ||
                (Array.isArray(b.takbisList) && b.takbisList.length > 0) ||
                b.icraDosyasiVar === true
            );
        }
        queryMatch = queryItems.filter((item) => item.isMatch).length;
        emitFullProgress();
      }
      if (modes.includes("takbis")) {
        await runTalepPass(["takbis"]);
      }
    } finally {
      hacizRunState.isRunning = false;
      hacizRunState.stopRequested = false;
      clearHacizActiveQuery();
      setPendingTakbisCount(0);
    }

    const stopped = processed < total;

    window.postMessage(
      {
        __EWR_PAGE__: true,
        requestId,
        ok: true,
        result: {
          runMode: "haciz",
          phase: "full",
          total,
          processed,
          matchCount: queryMatch,
          stopped,
          items: queryItems,
          modes,
          talepResults,
          talepProcessed,
          talepSuccess
        }
      },
      "*"
    );
  };

  // ─── Mesaj dinleyici ───────────────────────────────────────────────────
  window.addEventListener("message", (event) => {
    if (!event.data || event.source !== window) {
      return;
    }

    if (event.data.__EWR_EXT__ === true && event.data.type === "RUN_HACIZ") {
      const { requestId, settings, inputs } = event.data;
      runHacizWorkflow(requestId, settings, inputs).catch(() => {
        hacizRunState.isRunning = false;
      });
      return;
    }

    if (event.data.__EWR_EXT__ === true && event.data.type === "STOP_HACIZ") {
      hacizRunState.stopRequested = true;
      if (hacizRunState.activeRequestController) {
        try {
          hacizRunState.activeRequestController.abort();
        } catch {}
      }
      for (const controller of Array.from(hacizRunState.pendingTakbisControllers || [])) {
        try {
          controller.abort();
        } catch {}
      }
      return;
    }

    if (event.data.__EWR_EXT__ === true && event.data.type === "SEND_HACIZ_TALEP") {
      const { requestId, settings, items, bankaHacizData } = event.data;
      runHacizTalepWorkflow(requestId, settings, items, bankaHacizData).catch(() => {
        hacizRunState.isRunning = false;
      });
      return;
    }

    if (event.data.__EWR_EXT__ === true && event.data.type === "RUN_HACIZ_FULL") {
      const { requestId, settings, inputs, bankaHacizData, cachedQueryItems, cachedTalepResults } = event.data;
      runHacizFullWorkflow(
        requestId,
        settings,
        inputs,
        bankaHacizData,
        cachedQueryItems || null,
        cachedTalepResults || null
      ).catch((err) => {
        hacizRunState.isRunning = false;
        window.postMessage(
          {
            __EWR_PAGE__: true,
            requestId,
            ok: true,
            result: {
              runMode: "haciz",
              phase: "full",
              total: Array.isArray(inputs) ? inputs.length : 0,
              processed: 0,
              matchCount: 0,
              stopped: false,
              items: [],
              talepResults: [],
              talepProcessed: 0,
              talepSuccess: 0,
              error: String(err?.message || err)
            }
          },
          "*"
        );
      });
      return;
    }
  });
})();

﻿(() => {
  "use strict";

  // Prevent double-load
  if (window.__EWR_HACIZ_LOADED__) {
    return;
  }
  window.__EWR_HACIZ_LOADED__ = true;

  // â”€â”€â”€ Shared helpers from page-runner-core â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const getCore = () => window.__EWR_PR_Core || {};

  const runRequest           = (...a) => getCore().runRequest           ? getCore().runRequest(...a)           : Promise.reject(new Error("Core y\u00fcklenmedi."));
  const parseInput           = (...a) => { const f = getCore().parseInput;           if (!f) throw new Error("Core y\u00fcklenmedi."); return f(...a); };
  const applyTemplate        = (...a) => getCore().applyTemplate        ? getCore().applyTemplate(...a)        : String(a[0] || "");
  const applyJsonBodyTemplate= (...a) => getCore().applyJsonBodyTemplate? getCore().applyJsonBodyTemplate(...a): String(a[0] || "");
  const parseHeaders         = (...a) => getCore().parseHeaders         ? getCore().parseHeaders(...a)         : {};
  const toAbsoluteUrl        = (...a) => getCore().toAbsoluteUrl        ? getCore().toAbsoluteUrl(...a)        : String(a[0] || "");
  const normalizeJsonBodyValue=(...a) => getCore().normalizeJsonBodyValue?getCore().normalizeJsonBodyValue(...a): String(a[0] || "");
  const findByKeyDeep        = (...a) => getCore().findByKeyDeep        ? getCore().findByKeyDeep(...a)        : undefined;

  // â”€â”€â”€ Run state â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const hacizRunState = {
    isRunning: false,
    stopRequested: false,
    activeRequestController: null,
    pendingTakbisControllers: new Set(),
    pendingTakbisCount: 0,
    activeQueryLabel: "",
    activeQueryDosyaNo: "",
    activeQueryKisi: "",
    activeQueryStartedAt: 0
  };

  const setHacizActiveQuery = (label, dosyaNo = "", kisi = "") => {
    hacizRunState.activeQueryLabel = String(label || "");
    hacizRunState.activeQueryDosyaNo = String(dosyaNo || "");
    hacizRunState.activeQueryKisi = String(kisi || "");
    hacizRunState.activeQueryStartedAt = Date.now();
  };

  const clearHacizActiveQuery = () => {
    hacizRunState.activeQueryLabel = "";
    hacizRunState.activeQueryDosyaNo = "";
    hacizRunState.activeQueryKisi = "";
    hacizRunState.activeQueryStartedAt = 0;
  };

  const setPendingTakbisCount = (count) => {
    hacizRunState.pendingTakbisCount = Math.max(0, Number(count) || 0);
  };

  const parseJsonSafe = (text) => {
    try {
      return JSON.parse(text);
    } catch {
      return null;
    }
  };

  // â”€â”€â”€ Helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

  // â”€â”€ Bank name matching â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const BANK_SUFFIXES = /\s*(T\u00dcRK ANON\u0130M \u015e\u0130RKET\u0130|ANON\u0130M \u015e\u0130RKET\u0130|T\.A\.\u015e\.|A\.\u015e\.|T\.A\.O\.|T\u00dcRK ANON\u0130M ORTAKLI\u011eI|GENEL M\u00dcD\u00dcRL\u00dc\u011e\u00dc)\s*/gi;
  const BANK_PREFIXES = /\s*(T\u00dcRK\u0130YE CUMHUR\u0130YET\u0130|T\.C\.)\s*/gi;
  const normalizeBank = (s) => String(s || "").toUpperCase().replace(BANK_SUFFIXES, "").replace(BANK_PREFIXES, " ").replace(/\s+/g, " ").trim();

  const buildBankMap = (bankParams) => {
    if (!Array.isArray(bankParams) || bankParams.length === 0) {
      return { exactMap: new Map(), entries: [] };
    }
    const exactMap = new Map();
    const entries = [];
    for (const bp of bankParams) {
      const key = normalizeBank(bp.ilgili);
      if (key) {
        exactMap.set(key, bp);
        entries.push({ key, bp });
      }
    }
    return { exactMap, entries };
  };

  const matchBankFromMap = (bankaAdi, bankMap) => {
    if (!bankMap) { return null; }
    const key = normalizeBank(bankaAdi);
    if (!key) { return null; }
    const exact = bankMap.exactMap.get(key);
    if (exact) { return exact; }
    for (const { key: bpKey, bp } of bankMap.entries) {
      if (bpKey.startsWith(key) || key.startsWith(bpKey)) { return bp; }
    }
    return null;
  };

  /**
   * borçlu nesnesinden ad bilgisini çıkarır (kişi veya kurum).
   */
  const getBorcluAdi = (borclu) => {
    if (borclu && borclu.kisi) {
      return String(borclu.kisi).trim();
    }
    const kisi = borclu.kisiTumDVO || {};
    const ad = [kisi.adi, kisi.soyadi].filter(Boolean).join(" ");
    if (ad) return ad;
    const kurum = borclu.kurumDVO || {};
    if (kurum.kurumAdi) return String(kurum.kurumAdi).trim();
    return "Bilinmeyen";
  };

  /**
   * borçlu listesinden X-Borclu header değerini oluşturur.
   * Format: "{adi} {soyadi} - {tcKimlikNo}" veya "{kurumAdi} - {vergiNo}"
   */
  const buildBorcluHeaderValue = (borclu) => {
    if (!borclu) {
      return "undefined";
    }
    if (borclu.borcluHeaderValue) {
      return String(borclu.borcluHeaderValue);
    }
    const kisi = borclu.kisiTumDVO || {};
    const adi    = String(kisi.adi    || "").trim();
    const soyadi = String(kisi.soyadi || "").trim();
    const tc     = String(kisi.tcKimlikNo || "").trim();
    if (adi || soyadi) {
      const name = [adi, soyadi].filter(Boolean).join(" ");
      return tc ? `${name} - ${tc}` : name;
    }
    const kurum = borclu.kurumDVO || {};
    if (kurum.kurumAdi) {
      const vergi = String(kurum.vergiNo || "").trim();
      return vergi ? `${kurum.kurumAdi} - ${vergi}` : String(kurum.kurumAdi);
    }
    return "undefined";
  };

  const HACIZ_QUERY_COOLDOWN_MS = 3 * 60 * 1000;

  const getModeMeta = (mode) => ({
    doneKey: mode === "icraDosyasi" ? "icraDosyasiQueryDone" : `${mode}QueryDone`,
    errorKey:
      mode === "arac" ? "aracError" :
      mode === "banka" ? "bankaError" :
      mode === "takbis" ? "takbisError" :
      "icraDosyasiError",
    cooldownKey: mode === "icraDosyasi" ? "icraDosyasiCooldownUntil" : `${mode}CooldownUntil`
  });

  const getModeCooldownUntil = (mode, borclu) => {
    const meta = getModeMeta(mode);
    const value = Number(borclu && borclu[meta.cooldownKey]);
    return Number.isFinite(value) ? value : 0;
  };

  const isRetryableQueryError = (errorCode) => !!errorCode && String(errorCode) !== "PRTL_AVKT_10104";

  const shouldReuseCachedMode = (mode, borclu) => {
    const meta = getModeMeta(mode);
    if (getModeCooldownUntil(mode, borclu) > Date.now()) {
      return true;
    }
    if (borclu && borclu[meta.doneKey] === true) {
      const error =
        mode === "arac" ? borclu.aracError :
        mode === "banka" ? borclu.bankaError :
        mode === "takbis" ? borclu.takbisError :
        borclu.icraDosyasiError;
      return !isRetryableQueryError(error && error.code);
    }
    return false;
  };

  const runHacizQueryRequest = async (
    url,
    headers,
    body,
    emptyResponseErrorCode,
    emptyResponseErrorMessage,
    timeoutMs = 30000,
    timeoutErrorCode = "QUERY_TIMEOUT_PENDING",
    timeoutErrorMessage = "Sorgu yanıtı gecikti. Aynı sorgu 3 dakika boyunca otomatik yeniden denenmeyecek."
  ) => {
    if (hacizRunState.stopRequested) {
      throw new Error("STOP_REQUESTED");
    }

    const controller = new AbortController();
    hacizRunState.activeRequestController = controller;
    let didTimeout = false;
    const timer = timeoutMs > 0
      ? setTimeout(() => {
          didTimeout = true;
          controller.abort();
        }, timeoutMs)
      : null;

    try {
      const response = await fetch(url, {
        method: "POST",
        headers,
        body,
        credentials: "include",
        signal: controller.signal
      });
      const text = await response.text();
      const res = {
        ok: response.ok,
        status: response.status,
        text,
        json: parseJsonSafe(text)
      };
      const hasBody = typeof text === "string" && text.trim().length > 0;
      if (!hasBody) {
        return {
          response: res,
          emptyResponseExhausted: true,
          emptyResponseErrorCode,
          emptyResponseErrorMessage,
          timedOut: false,
          cooldownUntil: 0
        };
      }
      return {
        response: res,
        emptyResponseExhausted: false,
        timedOut: false,
        cooldownUntil: 0
      };
    } catch (error) {
      if (hacizRunState.stopRequested) {
        throw new Error("STOP_REQUESTED");
      }
      if (error && error.name === "AbortError" && didTimeout) {
        return {
          response: { ok: false, status: 0, text: null, json: null, error: "REQUEST_TIMEOUT", timeout: true },
          emptyResponseExhausted: false,
          timedOut: true,
          timeoutErrorCode,
          timeoutErrorMessage,
          cooldownUntil: Date.now() + HACIZ_QUERY_COOLDOWN_MS
        };
      }
      throw error;
    } finally {
      if (timer) {
        clearTimeout(timer);
      }
      if (hacizRunState.activeRequestController === controller) {
        hacizRunState.activeRequestController = null;
      }
    }
  };

  /**
   * Bir borçlu için araç sorgusu yapar.
   * @returns {{ kisi, kisiKurumId, aracList, sorguOk, sorguStatus }}
   */
  const sorguBorcluArac = async (dosyaId, borclu, baseHeaders, settings, secondCtx) => {
    const kisiKurumId  = borclu.kisiKurumId;
    const borcluValue  = buildBorcluHeaderValue(borclu);

    const headers = {
      ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
      "Content-Type": "application/json",
      "X-Borclu": encodeURIComponent(borcluValue)
    };

    const body = JSON.stringify({
      dosyaId: normalizeJsonBodyValue(dosyaId),
      kisiKurumId,
      pageIndex: 0
    });

    const url = toAbsoluteUrl("/borclu_bilgileri_goruntule_egm_brd.ajx");
    let aracList    = [];
    let sorguOk      = false;
    let sorguStatus  = 0;
    let errorCode    = null;
    let errorMessage = null;
    let cooldownUntil = 0;

    try {
      const queryRun = await runHacizQueryRequest(
        url,
        headers,
        body,
        "ARAC_EMPTY_RESPONSE",
        "Araç sorgusunda servis boş yanıt döndü.",
        30000,
        "ARAC_TIMEOUT_PENDING",
        "Araç sorgusunda 30 saniye içinde yanıt gelmedi. Aynı sorgu 3 dakika boyunca otomatik yeniden denenmeyecek."
      );
      const res = queryRun.response;
      sorguOk     = !!res.ok;
      sorguStatus = res.status;

      if (queryRun.timedOut) {
        errorCode = queryRun.timeoutErrorCode;
        errorMessage = queryRun.timeoutErrorMessage;
        cooldownUntil = Number(queryRun.cooldownUntil || 0);
      } else if (queryRun.emptyResponseExhausted) {
        errorCode = queryRun.emptyResponseErrorCode;
        errorMessage = queryRun.emptyResponseErrorMessage;
      } else if (res.ok && res.json) {
        if (res.json.errorCode) {
          errorCode    = String(res.json.errorCode);
          errorMessage = String(res.json.error || "").trim();
        } else {
          const bilgileri = res.json.sorguSonucDVO || res.json;
          const aracBilgileri = bilgileri.aracBilgileri || bilgileri;
          if (Array.isArray(aracBilgileri.aracList)) {
            aracList = aracBilgileri.aracList.map((a) => ({
              plaka:      String(a.plaka      || ""),
              marka:      String(a.marka      || ""),
              model:      String(a.model      || ""),
              ticariAd:   String(a.ticariAd   || ""),
              renk:       String(a.renk       || ""),
              cins:       String(a.cins       || ""),
              plakaSifreli: String(a.plakaSifreli || ""),
              isMock:     !!a.isMock
            }));
          } else {
            errorCode = "ARAC_INVALID_RESPONSE";
            errorMessage = "Araç sorgusunda beklenen veri yapısı gelmedi.";
          }
        }
      }
    } catch {
      // hata zaten sorguOk=false
    }

    const kisiAdi = getBorcluAdi(borclu);

    return {
      kisi:        kisiAdi,
      tcKimlikNo:  String((borclu.kisiTumDVO || {}).tcKimlikNo || (borclu.kurumDVO || {}).vergiNo || ""),
      kisiKurumId,
      aracList,
      sorguOk,
      sorguStatus,
      errorCode,
      errorMessage
    };
  };

  /**
   * Bir borçlu için banka sorgusu yapar.
   * @returns {{ kisi, kisiKurumId, bankaList, sorguOk, sorguStatus, errorCode, errorMessage }}
   */
  const sorguBorcluBanka = async (dosyaId, borclu, settings, secondCtx, bankMap) => {
    const kisiKurumId  = borclu.kisiKurumId;
    const borcluValue  = buildBorcluHeaderValue(borclu);

    const headers = {
      ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
      "Content-Type": "application/json",
      "X-Borclu": encodeURIComponent(borcluValue)
    };

    const body = JSON.stringify({
      dosyaId: normalizeJsonBodyValue(dosyaId),
      kisiKurumId
    });

    const url = toAbsoluteUrl("/borclu_bilgileri_goruntule_banka.ajx");
    let bankaList    = [];
    let sorguOk      = false;
    let sorguStatus  = 0;
    let errorCode    = null;
    let errorMessage = null;
    let cooldownUntil = 0;

    try {
      const queryRun = await runHacizQueryRequest(
        url,
        headers,
        body,
        "BANKA_EMPTY_RESPONSE",
        "Banka sorgusunda servis boş yanıt döndü.",
        30000,
        "BANKA_TIMEOUT_PENDING",
        "Banka sorgusunda 30 saniye içinde yanıt gelmedi. Aynı sorgu 3 dakika boyunca otomatik yeniden denenmeyecek."
      );
      const res = queryRun.response;
      sorguOk     = !!res.ok;
      sorguStatus = res.status;

      if (queryRun.timedOut) {
        errorCode = queryRun.timeoutErrorCode;
        errorMessage = queryRun.timeoutErrorMessage;
        cooldownUntil = Number(queryRun.cooldownUntil || 0);
      } else if (queryRun.emptyResponseExhausted) {
        errorCode = queryRun.emptyResponseErrorCode;
        errorMessage = queryRun.emptyResponseErrorMessage;
      } else if (res.ok && res.json) {
        if (res.json.errorCode) {
          errorCode    = String(res.json.errorCode);
          errorMessage = String(res.json.error || "").trim();
        } else if (Array.isArray(res.json.sorguSonucDVO)) {
          bankaList = res.json.sorguSonucDVO.map((s) => {
            const match = matchBankFromMap(String(s.bankaAdi || ""), bankMap);
            return {
              bankaAdi:       String(s.bankaAdi || ""),
              eftKodu:        s.eftKodu != null ? Number(s.eftKodu) : null,
              matchedId:      match ? match.ilgiliKisiIlkKisiKurumId : null,
              matchedIlgili:  match ? match.ilgili : null
            };
          });
        } else {
          errorCode = "BANKA_INVALID_RESPONSE";
          errorMessage = "Banka sorgusunda beklenen veri yapısı gelmedi.";
        }
      }
    } catch {
      // hata zaten sorguOk=false
    }

    const kisiAdi = getBorcluAdi(borclu);

    return {
      kisi:        kisiAdi,
      tcKimlikNo:  String((borclu.kisiTumDVO || {}).tcKimlikNo || (borclu.kurumDVO || {}).vergiNo || ""),
      kisiKurumId,
      bankaList,
      sorguOk,
      sorguStatus,
      errorCode,
      errorMessage,
      cooldownUntil
    };
  };

  /**
   * Bir borçlu için takbis (gayrimenkul) sorgusu yapar.
   * @returns {{ kisi, kisiKurumId, takbisList, sorguOk, sorguStatus, errorCode, errorMessage }}
   */
  const sorguBorcluTakbis = async (dosyaId, borclu, settings, secondCtx) => {
    const kisiKurumId  = borclu.kisiKurumId;
    const borcluValue  = buildBorcluHeaderValue(borclu);

    const headers = {
      ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
      "Content-Type": "application/json",
      "X-Borclu": encodeURIComponent(borcluValue)
    };

    const body = JSON.stringify({
      dosyaId: normalizeJsonBodyValue(dosyaId),
      kisiKurumId
    });

    const url = toAbsoluteUrl("/borclu_bilgileri_goruntule_takbis.ajx");
    let takbisList   = [];
    let sorguOk      = false;
    let sorguStatus  = 0;
    let errorCode    = null;
    let errorMessage = null;
    let cooldownUntil = 0;

    try {
      const queryRun = await runHacizQueryRequest(
        url,
        headers,
        body,
        "TAKBIS_EMPTY_RESPONSE",
        "Takbis sorgusunda servis boş yanıt döndü.",
        60000,
        "TAKBIS_TIMEOUT_PENDING",
        "Takbis sorgusunda 60 saniye içinde yanıt gelmedi. Aynı sorgu 3 dakika boyunca otomatik yeniden denenmeyecek."
      );
      const res = queryRun.response;
      sorguOk     = !!res.ok;
      sorguStatus = res.status;

      if (queryRun.timedOut) {
        errorCode = queryRun.timeoutErrorCode;
        errorMessage = queryRun.timeoutErrorMessage;
        cooldownUntil = Number(queryRun.cooldownUntil || 0);
      } else if (queryRun.emptyResponseExhausted) {
        errorCode = queryRun.emptyResponseErrorCode;
        errorMessage = queryRun.emptyResponseErrorMessage;
      } else if (res.ok && res.json) {
        if (res.json.errorCode) {
          errorCode    = String(res.json.errorCode);
          errorMessage = String(res.json.error || "").trim();
        } else if (
          typeof res.json.sorguSonucDVO === "string" &&
          res.json.sorguSonucDVO.toLocaleLowerCase("tr-TR").includes("taşınmaz kaydı yok")
        ) {
          takbisList = [];
        } else if (res.json.hasError === true && !Array.isArray(res.json.sorguSonucDVO)) {
          errorCode    = "TAKBIS_ERROR";
          errorMessage = "Takbis sorgusunda hata olu\u015ftu.";
        } else if (Array.isArray(res.json.sorguSonucDVO)) {
          takbisList = res.json.sorguSonucDVO
            .map((s) => {
              const t = (s && (s.tasinmazDVO || s.tasinmaz || s)) || null;
              if (!t || typeof t !== "object") {
                return null;
              }
              const bb = t.bagimsizBolum || t.bagimsizBolumDVO || {};
              const bagimsizBolumId =
                bb.bagimsizBolumid ||
                bb.bagimsizBolumId ||
                t.bagimsizBolumid ||
                t.bagimsizBolumId ||
                0;
              const bagimsizBolumStr = bagimsizBolumId
                ? `Kat: ${bb.kat || t.kat || ""},No: ${bb.no || t.no || ""},Arsa Pay: ${bb.arsaPay || t.arsaPay || ""},Arsa Payda: ${bb.arsaPayda || t.arsaPayda || ""},Kat Mülkiyeti: ${bb.bagimsizBolumTip || t.bagimsizBolumTip || ""}`
                : String(t.bagimsizBolum || "");
              const row = {
                tasinmazId: t.tasinmazId || t.id || 0,
                il: String(t.il || ""),
                ilce: String(t.ilce || ""),
                mahalle: String(t.mahalle || t.mahalleKoy || ""),
                ada: String(t.ada || ""),
                parsel: String(t.parsel || ""),
                nitelik: String(t.nitelik || t.cinsi || ""),
                yuzolcum: t.yuzolcum || t.alan || 0,
                bagimsizBolumid: bagimsizBolumId || 0,
                bagimsizBolum: bagimsizBolumStr
              };
              return row.tasinmazId || row.il || row.ilce || row.mahalle || row.ada || row.parsel || row.nitelik || row.bagimsizBolum
                ? row
                : null;
            })
            .filter(Boolean);
        } else {
          errorCode = "TAKBIS_INVALID_RESPONSE";
          errorMessage = "Takbis sorgusunda beklenen veri yapısı gelmedi.";
        }
      }
    } catch {
      // hata zaten sorguOk=false
    }

    const kisiAdi = getBorcluAdi(borclu);

    return {
      kisi:        kisiAdi,
      tcKimlikNo:  String((borclu.kisiTumDVO || {}).tcKimlikNo || (borclu.kurumDVO || {}).vergiNo || ""),
      kisiKurumId,
      takbisList,
      sorguOk,
      sorguStatus,
      errorCode,
      errorMessage,
      cooldownUntil
    };
  };

  const sorguBorcluTakbisBeklemede = (dosyaId, borclu, settings, secondCtx) => {
    const kisiKurumId  = borclu.kisiKurumId;
    const borcluValue  = buildBorcluHeaderValue(borclu);

    const headers = {
      ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
      "Content-Type": "application/json",
      "X-Borclu": encodeURIComponent(borcluValue)
    };

    const body = JSON.stringify({
      dosyaId: normalizeJsonBodyValue(dosyaId),
      kisiKurumId
    });

    const url = toAbsoluteUrl("/borclu_bilgileri_goruntule_takbis.ajx");
    const controller = new AbortController();
    hacizRunState.pendingTakbisControllers.add(controller);

    return (async () => {
      let takbisList = [];
      let sorguOk = false;
      let sorguStatus = 0;
      let errorCode = null;
      let errorMessage = null;

      try {
        const response = await fetch(url, {
          method: "POST",
          headers,
          body,
          credentials: "include",
          signal: controller.signal
        });
        const text = await response.text();
        const json = parseJsonSafe(text);
        sorguOk = !!response.ok;
        sorguStatus = response.status;

        if (typeof text !== "string" || text.trim().length === 0) {
          errorCode = "TAKBIS_EMPTY_RESPONSE";
          errorMessage = "Takbis sorgusunda servis boş yanıt döndü.";
        } else if (response.ok && json) {
          if (json.errorCode) {
            errorCode = String(json.errorCode);
            errorMessage = String(json.error || "").trim();
          } else if (
            typeof json.sorguSonucDVO === "string" &&
            json.sorguSonucDVO.toLocaleLowerCase("tr-TR").includes("taşınmaz kaydı yok")
          ) {
            takbisList = [];
          } else if (json.hasError === true && !Array.isArray(json.sorguSonucDVO)) {
            errorCode = "TAKBIS_ERROR";
            errorMessage = "Takbis sorgusunda hata oluştu.";
          } else if (Array.isArray(json.sorguSonucDVO)) {
            takbisList = json.sorguSonucDVO
              .map((s) => {
                const t = (s && (s.tasinmazDVO || s.tasinmaz || s)) || null;
                if (!t || typeof t !== "object") {
                  return null;
                }
                const bb = t.bagimsizBolum || t.bagimsizBolumDVO || {};
                const bagimsizBolumId =
                  bb.bagimsizBolumid ||
                  bb.bagimsizBolumId ||
                  t.bagimsizBolumid ||
                  t.bagimsizBolumId ||
                  0;
                const bagimsizBolumStr = bagimsizBolumId
                  ? `Kat: ${bb.kat || t.kat || ""},No: ${bb.no || t.no || ""},Arsa Pay: ${bb.arsaPay || t.arsaPay || ""},Arsa Payda: ${bb.arsaPayda || t.arsaPayda || ""},Kat Mülkiyeti: ${bb.bagimsizBolumTip || t.bagimsizBolumTip || ""}`
                  : String(t.bagimsizBolum || "");
                const row = {
                  tasinmazId: t.tasinmazId || t.id || 0,
                  il: String(t.il || ""),
                  ilce: String(t.ilce || ""),
                  mahalle: String(t.mahalle || t.mahalleKoy || ""),
                  ada: String(t.ada || ""),
                  parsel: String(t.parsel || ""),
                  nitelik: String(t.nitelik || t.cinsi || ""),
                  yuzolcum: t.yuzolcum || t.alan || 0,
                  bagimsizBolumid: bagimsizBolumId || 0,
                  bagimsizBolum: bagimsizBolumStr
                };
                return row.tasinmazId || row.il || row.ilce || row.mahalle || row.ada || row.parsel || row.nitelik || row.bagimsizBolum
                  ? row
                  : null;
              })
              .filter(Boolean);
          } else {
            errorCode = "TAKBIS_INVALID_RESPONSE";
            errorMessage = "Takbis sorgusunda beklenen veri yapısı gelmedi.";
          }
        }
      } catch (error) {
        if (error && error.name === "AbortError") {
          throw new Error("STOP_REQUESTED");
        }
        throw error;
      } finally {
        hacizRunState.pendingTakbisControllers.delete(controller);
      }

      const kisiAdi = getBorcluAdi(borclu);
      return {
        kisi: kisiAdi,
        tcKimlikNo: String((borclu.kisiTumDVO || {}).tcKimlikNo || (borclu.kurumDVO || {}).vergiNo || ""),
        kisiKurumId,
        takbisList,
        sorguOk,
        sorguStatus,
        errorCode,
        errorMessage,
        cooldownUntil: 0
      };
    })();
  };

  /**
   * Bir borçlu için icra dosyası sorgusu yapar.
   * @returns {{ kisi, kisiKurumId, icraDosyasiVar, sorguOk, sorguStatus, errorCode, errorMessage }}
   */
  const sorguBorcluIcraDosyasi = async (dosyaId, borclu, settings, secondCtx) => {
    const kisiKurumId  = borclu.kisiKurumId;
    const borcluValue  = buildBorcluHeaderValue(borclu);

    const headers = {
      ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
      "Content-Type": "application/json",
      "X-Borclu": encodeURIComponent(borcluValue)
    };

    const body = JSON.stringify({
      dosyaId: normalizeJsonBodyValue(dosyaId),
      kisiKurumId
    });

    const url = toAbsoluteUrl("/borclu_bilgileri_goruntule_icra_dosyasi.ajx");
    let icraDosyasiVar = false;
    let icraDosyasiList = [];
    let sorguOk        = false;
    let sorguStatus    = 0;
    let errorCode      = null;
    let errorMessage   = null;
    let cooldownUntil  = 0;

    try {
      const queryRun = await runHacizQueryRequest(
        url,
        headers,
        body,
        "ICRA_DOSYASI_EMPTY_RESPONSE",
        "İcra dosyası sorgusunda servis boş yanıt döndü.",
        30000,
        "ICRA_DOSYASI_TIMEOUT_PENDING",
        "İcra dosyası sorgusunda 30 saniye içinde yanıt gelmedi. Aynı sorgu 3 dakika boyunca otomatik yeniden denenmeyecek."
      );
      const res = queryRun.response;
      sorguOk     = !!res.ok;
      sorguStatus = res.status;

      if (queryRun.timedOut) {
        errorCode = queryRun.timeoutErrorCode;
        errorMessage = queryRun.timeoutErrorMessage;
        cooldownUntil = Number(queryRun.cooldownUntil || 0);
      } else if (queryRun.emptyResponseExhausted) {
        errorCode = queryRun.emptyResponseErrorCode;
        errorMessage = queryRun.emptyResponseErrorMessage;
      } else if (res.ok && res.json) {
        if (res.json.errorCode) {
          errorCode    = String(res.json.errorCode);
          errorMessage = String(res.json.error || "").trim();
        } else if (
          res.json.sorguSonucu === false ||
          (res.json.hasError === false && res.json.hasData === false)
        ) {
          icraDosyasiVar = false;
          icraDosyasiList = [];
        } else if (res.json.hasError && res.json.hasData !== false) {
          errorCode    = "ICRA_DOSYASI_ERROR";
          errorMessage = "\u0130cra dosyas\u0131 sorgusunda hata olu\u015ftu.";
        } else if (Array.isArray(res.json.sorguSonucDVO)) {
          icraDosyasiList = res.json.sorguSonucDVO.map((s) => ({
            dosyaId: String((s && s.dosyaId) || ""),
            dosyaNo: String((s && s.dosyaNo) || ""),
            birimAdi: String((s && s.birimAdi) || ""),
            dosyaTurKod: Number((s && (s.dosyaTurKodu ?? s.dosyaTurKod)) || 0),
            dosyaDurumuAciklama: String((s && s.dosyaDurumuAciklama) || ""),
            dosyaTurKoduAciklama: String((s && s.dosyaTurKoduAciklama) || (s && s.dosyaTurAd) || ""),
            takipTurAciklamasi: String((s && s.takipTurAciklamasi) || ""),
            takipYoluAciklamasi: String((s && s.takipYoluAciklamasi) || ""),
            tarafRolu: String((s && s.tarafRolu) || "")
          }));
          icraDosyasiVar = icraDosyasiList.length > 0;
        } else {
          errorCode = "ICRA_DOSYASI_INVALID_RESPONSE";
          errorMessage = "İcra dosyası sorgusunda beklenen veri yapısı gelmedi.";
        }
      }
    } catch {
      // hata zaten sorguOk=false
    }

    const kisiAdi = getBorcluAdi(borclu);

    return {
      kisi:        kisiAdi,
      tcKimlikNo:  String((borclu.kisiTumDVO || {}).tcKimlikNo || (borclu.kurumDVO || {}).vergiNo || ""),
      kisiKurumId,
      icraDosyasiVar,
      icraDosyasiList,
      sorguOk,
      sorguStatus,
      errorCode,
      errorMessage,
      cooldownUntil
    };
  };

  /**
   * Tek bir dosya için borçlu listesini alır, her borçlu için araç sorgular.
   */
  const processOneDosyaHaciz = async (settings, input, progressHooks = null) => {
    const parsed = parseInput(input);

    const firstCtx = {
      dosyaYil:      parsed.dosyaYil,
      dosyaSira:     parsed.dosyaSira,
      birimId:       parsed.birimId  || settings.defaultBirimId  || "",
      birimAdi:      parsed.birimAdi || settings.defaultBirimAdi || "",
      inputEncoded:  encodeURIComponent(parsed.raw),
      birimAdiEncoded: encodeURIComponent(parsed.birimAdi || settings.defaultBirimAdi || ""),
      dosyaDurum:    encodeURIComponent(settings.defaultDosyaDurum || "Acik"),
      dosyaDurumKod: String(settings.dosyaHesabiDosyaDurumKod || "0")
    };

    // â”€â”€ 1. Birinci istek: dosya arama â†’ dosyaId â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    const firstUrl     = toAbsoluteUrl(applyTemplate(settings.firstEndpointPath, firstCtx));
    const firstMethod  = String(settings.firstMethod || "POST").toUpperCase();
    const firstHeaders = parseHeaders(settings.firstHeadersText, firstCtx);
    const firstBody    = applyJsonBodyTemplate(settings.firstBodyTemplate, firstCtx);

    const first = await runRequest(firstUrl, firstMethod, firstHeaders, firstBody);
    if (!first.ok || !first.json) {
      return {
        runMode: "haciz",
        input: parsed.raw,
        success: false,
        status: first.status,
        error: `Birinci istek başarısız (HTTP ${first.status})`,
        borclular: []
      };
    }

    const dosyaId = findDosyaId(first.json);
    if (!dosyaId) {
      return {
        runMode: "haciz",
        input: parsed.raw,
        success: false,
        status: first.status,
        error: "dosyaId bulunamadı.",
        borclular: []
      };
    }

    const secondCtx = {
      ...firstCtx,
      dosyaId
    };

    // â”€â”€ 2. borçlu listesi â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    const borcluHeaders = {
      ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
      "Content-Type": "application/json",
      "X-Borclu": "undefined"
    };
    const borcluBody = JSON.stringify({ dosyaId: normalizeJsonBodyValue(dosyaId) });
    const borcluUrl  = toAbsoluteUrl("/dosya_borclu_list.ajx");
    const borcluRes  = await runRequest(borcluUrl, "POST", borcluHeaders, borcluBody);

    if (!borcluRes.ok || !Array.isArray(borcluRes.json)) {
      return {
        runMode: "haciz",
        input: parsed.raw,
        success: false,
        status: borcluRes.status,
        error: `Borçlu listesi alınamadı (HTTP ${borcluRes.status})`,
        borclular: []
      };
    }

    const borcluListesi = borcluRes.json.filter((b) => b && typeof b.kisiKurumId !== "undefined");

    //  3. Her borçlu için seçilen sorguları çalıştır 
    const modes = Array.isArray(settings.hacizModes) ? settings.hacizModes : ["arac"];
    const bankMap = modes.includes("banka") ? buildBankMap(settings.bankaHacizParams) : null;

    const borclular = [];
    const pendingTasks = [];
    for (const borclu of borcluListesi) {
      if (hacizRunState.stopRequested) {
        break;
      }

      const kisiAdi = getBorcluAdi(borclu);

      const merged = {
        kisi:         kisiAdi,
        tcKimlikNo:   String((borclu.kisiTumDVO || {}).tcKimlikNo || (borclu.kurumDVO || {}).vergiNo || ""),
        kisiKurumId:  borclu.kisiKurumId,
        borcluHeaderValue: buildBorcluHeaderValue(borclu),
        aracList:     [],
        bankaList:    [],
        takbisList:   [],
        takbisPending: false,
        icraDosyasiVar: false,
        icraDosyasiList: [],
        aracCooldownUntil: 0,
        bankaCooldownUntil: 0,
        takbisCooldownUntil: 0,
        icraDosyasiCooldownUntil: 0,
        aracQueryDone: false,
        bankaQueryDone: false,
        takbisQueryDone: false,
        icraDosyasiQueryDone: false,
        errorCode:    null,
        errorMessage: null,
        aracError:    null,
        bankaError:   null,
        takbisError:  null,
        icraDosyasiError: null
      };

      if (modes.includes("arac")) {
        progressHooks?.setActiveQuery?.("Araç", parsed.raw, kisiAdi);
        const aracResult = await sorguBorcluArac(dosyaId, borclu, borcluHeaders, settings, secondCtx);
        progressHooks?.clearActiveQuery?.();
        merged.aracList = aracResult.aracList;
        merged.aracQueryDone = true;
        merged.aracCooldownUntil = Number(aracResult.cooldownUntil || 0);
        if (aracResult.errorCode) {
          merged.aracError = { code: aracResult.errorCode, message: aracResult.errorMessage };
          if (!merged.errorCode) {
            merged.errorCode    = aracResult.errorCode;
            merged.errorMessage = aracResult.errorMessage;
          }
        }
        if (aracResult.errorCode === "PRTL_AVKT_10104") {
          borclular.push(merged);
          continue;
        }
      }

      if (hacizRunState.stopRequested) {
        borclular.push(merged);
        break;
      }

      if (modes.includes("banka")) {
        progressHooks?.setActiveQuery?.("Banka", parsed.raw, kisiAdi);
        const bankaResult = await sorguBorcluBanka(dosyaId, borclu, settings, secondCtx, bankMap);
        progressHooks?.clearActiveQuery?.();
        merged.bankaList = bankaResult.bankaList;
        merged.bankaQueryDone = true;
        merged.bankaCooldownUntil = Number(bankaResult.cooldownUntil || 0);
        if (bankaResult.errorCode) {
          merged.bankaError = { code: bankaResult.errorCode, message: bankaResult.errorMessage };
          if (!merged.errorCode) {
            merged.errorCode    = bankaResult.errorCode;
            merged.errorMessage = bankaResult.errorMessage;
          }
        }
      }

      if (hacizRunState.stopRequested) {
        borclular.push(merged);
        break;
      }

      if (modes.includes("takbis")) {
        if (progressHooks?.allowBackgroundTakbis === true) {
          merged.takbisPending = true;
          setPendingTakbisCount(hacizRunState.pendingTakbisCount + 1);
          progressHooks?.notifyProgress?.();
          const pendingTask = sorguBorcluTakbisBeklemede(dosyaId, borclu, settings, secondCtx)
            .then((takbisResult) => {
              merged.takbisPending = false;
              merged.takbisList = takbisResult.takbisList;
              merged.takbisQueryDone = true;
              merged.takbisCooldownUntil = 0;
              merged.takbisError = takbisResult.errorCode ? { code: takbisResult.errorCode, message: takbisResult.errorMessage } : null;
              if (takbisResult.errorCode && !merged.errorCode) {
                merged.errorCode = takbisResult.errorCode;
                merged.errorMessage = takbisResult.errorMessage;
              }
              if (!takbisResult.errorCode && merged.errorCode === (merged.takbisError && merged.takbisError.code)) {
                merged.errorCode = null;
                merged.errorMessage = null;
              }
            })
            .catch((error) => {
              merged.takbisPending = false;
              merged.takbisQueryDone = true;
              merged.takbisError = { code: "TAKBIS_ABORTED", message: String(error?.message || error || "Takbis sorgusu durduruldu.") };
              if (!merged.errorCode) {
                merged.errorCode = merged.takbisError.code;
                merged.errorMessage = merged.takbisError.message;
              }
            })
            .finally(() => {
              setPendingTakbisCount(hacizRunState.pendingTakbisCount - 1);
              progressHooks?.notifyProgress?.();
            });
          pendingTasks.push(pendingTask);
        } else {
          progressHooks?.setActiveQuery?.("Takbis", parsed.raw, kisiAdi);
          const takbisResult = await sorguBorcluTakbis(dosyaId, borclu, settings, secondCtx);
          progressHooks?.clearActiveQuery?.();
          merged.takbisList = takbisResult.takbisList;
          merged.takbisQueryDone = true;
          merged.takbisCooldownUntil = Number(takbisResult.cooldownUntil || 0);
          if (takbisResult.errorCode) {
            merged.takbisError = { code: takbisResult.errorCode, message: takbisResult.errorMessage };
            if (!merged.errorCode) {
              merged.errorCode    = takbisResult.errorCode;
              merged.errorMessage = takbisResult.errorMessage;
            }
          }
        }
      }

      if (hacizRunState.stopRequested) {
        borclular.push(merged);
        break;
      }

      if (modes.includes("icraDosyasi")) {
        progressHooks?.setActiveQuery?.("İcra Dosyası", parsed.raw, kisiAdi);
        const icraDosyasiResult = await sorguBorcluIcraDosyasi(dosyaId, borclu, settings, secondCtx);
        progressHooks?.clearActiveQuery?.();
        merged.icraDosyasiVar = icraDosyasiResult.icraDosyasiVar;
        merged.icraDosyasiList = icraDosyasiResult.icraDosyasiList;
        merged.icraDosyasiQueryDone = true;
        merged.icraDosyasiCooldownUntil = Number(icraDosyasiResult.cooldownUntil || 0);
        if (icraDosyasiResult.errorCode) {
          merged.icraDosyasiError = { code: icraDosyasiResult.errorCode, message: icraDosyasiResult.errorMessage };
          if (!merged.errorCode) {
            merged.errorCode    = icraDosyasiResult.errorCode;
            merged.errorMessage = icraDosyasiResult.errorMessage;
          }
        }
      }

      borclular.push(merged);
    }

    const hasArac   = borclular.some((b) => b.aracList && b.aracList.length > 0);
    const hasBanka  = borclular.some((b) => b.bankaList && b.bankaList.length > 0);
    const hasTakbis = borclular.some((b) => b.takbisList && b.takbisList.length > 0);
    const hasIcraDosyasi = borclular.some((b) => b.icraDosyasiVar === true);

    return {
      runMode: "haciz",
      input: parsed.raw,
      dosyaId,
      dosyaNo: `${parsed.dosyaYil}/${parsed.dosyaSira}`,
      birimId: firstCtx.birimId,
      birimAdi: firstCtx.birimAdi,
      success: true,
      status: 200,
      error: null,
      isMatch: hasArac || hasBanka || hasTakbis || hasIcraDosyasi,
      borclular,
      pendingTasks
    };
  };

  const refreshCachedDosyaHaciz = async (settings, input, cachedItem, progressHooks = null) => {
    if (!cachedItem || !cachedItem.dosyaId || !Array.isArray(cachedItem.borclular)) {
      return processOneDosyaHaciz(settings, input);
    }

    const parsed = parseInput(input);
    const firstCtx = {
      dosyaYil:      parsed.dosyaYil,
      dosyaSira:     parsed.dosyaSira,
      birimId:       parsed.birimId  || settings.defaultBirimId  || cachedItem.birimId || "",
      birimAdi:      parsed.birimAdi || settings.defaultBirimAdi || cachedItem.birimAdi || "",
      inputEncoded:  encodeURIComponent(parsed.raw),
      birimAdiEncoded: encodeURIComponent(parsed.birimAdi || settings.defaultBirimAdi || cachedItem.birimAdi || ""),
      dosyaDurum:    encodeURIComponent(settings.defaultDosyaDurum || "Acik"),
      dosyaDurumKod: String(settings.dosyaHesabiDosyaDurumKod || "0")
    };
    const secondCtx = {
      ...firstCtx,
      dosyaId: cachedItem.dosyaId
    };
    const borcluHeaders = {
      ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
      "Content-Type": "application/json",
      "X-Borclu": "undefined"
    };
    const modes = Array.isArray(settings.hacizModes) ? settings.hacizModes : ["arac"];
    const bankMap = modes.includes("banka") ? buildBankMap(settings.bankaHacizParams) : null;
    const borclular = [];
    const pendingTasks = [];

    for (const cachedBorclu of cachedItem.borclular) {
      if (hacizRunState.stopRequested) {
        break;
      }

      const merged = {
        ...cachedBorclu,
        kisi: String(cachedBorclu.kisi || ""),
        tcKimlikNo: String(cachedBorclu.tcKimlikNo || ""),
        borcluHeaderValue: buildBorcluHeaderValue(cachedBorclu)
      };

      if (modes.includes("arac") && !shouldReuseCachedMode("arac", cachedBorclu)) {
        progressHooks?.setActiveQuery?.("Araç", parsed.raw, merged.kisi);
        const aracResult = await sorguBorcluArac(cachedItem.dosyaId, cachedBorclu, borcluHeaders, settings, secondCtx);
        progressHooks?.clearActiveQuery?.();
        merged.aracQueryDone = true;
        merged.aracCooldownUntil = Number(aracResult.cooldownUntil || 0);
        merged.aracError = aracResult.errorCode ? { code: aracResult.errorCode, message: aracResult.errorMessage } : null;
        if (!aracResult.errorCode) {
          merged.aracList = aracResult.aracList;
        }
        if (!merged.aracError && merged.errorCode === (cachedBorclu.aracError && cachedBorclu.aracError.code)) {
          merged.errorCode = null;
          merged.errorMessage = null;
        }
        if (aracResult.errorCode) {
          merged.errorCode = aracResult.errorCode;
          merged.errorMessage = aracResult.errorMessage;
        }
        if (aracResult.errorCode === "PRTL_AVKT_10104") {
          borclular.push(merged);
          continue;
        }
      }

      if (modes.includes("banka") && !shouldReuseCachedMode("banka", cachedBorclu)) {
        progressHooks?.setActiveQuery?.("Banka", parsed.raw, merged.kisi);
        const bankaResult = await sorguBorcluBanka(cachedItem.dosyaId, cachedBorclu, settings, secondCtx, bankMap);
        progressHooks?.clearActiveQuery?.();
        merged.bankaQueryDone = true;
        merged.bankaCooldownUntil = Number(bankaResult.cooldownUntil || 0);
        merged.bankaError = bankaResult.errorCode ? { code: bankaResult.errorCode, message: bankaResult.errorMessage } : null;
        if (!bankaResult.errorCode) {
          merged.bankaList = bankaResult.bankaList;
          if (merged.errorCode === (cachedBorclu.bankaError && cachedBorclu.bankaError.code)) {
            merged.errorCode = null;
            merged.errorMessage = null;
          }
        }
        if (bankaResult.errorCode && !merged.errorCode) {
          merged.errorCode = bankaResult.errorCode;
          merged.errorMessage = bankaResult.errorMessage;
        }
      }

      if (modes.includes("takbis") && !shouldReuseCachedMode("takbis", cachedBorclu)) {
        if (progressHooks?.allowBackgroundTakbis === true) {
          merged.takbisPending = true;
          setPendingTakbisCount(hacizRunState.pendingTakbisCount + 1);
          progressHooks?.notifyProgress?.();
          const pendingTask = sorguBorcluTakbisBeklemede(cachedItem.dosyaId, cachedBorclu, settings, secondCtx)
            .then((takbisResult) => {
              merged.takbisPending = false;
              merged.takbisQueryDone = true;
              merged.takbisCooldownUntil = 0;
              merged.takbisError = takbisResult.errorCode ? { code: takbisResult.errorCode, message: takbisResult.errorMessage } : null;
              if (!takbisResult.errorCode) {
                merged.takbisList = takbisResult.takbisList;
                if (merged.errorCode === (cachedBorclu.takbisError && cachedBorclu.takbisError.code)) {
                  merged.errorCode = null;
                  merged.errorMessage = null;
                }
              }
              if (takbisResult.errorCode && !merged.errorCode) {
                merged.errorCode = takbisResult.errorCode;
                merged.errorMessage = takbisResult.errorMessage;
              }
            })
            .catch((error) => {
              merged.takbisPending = false;
              merged.takbisQueryDone = true;
              merged.takbisError = { code: "TAKBIS_ABORTED", message: String(error?.message || error || "Takbis sorgusu durduruldu.") };
              if (!merged.errorCode) {
                merged.errorCode = merged.takbisError.code;
                merged.errorMessage = merged.takbisError.message;
              }
            })
            .finally(() => {
              setPendingTakbisCount(hacizRunState.pendingTakbisCount - 1);
              progressHooks?.notifyProgress?.();
            });
          pendingTasks.push(pendingTask);
        } else {
          progressHooks?.setActiveQuery?.("Takbis", parsed.raw, merged.kisi);
          const takbisResult = await sorguBorcluTakbis(cachedItem.dosyaId, cachedBorclu, settings, secondCtx);
          progressHooks?.clearActiveQuery?.();
          merged.takbisQueryDone = true;
          merged.takbisCooldownUntil = Number(takbisResult.cooldownUntil || 0);
          merged.takbisError = takbisResult.errorCode ? { code: takbisResult.errorCode, message: takbisResult.errorMessage } : null;
          if (!takbisResult.errorCode) {
            merged.takbisList = takbisResult.takbisList;
            if (merged.errorCode === (cachedBorclu.takbisError && cachedBorclu.takbisError.code)) {
              merged.errorCode = null;
              merged.errorMessage = null;
            }
          }
          if (takbisResult.errorCode && !merged.errorCode) {
            merged.errorCode = takbisResult.errorCode;
            merged.errorMessage = takbisResult.errorMessage;
          }
        }
      }

      if (modes.includes("icraDosyasi") && !shouldReuseCachedMode("icraDosyasi", cachedBorclu)) {
        progressHooks?.setActiveQuery?.("İcra Dosyası", parsed.raw, merged.kisi);
        const icraDosyasiResult = await sorguBorcluIcraDosyasi(cachedItem.dosyaId, cachedBorclu, settings, secondCtx);
        progressHooks?.clearActiveQuery?.();
        merged.icraDosyasiQueryDone = true;
        merged.icraDosyasiCooldownUntil = Number(icraDosyasiResult.cooldownUntil || 0);
        merged.icraDosyasiError = icraDosyasiResult.errorCode ? { code: icraDosyasiResult.errorCode, message: icraDosyasiResult.errorMessage } : null;
        if (!icraDosyasiResult.errorCode) {
          merged.icraDosyasiVar = icraDosyasiResult.icraDosyasiVar;
          merged.icraDosyasiList = icraDosyasiResult.icraDosyasiList;
          if (merged.errorCode === (cachedBorclu.icraDosyasiError && cachedBorclu.icraDosyasiError.code)) {
            merged.errorCode = null;
            merged.errorMessage = null;
          }
        }
        if (icraDosyasiResult.errorCode && !merged.errorCode) {
          merged.errorCode = icraDosyasiResult.errorCode;
          merged.errorMessage = icraDosyasiResult.errorMessage;
        }
      }

      borclular.push(merged);
    }

    const hasArac = borclular.some((b) => Array.isArray(b.aracList) && b.aracList.length > 0);
    const hasBanka = borclular.some((b) => Array.isArray(b.bankaList) && b.bankaList.length > 0);
    const hasTakbis = borclular.some((b) => Array.isArray(b.takbisList) && b.takbisList.length > 0);
    const hasIcraDosyasi = borclular.some((b) => b.icraDosyasiVar === true);

    return {
      ...cachedItem,
      input: parsed.raw,
      dosyaNo: `${parsed.dosyaYil}/${parsed.dosyaSira}`,
      birimId: firstCtx.birimId,
      birimAdi: firstCtx.birimAdi,
      success: true,
      status: 200,
      error: null,
      isMatch: hasArac || hasBanka || hasTakbis || hasIcraDosyasi,
      borclular,
      pendingTasks
    };
  };

  /** dosyaId'yi first.json içinde arar (page-runner-core.findByKeyDeep kullanır) */
  const findDosyaId = (json) => {
    if (!json) {
      return null;
    }
    const arr = Array.isArray(json) ? json : (Array.isArray(json.data) ? json.data : null);
    const first = arr && arr[0] ? arr[0] : (typeof json === "object" ? json : null);
    if (!first) {
      return null;
    }
    const candidates = [
      first.dosyaId,
      first.id,
      findByKeyDeep(first, "dosyaId")
    ];
    const found = candidates.find((c) => c !== null && c !== undefined && String(c).trim() !== "");
    return found !== undefined ? String(found).trim() : null;
  };

  // â”€â”€â”€ Ana workflow â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const runHacizWorkflow = async (requestId, settings, inputs) => {
    if (hacizRunState.isRunning) {
      window.postMessage({ __EWR_PAGE__: true, requestId, ok: false, error: "İşlem zaten çalışıyor." }, "*");
      return;
    }
    hacizRunState.isRunning    = true;
    hacizRunState.stopRequested = false;
    setPendingTakbisCount(0);

    const total   = inputs.length;
    const items   = [];
    let processed = 0;

    try {
      for (const input of inputs) {
        if (hacizRunState.stopRequested) {
          break;
        }

        let result;
        try {
          result = await processOneDosyaHaciz(settings, input, {
            setActiveQuery: (label, dosyaNo, kisi) => {
              setHacizActiveQuery(label, dosyaNo, kisi);
              emitHacizProgress(requestId, total, items, false);
            },
            clearActiveQuery: () => {
              clearHacizActiveQuery();
              emitHacizProgress(requestId, total, items, false);
            },
            notifyProgress: () => {
              emitHacizProgress(requestId, total, items, false);
            }
          });
        } catch (err) {
          result = {
            runMode: "haciz",
            input:   typeof input === "object" ? (input.dosyaNo || "") : String(input || ""),
            success: false,
            error:   String(err && err.message ? err.message : err),
            borclular: []
          };
        }

        items.push(result);
        processed += 1;

        emitHacizProgress(requestId, total, items, hacizRunState.stopRequested);
      }
    } finally {
      hacizRunState.isRunning    = false;
      hacizRunState.stopRequested = false;
      clearHacizActiveQuery();
      setPendingTakbisCount(0);
    }

    const stopped = processed < total;
    emitHacizProgress(requestId, total, items, stopped);

    window.postMessage(
      {
        __EWR_PAGE__: true,
        requestId,
        ok: true,
        result: {
          runMode:    "haciz",
          total,
          processed,
          matchCount: items.filter((x) => x.isMatch).length,
          stopped,
          items
        }
      },
      "*"
    );
  };

  const emitHacizProgress = (requestId, total, items, stopped = false) => {
    const hasErrorOrMatch = (x) =>
      x.isMatch ||
      (Array.isArray(x.borclular) && x.borclular.some((b) => b.errorCode || b.aracError || b.bankaError || b.takbisError || b.icraDosyasiError));
    const relevant = items
      .filter(hasErrorOrMatch)
      .map((x) => ({
        input:     x.input,
        borclular: x.borclular
      }));

    window.postMessage(
      {
        __EWR_HACIZ_PROGRESS__: true,
        requestId,
        progress: {
          runMode:    "haciz",
          total,
          processed:  items.length,
          matchCount: items.filter((x) => x.isMatch).length,
          matched:    relevant,
          stopped,
          activeQueryLabel: hacizRunState.activeQueryLabel,
          activeQueryDosyaNo: hacizRunState.activeQueryDosyaNo,
          activeQueryKisi: hacizRunState.activeQueryKisi,
          activeQueryStartedAt: hacizRunState.activeQueryStartedAt,
          pendingTakbisCount: hacizRunState.pendingTakbisCount
        }
      },
      "*"
    );
  };

  // â”€â”€â”€ Talep Evrakı Hazırlama â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

  const HACIZ_TALEP_LIMIT = 10;
  const getLimitedHacizCount = (count) => Math.min(Number(count) || 0, HACIZ_TALEP_LIMIT);
  const isTalepImzaErrorMessage = (message) =>
    typeof message === "string" && message.includes("değişiklik yapmadan imzalayıp göndermeniz gerekmektedir");

  const buildTalepBilgileri = (dosyaId, borclu, bankaHacizData, modes) => {
    const talepArray = [];
    let idx = 0;

    if (modes.includes("arac") && Array.isArray(borclu.aracList)) {
      for (const arac of borclu.aracList.slice(0, HACIZ_TALEP_LIMIT)) {
        talepArray.push({
          grupKodu: 0,
          talepKodu: 0,
          talepAdi: "Araç Haczi Talebi",
          talepKisaAdi: "Araç Haczi Talebi",
          talepMasrafi: 0,
          className: "AvukatTalepAracHacziDVO",
          postaMasrafId: 0,
          dosyaDurum: "A",
          sorguId: 0,
          plaka: arac.plakaSifreli || "",
          plakaYildizli: arac.plaka || "",
          hacizSerhi: 0,
          hacizSerhiText: "Haciz",
          masraf: 0,
          fields: [
            { id: "plakaYildizli", title: "Plaka" },
            { id: "hacizSerhiText", title: "Şerh Tipi" }
          ],
          id: idx++
        });
      }
    }

    if (modes.includes("banka") && Array.isArray(borclu.bankaList)) {
      const matchedBanks = borclu.bankaList.filter((bk) => bk.matchedId).slice(0, HACIZ_TALEP_LIMIT);
      if (matchedBanks.length > 0) {
        const hesapTurleri   = (Array.isArray(bankaHacizData) && Array.isArray(bankaHacizData[1])) ? bankaHacizData[1] : [];
        const hacizTurleri   = (Array.isArray(bankaHacizData) && Array.isArray(bankaHacizData[2])) ? bankaHacizData[2] : [];
        const istisnaTurleri = (Array.isArray(bankaHacizData) && Array.isArray(bankaHacizData[3])) ? bankaHacizData[3] : [];

        const defaultEvrak   = hacizTurleri[0]   || { value: "MZK",  name: "Haciz Müzekkeresi" };
        const defaultIstisna = istisnaTurleri[0]  || { value: "MAAS", name: "Maaş Hesabı Hariç" };
        const talepMasrafi   = 23.7;
        const normalizedDId  = normalizeJsonBodyValue(dosyaId);

        talepArray.push({
          grupKodu: 0,
          talepKodu: 4,
          talepAdi: "Banka Haczi Talebi",
          talepKisaAdi: "Banka Haczi Talebi",
          talepMasrafi,
          className: "AvukatTalepBankaHacziDVO",
          postaMasrafId: 3585,
          dosyaDurum: "A",
          dosyaId: normalizedDId,
          tarafList: "",
          bankaListStr: matchedBanks.map((bk) => bk.matchedIlgili).join(", "),
          bankaList:    matchedBanks.map((bk) => String(bk.matchedId)).join(","),
          hesapList:    hesapTurleri.map((h) => h.tktId).join(","),
          hesapListStr: hesapTurleri.map((h) => h.aciklama).join(", "),
          evrakAdi:     defaultEvrak.value,
          evrakAdiSTR:  defaultEvrak.name,
          haricAdi:     defaultIstisna.value,
          haricAdiSTR:  defaultIstisna.name,
          masraf: Math.round(talepMasrafi * matchedBanks.length * 100) / 100,
          fields: [
            { id: "bankaListStr", title: "Banka Listesi" },
            { id: "hesapListStr", title: "Hesap Listesi" },
            { id: "evrakAdiSTR",  title: "Evrak" },
            { id: "haricAdiSTR",  title: "Haciz" }
          ],
          id: idx++
        });
      }
    }

    if (modes.includes("takbis") && Array.isArray(borclu.takbisList)) {
      for (const t of borclu.takbisList.slice(0, HACIZ_TALEP_LIMIT)) {
        talepArray.push({
          grupKodu: 0,
          talepKodu: 2,
          talepAdi: "Gayrimenkul Haczi Talebi",
          talepKisaAdi: "Gayrimenkul Haczi Talebi",
          talepMasrafi: 0,
          className: "AvukatTalepGayrimenkulHacziDVO",
          postaMasrafId: 0,
          dosyaDurum: "A",
          sorguId: 0,
          il:              t.il || "",
          ilce:            t.ilce || "",
          mahalle:         t.mahalle || "",
          ada:             t.ada || "",
          parsel:          t.parsel || "",
          tasinmazId:      t.tasinmazId || 0,
          masraf:          0,
          bagimsizBolumid: t.bagimsizBolumid || 0,
          bagimsizBolum:   t.bagimsizBolum || "",
          fields: [
            { id: "il",             title: "İl" },
            { id: "ilce",           title: "İlçe" },
            { id: "mahalle",        title: "Mahalle" },
            { id: "ada",            title: "Ada" },
            { id: "parsel",         title: "Parsel" },
            { id: "bagimsizBolum",  title: "Bağımsız Bölüm" }
          ],
          id: idx++
        });
      }
    }

    if (modes.includes("icraDosyasi") && Array.isArray(borclu.icraDosyasiList)) {
      for (const d of borclu.icraDosyasiList.slice(0, HACIZ_TALEP_LIMIT)) {
        const targetDosyaId = String(d.dosyaId || "");
        const targetDosyaNo = String(d.dosyaNo || "");
        if (!targetDosyaId || !targetDosyaNo) {
          continue;
        }
        talepArray.push({
          grupKodu: 0,
          talepKodu: 7,
          talepAdi: "Alacaklı Olduğu Dosya",
          talepKisaAdi: "Alacaklı Olduğu Dosya",
          talepMasrafi: 0,
          className: "AvukatTalepAlacakliDosyaDVO",
          postaMasrafId: 0,
          dosyaDurum: "A",
          sorguId: 0,
          dosyaId: targetDosyaId,
          kisiKurumId: borclu.kisiKurumId,
          birimAdi: String(d.birimAdi || ""),
          dosyaNo: targetDosyaNo,
          dosyaTurKod: Number(d.dosyaTurKod) || 35,
          masraf: 0,
          fields: [
            { id: "birimAdi", title: "Birim Adı" },
            { id: "dosyaNo", title: "Dosya No" }
          ],
          id: idx++
        });
      }
    }

    return talepArray;
  };

  /** Multipart form-data olarak gönderme için statik evrak metadatası */
  const EVRAK_ITEMS_TEMPLATE = [{
    id: 1,
    evrakTuruOptionDVO: {
      tur: "ICR_AVUKAT_PORTAL_HACIZ_TALEP",
      label: "Haciz Talebi",
      mandatory: true,
      max: 1,
      ekEvrakMax: 2,
      sablonTurKodu: "",
      acceptTypeList: [".udf", ".UDF"],
      ekEvrakAcceptTypeList: [".udf", ".pdf", ".jpg", ".jpeg", ".png", ".tif", ".tiff", ".UDF", ".PDF", ".JPG", ".JPEG", ".PNG", ".TIF", ".TIFF"]
    },
    tur: "ICR_AVUKAT_PORTAL_HACIZ_TALEP",
    turAciklama: "Haciz Talebi",
    mandatory: true,
    file: {},
    path: "C:/fakepath/Talep.udf",
    kullaniciEvrakAciklama: "",
    parentId: -1,
    isVekalet: false,
    isVekaletBilgiFormu: false,
    fileId: 1
  }];

  const sendTalepForBorclu = async (item, borclu, settings, bankaHacizData, modes) => {
    const talepArray = buildTalepBilgileri(item.dosyaId, borclu, bankaHacizData, modes);
    if (talepArray.length === 0) {
      return { success: false, error: "Talep oluşturulacak veri yok.", talepCount: 0, masraf: 0 };
    }

    const totalMasraf = Math.round(talepArray.reduce((s, t) => s + (Number(t.masraf) || 0), 0) * 100) / 100;

    const normalizedDId = normalizeJsonBodyValue(item.dosyaId);

    const ctx = {
      dosyaYil:        item.dosyaNo.split("/")[0] || "",
      dosyaSira:       item.dosyaNo.split("/")[1] || "",
      birimId:         item.birimId  || settings.defaultBirimId  || "",
      birimAdi:        item.birimAdi || settings.defaultBirimAdi || "",
      dosyaId:         item.dosyaId,
      inputEncoded:    encodeURIComponent(item.dosyaNo),
      birimAdiEncoded: encodeURIComponent(item.birimAdi || settings.defaultBirimAdi || ""),
      dosyaDurum:      encodeURIComponent(settings.defaultDosyaDurum || "Açık"),
      dosyaDurumKod:   "0"
    };

    const baseHeaders = {
      ...(parseHeaders(settings.secondHeadersText, ctx) || {}),
      "X-Borclu": encodeURIComponent(borclu.borcluHeaderValue || "undefined")
    };

    // â”€â”€ Ortak Adım 1+2 işlemi â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    const executeTalepSteps = async (talepArr) => {
      // Adım 1: getIcraTalepEvrakHazirla.uyap â†’ UDF
      const step1Headers = { ...baseHeaders, "Content-Type": "application/json" };
      const step1Body = JSON.stringify({
        dosyaId:         normalizedDId,
        filename:        item.dosyaNo,
        kisiKurumId:     borclu.kisiKurumId,
        talepBilgileri:  JSON.stringify(talepArr)
      });

      const res = await runRequest(toAbsoluteUrl("/getIcraTalepEvrakHazirla.uyap"), "POST", step1Headers, step1Body);
      if (!res.ok || !res.text) {
        return { ok: false, error: `Evrak hazırlama başarısız (HTTP ${res.status})` };
      }

      // Adım 2: avukatIcraTalepEvrakiGonder.ajx â†’ multipart/form-data
      const tutar = Math.round(talepArr.reduce((s, t) => s + (Number(t.masraf) || 0), 0) * 100) / 100;
      const formData = new FormData();
      formData.append("file_1", new Blob([res.text], { type: "application/octet-stream" }), "Talep.udf");
      formData.append("items", JSON.stringify(EVRAK_ITEMS_TEMPLATE));
      formData.append("dosyaId", normalizedDId);
      formData.append("kisiKurumId", String(borclu.kisiKurumId));
      formData.append("tutar", String(tutar));
      formData.append("talepGrupId", "0");
      formData.append("talepBilgileri", JSON.stringify(talepArr));
      formData.append("vakifbankHesapBilgileri", "null");
      formData.append("vakifbankOdemeIstekBilgileri", "null");
      formData.append("smsSifre", "null");
      formData.append("odemeTipi", "7");

      const step2Headers = { ...baseHeaders };
      delete step2Headers["Content-Type"];

      const res2 = await fetch(toAbsoluteUrl("/avukatIcraTalepEvrakiGonder.ajx"), {
        method: "POST",
        headers: step2Headers,
        body: formData,
        credentials: "include"
      });
      const text = await res2.text();
      let json = null;
      try { json = JSON.parse(text); } catch { /* text/html yanıt olabilir */ }
      return { ok: res2.ok, status: res2.status, json };
    };

    // â”€â”€ Birleşik gönder â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    try {
      const combined = await executeTalepSteps(talepArray);
      if (!combined.ok) {
        return { success: false, error: combined.error || `HTTP ${combined.status}`, talepCount: talepArray.length, masraf: totalMasraf };
      }
      const resp = combined.json;

      // Başarılı
      if (resp && resp.type === "success") {
        return { success: true, status: combined.status, response: resp, message: resp.message || "", talepCount: talepArray.length, masraf: totalMasraf };
      }

      // "deÄŸişiklik yapmadan" hatası â†’ araç ve bankayı ayrı gönder
      const isSignError = resp && resp.type === "error" && isTalepImzaErrorMessage(resp.message);

      if (isSignError) {
        if (talepArray.length === 1) {
          const retried = await executeTalepSteps(talepArray.map((t, i) => ({ ...t, id: i })));
          if (retried.ok && retried.json && retried.json.type === "success") {
            return {
              success: true,
              status: retried.status,
              response: retried.json,
              message: retried.json.message || "",
              talepCount: talepArray.length,
              masraf: totalMasraf
            };
          }
          const retryMsg =
            (retried.json && retried.json.message) ||
            retried.error ||
            `HTTP ${retried.status}`;
          return {
            success: false,
            error: retryMsg,
            errorType: (retried.json && retried.json.type) || (resp && resp.type) || "error",
            status: retried.status || combined.status,
            response: retried.json || resp,
            talepCount: talepArray.length,
            masraf: totalMasraf
          };
        }

        const aracTalepler = talepArray.filter((t) => t.className === "AvukatTalepAracHacziDVO");
        const bankaTalepler = talepArray.filter((t) => t.className === "AvukatTalepBankaHacziDVO");
        const gayrimenkulTalepler = talepArray.filter((t) => t.className === "AvukatTalepGayrimenkulHacziDVO");
        const icraDosyasiTalepleri = talepArray.filter((t) => t.className === "AvukatTalepAlacakliDosyaDVO");
        const subResults = [];

        for (const subset of [aracTalepler, bankaTalepler, gayrimenkulTalepler, icraDosyasiTalepleri]) {
          if (subset.length === 0) { continue; }
          if (hacizRunState.stopRequested) { break; }
          try {
            const sub = await executeTalepSteps(subset.map((t, i) => ({ ...t, id: i })));
            if (sub.ok && sub.json && sub.json.type === "success") {
              subResults.push({ success: true, type: subset[0].className, message: sub.json.message || "" });
            } else {
              const msg = (sub.json && sub.json.message) ? sub.json.message : (sub.error || `HTTP ${sub.status}`);
              subResults.push({ success: false, type: subset[0].className, error: msg });
            }
          } catch (err) {
            subResults.push({ success: false, type: subset[0].className, error: String(err?.message || err) });
          }
        }

        const allOk = subResults.every((r) => r.success);
        const anyOk = subResults.some((r) => r.success);
        const errors = subResults.filter((r) => !r.success).map((r) => r.error);
        return {
          success:    allOk,
          partial:    anyOk && !allOk,
          status:     combined.status,
          response:   resp,
          message:    allOk ? "Ayrı gönderildi - tümü başarılı." : errors.join(" | "),
          talepCount: talepArray.length,
          masraf: totalMasraf,
          subResults
        };
      }

      // DiÄŸer hatalar
      const errMsg = (resp && resp.message) ? resp.message : "Bilinmeyen hata";
      return { success: false, error: errMsg, errorType: (resp && resp.type) || "error", status: combined.status, response: resp, talepCount: talepArray.length, masraf: totalMasraf };

    } catch (err) {
      return { success: false, error: String(err?.message || err), talepCount: talepArray.length, masraf: totalMasraf };
    }
  };

  const runHacizTalepWorkflow = async (requestId, settings, items, bankaHacizData) => {
    if (hacizRunState.isRunning) {
      window.postMessage({ __EWR_PAGE__: true, requestId, ok: false, error: "İşlem zaten çalışıyor." }, "*");
      return;
    }
    hacizRunState.isRunning     = true;
    hacizRunState.stopRequested = false;

    const modes = Array.isArray(settings.hacizModes) ? settings.hacizModes : ["arac"];
    const results  = [];
    let totalBorclu = 0;
    let processed   = 0;
    let successCount = 0;

    for (const item of items) {
      if (item.success && item.dosyaId && Array.isArray(item.borclular)) {
        totalBorclu += item.borclular.filter((b) => {
          const hasA = modes.includes("arac")  && Array.isArray(b.aracList)  && b.aracList.length > 0;
          const hasB = modes.includes("banka") && Array.isArray(b.bankaList) && b.bankaList.filter((bk) => bk.matchedId).length > 0;
          const hasT = modes.includes("takbis") && Array.isArray(b.takbisList) && b.takbisList.length > 0;
          const hasI = modes.includes("icraDosyasi") && Array.isArray(b.icraDosyasiList) && b.icraDosyasiList.length > 0;
          return hasA || hasB || hasT || hasI;
        }).length;
      }
    }

    const emitTalepProgress = () => {
      window.postMessage({
        __EWR_HACIZ_PROGRESS__: true,
        requestId,
        progress: {
          runMode:    "haciz",
          phase:      "talep",
          total:      totalBorclu,
          processed,
          matchCount: successCount,
          stopped:    false,
          talepResults: results
        }
      }, "*");
    };

    try {
      for (const item of items) {
        if (hacizRunState.stopRequested) { break; }
        if (!item.success || !item.dosyaId || !Array.isArray(item.borclular)) { continue; }

        for (const borclu of item.borclular) {
          if (hacizRunState.stopRequested) { break; }

          const hasA = modes.includes("arac")  && Array.isArray(borclu.aracList)  && borclu.aracList.length > 0;
          const hasB = modes.includes("banka") && Array.isArray(borclu.bankaList) && borclu.bankaList.filter((bk) => bk.matchedId).length > 0;
          const hasT = modes.includes("takbis") && Array.isArray(borclu.takbisList) && borclu.takbisList.length > 0;
          if (!hasA && !hasB && !hasT) { continue; }

          const result = await sendTalepForBorclu(item, borclu, settings, bankaHacizData, modes);
          processed++;
          if (result.success) { successCount++; }

          results.push({
            dosyaNo:  item.dosyaNo || item.input,
            kisi:     borclu.kisi,
            success:  result.success,
            partial:  !!result.partial,
            error:    result.error || null,
            message:  result.message || null,
            talepCount: result.talepCount,
            aracCount:   Array.isArray(borclu.aracList) ? getLimitedHacizCount(borclu.aracList.length) : 0,
            bankaCount:  Array.isArray(borclu.bankaList) ? getLimitedHacizCount(borclu.bankaList.filter((bk) => bk.matchedId).length) : 0,
            takbisCount: Array.isArray(borclu.takbisList) ? getLimitedHacizCount(borclu.takbisList.length) : 0,
            icraDosyasiCount: Array.isArray(borclu.icraDosyasiList) ? getLimitedHacizCount(borclu.icraDosyasiList.length) : 0,
            masraf:     result.masraf || 0,
            subResults: result.subResults || null
          });

          emitTalepProgress();
        }
      }
    } finally {
      hacizRunState.isRunning     = false;
      hacizRunState.stopRequested = false;
    }

    const stopped = processed < totalBorclu;

    window.postMessage({
      __EWR_PAGE__: true,
      requestId,
      ok: true,
      result: {
        runMode:      "haciz",
        phase:        "talep",
        total:        totalBorclu,
        processed,
        matchCount:   successCount,
        stopped,
        talepResults: results
      }
    }, "*");
  };

  // â”€â”€â”€ Birleşik Sorgu + Talep Workflow â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const runHacizFullWorkflow = async (requestId, settings, inputs, bankaHacizData, cachedQueryItems, cachedTalepResults) => {
    if (hacizRunState.isRunning) {
      window.postMessage({ __EWR_PAGE__: true, requestId, ok: false, error: "İşlem zaten çalışıyor." }, "*");
      return;
    }
    hacizRunState.isRunning     = true;
    hacizRunState.stopRequested = false;
    setPendingTakbisCount(0);

    const modes = Array.isArray(settings.hacizModes) ? settings.hacizModes : ["arac"];
    const total        = inputs.length;
    const talepResults = [];
    let processed      = 0;
    let queryMatch     = 0;
    let talepSuccess   = 0;
    let talepProcessed = 0;
    const pendingTakbisTasks = [];

    // â”€â”€ Cache kullan veya yeni sorgu at â”€â”€
    const useCache = Array.isArray(cachedQueryItems) && cachedQueryItems.length === inputs.length;
    const queryItems = [];
    const hasCoveredRequestedTalepModes = (prev, selectedModes) => {
      if (!prev || !Array.isArray(selectedModes) || selectedModes.length === 0) {
        return false;
      }
      const aracOk = !selectedModes.includes("arac") || (Number(prev.aracCount) || 0) > 0;
      const bankaOk = !selectedModes.includes("banka") || (Number(prev.bankaCount) || 0) > 0;
      const takbisOk = !selectedModes.includes("takbis") || (Number(prev.takbisCount) || 0) > 0;
      const icraDosyasiOk = !selectedModes.includes("icraDosyasi") || (Number(prev.icraDosyasiCount) || 0) > 0;
      return aracOk && bankaOk && takbisOk && icraDosyasiOk;
    };

    // â”€â”€ Ã–nceki başarılı talepleri takip et (tekrar göndermeyi önlemek için) â”€â”€
    const succeededTalepKeys = new Set();
    if (useCache && Array.isArray(cachedTalepResults)) {
      for (const prev of cachedTalepResults) {
        if (prev.success) {
          succeededTalepKeys.add(`${prev.dosyaNo || ""}|${prev.kisi || ""}`);
        }
      }
    }

    const emitFullProgress = () => {
      const hasErrorOrMatch = (x) =>
        x.isMatch ||
        (Array.isArray(x.borclular) && x.borclular.some((b) => b.errorCode || b.aracError || b.bankaError || b.takbisError || b.icraDosyasiError));
      const relevant = queryItems
        .filter(hasErrorOrMatch)
        .map((x) => ({ input: x.input, dosyaNo: x.dosyaNo, borclular: x.borclular }));

      window.postMessage({
        __EWR_HACIZ_PROGRESS__: true,
        requestId,
        progress: {
          runMode:       "haciz",
          phase:         "full",
          total,
          processed,
          matchCount:    queryMatch,
          stopped:       false,
          matched:       relevant,
          talepTotal:    talepProcessed + talepResults.length,
          talepProcessed,
          talepSuccess,
          talepResults,
          activeQueryLabel: hacizRunState.activeQueryLabel,
          activeQueryDosyaNo: hacizRunState.activeQueryDosyaNo,
          activeQueryKisi: hacizRunState.activeQueryKisi,
          activeQueryStartedAt: hacizRunState.activeQueryStartedAt,
          pendingTakbisCount: hacizRunState.pendingTakbisCount
        }
      }, "*");
    };

    const runTalepPass = async (selectedModes) => {
      for (const result of queryItems) {
        if (hacizRunState.stopRequested) { break; }
        if (!(result.success && result.dosyaId && Array.isArray(result.borclular))) { continue; }

        for (const borclu of result.borclular) {
          if (hacizRunState.stopRequested) { break; }
          if (borclu.takbisPending) { continue; }

          const hasA = selectedModes.includes("arac") && Array.isArray(borclu.aracList) && borclu.aracList.length > 0;
          const hasB = selectedModes.includes("banka") && Array.isArray(borclu.bankaList) && borclu.bankaList.filter((bk) => bk.matchedId).length > 0;
          const hasT = selectedModes.includes("takbis") && Array.isArray(borclu.takbisList) && borclu.takbisList.length > 0;
          const hasI = selectedModes.includes("icraDosyasi") && Array.isArray(borclu.icraDosyasiList) && borclu.icraDosyasiList.length > 0;
          if (!hasA && !hasB && !hasT && !hasI) { continue; }

          const talepKey = `${result.dosyaNo || result.input}|${borclu.kisi || ""}`;
          if (succeededTalepKeys.has(talepKey)) {
            const prev = [...talepResults, ...(Array.isArray(cachedTalepResults) ? cachedTalepResults : [])]
              .filter((p) => p.success && `${p.dosyaNo || ""}|${p.kisi || ""}` === talepKey)
              .slice(-1)[0];
            if (prev && hasCoveredRequestedTalepModes(prev, selectedModes)) {
              talepResults.push(prev);
              talepProcessed++;
              talepSuccess++;
              emitFullProgress();
              continue;
            }
          }

          let retryModes = selectedModes;
          const prevPartial = [...talepResults, ...(Array.isArray(cachedTalepResults) ? cachedTalepResults : [])]
            .filter((p) => p.partial && `${p.dosyaNo || ""}|${p.kisi || ""}` === talepKey)
            .slice(-1)[0];
          if (prevPartial && Array.isArray(prevPartial.subResults)) {
            const succeededTypes = new Set(
              prevPartial.subResults.filter((s) => s.success).map((s) =>
                s.type === "AvukatTalepAracHacziDVO" ? "arac" :
                s.type === "AvukatTalepGayrimenkulHacziDVO" ? "takbis" :
                s.type === "AvukatTalepAlacakliDosyaDVO" ? "icraDosyasi" : "banka"
              )
            );
            retryModes = selectedModes.filter((m) => !succeededTypes.has(m));
            if (retryModes.length === 0) {
              talepResults.push(prevPartial);
              talepProcessed++;
              emitFullProgress();
              continue;
            }
          }

          const talepResult = await sendTalepForBorclu(result, borclu, settings, bankaHacizData, retryModes);
          talepProcessed++;

          const shouldMergePrevPartial =
            !(isTalepImzaErrorMessage(talepResult.error) || isTalepImzaErrorMessage(talepResult.message));
          let mergedSubResults = talepResult.subResults || [];
          let mergedMasraf = talepResult.masraf || 0;
          let mergedTalepCount = talepResult.talepCount || 0;
          if (shouldMergePrevPartial && prevPartial && Array.isArray(prevPartial.subResults)) {
            const prevSucceeded = prevPartial.subResults.filter((s) => s.success);
            mergedSubResults = [...prevSucceeded, ...mergedSubResults];
            mergedMasraf += prevPartial.masraf || 0;
            mergedTalepCount += prevPartial.talepCount || 0;
          }
          const allSub = mergedSubResults.length > 0 && mergedSubResults.every((s) => s.success);
          const mergedSuccess = talepResult.success || allSub;
          if (mergedSuccess) {
            talepSuccess++;
            succeededTalepKeys.add(talepKey);
          }

          talepResults.push({
            dosyaNo: result.dosyaNo || result.input,
            kisi: borclu.kisi,
            success: mergedSuccess,
            partial: !mergedSuccess && mergedSubResults.some((s) => s.success),
            error: talepResult.error || null,
            message: talepResult.message || null,
            talepCount: mergedTalepCount,
            aracCount: hasA ? getLimitedHacizCount(borclu.aracList.length) : 0,
            bankaCount: hasB ? getLimitedHacizCount(borclu.bankaList.filter((bk) => bk.matchedId).length) : 0,
            takbisCount: hasT ? getLimitedHacizCount(borclu.takbisList.length) : 0,
            icraDosyasiCount: hasI ? getLimitedHacizCount(borclu.icraDosyasiList.length) : 0,
            masraf: mergedMasraf,
            subResults: mergedSubResults
          });
          emitFullProgress();
        }
      }
    };

    try {
      // â”€â”€ Sorgu aşaması (cache yoksa) â”€â”€
      if (!useCache) {
        let isFirstInput = true;
        for (const input of inputs) {
          if (hacizRunState.stopRequested) { break; }
          if (!isFirstInput) {
            await new Promise((r) => setTimeout(r, 3000));
            if (hacizRunState.stopRequested) { break; }
          }
          isFirstInput = false;

          let result;
          try {
            result = await processOneDosyaHaciz(settings, input, {
              setActiveQuery: (label, dosyaNo, kisi) => {
                setHacizActiveQuery(label, dosyaNo, kisi);
                emitFullProgress();
              },
              clearActiveQuery: () => {
                clearHacizActiveQuery();
                emitFullProgress();
              },
              notifyProgress: () => emitFullProgress(),
              allowBackgroundTakbis: true
            });
          } catch (err) {
            result = {
              runMode: "haciz",
              input:   typeof input === "object" ? (input.dosyaNo || "") : String(input || ""),
              success: false,
              error:   String(err && err.message ? err.message : err),
              borclular: []
            };
          }

          queryItems.push(result);
          if (Array.isArray(result.pendingTasks) && result.pendingTasks.length > 0) {
            pendingTakbisTasks.push(...result.pendingTasks);
          }
          delete result.pendingTasks;
          processed += 1;
          if (result.isMatch) { queryMatch++; }
          emitFullProgress();
        }
      } else {
        const cachedMap = new Map(cachedQueryItems.map((item) => [`${item.dosyaNo || item.input || ""}`, item]));
        let isFirstInput = true;
        for (const input of inputs) {
          if (hacizRunState.stopRequested) { break; }
          if (!isFirstInput) {
            await new Promise((r) => setTimeout(r, 3000));
            if (hacizRunState.stopRequested) { break; }
          }
          isFirstInput = false;

          const inputKey = typeof input === "object" ? (input.dosyaNo || "") : String(input || "");
          const cachedItem = cachedMap.get(inputKey) || null;
          let result;
          try {
            result = cachedItem
              ? await refreshCachedDosyaHaciz(settings, input, cachedItem, {
                  setActiveQuery: (label, dosyaNo, kisi) => {
                    setHacizActiveQuery(label, dosyaNo, kisi);
                    emitFullProgress();
                  },
                  clearActiveQuery: () => {
                    clearHacizActiveQuery();
                    emitFullProgress();
                  },
                  notifyProgress: () => emitFullProgress(),
                  allowBackgroundTakbis: true
                })
              : await processOneDosyaHaciz(settings, input, {
                  setActiveQuery: (label, dosyaNo, kisi) => {
                    setHacizActiveQuery(label, dosyaNo, kisi);
                    emitFullProgress();
                  },
                  clearActiveQuery: () => {
                    clearHacizActiveQuery();
                    emitFullProgress();
                  },
                  notifyProgress: () => emitFullProgress(),
                  allowBackgroundTakbis: true
                });
          } catch (err) {
            result = {
              runMode: "haciz",
              input:   inputKey,
              success: false,
              error:   String(err && err.message ? err.message : err),
              borclular: []
            };
          }

          queryItems.push(result);
          if (Array.isArray(result.pendingTasks) && result.pendingTasks.length > 0) {
            pendingTakbisTasks.push(...result.pendingTasks);
          }
          delete result.pendingTasks;
          processed += 1;
          if (result.isMatch) { queryMatch++; }
          emitFullProgress();
        }
      }

      await runTalepPass(modes.filter((mode) => mode !== "takbis"));
      if (pendingTakbisTasks.length > 0) {
        await Promise.allSettled(pendingTakbisTasks);
        for (const item of queryItems) {
          item.isMatch = Array.isArray(item.borclular) && item.borclular.some((b) =>
            (Array.isArray(b.aracList) && b.aracList.length > 0) ||
            (Array.isArray(b.bankaList) && b.bankaList.length > 0) ||
            (Array.isArray(b.takbisList) && b.takbisList.length > 0) ||
            b.icraDosyasiVar === true
          );
        }
        queryMatch = queryItems.filter((item) => item.isMatch).length;
        emitFullProgress();
      }
      if (modes.includes("takbis")) {
        await runTalepPass(["takbis"]);
      }
    } finally {
      hacizRunState.isRunning     = false;
      hacizRunState.stopRequested = false;
      clearHacizActiveQuery();
      setPendingTakbisCount(0);
    }

    const stopped = processed < total;

    window.postMessage({
      __EWR_PAGE__: true,
      requestId,
      ok: true,
      result: {
        runMode:      "haciz",
        phase:        "full",
        total,
        processed,
        matchCount:   queryMatch,
        stopped,
        items:        queryItems,
        modes,
        talepResults,
        talepProcessed,
        talepSuccess
      }
    }, "*");
  };

  // â”€â”€â”€ Mesaj dinleyici â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  window.addEventListener("message", (event) => {
    if (!event.data || event.source !== window) {
      return;
    }

    if (event.data.__EWR_EXT__ === true && event.data.type === "RUN_HACIZ") {
      const { requestId, settings, inputs } = event.data;
      runHacizWorkflow(requestId, settings, inputs).catch(() => {
        hacizRunState.isRunning = false;
      });
      return;
    }

    if (event.data.__EWR_EXT__ === true && event.data.type === "STOP_HACIZ") {
      hacizRunState.stopRequested = true;
      if (hacizRunState.activeRequestController) {
        try {
          hacizRunState.activeRequestController.abort();
        } catch {
        }
      }
      for (const controller of Array.from(hacizRunState.pendingTakbisControllers || [])) {
        try {
          controller.abort();
        } catch {
        }
      }
      return;
    }

    if (event.data.__EWR_EXT__ === true && event.data.type === "SEND_HACIZ_TALEP") {
      const { requestId, settings, items, bankaHacizData } = event.data;
      runHacizTalepWorkflow(requestId, settings, items, bankaHacizData).catch(() => {
        hacizRunState.isRunning = false;
      });
      return;
    }

    if (event.data.__EWR_EXT__ === true && event.data.type === "RUN_HACIZ_FULL") {
      const { requestId, settings, inputs, bankaHacizData, cachedQueryItems, cachedTalepResults } = event.data;
      runHacizFullWorkflow(requestId, settings, inputs, bankaHacizData, cachedQueryItems || null, cachedTalepResults || null).catch((err) => {
        hacizRunState.isRunning = false;
        window.postMessage({
          __EWR_PAGE__: true,
          requestId,
          ok: true,
          result: {
            runMode: "haciz",
            phase: "full",
            total: Array.isArray(inputs) ? inputs.length : 0,
            processed: 0,
            matchCount: 0,
            stopped: false,
            items: [],
            talepResults: [],
            talepProcessed: 0,
            talepSuccess: 0,
            error: String(err?.message || err)
          }
        }, "*");
      });
      return;
    }
  });
})();


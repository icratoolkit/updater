(() => {
  "use strict";

  if (window.__EWR_PR_HacizTalep) {
    return;
  }

  const { hacizRunState, normalizeJsonBodyValue, parseHeaders, runRequest, toAbsoluteUrl } = window.__EWR_PR_HacizCore;

  // ─── Talep Evrakı Hazırlama ────────────────────────────────────────────

  const HACIZ_TALEP_LIMIT = 10;
  const getLimitedHacizCount = (count) => Math.min(Number(count) || 0, HACIZ_TALEP_LIMIT);
  const isTalepImzaErrorMessage = (message) =>
    typeof message === "string" && message.includes("değişiklik yapmadan imzalayıp göndermeniz gerekmektedir");

  const buildTalepBilgileri = (dosyaId, borclu, bankaHacizData, modes) => {
    const talepArray = [];
    let idx = 0;

    if (modes.includes("arac") && Array.isArray(borclu.aracList)) {
      for (const arac of borclu.aracList.slice(0, HACIZ_TALEP_LIMIT)) {
        talepArray.push({
          grupKodu: 0,
          talepKodu: 0,
          talepAdi: "Araç Haczi Talebi",
          talepKisaAdi: "Araç Haczi Talebi",
          talepMasrafi: 0,
          className: "AvukatTalepAracHacziDVO",
          postaMasrafId: 0,
          dosyaDurum: "A",
          sorguId: 0,
          plaka: arac.plakaSifreli || "",
          plakaYildizli: arac.plaka || "",
          hacizSerhi: 0,
          hacizSerhiText: "Haciz",
          masraf: 0,
          fields: [
            { id: "plakaYildizli", title: "Plaka" },
            { id: "hacizSerhiText", title: "Şerh Tipi" }
          ],
          id: idx++
        });
      }
    }

    if (modes.includes("banka") && Array.isArray(borclu.bankaList)) {
      const matchedBanks = borclu.bankaList.filter((bk) => bk.matchedId).slice(0, HACIZ_TALEP_LIMIT);
      if (matchedBanks.length > 0) {
        const hesapTurleri = Array.isArray(bankaHacizData) && Array.isArray(bankaHacizData[1]) ? bankaHacizData[1] : [];
        const hacizTurleri = Array.isArray(bankaHacizData) && Array.isArray(bankaHacizData[2]) ? bankaHacizData[2] : [];
        const istisnaTurleri =
          Array.isArray(bankaHacizData) && Array.isArray(bankaHacizData[3]) ? bankaHacizData[3] : [];

        const defaultEvrak = hacizTurleri[0] || { value: "MZK", name: "Haciz Müzekkeresi" };
        const defaultIstisna = istisnaTurleri[0] || { value: "MAAS", name: "Maaş Hesabı Hariç" };
        const talepMasrafi = 28.7;
        const normalizedDId = normalizeJsonBodyValue(dosyaId);

        talepArray.push({
          grupKodu: 0,
          talepKodu: 4,
          talepAdi: "Banka Haczi Talebi",
          talepKisaAdi: "Banka Haczi Talebi",
          talepMasrafi,
          className: "AvukatTalepBankaHacziDVO",
          postaMasrafId: 3585,
          dosyaDurum: "A",
          dosyaId: normalizedDId,
          tarafList: "",
          bankaListStr: matchedBanks.map((bk) => bk.matchedIlgili).join(", "),
          bankaList: matchedBanks.map((bk) => String(bk.matchedId)).join(","),
          hesapList: hesapTurleri.map((h) => h.tktId).join(","),
          hesapListStr: hesapTurleri.map((h) => h.aciklama).join(", "),
          evrakAdi: defaultEvrak.value,
          evrakAdiSTR: defaultEvrak.name,
          haricAdi: defaultIstisna.value,
          haricAdiSTR: defaultIstisna.name,
          masraf: Math.round(talepMasrafi * matchedBanks.length * 100) / 100,
          fields: [
            { id: "bankaListStr", title: "Banka Listesi" },
            { id: "hesapListStr", title: "Hesap Listesi" },
            { id: "evrakAdiSTR", title: "Evrak" },
            { id: "haricAdiSTR", title: "Haciz" }
          ],
          id: idx++
        });
      }
    }

    if (modes.includes("takbis") && Array.isArray(borclu.takbisList)) {
      for (const t of borclu.takbisList.slice(0, HACIZ_TALEP_LIMIT)) {
        talepArray.push({
          grupKodu: 0,
          talepKodu: 2,
          talepAdi: "Gayrimenkul Haczi Talebi",
          talepKisaAdi: "Gayrimenkul Haczi Talebi",
          talepMasrafi: 0,
          className: "AvukatTalepGayrimenkulHacziDVO",
          postaMasrafId: 0,
          dosyaDurum: "A",
          sorguId: 0,
          il: t.il || "",
          ilce: t.ilce || "",
          mahalle: t.mahalle || "",
          ada: t.ada || "",
          parsel: t.parsel || "",
          tasinmazId: t.tasinmazId || 0,
          masraf: 0,
          bagimsizBolumid: t.bagimsizBolumid || 0,
          bagimsizBolum: t.bagimsizBolum || "",
          fields: [
            { id: "il", title: "İl" },
            { id: "ilce", title: "İlçe" },
            { id: "mahalle", title: "Mahalle" },
            { id: "ada", title: "Ada" },
            { id: "parsel", title: "Parsel" },
            { id: "bagimsizBolum", title: "Bağımsız Bölüm" }
          ],
          id: idx++
        });
      }
    }

    if (modes.includes("icraDosyasi") && Array.isArray(borclu.icraDosyasiList)) {
      for (const d of borclu.icraDosyasiList.slice(0, HACIZ_TALEP_LIMIT)) {
        const targetDosyaId = String(d.dosyaId || "");
        const targetDosyaNo = String(d.dosyaNo || "");
        if (!targetDosyaId || !targetDosyaNo) {
          continue;
        }
        talepArray.push({
          grupKodu: 0,
          talepKodu: 7,
          talepAdi: "Alacaklı Olduğu Dosya",
          talepKisaAdi: "Alacaklı Olduğu Dosya",
          talepMasrafi: 0,
          className: "AvukatTalepAlacakliDosyaDVO",
          postaMasrafId: 0,
          dosyaDurum: "A",
          sorguId: 0,
          dosyaId: targetDosyaId,
          kisiKurumId: borclu.kisiKurumId,
          birimAdi: String(d.birimAdi || ""),
          dosyaNo: targetDosyaNo,
          dosyaTurKod: Number(d.dosyaTurKod) || 35,
          masraf: 0,
          fields: [
            { id: "birimAdi", title: "Birim Adı" },
            { id: "dosyaNo", title: "Dosya No" }
          ],
          id: idx++
        });
      }
    }

    return talepArray;
  };

  /** Multipart form-data olarak gönderme için statik evrak metadatası */
  const EVRAK_ITEMS_TEMPLATE = [
    {
      id: 1,
      evrakTuruOptionDVO: {
        tur: "ICR_AVUKAT_PORTAL_HACIZ_TALEP",
        label: "Haciz Talebi",
        mandatory: true,
        max: 1,
        ekEvrakMax: 2,
        sablonTurKodu: "",
        acceptTypeList: [".udf", ".UDF"],
        ekEvrakAcceptTypeList: [
          ".udf",
          ".pdf",
          ".jpg",
          ".jpeg",
          ".png",
          ".tif",
          ".tiff",
          ".UDF",
          ".PDF",
          ".JPG",
          ".JPEG",
          ".PNG",
          ".TIF",
          ".TIFF"
        ]
      },
      tur: "ICR_AVUKAT_PORTAL_HACIZ_TALEP",
      turAciklama: "Haciz Talebi",
      mandatory: true,
      file: {},
      path: "C:/fakepath/Talep.udf",
      kullaniciEvrakAciklama: "",
      parentId: -1,
      isVekalet: false,
      isVekaletBilgiFormu: false,
      fileId: 1
    }
  ];

  const sendTalepForBorclu = async (item, borclu, settings, bankaHacizData, modes) => {
    const talepArray = buildTalepBilgileri(item.dosyaId, borclu, bankaHacizData, modes);
    if (talepArray.length === 0) {
      return { success: false, error: "Talep oluşturulacak veri yok.", talepCount: 0, masraf: 0 };
    }

    const totalMasraf = Math.round(talepArray.reduce((s, t) => s + (Number(t.masraf) || 0), 0) * 100) / 100;

    const normalizedDId = normalizeJsonBodyValue(item.dosyaId);

    const ctx = {
      dosyaYil: item.dosyaNo.split("/")[0] || "",
      dosyaSira: item.dosyaNo.split("/")[1] || "",
      birimId: item.birimId || settings.defaultBirimId || "",
      birimAdi: item.birimAdi || settings.defaultBirimAdi || "",
      dosyaId: item.dosyaId,
      inputEncoded: encodeURIComponent(item.dosyaNo),
      birimAdiEncoded: encodeURIComponent(item.birimAdi || settings.defaultBirimAdi || ""),
      dosyaDurum: encodeURIComponent(settings.defaultDosyaDurum || "Açık"),
      dosyaDurumKod: "0"
    };

    const baseHeaders = {
      ...(parseHeaders(settings.secondHeadersText, ctx) || {}),
      "X-Borclu": encodeURIComponent(borclu.borcluHeaderValue || "undefined")
    };

    // ─── Ortak Adım 1+2 işlemi ───────────────────────────────────────────
    const executeTalepSteps = async (talepArr) => {
      // Adım 1: getIcraTalepEvrakHazirla.uyap → UDF
      const step1Headers = { ...baseHeaders, "Content-Type": "application/json" };
      const step1Body = JSON.stringify({
        dosyaId: normalizedDId,
        filename: item.dosyaNo,
        kisiKurumId: borclu.kisiKurumId,
        talepBilgileri: JSON.stringify(talepArr)
      });

      const res = await runRequest(toAbsoluteUrl("/getIcraTalepEvrakHazirla.uyap"), "POST", step1Headers, step1Body);
      if (!res.ok || !res.text) {
        return { ok: false, error: `Evrak hazırlama başarısız (HTTP ${res.status})` };
      }

      // Adım 2: avukatIcraTalepEvrakiGonder.ajx → multipart/form-data
      const tutar = Math.round(talepArr.reduce((s, t) => s + (Number(t.masraf) || 0), 0) * 100) / 100;
      const formData = new FormData();
      formData.append("file_1", new Blob([res.text], { type: "application/octet-stream" }), "Talep.udf");
      formData.append("items", JSON.stringify(EVRAK_ITEMS_TEMPLATE));
      formData.append("dosyaId", normalizedDId);
      formData.append("kisiKurumId", String(borclu.kisiKurumId));
      formData.append("tutar", String(tutar));
      formData.append("talepGrupId", "0");
      formData.append("talepBilgileri", JSON.stringify(talepArr));
      formData.append("vakifbankHesapBilgileri", "null");
      formData.append("vakifbankOdemeIstekBilgileri", "null");
      formData.append("smsSifre", "null");
      formData.append("odemeTipi", "7");

      const step2Headers = { ...baseHeaders };
      delete step2Headers["Content-Type"];

      const res2 = await fetch(toAbsoluteUrl("/avukatIcraTalepEvrakiGonder.ajx"), {
        method: "POST",
        headers: step2Headers,
        body: formData,
        credentials: "include"
      });
      const text = await res2.text();
      let json = null;
      try {
        json = JSON.parse(text);
      } catch {
        /* text/html yanıt olabilir */
      }
      return { ok: res2.ok, status: res2.status, json };
    };

    // ─── Birleşik gönder ─────────────────────────────────────────────────
    try {
      const combined = await executeTalepSteps(talepArray);
      if (!combined.ok) {
        return {
          success: false,
          error: combined.error || `HTTP ${combined.status}`,
          talepCount: talepArray.length,
          masraf: totalMasraf
        };
      }
      const resp = combined.json;

      // Başarılı
      if (resp && resp.type === "success") {
        return {
          success: true,
          status: combined.status,
          response: resp,
          message: resp.message || "",
          talepCount: talepArray.length,
          masraf: totalMasraf
        };
      }

      // "değişiklik yapmadan" hatası → araç ve bankayı ayrı gönder
      const isSignError = resp && resp.type === "error" && isTalepImzaErrorMessage(resp.message);

      if (isSignError) {
        if (talepArray.length === 1) {
          const retried = await executeTalepSteps(talepArray.map((t, i) => ({ ...t, id: i })));
          if (retried.ok && retried.json && retried.json.type === "success") {
            return {
              success: true,
              status: retried.status,
              response: retried.json,
              message: retried.json.message || "",
              talepCount: talepArray.length,
              masraf: totalMasraf
            };
          }
          const retryMsg = (retried.json && retried.json.message) || retried.error || `HTTP ${retried.status}`;
          return {
            success: false,
            error: retryMsg,
            errorType: (retried.json && retried.json.type) || (resp && resp.type) || "error",
            status: retried.status || combined.status,
            response: retried.json || resp,
            talepCount: talepArray.length,
            masraf: totalMasraf
          };
        }

        const aracTalepler = talepArray.filter((t) => t.className === "AvukatTalepAracHacziDVO");
        const bankaTalepler = talepArray.filter((t) => t.className === "AvukatTalepBankaHacziDVO");
        const gayrimenkulTalepler = talepArray.filter((t) => t.className === "AvukatTalepGayrimenkulHacziDVO");
        const icraDosyasiTalepleri = talepArray.filter((t) => t.className === "AvukatTalepAlacakliDosyaDVO");
        const subResults = [];

        for (const subset of [aracTalepler, bankaTalepler, gayrimenkulTalepler, icraDosyasiTalepleri]) {
          if (subset.length === 0) {
            continue;
          }
          if (hacizRunState.stopRequested) {
            break;
          }
          try {
            const sub = await executeTalepSteps(subset.map((t, i) => ({ ...t, id: i })));
            if (sub.ok && sub.json && sub.json.type === "success") {
              subResults.push({ success: true, type: subset[0].className, message: sub.json.message || "" });
            } else {
              const msg = sub.json && sub.json.message ? sub.json.message : sub.error || `HTTP ${sub.status}`;
              subResults.push({ success: false, type: subset[0].className, error: msg });
            }
          } catch (err) {
            subResults.push({ success: false, type: subset[0].className, error: String(err?.message || err) });
          }
        }

        const allOk = subResults.every((r) => r.success);
        const anyOk = subResults.some((r) => r.success);
        const errors = subResults.filter((r) => !r.success).map((r) => r.error);
        return {
          success: allOk,
          partial: anyOk && !allOk,
          status: combined.status,
          response: resp,
          message: allOk ? "Ayrı gönderildi - tümü başarılı." : errors.join(" | "),
          talepCount: talepArray.length,
          masraf: totalMasraf,
          subResults
        };
      }

      // Diğer hatalar
      const errMsg = resp && resp.message ? resp.message : "Bilinmeyen hata";
      return {
        success: false,
        error: errMsg,
        errorType: (resp && resp.type) || "error",
        status: combined.status,
        response: resp,
        talepCount: talepArray.length,
        masraf: totalMasraf
      };
    } catch (err) {
      return { success: false, error: String(err?.message || err), talepCount: talepArray.length, masraf: totalMasraf };
    }
  };

  window.__EWR_PR_HacizTalep = {
    getLimitedHacizCount,
    isTalepImzaErrorMessage,
    sendTalepForBorclu
  };
})();

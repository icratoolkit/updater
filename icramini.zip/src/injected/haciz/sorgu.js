(() => {
  "use strict";

  if (window.__EWR_PR_HacizSorgu) {
    return;
  }

  const {
    applyJsonBodyTemplate,
    applyTemplate,
    buildBankMap,
    buildBorcluHeaderValue,
    findByKeyDeep,
    getBorcluAdi,
    hacizRunState,
    matchBankFromMap,
    normalizeJsonBodyValue,
    parseHeaders,
    parseInput,
    parseJsonSafe,
    runHacizQueryRequest,
    runRequest,
    setPendingTakbisCount,
    shouldReuseCachedMode,
    toAbsoluteUrl
  } = window.__EWR_PR_HacizCore;

  /**
   * Bir borçlu için araç sorgusu yapar.
   * @returns {{ kisi, kisiKurumId, aracList, sorguOk, sorguStatus }}
   */
  const sorguBorcluArac = async (dosyaId, borclu, baseHeaders, settings, secondCtx) => {
    const kisiKurumId = borclu.kisiKurumId;
    const borcluValue = buildBorcluHeaderValue(borclu);

    const headers = {
      ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
      "Content-Type": "application/json",
      "X-Borclu": encodeURIComponent(borcluValue)
    };

    const body = JSON.stringify({
      dosyaId: normalizeJsonBodyValue(dosyaId),
      kisiKurumId,
      pageIndex: 0
    });

    const url = toAbsoluteUrl("/borclu_bilgileri_goruntule_egm_brd.ajx");
    let aracList = [];
    let sorguOk = false;
    let sorguStatus = 0;
    let errorCode = null;
    let errorMessage = null;
    let cooldownUntil = 0;

    try {
      const queryRun = await runHacizQueryRequest(url, headers, body, {
        label: "Araç",
        codePrefix: "ARAC"
      });
      const res = queryRun.response;
      sorguOk = !!res.ok;
      sorguStatus = res.status;

      if (queryRun.timedOut) {
        errorCode = queryRun.timeoutErrorCode;
        errorMessage = queryRun.timeoutErrorMessage;
        cooldownUntil = Number(queryRun.cooldownUntil || 0);
      } else if (queryRun.emptyResponseExhausted) {
        errorCode = queryRun.emptyResponseErrorCode;
        errorMessage = queryRun.emptyResponseErrorMessage;
      } else if (res.ok && res.json) {
        if (res.json.errorCode) {
          errorCode = String(res.json.errorCode);
          errorMessage = String(res.json.error || "").trim();
        } else {
          const bilgileri = res.json.sorguSonucDVO || res.json;
          const aracBilgileri = bilgileri.aracBilgileri || bilgileri;
          if (Array.isArray(aracBilgileri.aracList)) {
            aracList = aracBilgileri.aracList.map((a) => ({
              plaka: String(a.plaka || ""),
              marka: String(a.marka || ""),
              model: String(a.model || ""),
              ticariAd: String(a.ticariAd || ""),
              renk: String(a.renk || ""),
              cins: String(a.cins || ""),
              plakaSifreli: String(a.plakaSifreli || ""),
              isMock: !!a.isMock
            }));
          } else {
            errorCode = "ARAC_INVALID_RESPONSE";
            errorMessage = "Araç sorgusunda beklenen veri yapısı gelmedi.";
          }
        }
      }
    } catch {
      // hata zaten sorguOk=false
    }

    const kisiAdi = getBorcluAdi(borclu);

    return {
      kisi: kisiAdi,
      tcKimlikNo: String((borclu.kisiTumDVO || {}).tcKimlikNo || (borclu.kurumDVO || {}).vergiNo || ""),
      kisiKurumId,
      aracList,
      sorguOk,
      sorguStatus,
      errorCode,
      errorMessage,
      cooldownUntil
    };
  };

  /**
   * Bir borçlu için banka sorgusu yapar.
   * @returns {{ kisi, kisiKurumId, bankaList, sorguOk, sorguStatus, errorCode, errorMessage }}
   */
  const sorguBorcluBanka = async (dosyaId, borclu, settings, secondCtx, bankMap) => {
    const kisiKurumId = borclu.kisiKurumId;
    const borcluValue = buildBorcluHeaderValue(borclu);

    const headers = {
      ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
      "Content-Type": "application/json",
      "X-Borclu": encodeURIComponent(borcluValue)
    };

    const body = JSON.stringify({
      dosyaId: normalizeJsonBodyValue(dosyaId),
      kisiKurumId
    });

    const url = toAbsoluteUrl("/borclu_bilgileri_goruntule_banka.ajx");
    let bankaList = [];
    let sorguOk = false;
    let sorguStatus = 0;
    let errorCode = null;
    let errorMessage = null;
    let cooldownUntil = 0;

    try {
      const queryRun = await runHacizQueryRequest(url, headers, body, {
        label: "Banka",
        codePrefix: "BANKA"
      });
      const res = queryRun.response;
      sorguOk = !!res.ok;
      sorguStatus = res.status;

      if (queryRun.timedOut) {
        errorCode = queryRun.timeoutErrorCode;
        errorMessage = queryRun.timeoutErrorMessage;
        cooldownUntil = Number(queryRun.cooldownUntil || 0);
      } else if (queryRun.emptyResponseExhausted) {
        errorCode = queryRun.emptyResponseErrorCode;
        errorMessage = queryRun.emptyResponseErrorMessage;
      } else if (res.ok && res.json) {
        if (res.json.errorCode) {
          errorCode = String(res.json.errorCode);
          errorMessage = String(res.json.error || "").trim();
        } else if (Array.isArray(res.json.sorguSonucDVO)) {
          bankaList = res.json.sorguSonucDVO.map((s) => {
            const match = matchBankFromMap(String(s.bankaAdi || ""), bankMap);
            return {
              bankaAdi: String(s.bankaAdi || ""),
              eftKodu: s.eftKodu != null ? Number(s.eftKodu) : null,
              matchedId: match ? match.ilgiliKisiIlkKisiKurumId : null,
              matchedIlgili: match ? match.ilgili : null
            };
          });
        } else {
          errorCode = "BANKA_INVALID_RESPONSE";
          errorMessage = "Banka sorgusunda beklenen veri yapısı gelmedi.";
        }
      }
    } catch {
      // hata zaten sorguOk=false
    }

    const kisiAdi = getBorcluAdi(borclu);

    return {
      kisi: kisiAdi,
      tcKimlikNo: String((borclu.kisiTumDVO || {}).tcKimlikNo || (borclu.kurumDVO || {}).vergiNo || ""),
      kisiKurumId,
      bankaList,
      sorguOk,
      sorguStatus,
      errorCode,
      errorMessage,
      cooldownUntil
    };
  };

  /**
   * Bir borçlu için takbis (gayrimenkul) sorgusu yapar.
   * @returns {{ kisi, kisiKurumId, takbisList, sorguOk, sorguStatus, errorCode, errorMessage }}
   */
  const sorguBorcluTakbis = async (dosyaId, borclu, settings, secondCtx) => {
    const kisiKurumId = borclu.kisiKurumId;
    const borcluValue = buildBorcluHeaderValue(borclu);

    const headers = {
      ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
      "Content-Type": "application/json",
      "X-Borclu": encodeURIComponent(borcluValue)
    };

    const body = JSON.stringify({
      dosyaId: normalizeJsonBodyValue(dosyaId),
      kisiKurumId
    });

    const url = toAbsoluteUrl("/borclu_bilgileri_goruntule_takbis.ajx");
    let takbisList = [];
    let sorguOk = false;
    let sorguStatus = 0;
    let errorCode = null;
    let errorMessage = null;
    let cooldownUntil = 0;

    try {
      const queryRun = await runHacizQueryRequest(url, headers, body, {
        label: "Takbis",
        codePrefix: "TAKBIS"
      });
      const res = queryRun.response;
      sorguOk = !!res.ok;
      sorguStatus = res.status;

      if (queryRun.timedOut) {
        errorCode = queryRun.timeoutErrorCode;
        errorMessage = queryRun.timeoutErrorMessage;
        cooldownUntil = Number(queryRun.cooldownUntil || 0);
      } else if (queryRun.emptyResponseExhausted) {
        errorCode = queryRun.emptyResponseErrorCode;
        errorMessage = queryRun.emptyResponseErrorMessage;
      } else if (res.ok && res.json) {
        if (res.json.errorCode) {
          errorCode = String(res.json.errorCode);
          errorMessage = String(res.json.error || "").trim();
        } else if (
          typeof res.json.sorguSonucDVO === "string" &&
          res.json.sorguSonucDVO.toLocaleLowerCase("tr-TR").includes("taşınmaz kaydı yok")
        ) {
          takbisList = [];
        } else if (res.json.hasError === true && !Array.isArray(res.json.sorguSonucDVO)) {
          errorCode = "TAKBIS_ERROR";
          errorMessage = "Takbis sorgusunda hata olu\u015ftu.";
        } else if (Array.isArray(res.json.sorguSonucDVO)) {
          takbisList = res.json.sorguSonucDVO
            .map((s) => {
              const t = (s && (s.tasinmazDVO || s.tasinmaz || s)) || null;
              if (!t || typeof t !== "object") {
                return null;
              }
              const bb = t.bagimsizBolum || t.bagimsizBolumDVO || {};
              const bagimsizBolumId =
                bb.bagimsizBolumid || bb.bagimsizBolumId || t.bagimsizBolumid || t.bagimsizBolumId || 0;
              const bagimsizBolumStr = bagimsizBolumId
                ? `Kat: ${bb.kat || t.kat || ""},No: ${bb.no || t.no || ""},Arsa Pay: ${bb.arsaPay || t.arsaPay || ""},Arsa Payda: ${bb.arsaPayda || t.arsaPayda || ""},Kat Mülkiyeti: ${bb.bagimsizBolumTip || t.bagimsizBolumTip || ""}`
                : String(t.bagimsizBolum || "");
              const row = {
                tasinmazId: t.tasinmazId || t.id || 0,
                il: String(t.il || ""),
                ilce: String(t.ilce || ""),
                mahalle: String(t.mahalle || t.mahalleKoy || ""),
                ada: String(t.ada || ""),
                parsel: String(t.parsel || ""),
                nitelik: String(t.nitelik || t.cinsi || ""),
                yuzolcum: t.yuzolcum || t.alan || 0,
                bagimsizBolumid: bagimsizBolumId || 0,
                bagimsizBolum: bagimsizBolumStr
              };
              return row.tasinmazId ||
                row.il ||
                row.ilce ||
                row.mahalle ||
                row.ada ||
                row.parsel ||
                row.nitelik ||
                row.bagimsizBolum
                ? row
                : null;
            })
            .filter(Boolean);
        } else {
          errorCode = "TAKBIS_INVALID_RESPONSE";
          errorMessage = "Takbis sorgusunda beklenen veri yapısı gelmedi.";
        }
      }
    } catch {
      // hata zaten sorguOk=false
    }

    const kisiAdi = getBorcluAdi(borclu);

    return {
      kisi: kisiAdi,
      tcKimlikNo: String((borclu.kisiTumDVO || {}).tcKimlikNo || (borclu.kurumDVO || {}).vergiNo || ""),
      kisiKurumId,
      takbisList,
      sorguOk,
      sorguStatus,
      errorCode,
      errorMessage,
      cooldownUntil
    };
  };

  const sorguBorcluTakbisBeklemede = (dosyaId, borclu, settings, secondCtx) => {
    const kisiKurumId = borclu.kisiKurumId;
    const borcluValue = buildBorcluHeaderValue(borclu);

    const headers = {
      ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
      "Content-Type": "application/json",
      "X-Borclu": encodeURIComponent(borcluValue)
    };

    const body = JSON.stringify({
      dosyaId: normalizeJsonBodyValue(dosyaId),
      kisiKurumId
    });

    const url = toAbsoluteUrl("/borclu_bilgileri_goruntule_takbis.ajx");
    const controller = new AbortController();
    hacizRunState.pendingTakbisControllers.add(controller);

    return (async () => {
      let takbisList = [];
      let sorguOk = false;
      let sorguStatus = 0;
      let errorCode = null;
      let errorMessage = null;

      try {
        const response = await fetch(url, {
          method: "POST",
          headers,
          body,
          credentials: "include",
          signal: controller.signal
        });
        const text = await response.text();
        const json = parseJsonSafe(text);
        sorguOk = !!response.ok;
        sorguStatus = response.status;

        if (typeof text !== "string" || text.trim().length === 0) {
          errorCode = "TAKBIS_EMPTY_RESPONSE";
          errorMessage = "Takbis sorgusunda servis boş yanıt döndü.";
        } else if (response.ok && json) {
          if (json.errorCode) {
            errorCode = String(json.errorCode);
            errorMessage = String(json.error || "").trim();
          } else if (
            typeof json.sorguSonucDVO === "string" &&
            json.sorguSonucDVO.toLocaleLowerCase("tr-TR").includes("taşınmaz kaydı yok")
          ) {
            takbisList = [];
          } else if (json.hasError === true && !Array.isArray(json.sorguSonucDVO)) {
            errorCode = "TAKBIS_ERROR";
            errorMessage = "Takbis sorgusunda hata oluştu.";
          } else if (Array.isArray(json.sorguSonucDVO)) {
            takbisList = json.sorguSonucDVO
              .map((s) => {
                const t = (s && (s.tasinmazDVO || s.tasinmaz || s)) || null;
                if (!t || typeof t !== "object") {
                  return null;
                }
                const bb = t.bagimsizBolum || t.bagimsizBolumDVO || {};
                const bagimsizBolumId =
                  bb.bagimsizBolumid || bb.bagimsizBolumId || t.bagimsizBolumid || t.bagimsizBolumId || 0;
                const bagimsizBolumStr = bagimsizBolumId
                  ? `Kat: ${bb.kat || t.kat || ""},No: ${bb.no || t.no || ""},Arsa Pay: ${bb.arsaPay || t.arsaPay || ""},Arsa Payda: ${bb.arsaPayda || t.arsaPayda || ""},Kat Mülkiyeti: ${bb.bagimsizBolumTip || t.bagimsizBolumTip || ""}`
                  : String(t.bagimsizBolum || "");
                const row = {
                  tasinmazId: t.tasinmazId || t.id || 0,
                  il: String(t.il || ""),
                  ilce: String(t.ilce || ""),
                  mahalle: String(t.mahalle || t.mahalleKoy || ""),
                  ada: String(t.ada || ""),
                  parsel: String(t.parsel || ""),
                  nitelik: String(t.nitelik || t.cinsi || ""),
                  yuzolcum: t.yuzolcum || t.alan || 0,
                  bagimsizBolumid: bagimsizBolumId || 0,
                  bagimsizBolum: bagimsizBolumStr
                };
                return row.tasinmazId ||
                  row.il ||
                  row.ilce ||
                  row.mahalle ||
                  row.ada ||
                  row.parsel ||
                  row.nitelik ||
                  row.bagimsizBolum
                  ? row
                  : null;
              })
              .filter(Boolean);
          } else {
            errorCode = "TAKBIS_INVALID_RESPONSE";
            errorMessage = "Takbis sorgusunda beklenen veri yapısı gelmedi.";
          }
        }
      } catch (error) {
        if (error && error.name === "AbortError") {
          throw new Error("STOP_REQUESTED");
        }
        throw error;
      } finally {
        hacizRunState.pendingTakbisControllers.delete(controller);
      }

      const kisiAdi = getBorcluAdi(borclu);
      return {
        kisi: kisiAdi,
        tcKimlikNo: String((borclu.kisiTumDVO || {}).tcKimlikNo || (borclu.kurumDVO || {}).vergiNo || ""),
        kisiKurumId,
        takbisList,
        sorguOk,
        sorguStatus,
        errorCode,
        errorMessage,
        cooldownUntil: 0
      };
    })();
  };

  /**
   * Bir borçlu için icra dosyası sorgusu yapar.
   * @returns {{ kisi, kisiKurumId, icraDosyasiVar, sorguOk, sorguStatus, errorCode, errorMessage }}
   */
  const sorguBorcluIcraDosyasi = async (dosyaId, borclu, settings, secondCtx) => {
    const kisiKurumId = borclu.kisiKurumId;
    const borcluValue = buildBorcluHeaderValue(borclu);

    const headers = {
      ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
      "Content-Type": "application/json",
      "X-Borclu": encodeURIComponent(borcluValue)
    };

    const body = JSON.stringify({
      dosyaId: normalizeJsonBodyValue(dosyaId),
      kisiKurumId
    });

    const url = toAbsoluteUrl("/borclu_bilgileri_goruntule_icra_dosyasi.ajx");
    let icraDosyasiVar = false;
    let icraDosyasiList = [];
    let sorguOk = false;
    let sorguStatus = 0;
    let errorCode = null;
    let errorMessage = null;
    let cooldownUntil = 0;

    try {
      const queryRun = await runHacizQueryRequest(url, headers, body, {
        label: "İcra dosyası",
        codePrefix: "ICRA_DOSYASI"
      });
      const res = queryRun.response;
      sorguOk = !!res.ok;
      sorguStatus = res.status;

      if (queryRun.timedOut) {
        errorCode = queryRun.timeoutErrorCode;
        errorMessage = queryRun.timeoutErrorMessage;
        cooldownUntil = Number(queryRun.cooldownUntil || 0);
      } else if (queryRun.emptyResponseExhausted) {
        errorCode = queryRun.emptyResponseErrorCode;
        errorMessage = queryRun.emptyResponseErrorMessage;
      } else if (res.ok && res.json) {
        if (res.json.errorCode) {
          errorCode = String(res.json.errorCode);
          errorMessage = String(res.json.error || "").trim();
        } else if (res.json.sorguSonucu === false || (res.json.hasError === false && res.json.hasData === false)) {
          icraDosyasiVar = false;
          icraDosyasiList = [];
        } else if (res.json.hasError && res.json.hasData !== false) {
          errorCode = "ICRA_DOSYASI_ERROR";
          errorMessage = "\u0130cra dosyas\u0131 sorgusunda hata olu\u015ftu.";
        } else if (Array.isArray(res.json.sorguSonucDVO)) {
          icraDosyasiList = res.json.sorguSonucDVO.map((s) => ({
            dosyaId: String((s && s.dosyaId) || ""),
            dosyaNo: String((s && s.dosyaNo) || ""),
            birimAdi: String((s && s.birimAdi) || ""),
            dosyaTurKod: Number((s && (s.dosyaTurKodu ?? s.dosyaTurKod)) || 0),
            dosyaDurumuAciklama: String((s && s.dosyaDurumuAciklama) || ""),
            dosyaTurKoduAciklama: String((s && s.dosyaTurKoduAciklama) || (s && s.dosyaTurAd) || ""),
            takipTurAciklamasi: String((s && s.takipTurAciklamasi) || ""),
            takipYoluAciklamasi: String((s && s.takipYoluAciklamasi) || ""),
            tarafRolu: String((s && s.tarafRolu) || "")
          }));
          icraDosyasiVar = icraDosyasiList.length > 0;
        } else {
          errorCode = "ICRA_DOSYASI_INVALID_RESPONSE";
          errorMessage = "İcra dosyası sorgusunda beklenen veri yapısı gelmedi.";
        }
      }
    } catch {
      // hata zaten sorguOk=false
    }

    const kisiAdi = getBorcluAdi(borclu);

    return {
      kisi: kisiAdi,
      tcKimlikNo: String((borclu.kisiTumDVO || {}).tcKimlikNo || (borclu.kurumDVO || {}).vergiNo || ""),
      kisiKurumId,
      icraDosyasiVar,
      icraDosyasiList,
      sorguOk,
      sorguStatus,
      errorCode,
      errorMessage,
      cooldownUntil
    };
  };

  /**
   * Tek bir dosya için borçlu listesini alır, her borçlu için araç sorgular.
   */
  const processOneDosyaHaciz = async (settings, input, progressHooks = null) => {
    const parsed = parseInput(input);

    const firstCtx = {
      dosyaYil: parsed.dosyaYil,
      dosyaSira: parsed.dosyaSira,
      birimId: parsed.birimId || settings.defaultBirimId || "",
      birimAdi: parsed.birimAdi || settings.defaultBirimAdi || "",
      inputEncoded: encodeURIComponent(parsed.raw),
      birimAdiEncoded: encodeURIComponent(parsed.birimAdi || settings.defaultBirimAdi || ""),
      dosyaDurum: encodeURIComponent(settings.defaultDosyaDurum || "Acik"),
      dosyaDurumKod: String(settings.dosyaHesabiDosyaDurumKod || "0")
    };

    // ─── 1. Birinci istek: dosya arama → dosyaId ─────────────────────────
    const firstUrl = toAbsoluteUrl(applyTemplate(settings.firstEndpointPath, firstCtx));
    const firstMethod = String(settings.firstMethod || "POST").toUpperCase();
    const firstHeaders = parseHeaders(settings.firstHeadersText, firstCtx);
    const firstBody = applyJsonBodyTemplate(settings.firstBodyTemplate, firstCtx);

    const first = await runRequest(firstUrl, firstMethod, firstHeaders, firstBody);
    if (!first.ok || !first.json) {
      return {
        runMode: "haciz",
        input: parsed.raw,
        success: false,
        status: first.status,
        error: `Birinci istek başarısız (HTTP ${first.status})`,
        borclular: []
      };
    }

    const dosyaId = findDosyaId(first.json);
    if (!dosyaId) {
      return {
        runMode: "haciz",
        input: parsed.raw,
        success: false,
        status: first.status,
        error: "dosyaId bulunamadı.",
        borclular: []
      };
    }

    const secondCtx = {
      ...firstCtx,
      dosyaId
    };

    // ─── 2. borçlu listesi ───────────────────────────────────────────────
    const borcluHeaders = {
      ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
      "Content-Type": "application/json",
      "X-Borclu": "undefined"
    };
    const borcluBody = JSON.stringify({ dosyaId: normalizeJsonBodyValue(dosyaId) });
    const borcluUrl = toAbsoluteUrl("/dosya_borclu_list.ajx");
    const borcluRes = await runRequest(borcluUrl, "POST", borcluHeaders, borcluBody);

    if (!borcluRes.ok || !Array.isArray(borcluRes.json)) {
      return {
        runMode: "haciz",
        input: parsed.raw,
        success: false,
        status: borcluRes.status,
        error: `Borçlu listesi alınamadı (HTTP ${borcluRes.status})`,
        borclular: []
      };
    }

    const borcluListesi = borcluRes.json.filter((b) => b && typeof b.kisiKurumId !== "undefined");

    //  3. Her borçlu için seçilen sorguları çalıştır
    const modes = Array.isArray(settings.hacizModes) ? settings.hacizModes : ["arac"];
    const bankMap = modes.includes("banka") ? buildBankMap(settings.bankaHacizParams) : null;

    const borclular = [];
    const pendingTasks = [];
    for (const borclu of borcluListesi) {
      if (hacizRunState.stopRequested) {
        break;
      }

      const kisiAdi = getBorcluAdi(borclu);

      const merged = {
        kisi: kisiAdi,
        tcKimlikNo: String((borclu.kisiTumDVO || {}).tcKimlikNo || (borclu.kurumDVO || {}).vergiNo || ""),
        kisiKurumId: borclu.kisiKurumId,
        borcluHeaderValue: buildBorcluHeaderValue(borclu),
        aracList: [],
        bankaList: [],
        takbisList: [],
        takbisPending: false,
        icraDosyasiVar: false,
        icraDosyasiList: [],
        aracCooldownUntil: 0,
        bankaCooldownUntil: 0,
        takbisCooldownUntil: 0,
        icraDosyasiCooldownUntil: 0,
        aracQueryDone: false,
        bankaQueryDone: false,
        takbisQueryDone: false,
        icraDosyasiQueryDone: false,
        errorCode: null,
        errorMessage: null,
        aracError: null,
        bankaError: null,
        takbisError: null,
        icraDosyasiError: null
      };

      if (modes.includes("arac")) {
        progressHooks?.setActiveQuery?.("Araç", parsed.raw, kisiAdi);
        const aracResult = await sorguBorcluArac(dosyaId, borclu, borcluHeaders, settings, secondCtx);
        progressHooks?.clearActiveQuery?.();
        merged.aracList = aracResult.aracList;
        merged.aracQueryDone = true;
        merged.aracCooldownUntil = Number(aracResult.cooldownUntil || 0);
        if (aracResult.errorCode) {
          merged.aracError = { code: aracResult.errorCode, message: aracResult.errorMessage };
          if (!merged.errorCode) {
            merged.errorCode = aracResult.errorCode;
            merged.errorMessage = aracResult.errorMessage;
          }
        }
        if (aracResult.errorCode === "PRTL_AVKT_10104") {
          borclular.push(merged);
          continue;
        }
      }

      if (hacizRunState.stopRequested) {
        borclular.push(merged);
        break;
      }

      if (modes.includes("banka")) {
        progressHooks?.setActiveQuery?.("Banka", parsed.raw, kisiAdi);
        const bankaResult = await sorguBorcluBanka(dosyaId, borclu, settings, secondCtx, bankMap);
        progressHooks?.clearActiveQuery?.();
        merged.bankaList = bankaResult.bankaList;
        merged.bankaQueryDone = true;
        merged.bankaCooldownUntil = Number(bankaResult.cooldownUntil || 0);
        if (bankaResult.errorCode) {
          merged.bankaError = { code: bankaResult.errorCode, message: bankaResult.errorMessage };
          if (!merged.errorCode) {
            merged.errorCode = bankaResult.errorCode;
            merged.errorMessage = bankaResult.errorMessage;
          }
        }
      }

      if (hacizRunState.stopRequested) {
        borclular.push(merged);
        break;
      }

      if (modes.includes("takbis")) {
        if (progressHooks?.allowBackgroundTakbis === true) {
          merged.takbisPending = true;
          setPendingTakbisCount(hacizRunState.pendingTakbisCount + 1);
          progressHooks?.notifyProgress?.();
          const pendingTask = sorguBorcluTakbisBeklemede(dosyaId, borclu, settings, secondCtx)
            .then((takbisResult) => {
              merged.takbisPending = false;
              merged.takbisList = takbisResult.takbisList;
              merged.takbisQueryDone = true;
              merged.takbisCooldownUntil = 0;
              merged.takbisError = takbisResult.errorCode
                ? { code: takbisResult.errorCode, message: takbisResult.errorMessage }
                : null;
              if (takbisResult.errorCode && !merged.errorCode) {
                merged.errorCode = takbisResult.errorCode;
                merged.errorMessage = takbisResult.errorMessage;
              }
              if (!takbisResult.errorCode && merged.errorCode === (merged.takbisError && merged.takbisError.code)) {
                merged.errorCode = null;
                merged.errorMessage = null;
              }
            })
            .catch((error) => {
              merged.takbisPending = false;
              merged.takbisQueryDone = true;
              merged.takbisError = {
                code: "TAKBIS_ABORTED",
                message: String(error?.message || error || "Takbis sorgusu durduruldu.")
              };
              if (!merged.errorCode) {
                merged.errorCode = merged.takbisError.code;
                merged.errorMessage = merged.takbisError.message;
              }
            })
            .finally(() => {
              setPendingTakbisCount(hacizRunState.pendingTakbisCount - 1);
              progressHooks?.notifyProgress?.();
            });
          pendingTasks.push(pendingTask);
        } else {
          progressHooks?.setActiveQuery?.("Takbis", parsed.raw, kisiAdi);
          const takbisResult = await sorguBorcluTakbis(dosyaId, borclu, settings, secondCtx);
          progressHooks?.clearActiveQuery?.();
          merged.takbisList = takbisResult.takbisList;
          merged.takbisQueryDone = true;
          merged.takbisCooldownUntil = Number(takbisResult.cooldownUntil || 0);
          if (takbisResult.errorCode) {
            merged.takbisError = { code: takbisResult.errorCode, message: takbisResult.errorMessage };
            if (!merged.errorCode) {
              merged.errorCode = takbisResult.errorCode;
              merged.errorMessage = takbisResult.errorMessage;
            }
          }
        }
      }

      if (hacizRunState.stopRequested) {
        borclular.push(merged);
        break;
      }

      if (modes.includes("icraDosyasi")) {
        progressHooks?.setActiveQuery?.("İcra Dosyası", parsed.raw, kisiAdi);
        const icraDosyasiResult = await sorguBorcluIcraDosyasi(dosyaId, borclu, settings, secondCtx);
        progressHooks?.clearActiveQuery?.();
        merged.icraDosyasiVar = icraDosyasiResult.icraDosyasiVar;
        merged.icraDosyasiList = icraDosyasiResult.icraDosyasiList;
        merged.icraDosyasiQueryDone = true;
        merged.icraDosyasiCooldownUntil = Number(icraDosyasiResult.cooldownUntil || 0);
        if (icraDosyasiResult.errorCode) {
          merged.icraDosyasiError = { code: icraDosyasiResult.errorCode, message: icraDosyasiResult.errorMessage };
          if (!merged.errorCode) {
            merged.errorCode = icraDosyasiResult.errorCode;
            merged.errorMessage = icraDosyasiResult.errorMessage;
          }
        }
      }

      borclular.push(merged);
    }

    const hasArac = borclular.some((b) => b.aracList && b.aracList.length > 0);
    const hasBanka = borclular.some((b) => b.bankaList && b.bankaList.length > 0);
    const hasTakbis = borclular.some((b) => b.takbisList && b.takbisList.length > 0);
    const hasIcraDosyasi = borclular.some((b) => b.icraDosyasiVar === true);

    return {
      runMode: "haciz",
      input: parsed.raw,
      dosyaId,
      dosyaNo: `${parsed.dosyaYil}/${parsed.dosyaSira}`,
      birimId: firstCtx.birimId,
      birimAdi: firstCtx.birimAdi,
      success: true,
      status: 200,
      error: null,
      isMatch: hasArac || hasBanka || hasTakbis || hasIcraDosyasi,
      borclular,
      pendingTasks
    };
  };

  const refreshCachedDosyaHaciz = async (settings, input, cachedItem, progressHooks = null) => {
    if (!cachedItem || !cachedItem.dosyaId || !Array.isArray(cachedItem.borclular)) {
      return processOneDosyaHaciz(settings, input);
    }

    const parsed = parseInput(input);
    const firstCtx = {
      dosyaYil: parsed.dosyaYil,
      dosyaSira: parsed.dosyaSira,
      birimId: parsed.birimId || settings.defaultBirimId || cachedItem.birimId || "",
      birimAdi: parsed.birimAdi || settings.defaultBirimAdi || cachedItem.birimAdi || "",
      inputEncoded: encodeURIComponent(parsed.raw),
      birimAdiEncoded: encodeURIComponent(parsed.birimAdi || settings.defaultBirimAdi || cachedItem.birimAdi || ""),
      dosyaDurum: encodeURIComponent(settings.defaultDosyaDurum || "Acik"),
      dosyaDurumKod: String(settings.dosyaHesabiDosyaDurumKod || "0")
    };
    const secondCtx = {
      ...firstCtx,
      dosyaId: cachedItem.dosyaId
    };
    const borcluHeaders = {
      ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
      "Content-Type": "application/json",
      "X-Borclu": "undefined"
    };
    const modes = Array.isArray(settings.hacizModes) ? settings.hacizModes : ["arac"];
    const bankMap = modes.includes("banka") ? buildBankMap(settings.bankaHacizParams) : null;
    const borclular = [];
    const pendingTasks = [];

    for (const cachedBorclu of cachedItem.borclular) {
      if (hacizRunState.stopRequested) {
        break;
      }

      const merged = {
        ...cachedBorclu,
        kisi: String(cachedBorclu.kisi || ""),
        tcKimlikNo: String(cachedBorclu.tcKimlikNo || ""),
        borcluHeaderValue: buildBorcluHeaderValue(cachedBorclu)
      };

      if (modes.includes("arac") && !shouldReuseCachedMode("arac", cachedBorclu)) {
        progressHooks?.setActiveQuery?.("Araç", parsed.raw, merged.kisi);
        const aracResult = await sorguBorcluArac(cachedItem.dosyaId, cachedBorclu, borcluHeaders, settings, secondCtx);
        progressHooks?.clearActiveQuery?.();
        merged.aracQueryDone = true;
        merged.aracCooldownUntil = Number(aracResult.cooldownUntil || 0);
        merged.aracError = aracResult.errorCode
          ? { code: aracResult.errorCode, message: aracResult.errorMessage }
          : null;
        if (!aracResult.errorCode) {
          merged.aracList = aracResult.aracList;
        }
        if (!merged.aracError && merged.errorCode === (cachedBorclu.aracError && cachedBorclu.aracError.code)) {
          merged.errorCode = null;
          merged.errorMessage = null;
        }
        if (aracResult.errorCode) {
          merged.errorCode = aracResult.errorCode;
          merged.errorMessage = aracResult.errorMessage;
        }
        if (aracResult.errorCode === "PRTL_AVKT_10104") {
          borclular.push(merged);
          continue;
        }
      }

      if (modes.includes("banka") && !shouldReuseCachedMode("banka", cachedBorclu)) {
        progressHooks?.setActiveQuery?.("Banka", parsed.raw, merged.kisi);
        const bankaResult = await sorguBorcluBanka(cachedItem.dosyaId, cachedBorclu, settings, secondCtx, bankMap);
        progressHooks?.clearActiveQuery?.();
        merged.bankaQueryDone = true;
        merged.bankaCooldownUntil = Number(bankaResult.cooldownUntil || 0);
        merged.bankaError = bankaResult.errorCode
          ? { code: bankaResult.errorCode, message: bankaResult.errorMessage }
          : null;
        if (!bankaResult.errorCode) {
          merged.bankaList = bankaResult.bankaList;
          if (merged.errorCode === (cachedBorclu.bankaError && cachedBorclu.bankaError.code)) {
            merged.errorCode = null;
            merged.errorMessage = null;
          }
        }
        if (bankaResult.errorCode && !merged.errorCode) {
          merged.errorCode = bankaResult.errorCode;
          merged.errorMessage = bankaResult.errorMessage;
        }
      }

      if (modes.includes("takbis") && !shouldReuseCachedMode("takbis", cachedBorclu)) {
        if (progressHooks?.allowBackgroundTakbis === true) {
          merged.takbisPending = true;
          setPendingTakbisCount(hacizRunState.pendingTakbisCount + 1);
          progressHooks?.notifyProgress?.();
          const pendingTask = sorguBorcluTakbisBeklemede(cachedItem.dosyaId, cachedBorclu, settings, secondCtx)
            .then((takbisResult) => {
              merged.takbisPending = false;
              merged.takbisQueryDone = true;
              merged.takbisCooldownUntil = 0;
              merged.takbisError = takbisResult.errorCode
                ? { code: takbisResult.errorCode, message: takbisResult.errorMessage }
                : null;
              if (!takbisResult.errorCode) {
                merged.takbisList = takbisResult.takbisList;
                if (merged.errorCode === (cachedBorclu.takbisError && cachedBorclu.takbisError.code)) {
                  merged.errorCode = null;
                  merged.errorMessage = null;
                }
              }
              if (takbisResult.errorCode && !merged.errorCode) {
                merged.errorCode = takbisResult.errorCode;
                merged.errorMessage = takbisResult.errorMessage;
              }
            })
            .catch((error) => {
              merged.takbisPending = false;
              merged.takbisQueryDone = true;
              merged.takbisError = {
                code: "TAKBIS_ABORTED",
                message: String(error?.message || error || "Takbis sorgusu durduruldu.")
              };
              if (!merged.errorCode) {
                merged.errorCode = merged.takbisError.code;
                merged.errorMessage = merged.takbisError.message;
              }
            })
            .finally(() => {
              setPendingTakbisCount(hacizRunState.pendingTakbisCount - 1);
              progressHooks?.notifyProgress?.();
            });
          pendingTasks.push(pendingTask);
        } else {
          progressHooks?.setActiveQuery?.("Takbis", parsed.raw, merged.kisi);
          const takbisResult = await sorguBorcluTakbis(cachedItem.dosyaId, cachedBorclu, settings, secondCtx);
          progressHooks?.clearActiveQuery?.();
          merged.takbisQueryDone = true;
          merged.takbisCooldownUntil = Number(takbisResult.cooldownUntil || 0);
          merged.takbisError = takbisResult.errorCode
            ? { code: takbisResult.errorCode, message: takbisResult.errorMessage }
            : null;
          if (!takbisResult.errorCode) {
            merged.takbisList = takbisResult.takbisList;
            if (merged.errorCode === (cachedBorclu.takbisError && cachedBorclu.takbisError.code)) {
              merged.errorCode = null;
              merged.errorMessage = null;
            }
          }
          if (takbisResult.errorCode && !merged.errorCode) {
            merged.errorCode = takbisResult.errorCode;
            merged.errorMessage = takbisResult.errorMessage;
          }
        }
      }

      if (modes.includes("icraDosyasi") && !shouldReuseCachedMode("icraDosyasi", cachedBorclu)) {
        progressHooks?.setActiveQuery?.("İcra Dosyası", parsed.raw, merged.kisi);
        const icraDosyasiResult = await sorguBorcluIcraDosyasi(cachedItem.dosyaId, cachedBorclu, settings, secondCtx);
        progressHooks?.clearActiveQuery?.();
        merged.icraDosyasiQueryDone = true;
        merged.icraDosyasiCooldownUntil = Number(icraDosyasiResult.cooldownUntil || 0);
        merged.icraDosyasiError = icraDosyasiResult.errorCode
          ? { code: icraDosyasiResult.errorCode, message: icraDosyasiResult.errorMessage }
          : null;
        if (!icraDosyasiResult.errorCode) {
          merged.icraDosyasiVar = icraDosyasiResult.icraDosyasiVar;
          merged.icraDosyasiList = icraDosyasiResult.icraDosyasiList;
          if (merged.errorCode === (cachedBorclu.icraDosyasiError && cachedBorclu.icraDosyasiError.code)) {
            merged.errorCode = null;
            merged.errorMessage = null;
          }
        }
        if (icraDosyasiResult.errorCode && !merged.errorCode) {
          merged.errorCode = icraDosyasiResult.errorCode;
          merged.errorMessage = icraDosyasiResult.errorMessage;
        }
      }

      borclular.push(merged);
    }

    const hasArac = borclular.some((b) => Array.isArray(b.aracList) && b.aracList.length > 0);
    const hasBanka = borclular.some((b) => Array.isArray(b.bankaList) && b.bankaList.length > 0);
    const hasTakbis = borclular.some((b) => Array.isArray(b.takbisList) && b.takbisList.length > 0);
    const hasIcraDosyasi = borclular.some((b) => b.icraDosyasiVar === true);

    return {
      ...cachedItem,
      input: parsed.raw,
      dosyaNo: `${parsed.dosyaYil}/${parsed.dosyaSira}`,
      birimId: firstCtx.birimId,
      birimAdi: firstCtx.birimAdi,
      success: true,
      status: 200,
      error: null,
      isMatch: hasArac || hasBanka || hasTakbis || hasIcraDosyasi,
      borclular,
      pendingTasks
    };
  };

  /** dosyaId'yi first.json içinde arar (page-runner-core.findByKeyDeep kullanır) */
  const findDosyaId = (json) => {
    if (!json) {
      return null;
    }
    const arr = Array.isArray(json) ? json : Array.isArray(json.data) ? json.data : null;
    const first = arr && arr[0] ? arr[0] : typeof json === "object" ? json : null;
    if (!first) {
      return null;
    }
    const candidates = [first.dosyaId, first.id, findByKeyDeep(first, "dosyaId")];
    const found = candidates.find((c) => c !== null && c !== undefined && String(c).trim() !== "");
    return found !== undefined ? String(found).trim() : null;
  };

  window.__EWR_PR_HacizSorgu = {
    processOneDosyaHaciz,
    refreshCachedDosyaHaciz
  };
})();

(() => {
  const C = window.__EWR_PR_Core;
  const E = window.__EWR_PR_Extract;
  const Progress = window.__EWR_PR_QueryProgress;
  const Talep = window.__EWR_PR_QueryTalep;
  const DosyaHesabi = window.__EWR_PR_QueryDosyaHesabi;
  const Kesinlestirme = window.__EWR_PR_QueryKesinlestirme;

  if (!C || !E || !Progress || !Talep || !DosyaHesabi || !Kesinlestirme) {
    console.error("page-runner.js: çekirdek, çıkarım ve query/ modülleri önce yüklenmeli.");
    return;
  }

  if (window.__EWR_PAGE_LOADED__ === true && window.__EWR_PAGE_TOKEN__ === C.__EWR_PAGE_TOKEN__) {
    return;
  }
  window.__EWR_PAGE_LOADED__ = true;
  window.__EWR_PAGE_TOKEN__ = C.__EWR_PAGE_TOKEN__;

  const {
    handledRequestIds,
    runState,
    DEFAULT_SETTINGS,
    parseInput,
    applyTemplate,
    applyJsonBodyTemplate,
    parseHeaders,
    toAbsoluteUrl,
    applyDosyaDurumKodToRequestBody,
    normalizeJsonBodyValue,
    findByKeyDeep,
    numberOrNull,
    extractYatanPara,
    extractDosyaHesapSummary,
    runRequest,
    normalizeText
  } = C;

  const { collectAlacakliNameKeys, extractReddiyatKalanMiktari, extractReddiyatTahsilatKalemleri } = E;
  const { setActiveStep, clearActiveStep, emitProgress } = Progress;
  const { sendGenelTalep, sendIbanDegisikligiTalebi } = Talep;
  const { collectDosyaHesabiData, computeDosyaHesabiTotals, createDosyaHesabiDebug } = DosyaHesabi;
  const { collectTebligBilgileri, createBarcodeDebug } = Kesinlestirme;

  // Girdiler arasında bekle; UYAP arka arkaya istekte hata dönebiliyor.
  const INPUT_DELAY_MS = 1000;
  const HANDLED_REQUEST_ID_LIMIT = 2000;

  const NO_TIMEOUT_RUN_MODES = new Set([
    "normal",
    "datedCurrentMonth",
    "reddiyat",
    "kalan",
    "talepMasrafAvansIadesi",
    "talepBorcluOdemeAktar",
    "talepKesinlestirme",
    "talepEvrakiOlustur"
  ]);

  // Bu modlarda dosya kapalı da olabilir; açıkta bulunamazsa kapalıda aranır.
  const KAPALI_FALLBACK_RUN_MODES = new Set([
    "reddiyat",
    "talepMasrafAvansIadesi",
    "talepBorcluOdemeAktar",
    "talepKesinlestirme",
    "talepEvrakiOlustur"
  ]);

  const GENEL_TALEP_RUN_MODES = new Set(["talepMasrafAvansIadesi", "talepBorcluOdemeAktar", "talepKesinlestirme"]);

  const createRowState = (settings) => ({
    secondUrl: null,
    secondStatus: null,
    secondOk: true,
    secondText: null,
    secondJson: null,
    thirdUrl: null,
    fourthUrl: null,

    yatanPara: null,
    reddiyatKalanMiktari: null,
    reddiyatKalemleri: [],
    kalanBorc: null,
    kalanQueryThreshold: null,

    talepTarihi: null,
    asilAlacak: null,
    gecmisGunFaizi: null,
    vekaletPulu: null,
    tebligatGideri: null,
    pesinHarc: null,
    basvurmaHarci: null,
    vekaletSuretHarci: null,
    tahsilHarciHesap: null,
    takipteKesinlesenMiktar: null,
    vekaletUcretiDosyaHesap: null,
    icraFaizTutari: null,
    danismanlikUcreti: null,
    toplamBorcHesap: null,
    masrafToplami: null,
    vazgecmeHesabi: null,
    anaPara: null,
    hakEdis: null,
    indirimliToplamBorc: null,
    indirimYeniAsilAlacak: null,
    indirimYeniDanismanlikUcreti: null,
    indirimTutari: numberOrNull(settings.dosyaHesabiIndirimTutari) ?? 0,
    dosyaHesabiHesapTuru: String(settings.dosyaHesabiHesapTuru || "normal"),

    aracMahrumiyetBedeli: null,
    aracMahrumiyetFaizi: null,
    mahkemeVekaletUcreti: null,
    mahkemeVekaletUcretiFaizi: null,
    mahkemeYargilamaGiderleri: null,
    mahkemeYargilamaGiderleriFaizi: null,
    mahkemeHarclari: null,
    mahkemeHarclariFaizi: null,
    ygIcraFaiz: null,
    harcIcraFaiz: null,
    ivuIcraFaiz: null,

    takibinTuruAciklama: "",
    isIlamliTakip: false,
    dosyaKesinlesmeMs: 0,
    dosyaHesabiOk: true,
    dosyaHesabiStatus: null,
    // İlgili aşama çalışmasa da sonuçta bulunmalı; popup bu alanları okuyor.
    dosyaHesabiDebug: createDosyaHesabiDebug(),
    evrakPayloadForTracking: null,

    barcode: null,
    barcodeSource: null,
    barcodeEvrakId: null,
    tebligTarihi: null,
    tebligYediGunSonrasi: null,
    tebligDetaylari: [],
    pttUrl: null,
    borcaItirazSayisi: 0,
    borcluSayisi: 0,
    itirazKontrolTarihi: null,
    barcodeDebug: createBarcodeDebug()
  });

  const collectReddiyatData = async ({ parsed, settings, secondCtx, firstJson, requestOptions, isDosyaKapali }) => {
    const patch = { secondUrl: null, secondStatus: null, secondOk: true, secondText: null, secondJson: null };

    try {
      setActiveStep(parsed.raw, "2. istek: Taraf bilgileri");
      const tarafHeaders = parseHeaders(settings.thirdHeadersText, secondCtx);
      const tarafBody = JSON.stringify({ dosyaId: normalizeJsonBodyValue(secondCtx.dosyaId || "") });
      const taraf = await runRequest(
        toAbsoluteUrl("/dosya_taraf_bilgileri_brd.ajx"),
        "POST",
        tarafHeaders,
        tarafBody,
        requestOptions
      );
      const alacakliNameKeys = taraf.ok && Array.isArray(taraf.json) ? collectAlacakliNameKeys(taraf.json) : new Set();

      patch.secondUrl = toAbsoluteUrl("/dosya_tahsilat_reddiyat_bilgileri_brd.ajx");
      setActiveStep(parsed.raw, "3. istek: Reddiyat bilgileri");
      const reddiyat = await runRequest(
        patch.secondUrl,
        "POST",
        parseHeaders(settings.thirdHeadersText, secondCtx),
        JSON.stringify({
          dosyaId: normalizeJsonBodyValue(secondCtx.dosyaId || ""),
          dosyaTurKod: Number(findByKeyDeep(firstJson, "dosyaTurKod")) || 35
        }),
        requestOptions
      );

      patch.secondStatus = reddiyat.status;
      patch.secondOk = !!reddiyat.ok;
      patch.secondText = reddiyat.text;
      patch.secondJson = reddiyat.json;

      if (reddiyat.ok && reddiyat.json && typeof reddiyat.json === "object") {
        patch.reddiyatKalanMiktari = extractReddiyatKalanMiktari(reddiyat.json, parsed.raw);
        patch.reddiyatKalemleri = extractReddiyatTahsilatKalemleri(reddiyat.json, parsed.raw, alacakliNameKeys, {
          isDosyaKapali
        });
      }
    } catch (error) {
      patch.secondOk = false;
      patch.secondText = error && error.message ? String(error.message) : null;
    }

    return patch;
  };

  const collectYatanParaData = async ({ parsed, settings, secondCtx, runMode, requestOptions }) => {
    setActiveStep(parsed.raw, "2. istek: Dosya hesap bilgileri");
    const secondUrl = toAbsoluteUrl(applyTemplate(settings.secondEndpointPath, secondCtx));
    const second = await runRequest(
      secondUrl,
      String(settings.secondMethod || "POST").toUpperCase(),
      parseHeaders(settings.secondHeadersText, secondCtx),
      applyJsonBodyTemplate(settings.secondBodyTemplate, secondCtx),
      requestOptions
    );

    const summary = second.json ? extractDosyaHesapSummary(second.json) : null;
    return {
      secondUrl,
      secondStatus: second.status,
      secondOk: !!second.ok,
      secondText: second.text,
      secondJson: second.json,
      yatanPara: second.json ? extractYatanPara(second.json, runMode, settings) : null,
      kalanBorc: summary ? summary.bakiyeBorcMiktari : null
    };
  };

  const resolveMatch = (row, { runMode, enableBarcode, settings }) => {
    if (runMode === "dosyaHesabi") {
      return { isMatch: !!row.talepTarihi, kalanQueryThreshold: row.kalanQueryThreshold };
    }
    if (runMode === "reddiyat") {
      return {
        isMatch: Array.isArray(row.reddiyatKalemleri) && row.reddiyatKalemleri.length > 0,
        kalanQueryThreshold: row.kalanQueryThreshold
      };
    }
    if (runMode === "kalan") {
      const parsedThreshold = Number(String(settings.kalanQueryAmount || "").replace(",", "."));
      const isValidThreshold = Number.isFinite(parsedThreshold) && parsedThreshold >= 0;
      return {
        kalanQueryThreshold: isValidThreshold ? parsedThreshold : null,
        isMatch: isValidThreshold && row.kalanBorc !== null && Number(row.kalanBorc) < parsedThreshold
      };
    }
    if (enableBarcode === true) {
      // Kesinleşme: en az bir tebligat olgunlaşmış ve hiç borca itiraz yok.
      const tebligOlgun = row.tebligDetaylari.some((detay) => !!detay.isMatch);
      return { isMatch: tebligOlgun && row.borcaItirazSayisi === 0, kalanQueryThreshold: row.kalanQueryThreshold };
    }
    return {
      isMatch: row.secondOk && row.yatanPara !== null && row.yatanPara > 0,
      kalanQueryThreshold: row.kalanQueryThreshold
    };
  };

  const buildResult = (row, { parsed, runMode, enableBarcode, birimAdi, dosyaId, firstUrl, first, isMatch }) => ({
    runMode,
    input: parsed.raw,
    birimAdi: String(birimAdi || ""),
    dosyaYil: parsed.dosyaYil,
    dosyaSira: parsed.dosyaSira,
    success: runMode === "dosyaHesabi" ? row.dosyaHesabiOk : enableBarcode === true ? true : row.secondOk,
    status:
      runMode === "dosyaHesabi" ? row.dosyaHesabiStatus : enableBarcode === true ? first.status : row.secondStatus,
    isMatch,
    yatanPara: row.yatanPara,
    reddiyatKalanMiktari: row.reddiyatKalanMiktari,
    reddiyatKalemleri: row.reddiyatKalemleri,
    kalanBorc: row.kalanBorc,
    kalanQueryThreshold: row.kalanQueryThreshold,
    talepTarihi: row.talepTarihi,
    asilAlacak: row.asilAlacak,
    gecmisGunFaizi: row.gecmisGunFaizi,
    vekaletPulu: row.vekaletPulu,
    tebligatGideri: row.tebligatGideri,
    pesinHarc: row.pesinHarc,
    basvurmaHarci: row.basvurmaHarci,
    vekaletSuretHarci: row.vekaletSuretHarci,
    tahsilHarciHesap: row.tahsilHarciHesap,
    takipteKesinlesenMiktar: row.takipteKesinlesenMiktar,
    vekaletUcretiDosyaHesap: row.vekaletUcretiDosyaHesap,
    icraFaizTutari: row.icraFaizTutari,
    danismanlikUcreti: row.danismanlikUcreti,
    toplamBorcHesap: row.toplamBorcHesap,
    masrafToplami: row.masrafToplami,
    vazgecmeHesabi: row.vazgecmeHesabi,
    anaPara: row.anaPara,
    hakEdis: row.hakEdis,
    indirimTutari: row.indirimTutari,
    indirimYeniAsilAlacak: row.indirimYeniAsilAlacak,
    indirimYeniDanismanlikUcreti: row.indirimYeniDanismanlikUcreti,
    indirimliToplamBorc: row.indirimliToplamBorc,
    dosyaHesabiHesapTuru: row.dosyaHesabiHesapTuru,
    aracMahrumiyetBedeli: row.aracMahrumiyetBedeli,
    aracMahrumiyetFaizi: row.aracMahrumiyetFaizi,
    mahkemeVekaletUcreti: row.mahkemeVekaletUcreti,
    mahkemeVekaletUcretiFaizi: row.mahkemeVekaletUcretiFaizi,
    mahkemeYargilamaGiderleri: row.mahkemeYargilamaGiderleri,
    mahkemeYargilamaGiderleriFaizi: row.mahkemeYargilamaGiderleriFaizi,
    mahkemeHarclari: row.mahkemeHarclari,
    mahkemeHarclariFaizi: row.mahkemeHarclariFaizi,
    ygIcraFaiz: row.ygIcraFaiz,
    harcIcraFaiz: row.harcIcraFaiz,
    ivuIcraFaiz: row.ivuIcraFaiz,
    takibinTuruAciklama: row.takibinTuruAciklama,
    isIlamliTakip: row.isIlamliTakip,
    dosyaHesabiDebug: row.dosyaHesabiDebug,
    barcode: row.barcode,
    barcodeSource: row.barcodeSource,
    barcodeEvrakId: row.barcodeEvrakId,
    tebligTarihi: row.tebligTarihi,
    tebligYediGunSonrasi: row.tebligYediGunSonrasi,
    tebligDetaylari: row.tebligDetaylari,
    borcaItirazSayisi: row.borcaItirazSayisi,
    borcluSayisi: row.borcluSayisi,
    itirazKontrolTarihi: row.itirazKontrolTarihi,
    pttUrl: row.pttUrl,
    barcodeDebug: row.barcodeDebug,
    dosyaId: String(dosyaId),
    firstUrl,
    secondUrl: row.secondUrl,
    thirdUrl: row.thirdUrl,
    fourthUrl: row.fourthUrl,
    responseText: enableBarcode === true ? null : row.secondText,
    responseJson: enableBarcode === true ? null : row.secondJson,
    error:
      runMode === "dosyaHesabi"
        ? row.dosyaHesabiOk
          ? null
          : `Evrak listesi istegi HTTP ${row.dosyaHesabiStatus}`
        : enableBarcode === true
          ? null
          : row.secondOk
            ? null
            : `${runMode === "reddiyat" ? "Reddiyat" : "Ikinci"} istek HTTP ${row.secondStatus}`
  });

  const runOne = async (inputValue, settings, runMode, enableBarcode) => {
    const parsed = parseInput(inputValue);
    const requestOptions = NO_TIMEOUT_RUN_MODES.has(runMode) ? { timeoutMs: 0 } : undefined;

    const ctx = {
      input: parsed.raw,
      dosyaYil: parsed.dosyaYil,
      dosyaSira: parsed.dosyaSira,
      inputEncoded: encodeURIComponent(parsed.raw),
      birimAdi: parsed.birimAdi || settings.defaultBirimAdi || "",
      birimId: parsed.birimId || settings.defaultBirimId || ""
    };

    const firstUrl = toAbsoluteUrl(applyTemplate(settings.firstEndpointPath, ctx));
    const firstMethod = String(settings.firstMethod || "POST").toUpperCase();
    const firstHeaders = parseHeaders(settings.firstHeadersText, ctx);
    const firstBodyRaw = applyJsonBodyTemplate(settings.firstBodyTemplate, ctx);
    const firstBody =
      runMode === "dosyaHesabi"
        ? applyDosyaDurumKodToRequestBody(firstBodyRaw, settings.dosyaHesabiDosyaDurumKod)
        : firstBodyRaw;

    setActiveStep(parsed.raw, "1. istek: Dosya arama");
    let first = await runRequest(firstUrl, firstMethod, firstHeaders, firstBody, requestOptions);
    let firstJson = first.json;
    let foundViaKapaliFallback = false;

    if (KAPALI_FALLBACK_RUN_MODES.has(runMode) && !findByKeyDeep(firstJson, "dosyaId")) {
      // dosyaDurumKod=1 ile kapalı dosyalarda tekrar ara.
      setActiveStep(parsed.raw, "1. istek: Kapalı dosya arama");
      const kapaliFirst = await runRequest(
        firstUrl,
        firstMethod,
        firstHeaders,
        applyDosyaDurumKodToRequestBody(firstBodyRaw, "1"),
        requestOptions
      );
      if (findByKeyDeep(kapaliFirst.json, "dosyaId")) {
        first = kapaliFirst;
        firstJson = kapaliFirst.json;
        foundViaKapaliFallback = true;
      }
    }

    if (!first.ok || !firstJson) {
      return {
        input: parsed.raw,
        dosyaYil: parsed.dosyaYil,
        dosyaSira: parsed.dosyaSira,
        success: false,
        status: first.status,
        firstUrl,
        error: !first.ok ? `Ilk istek HTTP ${first.status}` : "Ilk istek JSON degil.",
        responseText: first.text,
        responseJson: firstJson
      };
    }

    const dosyaId = findByKeyDeep(firstJson, "dosyaId");
    if (!dosyaId) {
      return {
        input: parsed.raw,
        dosyaYil: parsed.dosyaYil,
        dosyaSira: parsed.dosyaSira,
        success: false,
        status: first.status,
        firstUrl,
        error: "Ilk yanitta dosyaId bulunamadi.",
        responseJson: firstJson
      };
    }

    const birimId = parsed.birimId || findByKeyDeep(firstJson, "birimId") || settings.defaultBirimId;
    const birimAdi = parsed.birimAdi || findByKeyDeep(firstJson, "birimAdi") || settings.defaultBirimAdi;
    const dosyaDurum = findByKeyDeep(firstJson, "dosyaDurum") || settings.defaultDosyaDurum;
    const dosyaDurumKod = findByKeyDeep(firstJson, "dosyaDurumKod");
    const dosyaDurumNorm = normalizeText(`${dosyaDurum || ""} ${dosyaDurumKod || ""}`);
    const isDosyaKapali =
      foundViaKapaliFallback || dosyaDurumNorm.includes("kapali") || String(dosyaDurumKod || "").trim() === "1";

    const secondCtx = {
      ...ctx,
      dosyaId: String(dosyaId),
      dosyaIdEncoded: encodeURIComponent(String(dosyaId)),
      birimId: String(birimId || ""),
      birimAdi: String(birimAdi || ""),
      birimAdiEncoded: encodeURIComponent(String(birimAdi || "")),
      dosyaDurum: String(dosyaDurum || "")
    };

    if (runMode === "talepEvrakiOlustur") {
      const talep = await sendIbanDegisikligiTalebi(parsed, settings, secondCtx);
      return {
        runMode,
        input: parsed.raw,
        birimAdi: String(birimAdi || ""),
        dosyaYil: parsed.dosyaYil,
        dosyaSira: parsed.dosyaSira,
        success: !!talep.ok,
        status: talep.status,
        isMatch: !!talep.ok,
        talepAdi: talep.talepAdi || "IBAN Değişikliği Talebi",
        fileName: talep.fileName || "",
        message: talep.message || talep.fileName || null,
        error: talep.ok ? null : talep.error || talep.message || `IBAN değişikliği evrak gönderme HTTP ${talep.status}`,
        responseText: talep.text || null,
        responseJson: talep.json || null
      };
    }

    if (GENEL_TALEP_RUN_MODES.has(runMode)) {
      const talep = await sendGenelTalep(parsed, settings, secondCtx, runMode);
      return {
        runMode,
        input: parsed.raw,
        birimAdi: String(birimAdi || ""),
        dosyaYil: parsed.dosyaYil,
        dosyaSira: parsed.dosyaSira,
        success: !!talep.ok,
        partialSuccess: !!talep.partialOk,
        status: talep.status,
        isMatch: !!talep.ok || !!talep.partialOk,
        talepAdi: talep.talepAdi || "Talep",
        talepBorclu: talep.borclu || "",
        kisiKurumId: talep.kisiKurumId || null,
        message: talep.message || null,
        error: talep.ok ? null : talep.error || talep.message || `Talep gönderme HTTP ${talep.status}`,
        responseText: talep.text || null,
        responseJson: talep.json || null,
        borcluResults: talep.borcluResults || null
      };
    }

    const row = createRowState(settings);

    if (runMode === "reddiyat") {
      Object.assign(
        row,
        await collectReddiyatData({ parsed, settings, secondCtx, firstJson, requestOptions, isDosyaKapali })
      );
    } else if (enableBarcode !== true && runMode !== "dosyaHesabi") {
      Object.assign(row, await collectYatanParaData({ parsed, settings, secondCtx, runMode, requestOptions }));
    }

    if (runMode === "dosyaHesabi") {
      Object.assign(row, await collectDosyaHesabiData({ parsed, settings, secondCtx, firstJson }));
    }

    if (enableBarcode === true || runMode === "dosyaHesabi") {
      Object.assign(
        row,
        await collectTebligBilgileri({
          settings,
          secondCtx,
          runMode,
          evrakPayloadForTracking: row.evrakPayloadForTracking,
          thirdUrl: row.thirdUrl,
          fourthUrl: row.fourthUrl
        })
      );
    }

    if (runMode === "dosyaHesabi") {
      Object.assign(row, computeDosyaHesabiTotals(row, settings));
    }

    const { isMatch, kalanQueryThreshold } = resolveMatch(row, { runMode, enableBarcode, settings });
    row.kalanQueryThreshold = kalanQueryThreshold;

    return buildResult(row, { parsed, runMode, enableBarcode, birimAdi, dosyaId, firstUrl, first, isMatch });
  };

  const normalizeInputs = (inputs) =>
    (Array.isArray(inputs) ? inputs : [])
      .map((input) => {
        if (input && typeof input === "object") {
          const dosyaNo = String(input.dosyaNo || "").trim();
          if (!dosyaNo) {
            return null;
          }
          return {
            dosyaNo,
            birimAdi: String(input.birimAdi || "").trim(),
            birimId: String(input.birimId || "").trim()
          };
        }
        const text = String(input || "").trim();
        return text || null;
      })
      .filter(Boolean);

  const runWorkflow = async (requestId, settings, inputs, runMode, enableBarcode) => {
    if (runState.isRunning) {
      throw new Error("İşlem zaten çalışıyor.");
    }
    runState.isRunning = true;
    runState.stopRequested = false;

    const effectiveSettings = { ...DEFAULT_SETTINGS, ...(settings || {}) };
    const cleanInputs = normalizeInputs(inputs);
    const items = [];
    let stopped = false;

    try {
      let isFirstInput = true;
      for (const input of cleanInputs) {
        if (runState.stopRequested) {
          stopped = true;
          break;
        }
        if (!isFirstInput) {
          await new Promise((resolve) => setTimeout(resolve, INPUT_DELAY_MS));
          if (runState.stopRequested) {
            stopped = true;
            break;
          }
        }
        isFirstInput = false;

        try {
          items.push(await runOne(input, effectiveSettings, runMode, enableBarcode));
          emitProgress(requestId, cleanInputs.length, items, runMode, false);
        } catch (error) {
          const message = String(error && error.message ? error.message : error);
          if (message === "STOP_REQUESTED") {
            stopped = true;
            emitProgress(requestId, cleanInputs.length, items, runMode, true);
            break;
          }
          items.push({ input, success: false, status: 0, error: message });
          emitProgress(requestId, cleanInputs.length, items, runMode, false);
        }
      }
    } finally {
      clearActiveStep();
      runState.isRunning = false;
      runState.stopRequested = false;
      runState.activeController = null;
    }

    const matchedInputs = items.filter((item) => item.isMatch).map((item) => item.input);

    return {
      runMode,
      ranAt: new Date().toISOString(),
      total: cleanInputs.length,
      processed: items.length,
      stopped,
      successCount: items.filter((item) => item.success).length,
      matchCount: matchedInputs.length,
      barcodeCount: items.filter((item) => !!item.barcode).length,
      matchedInputs,
      items
    };
  };

  window.addEventListener("message", (event) => {
    if (event.source !== window || !event.data || event.data.__EWR_EXT__ !== true) {
      return;
    }

    const data = event.data;

    if (data.type === "STOP_WORKFLOW") {
      runState.stopRequested = true;
      if (runState.activeController) {
        runState.activeController.abort();
      }
      return;
    }

    if (data.type !== "RUN_WORKFLOW") {
      return;
    }
    if (!data.requestId || handledRequestIds.has(data.requestId)) {
      return;
    }
    handledRequestIds.add(data.requestId);

    runWorkflow(data.requestId, data.settings, data.inputs, data.runMode || "normal", !!data.enableBarcode)
      .then((result) => {
        window.postMessage({ __EWR_PAGE__: true, requestId: data.requestId, ok: true, result }, "*");
      })
      .catch((error) => {
        window.postMessage(
          {
            __EWR_PAGE__: true,
            requestId: data.requestId,
            ok: false,
            error: String(error && error.message ? error.message : error)
          },
          "*"
        );
      })
      .finally(() => {
        if (handledRequestIds.size > HANDLED_REQUEST_ID_LIMIT) {
          handledRequestIds.clear();
        }
      });
  });
})();


(() => {
  const C = window.__EWR_PR_Core;
  const E = window.__EWR_PR_Extract;
  const T = window.MiniIcraTalepTemplate;
  if (!C || !E) { console.error("page-runner-core.js and page-runner-extract.js must load first"); return; }

  if (window.__EWR_PAGE_LOADED__ === true && window.__EWR_PAGE_TOKEN__ === C.__EWR_PAGE_TOKEN__) {
    return;
  }
  window.__EWR_PAGE_LOADED__ = true;
  window.__EWR_PAGE_TOKEN__ = C.__EWR_PAGE_TOKEN__;

  const {
    handledRequestIds, runState, DEFAULT_SETTINGS,
    parseInput, applyTemplate, applyJsonBodyTemplate, parseHeaders,
    toAbsoluteUrl, stripWrappingQuotes, applyDosyaDurumKodToRequestBody,
    normalizeJsonBodyValue, findByKeyDeep, numberOrNull,
    extractYatanPara, extractDosyaHesapSummary,
    parseOdemeDateInput, computeIcraFaizTutari, sumNumericAmounts,
    runRequest, runRequestBinary, runRequestViaExtension,
    fixMojibake, normalizeText, parseTrDateToTime
  } = C;

  const {
    extractTebligDateFromPtt, extractTebligDateFromPttApi,
    collectEvrakItems, collectTumEvraklarItems, dedupeByEvrakId,
    selectBarcodeCandidates, selectTakipTalebiCandidates,
    selectOdemeIcraEmriCandidates, selectVekaletPuluCandidates,
    extractLatestTakipTalebiDate, hasAvukatPortalHacizTalebi,
    estimateDosyaKesinlesmeInfoFromEvrakList,
    extractTakipTalebiAmountsFromText,
    extractTakipTalebiAmountsFromUdfBytes,
    extractTakipTalebiAmountsFromPdfBytes,
    getTakipParseQualityScore,
    extractVekaletPuluInfoFromHtmlText,
    extractDosyaMasrafBilgileri, extractReddiyatKalanMiktari,
    extractReddiyatTahsilatKalemleri,
    unwrapPdfLikeBytes, decodeEscapedTextVariants, extractInnerDocumentUrls,
    extractBarcodeFromPdfBytes, pdfContainsOdemeIcraEmri,
    extractETebligInfoFromPdfBytes,
    extractKisiFromAciklama, collectAlacakliNameKeys, pickBorcluHeaderValue,
    countBorcaItirazBefore, shouldTreatAsIlamliByItirazSonrasiOdemeEmri,
    matchIslemYapanToAlacakli
  } = E;

  const setQueryActiveStep = (inputValue, stepLabel) => {
    runState.activeInput = typeof inputValue === "object" ? String(inputValue.dosyaNo || "") : String(inputValue || "");
    runState.activeStepLabel = String(stepLabel || "");
  };

  const clearQueryActiveStep = () => {
    runState.activeInput = "";
    runState.activeStepLabel = "";
  };

  const getBorcluAdi = (borclu) => {
    if (borclu && borclu.kisi) {
      return String(borclu.kisi).trim();
    }
    const kisi = (borclu && borclu.kisiTumDVO) || {};
    const ad = [kisi.adi, kisi.soyadi].filter(Boolean).join(" ");
    if (ad) {
      return ad;
    }
    const kurum = (borclu && borclu.kurumDVO) || {};
    if (kurum.kurumAdi) {
      return String(kurum.kurumAdi).trim();
    }
    return "Bilinmeyen";
  };

  const buildBorcluHeaderValue = (borclu) => {
    if (!borclu) {
      return "undefined";
    }
    if (borclu.borcluHeaderValue) {
      return String(borclu.borcluHeaderValue);
    }
    const kisi = borclu.kisiTumDVO || {};
    const adi = String(kisi.adi || "").trim();
    const soyadi = String(kisi.soyadi || "").trim();
    const tc = String(kisi.tcKimlikNo || "").trim();
    if (adi || soyadi) {
      const name = [adi, soyadi].filter(Boolean).join(" ");
      return tc ? `${name} - ${tc}` : name;
    }
    const kurum = borclu.kurumDVO || {};
    if (kurum.kurumAdi) {
      const vergi = String(kurum.vergiNo || "").trim();
      return vergi ? `${kurum.kurumAdi} - ${vergi}` : String(kurum.kurumAdi);
    }
    return "undefined";
  };

  const getTalepDefinition = (runMode) => {
    if (runMode === "talepBorcluOdemeAktar") {
      return {
        talepKodu: 14,
        talepAdi: "Borçlu Tarafından Yapılan Ödemelerin Hesaba Aktarılması",
        className: "AvukatTalepGenelOdemeAktarDVO",
        outputName: "Borçlu Ödemelerinin Hesaba Aktarılması",
        dosyaDurum: "H",
        requiresIban: true
      };
    }
    if (runMode === "talepKesinlestirme") {
      return {
        talepKodu: 31,
        talepAdi: "Takibin Kesinleşmesi",
        className: "AvukatTalepGenelTakibiKesinlestirDVO",
        outputName: "Kesinleştirme Talebi",
        dosyaDurum: "A",
        requiresIban: false
      };
    }
    return {
      talepKodu: 37,
      talepAdi: "Dosyadaki Avansın İadesi",
      className: "AvukatTalepDosyaAvansIadesiDvo",
      outputName: "Masraf Avans İadesi",
      dosyaDurum: "H",
      requiresIban: true
    };
  };

  const buildTalepBilgileri = (ibanNo, runMode) => {
    const def = getTalepDefinition(runMode);
    const talep = {
      grupKodu: 2,
      talepKodu: def.talepKodu,
      talepAdi: def.talepAdi,
      talepKisaAdi: def.talepAdi,
      talepMasrafi: 0,
      className: def.className,
      postaMasrafId: 0,
      dosyaDurum: def.dosyaDurum || "H",
      masraf: 0,
      fields: def.requiresIban === false
        ? [{ id: "", title: "" }]
        : [
          { id: "hesapKimeAitText", title: "Hesap Kime Ait" },
          { id: "ibanNo", title: "IBAN No" }
        ],
      id: 0
    };
    if (def.requiresIban !== false) {
      talep.hesapKimeAit = "V";
      talep.hesapKimeAitText = "Vekil";
      talep.ibanNo = ibanNo;
    }
    return [talep];
  };

  const TALEP_EVRAK_ITEMS = [{
    id: 1,
    evrakTuruOptionDVO: {
      tur: "ICR_AVUKAT_PORTAL_GENEL_TALEP",
      label: "Genel Talebi",
      mandatory: true,
      max: 1,
      ekEvrakMax: 2,
      sablonTurKodu: "",
      acceptTypeList: [".udf", ".UDF"],
      ekEvrakAcceptTypeList: [".udf", ".pdf", ".jpg", ".jpeg", ".png", ".tif", ".tiff", ".UDF", ".PDF", ".JPG", ".JPEG", ".PNG", ".TIF", ".TIFF"]
    },
    tur: "ICR_AVUKAT_PORTAL_GENEL_TALEP",
    turAciklama: "Genel Talebi",
    mandatory: true,
    file: {},
    path: "C:/fakepath/Talep.udf",
    kullaniciEvrakAciklama: "",
    parentId: -1,
    isVekalet: false,
    isVekaletBilgiFormu: false,
    fileId: 1
  }];

  const IBAN_DEGISIKLIGI_EVRAK_ITEMS = (fileName) => [{
    id: Date.now(),
    evrakTuruOptionDVO: {
      tur: "ICR_GNL_HCZ_BLDRM",
      label: "Genel Haciz Talebi",
      mandatory: false,
      max: 1,
      ekEvrakMax: 5,
      sablonTurKodu: "",
      acceptTypeList: [".udf", ".UDF"],
      ekEvrakAcceptTypeList: [".udf", ".pdf", ".jpg", ".png", ".jpeg", ".image/jpg", ".image/jpeg", ".tif", ".tiff", ".UDF", ".JPG", ".JPEG", ".PNG", ".PDF", ".TIF", ".TIFF"]
    },
    tur: "ICR_GNL_HCZ_BLDRM",
    turAciklama: "Genel Haciz Talebi",
    mandatory: false,
    file: {},
    path: `C:/fakepath/${fileName}`,
    kullaniciEvrakAciklama: "",
    parentId: -1,
    isVekalet: false,
    isVekaletBilgiFormu: false,
    fileId: 1
  }];

  const sendIbanDegisikligiTalebi = async (parsed, settings, secondCtx) => {
    if (!T || typeof T.buildUdfFiles !== "function") {
      return { ok: false, status: 0, error: "IBAN değişikliği şablon modülü yüklenemedi." };
    }

    setQueryActiveStep(parsed.raw, "2. istek: IBAN değişikliği UDF hazırlama");
    const [udfFile] = await T.buildUdfFiles([{
      dosyaNo: parsed.raw,
      birimAdi: secondCtx.birimAdi || parsed.birimAdi || settings.defaultBirimAdi || ""
    }]);
    if (!udfFile || !udfFile.bytes) {
      return { ok: false, status: 0, error: "IBAN değişikliği UDF dosyası oluşturulamadı." };
    }

    const normalizedDosyaId = normalizeJsonBodyValue(secondCtx.dosyaId || "");
    const headers = { ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}) };
    delete headers["Content-Type"];
    delete headers["content-type"];

    const formData = new FormData();
    formData.append("file_1", new Blob([udfFile.bytes], { type: "application/octet-stream" }), udfFile.fileName);
    formData.append("items", JSON.stringify(IBAN_DEGISIKLIGI_EVRAK_ITEMS(udfFile.fileName)));
    formData.append("dosyaId", normalizedDosyaId);
    formData.append("isDusurme", "false");
    formData.append("evrakTipi", "undefined");
    formData.append("dosyaNo", parsed.raw);
    formData.append("birimId", String(secondCtx.birimId || ""));
    formData.append("birimAdi", String(secondCtx.birimAdi || ""));

    setQueryActiveStep(parsed.raw, "3. istek: IBAN değişikliği evrak gönderme");
    const gonder = await fetch(toAbsoluteUrl("/evrakGonder_brd.ajx"), {
      method: "POST",
      headers,
      body: formData,
      credentials: "include"
    });
    const text = await gonder.text();
    let json = null;
    try { json = JSON.parse(text); } catch { json = null; }
    const message = json && typeof json === "object" ? String(json.message || json.error || "") : "";
    const isError = json && json.type === "error";
    return {
      ok: gonder.ok && !isError,
      status: gonder.status,
      json,
      text,
      message,
      fileName: udfFile.fileName,
      talepAdi: "IBAN Değişikliği Talebi"
    };
  };

  const sendGenelTalep = async (parsed, settings, firstJson, secondCtx, runMode) => {
    const talepDef = getTalepDefinition(runMode);
    const ibanNo = String(settings.talepIbanNo || DEFAULT_SETTINGS.talepIbanNo || "TR620001009010684338705009").replace(/\s+/g, "").toUpperCase();
    if (talepDef.requiresIban !== false && !/^TR\d{24}$/.test(ibanNo)) {
      return { ok: false, status: 0, error: "Geçerli IBAN bulunamadı.", talepAdi: talepDef.outputName };
    }

    const dosyaId = secondCtx.dosyaId;
    const normalizedDosyaId = normalizeJsonBodyValue(dosyaId);
    setQueryActiveStep(parsed.raw, "2. istek: Borçlu listesi");
    const borcluHeaders = {
      ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
      "Content-Type": "application/json",
      "X-Borclu": "undefined"
    };
    const borcluBody = JSON.stringify({ dosyaId: normalizedDosyaId });
    const borclu = await runRequest(toAbsoluteUrl("/dosya_borclu_list.ajx"), "POST", borcluHeaders, borcluBody, { timeoutMs: 0 });
    if (!borclu.ok || !Array.isArray(borclu.json)) {
      return { ok: false, status: borclu.status, error: `Borçlu listesi alınamadı (HTTP ${borclu.status})`, talepAdi: talepDef.outputName };
    }

    const borclular = borclu.json.filter((x) => x && typeof x.kisiKurumId !== "undefined");
    if (borclular.length === 0) {
      return { ok: false, status: borclu.status, error: "Borçlu listesinde kisiKurumId bulunamadı.", talepAdi: talepDef.outputName };
    }

    const sendForBorclu = async (selectedBorclu, index) => {
      const talepBilgileri = buildTalepBilgileri(ibanNo, runMode);
      const baseHeaders = {
        ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
        "X-Borclu": encodeURIComponent(buildBorcluHeaderValue(selectedBorclu))
      };

      if (runMode === "talepKesinlestirme") {
        setQueryActiveStep(parsed.raw, `3. istek: Kesinleşme kontrolü (${index + 1}/${borclular.length})`);
        const kesinlesmeHeaders = { ...baseHeaders, "Content-Type": "application/json" };
        const kesinlesmeBody = JSON.stringify({
          dosyaId: normalizedDosyaId,
          kisiKurumId: selectedBorclu.kisiKurumId
        });
        const kesinlesme = await runRequest(toAbsoluteUrl("/dosya_icra_kesinlesme.ajx"), "POST", kesinlesmeHeaders, kesinlesmeBody, { timeoutMs: 0 });
        if (!kesinlesme.ok) {
          return {
            ok: false,
            status: kesinlesme.status,
            error: `Kesinleşme kontrolü başarısız (HTTP ${kesinlesme.status})`,
            text: kesinlesme.text,
            json: kesinlesme.json,
            borclu: getBorcluAdi(selectedBorclu),
            kisiKurumId: selectedBorclu.kisiKurumId
          };
        }
        if (!kesinlesme.json || kesinlesme.json.basarilimi !== true) {
          const message = kesinlesme.json && typeof kesinlesme.json === "object"
            ? String(kesinlesme.json.message || kesinlesme.json.error || "")
            : "";
          return {
            ok: false,
            status: kesinlesme.status,
            error: message || "Borçlu için kesinleştirme başarısız.",
            text: kesinlesme.text,
            json: kesinlesme.json,
            borclu: getBorcluAdi(selectedBorclu),
            kisiKurumId: selectedBorclu.kisiKurumId
          };
        }
      }

      setQueryActiveStep(parsed.raw, `${runMode === "talepKesinlestirme" ? "4" : "3"}. istek: Talep evrakı hazırlama (${index + 1}/${borclular.length})`);
      const hazirlaHeaders = { ...baseHeaders, "Content-Type": "application/json" };
      const hazirlaBody = JSON.stringify({
        dosyaId: normalizedDosyaId,
        filename: parsed.raw,
        kisiKurumId: selectedBorclu.kisiKurumId,
        talepBilgileri: JSON.stringify(talepBilgileri)
      });
      const hazirla = await runRequest(toAbsoluteUrl("/getIcraTalepEvrakHazirla.uyap"), "POST", hazirlaHeaders, hazirlaBody, { timeoutMs: 0 });
      if (!hazirla.ok || !hazirla.text) {
        return {
          ok: false,
          status: hazirla.status,
          error: `Talep evrakı hazırlanamadı (HTTP ${hazirla.status})`,
          text: hazirla.text,
          json: hazirla.json,
          borclu: getBorcluAdi(selectedBorclu),
          kisiKurumId: selectedBorclu.kisiKurumId
        };
      }

      setQueryActiveStep(parsed.raw, `${runMode === "talepKesinlestirme" ? "5" : "4"}. istek: Talep gönderme (${index + 1}/${borclular.length})`);
      const formData = new FormData();
      formData.append("file_1", new Blob([hazirla.text], { type: "application/octet-stream" }), "Talep.udf");
      formData.append("items", JSON.stringify(TALEP_EVRAK_ITEMS));
      formData.append("dosyaId", normalizedDosyaId);
      formData.append("kisiKurumId", String(selectedBorclu.kisiKurumId));
      formData.append("tutar", "0");
      formData.append("talepGrupId", "2");
      formData.append("talepBilgileri", JSON.stringify(talepBilgileri));

      const gonderHeaders = { ...baseHeaders };
      delete gonderHeaders["Content-Type"];
      delete gonderHeaders["content-type"];
      const gonder = await fetch(toAbsoluteUrl("/avukatIcraTalepEvrakiGonder.ajx"), {
        method: "POST",
        headers: gonderHeaders,
        body: formData,
        credentials: "include"
      });
      const text = await gonder.text();
      let json = null;
      try { json = JSON.parse(text); } catch { json = null; }

      const message = json && typeof json === "object" ? String(json.message || json.error || "") : "";
      const isError = json && json.type === "error";
      return {
        ok: gonder.ok && !isError,
        status: gonder.status,
        json,
        text,
        message,
        error: gonder.ok && !isError ? null : (message || `Talep gönderme HTTP ${gonder.status}`),
        borclu: getBorcluAdi(selectedBorclu),
        kisiKurumId: selectedBorclu.kisiKurumId
      };
    };

    const results = [];
    const targetBorclular = runMode === "talepKesinlestirme" ? borclular : [borclular[0]];
    for (let i = 0; i < targetBorclular.length; i += 1) {
      results.push(await sendForBorclu(targetBorclular[i], i));
    }

    const successCount = results.filter((r) => r && r.ok).length;
    const failed = results.filter((r) => !r || !r.ok);
    const firstResult = results[0] || {};
    return {
      ok: successCount > 0 && failed.length === 0,
      partialOk: successCount > 0 && failed.length > 0,
      status: failed[0]?.status || firstResult.status || 0,
      json: firstResult.json || null,
      text: firstResult.text || null,
      message: results.map((r) => `${r.borclu || r.kisiKurumId || "Borçlu"}: ${r.ok ? "Gönderildi" : (r.error || r.message || "Hata")}`).join(" | "),
      error: failed.length > 0 ? failed.map((r) => `${r.borclu || r.kisiKurumId || "Borçlu"}: ${r.error || r.message || "Hata"}`).join(" | ") : null,
      borclu: results.map((r) => r.borclu).filter(Boolean).join(", "),
      kisiKurumId: targetBorclular.length === 1 ? targetBorclular[0].kisiKurumId : null,
      talepAdi: talepDef.outputName,
      borcluResults: results
    };
  };

  const runOne = async (inputValue, settings, runMode, enableBarcode) => {
    const parsed = parseInput(inputValue);
    const requestOptions =
      runMode === "normal" || runMode === "datedCurrentMonth" || runMode === "reddiyat" || runMode === "kalan"
        || runMode === "talepMasrafAvansIadesi" || runMode === "talepBorcluOdemeAktar" || runMode === "talepKesinlestirme" || runMode === "talepEvrakiOlustur"
        ? { timeoutMs: 0 }
        : undefined;
    const ctx = {
      input: parsed.raw,
      dosyaYil: parsed.dosyaYil,
      dosyaSira: parsed.dosyaSira,
      inputEncoded: encodeURIComponent(parsed.raw),
      birimAdi: parsed.birimAdi || settings.defaultBirimAdi || "",
      birimId: parsed.birimId || settings.defaultBirimId || ""
    };

    const firstUrl = toAbsoluteUrl(applyTemplate(settings.firstEndpointPath, ctx));
    const firstMethod = String(settings.firstMethod || "POST").toUpperCase();
    const firstHeaders = parseHeaders(settings.firstHeadersText, ctx);
    const firstBodyRaw = applyJsonBodyTemplate(settings.firstBodyTemplate, ctx);
    const firstBody =
      runMode === "dosyaHesabi"
        ? applyDosyaDurumKodToRequestBody(firstBodyRaw, settings.dosyaHesabiDosyaDurumKod)
        : firstBodyRaw;
    setQueryActiveStep(parsed.raw, "1. istek: Dosya arama");
    let first = await runRequest(firstUrl, firstMethod, firstHeaders, firstBody, requestOptions);
    let firstJson = first.json;
    let foundViaKapaliFallback = false;

    // Reddiyat ve talep modlarında acik/kapali ayrimi olmadan dosya yakalamak icin fallback denemesi.
    if (
      runMode === "reddiyat"
      || runMode === "talepMasrafAvansIadesi"
      || runMode === "talepBorcluOdemeAktar"
      || runMode === "talepKesinlestirme"
      || runMode === "talepEvrakiOlustur"
    ) {
      const firstDosyaId = findByKeyDeep(firstJson, "dosyaId");
      if (!firstDosyaId) {
        const kapaliBody = applyDosyaDurumKodToRequestBody(firstBodyRaw, "1");
        setQueryActiveStep(parsed.raw, "1. istek: Kapalı dosya arama");
        const kapaliFirst = await runRequest(firstUrl, firstMethod, firstHeaders, kapaliBody, requestOptions);
        const kapaliDosyaId = findByKeyDeep(kapaliFirst.json, "dosyaId");
        if (kapaliDosyaId) {
          first = kapaliFirst;
          firstJson = kapaliFirst.json;
          foundViaKapaliFallback = true;
        }
      }
    }

    if (!first.ok || !firstJson) {
      return {
        input: parsed.raw,
        dosyaYil: parsed.dosyaYil,
        dosyaSira: parsed.dosyaSira,
        success: false,
        status: first.status,
        firstUrl,
        error: !first.ok ? `Ilk istek HTTP ${first.status}` : "Ilk istek JSON degil.",
        responseText: first.text,
        responseJson: firstJson
      };
    }

    const dosyaId = findByKeyDeep(firstJson, "dosyaId");
    if (!dosyaId) {
      return {
        input: parsed.raw,
        dosyaYil: parsed.dosyaYil,
        dosyaSira: parsed.dosyaSira,
        success: false,
        status: first.status,
        firstUrl,
        error: "Ilk yanitta dosyaId bulunamadi.",
        responseJson: firstJson
      };
    }

    const birimId = parsed.birimId || findByKeyDeep(firstJson, "birimId") || settings.defaultBirimId;
    const birimAdi = parsed.birimAdi || findByKeyDeep(firstJson, "birimAdi") || settings.defaultBirimAdi;
    const dosyaDurum = findByKeyDeep(firstJson, "dosyaDurum") || settings.defaultDosyaDurum;
    const dosyaDurumKod = findByKeyDeep(firstJson, "dosyaDurumKod");
    const dosyaDurumNorm = normalizeText(`${dosyaDurum || ""} ${dosyaDurumKod || ""}`);
    const isDosyaKapali =
      foundViaKapaliFallback ||
      dosyaDurumNorm.includes("kapali") ||
      String(dosyaDurumKod || "").trim() === "1";
    const secondCtx = {
      ...ctx,
      dosyaId: String(dosyaId),
      dosyaIdEncoded: encodeURIComponent(String(dosyaId)),
      birimId: String(birimId || ""),
      birimAdi: String(birimAdi || ""),
      birimAdiEncoded: encodeURIComponent(String(birimAdi || "")),
      dosyaDurum: String(dosyaDurum || "")
    };

    let secondUrl = null;
    let secondStatus = null;
    let secondOk = true;
    let secondText = null;
    let secondJson = null;
    let yatanPara = null;
    let reddiyatKalanMiktari = null;
    let reddiyatKalemleri = [];
    let kalanBorc = null;
    let kalanQueryThreshold = null;
    let talepTarihi = null;
    let asilAlacak = null;
    let gecmisGunFaizi = null;
    let vekaletPulu = null;
    let tebligatGideri = null;
    let pesinHarc = null;
    let basvurmaHarci = null;
    let vekaletSuretHarci = null;
    let tahsilHarciHesap = null;
    let takipteKesinlesenMiktar = null;
    let vekaletUcretiDosyaHesap = null;
    let icraFaizTutari = null;
    let danismanlikUcreti = null;
    let toplamBorcHesap = null;
    let masrafToplami = null;
    let vazgecmeHesabi = null;
    let anaPara = null;
    let hakEdis = null;
    let indirimliToplamBorc = null;
    let indirimYeniAsilAlacak = null;
    let indirimYeniDanismanlikUcreti = null;
    const indirimTutari = numberOrNull(settings.dosyaHesabiIndirimTutari) ?? 0;
    const dosyaHesabiHesapTuru = String(settings.dosyaHesabiHesapTuru || "normal");
    let aracMahrumiyetBedeli = null;
    let aracMahrumiyetFaizi = null;
    let mahkemeVekaletUcreti = null;
    let mahkemeVekaletUcretiFaizi = null;
    let mahkemeYargilamaGiderleri = null;
    let mahkemeYargilamaGiderleriFaizi = null;
    let mahkemeHarclari = null;
    let mahkemeHarclariFaizi = null;
    let ygIcraFaiz = null;
    let harcIcraFaiz = null;
    let ivuIcraFaiz = null;
    let takibinTuruAciklama = "";
    let isIlamliTakip = false;
    let dosyaKesinlesmeMs = 0;
    let dosyaHesabiOk = true;
    let dosyaHesabiStatus = null;
    const dosyaHesabiDebug = {
      aday: 0,
      source: "",
      asilFaizSource: "",
      asilFaizUrl: "",
      asilFaizEvrakTur: "",
      asilFaizEvrakId: "",
      ilamliForcedByItirazOdemeEmri: false,
      evrakIdAday: 0,
      urlTried: 0,
      pdfOk: 0,
      innerUrlTried: 0,
      jsonHit: false,
      parsed: false,
      udfTried: 0,
      udfParsed: 0,
      contentTypes: []
    };
    let bestTakipParseScore = -1;
    const maybeAdoptTakipParse = (candidate, source, sourceUrl, evrakTur, evrakId) => {
      if (!candidate || typeof candidate !== "object") {
        return false;
      }
      if (candidate.asilAlacak === null && candidate.gecmisGunFaizi === null) {
        return false;
      }
      const score = typeof getTakipParseQualityScore === "function" ? getTakipParseQualityScore(candidate) : -1;
      if (score < bestTakipParseScore) {
        return false;
      }

      bestTakipParseScore = score;
      asilAlacak = candidate.asilAlacak;
      gecmisGunFaizi = candidate.gecmisGunFaizi;
      aracMahrumiyetBedeli = candidate.aracMahrumiyetBedeli ?? aracMahrumiyetBedeli;
      aracMahrumiyetFaizi = candidate.aracMahrumiyetFaizi ?? aracMahrumiyetFaizi;
      mahkemeVekaletUcreti = candidate.mahkemeVekaletUcreti ?? mahkemeVekaletUcreti;
      mahkemeVekaletUcretiFaizi = candidate.mahkemeVekaletUcretiFaizi ?? mahkemeVekaletUcretiFaizi;
      mahkemeYargilamaGiderleri = candidate.mahkemeYargilamaGiderleri ?? mahkemeYargilamaGiderleri;
      mahkemeYargilamaGiderleriFaizi = candidate.mahkemeYargilamaGiderleriFaizi ?? mahkemeYargilamaGiderleriFaizi;
      mahkemeHarclari = candidate.mahkemeHarclari ?? mahkemeHarclari;
      mahkemeHarclariFaizi = candidate.mahkemeHarclariFaizi ?? mahkemeHarclariFaizi;
      dosyaHesabiDebug.parsed = true;
      dosyaHesabiDebug.asilFaizSource = source;
      dosyaHesabiDebug.asilFaizUrl = sourceUrl;
      dosyaHesabiDebug.asilFaizEvrakTur = String(evrakTur || "");
      dosyaHesabiDebug.asilFaizEvrakId = String(evrakId || "");
      return score >= 10;
    };

    if (runMode === "talepEvrakiOlustur") {
      const talep = await sendIbanDegisikligiTalebi(parsed, settings, secondCtx);
      return {
        runMode,
        input: parsed.raw,
        birimAdi: String(birimAdi || ""),
        dosyaYil: parsed.dosyaYil,
        dosyaSira: parsed.dosyaSira,
        success: !!talep.ok,
        status: talep.status,
        isMatch: !!talep.ok,
        talepAdi: talep.talepAdi || "IBAN Değişikliği Talebi",
        fileName: talep.fileName || "",
        message: talep.message || talep.fileName || null,
        error: talep.ok ? null : (talep.error || talep.message || `IBAN değişikliği evrak gönderme HTTP ${talep.status}`),
        responseText: talep.text || null,
        responseJson: talep.json || null
      };
    }

    if (runMode === "talepMasrafAvansIadesi" || runMode === "talepBorcluOdemeAktar" || runMode === "talepKesinlestirme") {
      const talep = await sendGenelTalep(parsed, settings, firstJson, secondCtx, runMode);
      return {
        runMode,
        input: parsed.raw,
        birimAdi: String(birimAdi || ""),
        dosyaYil: parsed.dosyaYil,
        dosyaSira: parsed.dosyaSira,
        success: !!talep.ok,
        partialSuccess: !!talep.partialOk,
        status: talep.status,
        isMatch: !!talep.ok || !!talep.partialOk,
        talepAdi: talep.talepAdi || "Talep",
        talepBorclu: talep.borclu || "",
        kisiKurumId: talep.kisiKurumId || null,
        message: talep.message || null,
        error: talep.ok ? null : (talep.error || talep.message || `Talep gönderme HTTP ${talep.status}`),
        responseText: talep.text || null,
        responseJson: talep.json || null,
        borcluResults: talep.borcluResults || null
      };
    }

    if (runMode === "reddiyat") {
      try {
        let alacakliNameKeys = new Set();
        setQueryActiveStep(parsed.raw, "2. istek: Taraf bilgileri");
        const tarafUrl = toAbsoluteUrl("/dosya_taraf_bilgileri_brd.ajx");
        const tarafHeaders = parseHeaders(settings.thirdHeadersText, secondCtx);
        const tarafBody = JSON.stringify({ dosyaId: normalizeJsonBodyValue(secondCtx.dosyaId || "") });
        const taraf = await runRequest(tarafUrl, "POST", tarafHeaders, tarafBody, requestOptions);
        if (taraf.ok && Array.isArray(taraf.json)) {
          alacakliNameKeys = collectAlacakliNameKeys(taraf.json);
        }

        secondUrl = toAbsoluteUrl("/dosya_tahsilat_reddiyat_bilgileri_brd.ajx");
        setQueryActiveStep(parsed.raw, "3. istek: Reddiyat bilgileri");
        const reddiyatHeaders = parseHeaders(settings.thirdHeadersText, secondCtx);
        const reddiyatBody = JSON.stringify({
          dosyaId: normalizeJsonBodyValue(secondCtx.dosyaId || ""),
          dosyaTurKod: Number(findByKeyDeep(firstJson, "dosyaTurKod")) || 35
        });
        const reddiyat = await runRequest(secondUrl, "POST", reddiyatHeaders, reddiyatBody, requestOptions);
        secondStatus = reddiyat.status;
        secondOk = !!reddiyat.ok;
        secondText = reddiyat.text;
        secondJson = reddiyat.json;
        if (reddiyat.ok && reddiyat.json && typeof reddiyat.json === "object") {
          reddiyatKalanMiktari = extractReddiyatKalanMiktari(reddiyat.json, parsed.raw);
          reddiyatKalemleri = extractReddiyatTahsilatKalemleri(reddiyat.json, parsed.raw, alacakliNameKeys, { isDosyaKapali });
        }
      } catch (err) {
        secondOk = false;
        secondText = err && err.message ? String(err.message) : null;
      }
    } else if (enableBarcode !== true && runMode !== "dosyaHesabi") {
      setQueryActiveStep(parsed.raw, "2. istek: Dosya hesap bilgileri");
      secondUrl = toAbsoluteUrl(applyTemplate(settings.secondEndpointPath, secondCtx));
      const secondMethod = String(settings.secondMethod || "POST").toUpperCase();
      const secondHeaders = parseHeaders(settings.secondHeadersText, secondCtx);
      const secondBody = applyJsonBodyTemplate(settings.secondBodyTemplate, secondCtx);
      const second = await runRequest(secondUrl, secondMethod, secondHeaders, secondBody, requestOptions);
      secondStatus = second.status;
      secondOk = !!second.ok;
      secondText = second.text;
      secondJson = second.json;
      yatanPara = second.json ? extractYatanPara(second.json, runMode, settings) : null;
      const secondSummary = second.json ? extractDosyaHesapSummary(second.json) : null;
      kalanBorc = secondSummary ? secondSummary.bakiyeBorcMiktari : null;
    }

    let barcode = null;
    let barcodeSource = null;
    let barcodeEvrakId = null;
    let tebligTarihi = null;
    let tebligYediGunSonrasi = null;
    const tebligDetaylari = [];
    let pttUrl = null;
    let borcaItirazSayisi = 0;
    let borcluSayisi = 0;
    let itirazKontrolTarihi = null;
    let thirdUrl = null;
    let fourthUrl = null;
    let evrakPayloadForTracking = null;
    const barcodeDebug = {
      thirdOk: false,
      evrakCount: 0,
      candidateCount: 0,
      triedPdfCount: 0,
      tried: []
    };

    if (runMode === "dosyaHesabi") {
      setQueryActiveStep(parsed.raw, "3. istek: Evrak listesi");
      const thirdUrlResolved = toAbsoluteUrl(applyTemplate(settings.thirdEndpointPath, secondCtx));
      const thirdMethod = String(settings.thirdMethod || "POST").toUpperCase();
      const thirdHeaders = parseHeaders(settings.thirdHeadersText, secondCtx);
      const thirdBody = applyJsonBodyTemplate(settings.thirdBodyTemplate, secondCtx);
      const third = await runRequest(thirdUrlResolved, thirdMethod, thirdHeaders, thirdBody);
      thirdUrl = thirdUrlResolved;
      dosyaHesabiStatus = third.status;
      dosyaHesabiOk = !!(third.ok && third.json);
      if (dosyaHesabiOk) {
        evrakPayloadForTracking = third.json;
        const tumEvrakList = collectTumEvraklarItems(third.json);
        const ilamliOverrideInfo = shouldTreatAsIlamliByItirazSonrasiOdemeEmri(tumEvrakList);
        const hasHacizTalebi = hasAvukatPortalHacizTalebi(tumEvrakList);
        const dosyaKesinlesmeInfo = estimateDosyaKesinlesmeInfoFromEvrakList(tumEvrakList);
        dosyaKesinlesmeMs = dosyaKesinlesmeInfo.kesinlesmeMs || 0;
        tebligTarihi = dosyaKesinlesmeInfo.tebligTarihi || null;
        talepTarihi = extractLatestTakipTalebiDate(tumEvrakList);

        let alacakliNameKeys = new Set();
        try {
          setQueryActiveStep(parsed.raw, "4. istek: Taraf bilgileri");
          const tarafUrl = toAbsoluteUrl("/dosya_taraf_bilgileri_brd.ajx");
          const tarafHeaders = parseHeaders(settings.thirdHeadersText, secondCtx);
          const tarafBody = JSON.stringify({ dosyaId: normalizeJsonBodyValue(secondCtx.dosyaId || "") });
          const taraf = await runRequest(tarafUrl, "POST", tarafHeaders, tarafBody);
          if (taraf.ok && Array.isArray(taraf.json)) {
            alacakliNameKeys = collectAlacakliNameKeys(taraf.json);
          }
        } catch {
          
        }

        try {
          setQueryActiveStep(parsed.raw, "5. istek: Dosya ayrıntı bilgileri");
          const ayrintiUrl = toAbsoluteUrl("/dosyaAyrintiBilgileri_brd.ajx");
          const ayrintiHeaders = parseHeaders(settings.thirdHeadersText, secondCtx);
          const ayrintiBody = JSON.stringify({ dosyaId: normalizeJsonBodyValue(secondCtx.dosyaId || "") });
          const ayrinti = await runRequest(ayrintiUrl, "POST", ayrintiHeaders, ayrintiBody);
          if (ayrinti.ok && ayrinti.json && typeof ayrinti.json === "object") {
            takibinTuruAciklama = String(ayrinti.json.takibinTuruAciklama || "").trim();
            isIlamliTakip = normalizeText(takibinTuruAciklama).includes("ilamli");
          }
        } catch {
          
        }

        if (ilamliOverrideInfo.value) {
          isIlamliTakip = true;
          dosyaHesabiDebug.ilamliForcedByItirazOdemeEmri = true;
        }

        {
        try {
          setQueryActiveStep(parsed.raw, "6. istek: Dosya hesap bilgileri");
          secondUrl = toAbsoluteUrl(applyTemplate(settings.secondEndpointPath, secondCtx));
          const secondMethod = String(settings.secondMethod || "POST").toUpperCase();
          const secondHeaders = parseHeaders(settings.secondHeadersText, secondCtx);
          const secondBody = applyJsonBodyTemplate(settings.secondBodyTemplate, secondCtx);
          const second = await runRequest(secondUrl, secondMethod, secondHeaders, secondBody);
          if (second.ok && second.json) {
            const summary = extractDosyaHesapSummary(second.json);
            takipteKesinlesenMiktar = summary.takipteKesinlesenMiktar;
            vekaletUcretiDosyaHesap = summary.vekaletUcreti;
          }
        } catch {
          
        }

        try {
          const tahsilatUrl = toAbsoluteUrl("/dosya_tahsilat_reddiyat_bilgileri_brd.ajx");
          const tahsilatHeaders = parseHeaders(settings.thirdHeadersText, secondCtx);
          const tahsilatBody = JSON.stringify({
            dosyaId: normalizeJsonBodyValue(secondCtx.dosyaId || ""),
            dosyaTurKod: Number(findByKeyDeep(firstJson, "dosyaTurKod")) || 35
          });
          const tahsilat = await runRequest(tahsilatUrl, "POST", tahsilatHeaders, tahsilatBody);
          if (tahsilat.ok && tahsilat.json && typeof tahsilat.json === "object") {
            const masraf = extractDosyaMasrafBilgileri(tahsilat.json, parsed.raw, alacakliNameKeys);
            tebligatGideri = masraf.tebligatGideri;
            pesinHarc = masraf.pesinHarc;
            basvurmaHarci = masraf.basvurmaHarci;
            vekaletSuretHarci = masraf.vekaletSuretHarci;
          }
        } catch {
          
        }

        const odemeIcraEmriAdaylari = selectOdemeIcraEmriCandidates(tumEvrakList);
        const takipTalebiAdaylari = selectTakipTalebiCandidates(tumEvrakList);

        const thirdJsonText = (() => {
          try {
            return JSON.stringify(third.json);
          } catch {
            return "";
          }
        })();
        if (thirdJsonText && odemeIcraEmriAdaylari.length === 0 && takipTalebiAdaylari.length === 0) {
          const jsonAmounts = extractTakipTalebiAmountsFromText(thirdJsonText);
          if (maybeAdoptTakipParse(jsonAmounts, "evrak-listesi-json", thirdUrlResolved, "liste fallback", "")) {
            dosyaHesabiDebug.jsonHit = true;
          }
        }

        const adayGruplari = [
          { source: "odemeIcraEmri", items: odemeIcraEmriAdaylari },
          { source: "takipTalebi", items: takipTalebiAdaylari }
        ];
        dosyaHesabiDebug.aday = adayGruplari.reduce((sum, group) => sum + group.items.length, 0);

        for (const adayGrubu of adayGruplari) {
          if (!Array.isArray(adayGrubu.items) || adayGrubu.items.length === 0) {
            continue;
          }
          dosyaHesabiDebug.source = adayGrubu.source;
          for (const asilFaizEvraki of adayGrubu.items) {
          if (!asilFaizEvraki || !asilFaizEvraki.evrakId) {
            continue;
          }
          const fourthMethod = String(settings.fourthMethod || "GET").toUpperCase();
          const docDosyaIdCandidates = [
            String(asilFaizEvraki.dosyaId || ""),
            String(secondCtx.dosyaId || "")
          ].filter(Boolean);
          const uniqueDocDosyaIds = [...new Set(docDosyaIdCandidates)];
          const evrakIdCandidates = [String(asilFaizEvraki.evrakId || "")];
          const uniqueEvrakIds = [...new Set(evrakIdCandidates.filter(Boolean))];
          dosyaHesabiDebug.evrakIdAday += uniqueEvrakIds.length;
          let shouldTryFallbackDosyaId = false;

          for (let idx = 0; idx < uniqueDocDosyaIds.length; idx += 1) {
            const docDosyaId = uniqueDocDosyaIds[idx];
            if (idx > 0 && !shouldTryFallbackDosyaId) {
              break;
            }

            let gotAnyOkPdf = false;
            for (const evrakIdCandidate of uniqueEvrakIds) {
              const isOdemeIcraEmriDoc = normalizeText(asilFaizEvraki.tur).includes("odeme icra emri");
              const docCtx = {
                ...secondCtx,
                dosyaId: docDosyaId,
                dosyaIdEncoded: encodeURIComponent(String(docDosyaId || "")),
                evrakId: String(evrakIdCandidate || ""),
                evrakIdEncoded: encodeURIComponent(String(evrakIdCandidate || "")),
                evrakEncoded: encodeURIComponent(String(asilFaizEvraki.tur || "")),
                tarihEncoded: encodeURIComponent(String(asilFaizEvraki.onaylandigiTarih || ""))
              };
              const candidateFourthUrl = toAbsoluteUrl(applyTemplate(settings.fourthEndpointPath, docCtx));

              
              const udfUrl = toAbsoluteUrl(
                `/download_document_brd.uyap?dosyaId=${encodeURIComponent(String(docDosyaId || ""))}` +
                  `&evrakId=${encodeURIComponent(String(evrakIdCandidate || ""))}` +
                  `&evrak=${encodeURIComponent(String(asilFaizEvraki.tur || ""))}` +
                  `&tarih=${encodeURIComponent(String(asilFaizEvraki.onaylandigiTarih || ""))}` +
                  `&sira=undefined`
              );
              dosyaHesabiDebug.udfTried += 1;
              const udfHeaders = parseHeaders(settings.fourthHeadersText, docCtx);
              const udf = await runRequestBinary(udfUrl, "GET", udfHeaders, undefined);
                if (udf.ok) {
                  const udfAmounts = extractTakipTalebiAmountsFromUdfBytes(udf.bytes);
                  if (udfAmounts.asilAlacak !== null || udfAmounts.gecmisGunFaizi !== null) {
                    fourthUrl = udfUrl;
                    dosyaHesabiDebug.udfParsed += 1;
                    if (maybeAdoptTakipParse(udfAmounts, "udf", udfUrl, asilFaizEvraki.tur, evrakIdCandidate)) {
                      break;
                    }
                  }
                }

              if (isOdemeIcraEmriDoc) {
                continue;
              }

              const candidateUrls = [candidateFourthUrl];
              if (candidateFourthUrl.includes('/view_document_brd.uyap')) {
                candidateUrls.push(candidateFourthUrl.replace('/view_document_brd.uyap', '/view_document.uyap'));
              }

              for (const docUrl of [...new Set(candidateUrls)]) {
                dosyaHesabiDebug.urlTried += 1;
                const fourthHeaders = parseHeaders(settings.fourthHeadersText, docCtx);
                const fourth = await runRequestBinary(docUrl, fourthMethod, fourthHeaders, undefined);
                if (!fourth.ok) {
                  continue;
                }
                gotAnyOkPdf = true;
                dosyaHesabiDebug.pdfOk += 1;
                if (fourth.contentType && dosyaHesabiDebug.contentTypes.length < 5) {
                  dosyaHesabiDebug.contentTypes.push(fourth.contentType);
                }
                fourthUrl = docUrl;

                const unwrappedPdf = unwrapPdfLikeBytes(fourth.bytes);
                const amounts = unwrappedPdf
                  ? await extractTakipTalebiAmountsFromPdfBytes(unwrappedPdf)
                  : await extractTakipTalebiAmountsFromPdfBytes(fourth.bytes);

                let finalAsil = amounts.asilAlacak;
                let finalFaiz = amounts.gecmisGunFaizi;
                let finalSource = unwrappedPdf ? "pdf" : "binary-pdf";
                let finalSourceUrl = docUrl;

                if (finalAsil === null && finalFaiz === null) {
                  const bodyText = [
                    new TextDecoder("utf-8", { fatal: false }).decode(fourth.bytes),
                    new TextDecoder("latin1").decode(fourth.bytes)
                  ].join("\n");

                  for (const variant of decodeEscapedTextVariants(bodyText)) {
                    const txtAmounts = extractTakipTalebiAmountsFromText(variant);
                    if (txtAmounts.asilAlacak !== null || txtAmounts.gecmisGunFaizi !== null) {
                      finalAsil = txtAmounts.asilAlacak;
                      finalFaiz = txtAmounts.gecmisGunFaizi;
                      finalSource = "view-document-text";
                      finalSourceUrl = docUrl;
                      break;
                    }
                  }

                  if (finalAsil === null && finalFaiz === null) {
                    const innerUrls = extractInnerDocumentUrls(bodyText, docUrl);
                    for (const innerUrl of innerUrls) {
                      dosyaHesabiDebug.innerUrlTried += 1;
                      const inner = await runRequestBinary(innerUrl, fourthMethod, fourthHeaders, undefined);
                      if (!inner.ok) {
                        continue;
                      }
                      if (inner.contentType && dosyaHesabiDebug.contentTypes.length < 5) {
                        dosyaHesabiDebug.contentTypes.push(inner.contentType);
                      }
                      const unwrappedInner = unwrapPdfLikeBytes(inner.bytes);
                      const innerAmounts = unwrappedInner
                        ? await extractTakipTalebiAmountsFromPdfBytes(unwrappedInner)
                        : await extractTakipTalebiAmountsFromPdfBytes(inner.bytes);
                      if (innerAmounts.asilAlacak !== null || innerAmounts.gecmisGunFaizi !== null) {
                        finalAsil = innerAmounts.asilAlacak;
                        finalFaiz = innerAmounts.gecmisGunFaizi;
                        fourthUrl = innerUrl;
                        finalSource = unwrappedInner ? "inner-pdf" : "inner-binary-pdf";
                        finalSourceUrl = innerUrl;
                        break;
                      }
                    }
                  }
                }

                if (finalAsil !== null || finalFaiz !== null) {
                  if (maybeAdoptTakipParse({
                    ...amounts,
                    asilAlacak: finalAsil,
                    gecmisGunFaizi: finalFaiz
                  }, finalSource, finalSourceUrl, asilFaizEvraki.tur, evrakIdCandidate)) {
                    break;
                  }
                }
              }

              if (bestTakipParseScore >= 10) {
                break;
              }
            }

            shouldTryFallbackDosyaId = !gotAnyOkPdf;
            if (bestTakipParseScore >= 10) {
              break;
            }
          }

            if (bestTakipParseScore >= 10) {
              break;
            }

          }
          if (bestTakipParseScore >= 10) {
            break;
          }
        }

        if (asilAlacak !== null && gecmisGunFaizi === null) {
          const faizTamamlamaAdaylari = dedupeByEvrakId(
            (Array.isArray(tumEvrakList) ? tumEvrakList : []).filter((item) => {
              const tur = normalizeText(item && item.tur);
              return tur.includes("takip talebi") || (tur.includes("takip") && tur.includes("talep")) || tur.includes("odeme icra emri");
            })
          )
            .sort((a, b) => {
              const dateDiff = parseTrDateToTime(b.onaylandigiTarih) - parseTrDateToTime(a.onaylandigiTarih);
              if (dateDiff !== 0) {
                return dateDiff;
              }
              return String(b.evrakId || "").localeCompare(String(a.evrakId || ""), "tr");
            })
            .slice(0, 50);

          for (const evrak of faizTamamlamaAdaylari) {
            if (!evrak || !evrak.evrakId || gecmisGunFaizi !== null) {
              continue;
            }
            const docDosyaIdCandidates = [
              String(evrak.dosyaId || ""),
              String(secondCtx.dosyaId || "")
            ].filter(Boolean);
            const uniqueDocDosyaIds = [...new Set(docDosyaIdCandidates)];
            for (const docDosyaId of uniqueDocDosyaIds) {
              if (gecmisGunFaizi !== null) {
                break;
              }
              const udfUrl = toAbsoluteUrl(
                `/download_document_brd.uyap?dosyaId=${encodeURIComponent(String(docDosyaId || ""))}` +
                  `&evrakId=${encodeURIComponent(String(evrak.evrakId || ""))}` +
                  `&evrak=${encodeURIComponent(String(evrak.tur || ""))}` +
                  `&tarih=${encodeURIComponent(String(evrak.onaylandigiTarih || ""))}` +
                  `&sira=undefined`
              );
              const docCtx = {
                ...secondCtx,
                dosyaId: docDosyaId,
                dosyaIdEncoded: encodeURIComponent(String(docDosyaId || "")),
                evrakId: String(evrak.evrakId || ""),
                evrakIdEncoded: encodeURIComponent(String(evrak.evrakId || "")),
                evrakEncoded: encodeURIComponent(String(evrak.tur || "")),
                tarihEncoded: encodeURIComponent(String(evrak.onaylandigiTarih || ""))
              };
              const udfHeaders = parseHeaders(settings.fourthHeadersText, docCtx);
              const udf = await runRequestBinary(udfUrl, "GET", udfHeaders, undefined);
              if (!udf.ok) {
                continue;
              }
              const udfAmounts = extractTakipTalebiAmountsFromUdfBytes(udf.bytes);
              const parsedFaiz = numberOrNull(udfAmounts.gecmisGunFaizi);
              const parsedAsil = numberOrNull(udfAmounts.asilAlacak);
              if (parsedFaiz === null) {
                continue;
              }
              if (asilAlacak !== null && parsedAsil !== null && Math.abs(parsedAsil - asilAlacak) > 0.01) {
                continue;
              }
              gecmisGunFaizi = parsedFaiz;
              if (aracMahrumiyetFaizi === null && numberOrNull(udfAmounts.aracMahrumiyetFaizi) !== null) {
                aracMahrumiyetFaizi = udfAmounts.aracMahrumiyetFaizi;
              }
              break;
            }
          }
        }
        const vekaletAdaylari = selectVekaletPuluCandidates(tumEvrakList);
        for (const vekalet of vekaletAdaylari) {
          if (!vekalet || !vekalet.evrakId) {
            continue;
          }
          const fourthMethod = String(settings.fourthMethod || "GET").toUpperCase();
          const docDosyaIdCandidates = [
            String(vekalet.dosyaId || ""),
            String(secondCtx.dosyaId || "")
          ].filter(Boolean);
          const uniqueDocDosyaIds = [...new Set(docDosyaIdCandidates)];
          const evrakIdCandidates = [String(vekalet.evrakId || "")];
          const uniqueEvrakIds = [...new Set(evrakIdCandidates.filter(Boolean))];

          let foundVekalet = false;
          for (const docDosyaId of uniqueDocDosyaIds) {
            if (foundVekalet) {
              break;
            }
            for (const evrakIdCandidate of uniqueEvrakIds) {
              const docCtx = {
                ...secondCtx,
                dosyaId: docDosyaId,
                dosyaIdEncoded: encodeURIComponent(String(docDosyaId || "")),
                evrakId: String(evrakIdCandidate || ""),
                evrakIdEncoded: encodeURIComponent(String(evrakIdCandidate || "")),
                evrakEncoded: encodeURIComponent(String(vekalet.tur || "")),
                tarihEncoded: encodeURIComponent(String(vekalet.onaylandigiTarih || ""))
              };
              const candidateFourthUrl = toAbsoluteUrl(applyTemplate(settings.fourthEndpointPath, docCtx));
              const candidateUrls = [candidateFourthUrl];
              if (candidateFourthUrl.includes('/view_document_brd.uyap')) {
                candidateUrls.push(candidateFourthUrl.replace('/view_document_brd.uyap', '/view_document.uyap'));
              }

              for (const docUrl of [...new Set(candidateUrls)]) {
                const fourthHeaders = parseHeaders(settings.fourthHeadersText, docCtx);
                const fourth = await runRequestBinary(docUrl, fourthMethod, fourthHeaders, undefined);
                if (!fourth.ok) {
                  continue;
                }

                const bodyText = [
                  new TextDecoder("utf-8", { fatal: false }).decode(fourth.bytes),
                  new TextDecoder("latin1").decode(fourth.bytes)
                ].join("\n");

                for (const variant of decodeEscapedTextVariants(bodyText)) {
                  const info = extractVekaletPuluInfoFromHtmlText(variant);
                  if (info.tutar === null) {
                    continue;
                  }
                  if (!matchIslemYapanToAlacakli(info.islemYapan, alacakliNameKeys)) {
                    continue;
                  }
                  vekaletPulu = info.tutar;
                  foundVekalet = true;
                  break;
                }

                if (foundVekalet) {
                  break;
                }
              }

              if (foundVekalet) {
                break;
              }
            }
          }

          if (foundVekalet) {
            break;
          }
        }

        {
          const oran = hasHacizTalebi ? 4.55 : 2.275;
          const bazMiktar =
            takipteKesinlesenMiktar !== null
              ? takipteKesinlesenMiktar
              : (asilAlacak !== null && gecmisGunFaizi !== null ? (asilAlacak + gecmisGunFaizi) : null);
          const pesinHarcDegeri = pesinHarc !== null ? pesinHarc : 0;
          if (bazMiktar !== null) {
            tahsilHarciHesap = Number((((bazMiktar) * oran) / 100 - pesinHarcDegeri).toFixed(2));
          }
        }
        }
      }
    }

    if (enableBarcode === true || runMode === "dosyaHesabi") {
      let thirdJsonForTracking = evrakPayloadForTracking;

      if (!thirdJsonForTracking) {
        const thirdUrlResolved = toAbsoluteUrl(applyTemplate(settings.thirdEndpointPath, secondCtx));
        const thirdMethod = String(settings.thirdMethod || "POST").toUpperCase();
        const thirdHeaders = parseHeaders(settings.thirdHeadersText, secondCtx);
        const thirdBody = applyJsonBodyTemplate(settings.thirdBodyTemplate, secondCtx);
        const third = await runRequest(thirdUrlResolved, thirdMethod, thirdHeaders, thirdBody);
        thirdUrl = thirdUrlResolved;
        barcodeDebug.thirdOk = !!(third.ok && third.json);
        thirdJsonForTracking = third.ok && third.json ? third.json : null;
      } else {
        barcodeDebug.thirdOk = true;
      }

      if (thirdJsonForTracking) {
        const evrakList = collectEvrakItems(thirdJsonForTracking);
        const tumEvrakList = collectTumEvraklarItems(thirdJsonForTracking);
        const candidates = selectBarcodeCandidates(evrakList);
        barcodeDebug.evrakCount = evrakList.length;
        barcodeDebug.candidateCount = candidates.length;

        for (const evrak of candidates) {
          const evrakTurNorm = normalizeText(evrak && evrak.tur);
          const isETeblig = evrakTurNorm.includes("kapali e-teblig mazbatasi");
          let evrakBarcode = null;
          let evrakBarcodeUrl = null;
          const fourthMethod = String(settings.fourthMethod || "GET").toUpperCase();
          const docDosyaIdCandidates = [
            String(evrak.dosyaId || ""),
            String(secondCtx.dosyaId || "")
          ].filter(Boolean);
          const uniqueDocDosyaIds = [...new Set(docDosyaIdCandidates)];
          let shouldTryFallbackDosyaId = false;

          for (let idx = 0; idx < uniqueDocDosyaIds.length; idx += 1) {
            const docDosyaId = uniqueDocDosyaIds[idx];
            if (idx > 0 && !shouldTryFallbackDosyaId) {
              break;
            }
            const docCtx = {
              ...secondCtx,
              dosyaId: docDosyaId,
              dosyaIdEncoded: encodeURIComponent(String(docDosyaId || "")),
              evrakId: String(evrak.evrakId || ""),
              evrakIdEncoded: encodeURIComponent(String(evrak.evrakId || "")),
              evrakEncoded: encodeURIComponent(String(evrak.tur || "")),
              tarihEncoded: encodeURIComponent(String(evrak.onaylandigiTarih || ""))
            };

            const downloadUrl = toAbsoluteUrl(
              `/download_document_brd.uyap?dosyaId=${encodeURIComponent(String(docDosyaId || ""))}` +
                `&evrakId=${encodeURIComponent(String(evrak.evrakId || ""))}` +
                `&evrak=${encodeURIComponent(String(evrak.tur || ""))}` +
                `&tarih=${encodeURIComponent(String(evrak.onaylandigiTarih || ""))}` +
                `&sira=undefined`
            );
            const candidateFourthUrl = toAbsoluteUrl(applyTemplate(settings.fourthEndpointPath, docCtx));
            const fourthHeaders = parseHeaders(settings.fourthHeadersText, docCtx);
            const binaryCandidates = [];
            const downloaded = await runRequestBinary(downloadUrl, fourthMethod, fourthHeaders, undefined);
            barcodeDebug.triedPdfCount += 1;
            if (barcodeDebug.tried.length < 10) {
              barcodeDebug.tried.push({
                evrakId: String(evrak.evrakId || ""),
                dosyaId: String(docDosyaId || ""),
                status: downloaded.status,
                ok: !!downloaded.ok,
                size: downloaded.bytes ? downloaded.bytes.length : 0
              });
            }
            if (downloaded.ok) {
              binaryCandidates.push({
                url: downloadUrl,
                bytes: unwrapPdfLikeBytes(downloaded.bytes) || downloaded.bytes
              });
            }

            const fourth = await runRequestBinary(candidateFourthUrl, fourthMethod, fourthHeaders, undefined);
            barcodeDebug.triedPdfCount += 1;
            if (barcodeDebug.tried.length < 10) {
              barcodeDebug.tried.push({
                evrakId: String(evrak.evrakId || ""),
                dosyaId: String(docDosyaId || ""),
                status: fourth.status,
                ok: !!fourth.ok,
                size: fourth.bytes ? fourth.bytes.length : 0
              });
            }
            if (fourth.ok) {
              binaryCandidates.push({
                url: candidateFourthUrl,
                bytes: unwrapPdfLikeBytes(fourth.bytes) || fourth.bytes
              });
            }

            if (binaryCandidates.length === 0) {
              shouldTryFallbackDosyaId = true;
              continue;
            }
            shouldTryFallbackDosyaId = false;

            if (isETeblig) {
              for (const candidate of binaryCandidates) {
                const eteblig = await extractETebligInfoFromPdfBytes(
                  candidate.bytes,
                  extractKisiFromAciklama(evrak.aciklama)
                );
                if (eteblig && eteblig.tebligTarihi) {
                  let evrakYediGunSonrasi = null;
                  let evrakIsMatch = false;
                  const tebligMs = parseTrDateToTime(eteblig.tebligTarihi);
                  if (tebligMs > 0) {
                    evrakYediGunSonrasi = new Date(tebligMs + 8 * 24 * 60 * 60 * 1000).toISOString();
                    const now = new Date();
                    const todayUtc = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
                    evrakIsMatch = todayUtc >= Date.parse(evrakYediGunSonrasi);
                  }

                  tebligDetaylari.push({
                    evrakId: String(evrak.evrakId || ""),
                    kisi: eteblig.kisi || extractKisiFromAciklama(evrak.aciklama),
                    barcode: "",
                    tebligTarihi: eteblig.tebligTarihi,
                    tebligYediGunSonrasi: evrakYediGunSonrasi,
                    isMatch: evrakIsMatch,
                    fourthUrl: candidate.url
                  });
                  evrakBarcodeUrl = candidate.url;
                  break;
                }
              }
              continue;
            } else {
              for (const candidate of binaryCandidates) {
                const found = await extractBarcodeFromPdfBytes(candidate.bytes);
                if (found) {
                  evrakBarcode = found;
                  evrakBarcodeUrl = candidate.url;
                  break;
                }
              }
              if (evrakBarcode) {
                break;
              }
            }
          }

          if (isETeblig) {
            continue;
          }

          if (!evrakBarcode) {
            continue;
          }

          const pttHeaders = {
            Accept: "application/json",
            "Content-Type": "application/json; charset=UTF-8",
            Origin: "https://www.ptt.gov.tr",
            Referer: "https://www.ptt.gov.tr/"
          };

          let evrakTebligTarihi = null;
          let evrakYediGunSonrasi = null;
          let evrakIsMatch = false;

          pttUrl = toAbsoluteUrl("/ptt_barkod_sorgula.ajx");
          const ptt = await runRequest(
            pttUrl,
            "POST",
            pttHeaders,
            JSON.stringify({ barcode: evrakBarcode })
          );

          if (ptt.ok && ptt.json) {
            evrakTebligTarihi = extractTebligDateFromPtt(ptt.json);
          }

          if (!evrakTebligTarihi) {
            const pttApiUrl = "https://api.ptt.gov.tr/api/ShipmentTracking";
            const pttApi = await runRequestViaExtension(
              pttApiUrl,
              "POST",
              pttHeaders,
              JSON.stringify([evrakBarcode])
            );
            if (pttApi.ok && pttApi.json) {
              evrakTebligTarihi = extractTebligDateFromPttApi(pttApi.json);
            }
          }

          if (evrakTebligTarihi) {
            const tebligMs = parseTrDateToTime(evrakTebligTarihi);
            if (tebligMs > 0) {
              // Kesinlesme, teslim gununu takip eden 7 tam gun bittikten sonra (8. gun) olur.
              evrakYediGunSonrasi = new Date(tebligMs + 8 * 24 * 60 * 60 * 1000).toISOString();
              const now = new Date();
              const todayUtc = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
              evrakIsMatch = todayUtc >= Date.parse(evrakYediGunSonrasi);
            }
          }

          tebligDetaylari.push({
            evrakId: String(evrak.evrakId || ""),
            kisi: extractKisiFromAciklama(evrak.aciklama),
            barcode: evrakBarcode,
            tebligTarihi: evrakTebligTarihi,
            tebligYediGunSonrasi: evrakYediGunSonrasi,
            isMatch: evrakIsMatch,
            fourthUrl: evrakBarcodeUrl
          });
        }

        if (tebligDetaylari.length > 0) {
          const borcluKeys = new Set(
            tebligDetaylari
              .map((x) => normalizeText(x && x.kisi))
              .filter((x) => !!x)
          );
          borcluSayisi = borcluKeys.size;
          let maxKesinlesmeMs = 0;
          let minKesinlesmeMs = 0;
          for (const d of tebligDetaylari) {
            const ms = Date.parse(String(d.tebligYediGunSonrasi || ""));
            if (!Number.isFinite(ms) || ms <= 0) {
              continue;
            }
            if (ms > maxKesinlesmeMs) {
              maxKesinlesmeMs = ms;
            }
            if (minKesinlesmeMs <= 0 || ms < minKesinlesmeMs) {
              minKesinlesmeMs = ms;
            }
          }
          if (maxKesinlesmeMs > 0) {
            itirazKontrolTarihi = new Date(maxKesinlesmeMs).toISOString();
            borcaItirazSayisi = countBorcaItirazBefore(tumEvrakList, maxKesinlesmeMs);
          }
          if (runMode === "dosyaHesabi" && minKesinlesmeMs > 0) {
            // Dosya Hesabi kurali: herhangi bir borcluya teblig +8 gun yeterli.
            dosyaKesinlesmeMs = minKesinlesmeMs;
          }

          const firstWithDate = tebligDetaylari.find((x) => !!x.tebligTarihi) || tebligDetaylari[0];
          if (firstWithDate) {
            barcode = firstWithDate.barcode || null;
            barcodeSource = "pdf";
            barcodeEvrakId = firstWithDate.evrakId || null;
            tebligTarihi = firstWithDate.tebligTarihi || null;
            tebligYediGunSonrasi = firstWithDate.tebligYediGunSonrasi || null;
            fourthUrl = firstWithDate.fourthUrl || null;
          }
        }
      }
    }

    if (runMode === "dosyaHesabi") {
      if (isIlamliTakip && !dosyaHesabiDebug.ilamliForcedByItirazOdemeEmri) {
        if (aracMahrumiyetBedeli !== null) {
          asilAlacak = aracMahrumiyetBedeli;
          if (aracMahrumiyetFaizi !== null) {
            gecmisGunFaizi = aracMahrumiyetFaizi;
          }
        } else if (mahkemeVekaletUcreti !== null) {
          asilAlacak = mahkemeVekaletUcreti;
          if (mahkemeVekaletUcretiFaizi !== null) {
            gecmisGunFaizi = mahkemeVekaletUcretiFaizi;
          }
        } else if (mahkemeYargilamaGiderleri !== null) {
          asilAlacak = mahkemeYargilamaGiderleri;
          if (mahkemeYargilamaGiderleriFaizi !== null) {
            gecmisGunFaizi = mahkemeYargilamaGiderleriFaizi;
          }
        } else if (mahkemeHarclari !== null) {
          asilAlacak = mahkemeHarclari;
          if (mahkemeHarclariFaizi !== null) {
            gecmisGunFaizi = mahkemeHarclariFaizi;
          }
        }
      }

      const odemeDate = parseOdemeDateInput(settings.dosyaHesabiOdemeTarihi);
      icraFaizTutari = odemeDate ? computeIcraFaizTutari(asilAlacak, talepTarihi, odemeDate, settings) : null;

      const odemeMs = odemeDate
        ? Date.UTC(odemeDate.getUTCFullYear(), odemeDate.getUTCMonth(), odemeDate.getUTCDate())
        : 0;
      const odemeTarihindeKesinlesmis = dosyaKesinlesmeMs > 0 && odemeMs >= dosyaKesinlesmeMs;
      const kesinlesmeEsigiGecildi = odemeTarihindeKesinlesmis;

      if (!isIlamliTakip && asilAlacak !== null) {
        const vekaletBaz = Number(Math.min(asilAlacak, 9000).toFixed(2));
        const oran = kesinlesmeEsigiGecildi ? 1 : 0.75;
        vekaletUcretiDosyaHesap = Number((vekaletBaz * oran).toFixed(2));
      }

      if (!isIlamliTakip && asilAlacak !== null && gecmisGunFaizi !== null && icraFaizTutari !== null) {
        danismanlikUcreti = Number((((asilAlacak + gecmisGunFaizi + icraFaizTutari) * 20) / 100).toFixed(2));
      }

      if (isIlamliTakip && odemeDate) {
        ygIcraFaiz = mahkemeYargilamaGiderleri !== null
          ? computeIcraFaizTutari(mahkemeYargilamaGiderleri, talepTarihi, odemeDate, settings)
          : null;
        harcIcraFaiz = mahkemeHarclari !== null
          ? computeIcraFaizTutari(mahkemeHarclari, talepTarihi, odemeDate, settings)
          : null;
        ivuIcraFaiz = mahkemeVekaletUcreti !== null
          ? computeIcraFaizTutari(mahkemeVekaletUcreti, talepTarihi, odemeDate, settings)
          : null;
      }

      const toplamKalemler = [
        asilAlacak,
        gecmisGunFaizi,
        icraFaizTutari,
        pesinHarc,
        basvurmaHarci,
        vekaletSuretHarci,
        tahsilHarciHesap,
        vekaletPulu,
        tebligatGideri,
        vekaletUcretiDosyaHesap
      ];

      if (isIlamliTakip) {
        toplamKalemler.push(
          mahkemeVekaletUcreti,
          mahkemeVekaletUcretiFaizi,
          mahkemeYargilamaGiderleri,
          mahkemeYargilamaGiderleriFaizi,
          mahkemeHarclari,
          mahkemeHarclariFaizi,
          ygIcraFaiz,
          harcIcraFaiz,
          ivuIcraFaiz
        );
      }

      toplamBorcHesap = sumNumericAmounts(toplamKalemler);

      masrafToplami = sumNumericAmounts([
        vekaletPulu,
        tebligatGideri,
        basvurmaHarci,
        vekaletSuretHarci,
        pesinHarc,
        tahsilHarciHesap
      ]);

      vazgecmeHesabi = sumNumericAmounts([
        vekaletUcretiDosyaHesap,
        danismanlikUcreti,
        tahsilHarciHesap,
        vekaletPulu,
        tebligatGideri,
        pesinHarc,
        basvurmaHarci,
        vekaletSuretHarci
      ]);

      anaPara = sumNumericAmounts([asilAlacak, gecmisGunFaizi, icraFaizTutari]);
      if (anaPara !== null && danismanlikUcreti !== null) {
        hakEdis = Number((anaPara - danismanlikUcreti).toFixed(2));
      }

      const indirimBaz = sumNumericAmounts([asilAlacak, gecmisGunFaizi, icraFaizTutari]);
      const indirimEkKalemler = sumNumericAmounts([
        mahkemeYargilamaGiderleri,
        mahkemeYargilamaGiderleriFaizi,
        ygIcraFaiz,
        mahkemeHarclari,
        mahkemeHarclariFaizi,
        harcIcraFaiz,
        mahkemeVekaletUcreti,
        mahkemeVekaletUcretiFaizi,
        ivuIcraFaiz,
        vekaletPulu,
        tebligatGideri,
        basvurmaHarci,
        vekaletSuretHarci,
        pesinHarc,
        tahsilHarciHesap,
        vekaletUcretiDosyaHesap
      ]);

      if (indirimBaz !== null) {
        indirimYeniAsilAlacak = Number(((((indirimBaz) * 0.8) - indirimTutari) * 1.25).toFixed(2));
      }
      if (indirimYeniAsilAlacak !== null && danismanlikUcreti !== null) {
        indirimYeniDanismanlikUcreti = Number((danismanlikUcreti - (indirimYeniAsilAlacak * 0.2)).toFixed(2));
      }
      indirimliToplamBorc = sumNumericAmounts([indirimYeniAsilAlacak, indirimYeniDanismanlikUcreti, indirimEkKalemler]);

      if (dosyaHesabiHesapTuru === "vazgecme" && vazgecmeHesabi !== null) {
        toplamBorcHesap = vazgecmeHesabi;
      }
      if (dosyaHesabiHesapTuru === "indirim" && indirimliToplamBorc !== null) {
        toplamBorcHesap = indirimliToplamBorc;
      }
    }

    let isMatch = secondOk && yatanPara !== null && yatanPara > 0;
    if (runMode === "dosyaHesabi") {
      isMatch = !!talepTarihi;
    } else if (runMode === "reddiyat") {
      isMatch = Array.isArray(reddiyatKalemleri) && reddiyatKalemleri.length > 0;
    } else if (runMode === "kalan") {
      const threshold = Number(String(settings.kalanQueryAmount || "").replace(",", "."));
      kalanQueryThreshold = Number.isFinite(threshold) && threshold >= 0 ? threshold : null;
      isMatch = Number.isFinite(threshold) && threshold >= 0 && kalanBorc !== null && Number(kalanBorc) < threshold;
    } else if (enableBarcode === true) {
      const tebligOlgun = tebligDetaylari.some((x) => !!x.isMatch);
      const hicItirazYok = borcaItirazSayisi === 0;
      isMatch = tebligOlgun && hicItirazYok;
    }

    return {
      runMode,
      input: parsed.raw,
      birimAdi: String(birimAdi || ""),
      dosyaYil: parsed.dosyaYil,
      dosyaSira: parsed.dosyaSira,
      success: runMode === "dosyaHesabi" ? dosyaHesabiOk : (enableBarcode === true ? true : secondOk),
      status: runMode === "dosyaHesabi" ? dosyaHesabiStatus : (enableBarcode === true ? first.status : secondStatus),
      isMatch,
      yatanPara,
      reddiyatKalanMiktari,
      reddiyatKalemleri,
      kalanBorc,
      kalanQueryThreshold,
      talepTarihi,
      asilAlacak,
      gecmisGunFaizi,
      vekaletPulu,
      tebligatGideri,
      pesinHarc,
      basvurmaHarci,
      vekaletSuretHarci,
      tahsilHarciHesap,
      takipteKesinlesenMiktar,
      vekaletUcretiDosyaHesap,
      icraFaizTutari,
      danismanlikUcreti,
      toplamBorcHesap,
      masrafToplami,
      vazgecmeHesabi,
      anaPara,
      hakEdis,
      indirimTutari,
      indirimYeniAsilAlacak,
      indirimYeniDanismanlikUcreti,
      indirimliToplamBorc,
      dosyaHesabiHesapTuru,
      aracMahrumiyetBedeli,
      aracMahrumiyetFaizi,
      mahkemeVekaletUcreti,
      mahkemeVekaletUcretiFaizi,
      mahkemeYargilamaGiderleri,
      mahkemeYargilamaGiderleriFaizi,
      mahkemeHarclari,
      mahkemeHarclariFaizi,
      ygIcraFaiz,
      harcIcraFaiz,
      ivuIcraFaiz,
      takibinTuruAciklama,
      isIlamliTakip,
      dosyaHesabiDebug,
      barcode,
      barcodeSource,
      barcodeEvrakId,
      tebligTarihi,
      tebligYediGunSonrasi,
      tebligDetaylari,
      borcaItirazSayisi,
      borcluSayisi,
      itirazKontrolTarihi,
      pttUrl,
      barcodeDebug,
      dosyaId: String(dosyaId),
      firstUrl,
      secondUrl,
      thirdUrl,
      fourthUrl,
      responseText: enableBarcode === true ? null : secondText,
      responseJson: enableBarcode === true ? null : secondJson,
      error:
        runMode === "dosyaHesabi"
          ? (dosyaHesabiOk ? null : `Evrak listesi istegi HTTP ${dosyaHesabiStatus}`)
          : (enableBarcode === true ? null : (secondOk ? null : `${runMode === "reddiyat" ? "Reddiyat" : "Ikinci"} istek HTTP ${secondStatus}`))
    };
  };

  const emitProgress = (requestId, total, items, runMode, stopped = false) => {
    const matched =
      runMode === "kesinlestirme"
        ? items
            .filter((x) => x.isMatch && Array.isArray(x.tebligDetaylari) && x.tebligDetaylari.length > 0)
            .map((x) => ({
              input: x.input,
              tebligDetaylari: x.tebligDetaylari.filter((d) => !!d.tebligTarihi)
            }))
        : runMode === "dosyaHesabi"
          ? items
              .filter((x) => x.isMatch && !!x.talepTarihi)
              .map((x) => ({
                input: x.input,
                talepTarihi: x.talepTarihi,
                tebligTarihi: x.tebligTarihi,
                asilAlacak: x.asilAlacak,
                gecmisGunFaizi: x.gecmisGunFaizi,
                vekaletPulu: x.vekaletPulu,
                tebligatGideri: x.tebligatGideri,
                pesinHarc: x.pesinHarc,
                basvurmaHarci: x.basvurmaHarci,
                vekaletSuretHarci: x.vekaletSuretHarci,
                tahsilHarciHesap: x.tahsilHarciHesap,
                takipteKesinlesenMiktar: x.takipteKesinlesenMiktar,
                vekaletUcretiDosyaHesap: x.vekaletUcretiDosyaHesap,
                icraFaizTutari: x.icraFaizTutari,
                danismanlikUcreti: x.danismanlikUcreti,
                toplamBorcHesap: x.toplamBorcHesap,
                masrafToplami: x.masrafToplami,
                vazgecmeHesabi: x.vazgecmeHesabi,
                anaPara: x.anaPara,
                hakEdis: x.hakEdis,
                indirimTutari: x.indirimTutari,
                indirimYeniAsilAlacak: x.indirimYeniAsilAlacak,
                indirimYeniDanismanlikUcreti: x.indirimYeniDanismanlikUcreti,
                indirimliToplamBorc: x.indirimliToplamBorc,
                dosyaHesabiHesapTuru: x.dosyaHesabiHesapTuru,
                aracMahrumiyetBedeli: x.aracMahrumiyetBedeli,
                aracMahrumiyetFaizi: x.aracMahrumiyetFaizi,
                mahkemeVekaletUcreti: x.mahkemeVekaletUcreti,
                mahkemeVekaletUcretiFaizi: x.mahkemeVekaletUcretiFaizi,
                mahkemeYargilamaGiderleri: x.mahkemeYargilamaGiderleri,
                mahkemeYargilamaGiderleriFaizi: x.mahkemeYargilamaGiderleriFaizi,
                mahkemeHarclari: x.mahkemeHarclari,
                mahkemeHarclariFaizi: x.mahkemeHarclariFaizi,
                ygIcraFaiz: x.ygIcraFaiz,
                harcIcraFaiz: x.harcIcraFaiz,
                ivuIcraFaiz: x.ivuIcraFaiz,
                takibinTuruAciklama: x.takibinTuruAciklama,
                dosyaHesabiDebug: x.dosyaHesabiDebug
              }))
        : runMode === "reddiyat"
          ? items
              .filter((x) => x.isMatch)
              .map((x) => ({ input: x.input, reddiyatKalemleri: x.reddiyatKalemleri }))
        : (runMode === "talepMasrafAvansIadesi" || runMode === "talepBorcluOdemeAktar" || runMode === "talepEvrakiOlustur")
          ? items
              .filter((x) => x.success || x.error)
              .map((x) => ({ input: x.input, birimAdi: x.birimAdi, success: x.success, error: x.error, message: x.message, talepAdi: x.talepAdi }))
        : items
              .filter((x) => x.isMatch)
              .map((x) => ({ input: x.input, yatanPara: x.yatanPara, reddiyatKalanMiktari: x.reddiyatKalanMiktari, kalanBorc: x.kalanBorc, kalanQueryThreshold: x.kalanQueryThreshold }));
    const barcodeCount = items.filter((x) => !!x.barcode).length;

    window.postMessage(
      {
        __EWR_PAGE_PROGRESS__: true,
        requestId,
        progress: {
          total,
          processed: items.length,
          matchCount: matched.length,
          barcodeCount,
          runMode,
          matched,
          stopped,
          activeInput: String(runState.activeInput || ""),
          activeStepLabel: String(runState.activeStepLabel || "")
        }
      },
      "*"
    );
  };

  const runWorkflow = async (requestId, settings, inputs, runMode, enableBarcode) => {
    if (runState.isRunning) {
      throw new Error("İşlem zaten çalışıyor.");
    }
    runState.isRunning = true;
    runState.stopRequested = false;

    const s = { ...DEFAULT_SETTINGS, ...(settings || {}) };
    const cleanInputs = Array.isArray(inputs)
      ? inputs
          .map((x) => {
            if (x && typeof x === "object") {
              const dosyaNo = String(x.dosyaNo || "").trim();
              if (!dosyaNo) {
                return null;
              }
              return {
                dosyaNo,
                birimAdi: String(x.birimAdi || "").trim(),
                birimId: String(x.birimId || "").trim()
              };
            }
            const s = String(x || "").trim();
            return s ? s : null;
          })
          .filter(Boolean)
      : [];

    const items = [];
    let stopped = false;

    try {
      let isFirstInput = true;
      for (const input of cleanInputs) {
        if (runState.stopRequested) {
          stopped = true;
          break;
        }
        const shouldDelayBetweenInputs =
          true;
        if (!isFirstInput && shouldDelayBetweenInputs) {
          await new Promise((r) => setTimeout(r, 1000));
          if (runState.stopRequested) { stopped = true; break; }
        }
        isFirstInput = false;

        try {
          const result = await runOne(input, s, runMode, enableBarcode);
          items.push(result);
          emitProgress(requestId, cleanInputs.length, items, runMode, false);
        } catch (error) {
          const msg = String(error && error.message ? error.message : error);
          if (msg === "STOP_REQUESTED") {
            stopped = true;
            emitProgress(requestId, cleanInputs.length, items, runMode, true);
            break;
          }
          items.push({
            input,
            success: false,
            status: 0,
            error: msg
          });
          emitProgress(requestId, cleanInputs.length, items, runMode, false);
        }
      }
    } finally {
      clearQueryActiveStep();
      runState.isRunning = false;
      runState.stopRequested = false;
      runState.activeController = null;
    }

    const matchedInputs = items.filter((x) => x.isMatch).map((x) => x.input);

    return {
      runMode,
      ranAt: new Date().toISOString(),
      total: cleanInputs.length,
      processed: items.length,
      stopped,
      successCount: items.filter((x) => x.success).length,
      matchCount: matchedInputs.length,
      barcodeCount: items.filter((x) => !!x.barcode).length,
      matchedInputs,
      items
    };
  };

  window.addEventListener("message", (event) => {
    if (event.source !== window || !event.data || event.data.__EWR_EXT__ !== true) {
      return;
    }

    const data = event.data;
    if (data.type === "STOP_WORKFLOW") {
      runState.stopRequested = true;
      if (runState.activeController) {
        runState.activeController.abort();
      }
      return;
    }

    if (data.type !== "RUN_WORKFLOW") {
      return;
    }
    if (!data.requestId || handledRequestIds.has(data.requestId)) {
      return;
    }
    handledRequestIds.add(data.requestId);

    runWorkflow(
      data.requestId,
      data.settings,
      data.inputs,
      data.runMode || "normal",
      !!data.enableBarcode
    )
      .then((result) => {
        window.postMessage(
          {
            __EWR_PAGE__: true,
            requestId: data.requestId,
            ok: true,
            result
          },
          "*"
        );
      })
      .catch((error) => {
        window.postMessage(
          {
            __EWR_PAGE__: true,
            requestId: data.requestId,
            ok: false,
            error: String(error && error.message ? error.message : error)
          },
          "*"
        );
      })
      .finally(() => {
        
        if (handledRequestIds.size > 2000) {
          handledRequestIds.clear();
        }
      });
  });
})();

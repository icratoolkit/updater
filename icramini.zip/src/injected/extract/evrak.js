(() => {
  const C = window.__EWR_PR_Core;
  if (!C) {
    console.error("extract/evrak.js: page-runner-core.js önce yüklenmeli.");
    return;
  }

  const { normalizeText, parseTrDateToTime } = C;

  const extractTebligDateFromPtt = (pttJson) => {
    const rows = pttJson && Array.isArray(pttJson.dongu) ? pttJson.dongu : [];
    let selectedDate = null;
    let selectedTime = Number.POSITIVE_INFINITY;

    for (const row of rows) {
      const islemRaw = String((row && row.ISLEM) || "");
      const islem = normalizeText(islemRaw).replace(/\s+/g, " ").trim();
      const tarih = String((row && row.ITARIH) || "").trim();
      if (!tarih) {
        continue;
      }

      // "TESLIM EDILDI", "TESLIM EDILDI MUHATABA ...", etc.

      if (/\bteslim\s+edildi\b/i.test(islem) && !/\biade\b/i.test(islem)) {
        const t = parseTrDateToTime(tarih);
        if (t > 0 && t < selectedTime) {
          selectedTime = t;
          selectedDate = tarih;
        }
      }
    }
    return selectedDate;
  };

  const toTrDateFromCompact = (raw) => {
    const s = String(raw || "").trim();
    const m = s.match(/^(\d{4})(\d{2})(\d{2})$/);
    if (!m) {
      return null;
    }
    return `${m[3]}/${m[2]}/${m[1]}`;
  };

  const extractTebligDateFromPttApi = (apiJson) => {
    const rows = Array.isArray(apiJson) ? apiJson : [];
    for (const item of rows) {
      if (!item || typeof item !== "object") {
        continue;
      }
      const sonDurum = item.sondurum && typeof item.sondurum === "object" ? item.sondurum : null;
      if (!sonDurum) {
        continue;
      }
      const durum = normalizeText(sonDurum.son_durum_aciklama || sonDurum.teslim_durum_aciklama || "");
      if (!/\bteslim\s+edildi\b/i.test(durum) || /\biade\b/i.test(durum)) {
        continue;
      }
      const rawDate = sonDurum.teslim_tarihi || sonDurum.son_islem_tarihi || "";
      const trDate = toTrDateFromCompact(rawDate);
      if (trDate) {
        return trDate;
      }
    }
    return null;
  };

  const collectEvrakItems = (payload) => {
    const out = [];
    const add = (arr) => {
      if (!Array.isArray(arr)) {
        return;
      }
      for (const item of arr) {
        if (item && typeof item === "object" && item.evrakId) {
          out.push(item);
        }
      }
    };

    if (payload && typeof payload === "object") {
      if (payload.tumEvraklar && typeof payload.tumEvraklar === "object") {
        for (const key of Object.keys(payload.tumEvraklar)) {
          add(payload.tumEvraklar[key]);
        }
      }
      add(payload.son20Evrak);
    }
    return out;
  };

  const collectTumEvraklarItems = (payload) => {
    const out = [];
    if (!payload || typeof payload !== "object" || !payload.tumEvraklar || typeof payload.tumEvraklar !== "object") {
      return out;
    }
    for (const key of Object.keys(payload.tumEvraklar)) {
      const arr = payload.tumEvraklar[key];
      if (!Array.isArray(arr)) {
        continue;
      }
      for (const item of arr) {
        if (item && typeof item === "object" && item.evrakId) {
          out.push(item);
        }
      }
    }
    return out;
  };

  const dedupeByEvrakId = (items) => {
    const seen = new Set();
    const out = [];
    for (const item of items) {
      const id = String(item.evrakId || "");
      if (!id || seen.has(id)) {
        continue;
      }
      seen.add(id);
      out.push(item);
    }
    return out;
  };

  const isBarcodeEvrak = (item) => {
    const tur = normalizeText(item.tur);
    return (
      tur.includes("kapali tebligat") || tur.includes("kapali e-teblig mazbatasi") || tur.includes("teblig mazbatasi")
    );
  };

  const selectBarcodeCandidates = (items) =>
    dedupeByEvrakId(items.filter((item) => isBarcodeEvrak(item)))
      .sort((a, b) => {
        const dateDiff = parseTrDateToTime(b.onaylandigiTarih) - parseTrDateToTime(a.onaylandigiTarih);
        if (dateDiff !== 0) {
          return dateDiff;
        }
        return String(b.evrakId || "").localeCompare(String(a.evrakId || ""), "tr");
      })
      .slice(0, 30);

  const extractLatestTakipTalebiDate = (items) => {
    let bestDate = "";
    let bestMs = 0;
    for (const item of Array.isArray(items) ? items : []) {
      if (!item || typeof item !== "object") {
        continue;
      }
      const tur = normalizeText(item.tur);
      if (!tur.includes("takip talebi")) {
        continue;
      }
      const tarih = String(item.onaylandigiTarih || "").trim();
      if (!tarih) {
        continue;
      }
      const ms = parseTrDateToTime(tarih);
      if (ms > bestMs) {
        bestMs = ms;
        bestDate = tarih;
      }
    }
    return bestDate || null;
  };

  const hasAvukatPortalHacizTalebi = (items) =>
    (Array.isArray(items) ? items : []).some((item) =>
      normalizeText(item && item.tur).includes("avukat portal haciz talebi")
    );

  const estimateDosyaKesinlesmeInfoFromEvrakList = (items) => {
    const rows = Array.isArray(items) ? items : [];
    let bestPriority = 99;
    let earliestTeslimMs = 0;
    let earliestTeslimTarih = null;

    for (const item of rows) {
      if (!item || typeof item !== "object") {
        continue;
      }

      const tur = normalizeText(item.tur);
      const aciklama = normalizeText(item.aciklama).replace(/\s+/g, " ").trim();
      const isBorcluTebligi = aciklama.includes("borclu") || aciklama.includes("muflis");
      const isTeslim = /\bteblig edildi\b/i.test(aciklama) && !/\biade\b/i.test(aciklama);
      const isOdemeIcraEmri = aciklama.includes("odeme icra emri") || aciklama.includes("odeme emri");
      if (!isTeslim || !isBorcluTebligi || !isOdemeIcraEmri) {
        continue;
      }

      let priority = 99;
      if (tur.includes("kapali e-teblig mazbatasi") || tur.includes("teblig mazbatasi")) {
        priority = 1;
      } else if (tur.includes("kapali tebligat")) {
        priority = 2;
      } else {
        continue;
      }

      const teslimTarih = String(item.onaylandigiTarih || item.sistemeGonderildigiTarih || "").trim();
      const teslimMs = parseTrDateToTime(teslimTarih);
      if (teslimMs <= 0) {
        continue;
      }

      if (
        priority < bestPriority ||
        (priority === bestPriority && (earliestTeslimMs <= 0 || teslimMs < earliestTeslimMs))
      ) {
        bestPriority = priority;
        earliestTeslimMs = teslimMs;
        earliestTeslimTarih = teslimTarih || null;
      }
    }

    if (earliestTeslimMs <= 0) {
      return { tebligTarihi: null, kesinlesmeMs: 0 };
    }

    // Dosyada borclulardan herhangi biri teslim oldugunda 8. gunde kesinlesme kabul edilir.
    return {
      tebligTarihi: earliestTeslimTarih,
      kesinlesmeMs: earliestTeslimMs + 8 * 24 * 60 * 60 * 1000
    };
  };

  const selectTakipTalebiCandidates = (items) =>
    dedupeByEvrakId(
      (Array.isArray(items) ? items : []).filter((item) => {
        const tur = normalizeText(item && item.tur);
        return tur.includes("takip talebi") || (tur.includes("takip") && tur.includes("talep"));
      })
    )
      .sort((a, b) => {
        const dateDiff = parseTrDateToTime(b.onaylandigiTarih) - parseTrDateToTime(a.onaylandigiTarih);
        if (dateDiff !== 0) {
          return dateDiff;
        }
        return String(b.evrakId || "").localeCompare(String(a.evrakId || ""), "tr");
      })
      .slice(0, 30);

  const selectOdemeIcraEmriCandidates = (items) =>
    dedupeByEvrakId(
      (Array.isArray(items) ? items : []).filter((item) => normalizeText(item && item.tur).includes("odeme icra emri"))
    )
      .sort((a, b) => {
        const dateDiff = parseTrDateToTime(b.onaylandigiTarih) - parseTrDateToTime(a.onaylandigiTarih);
        if (dateDiff !== 0) {
          return dateDiff;
        }
        return String(b.evrakId || "").localeCompare(String(a.evrakId || ""), "tr");
      })
      .slice(0, 1);

  const selectVekaletPuluCandidates = (items) =>
    dedupeByEvrakId(
      (Array.isArray(items) ? items : []).filter((item) =>
        normalizeText(item && item.tur).includes("vekalet pulu makbuzu")
      )
    )
      .sort((a, b) => {
        const dateDiff = parseTrDateToTime(b.onaylandigiTarih) - parseTrDateToTime(a.onaylandigiTarih);
        if (dateDiff !== 0) {
          return dateDiff;
        }
        return String(b.evrakId || "").localeCompare(String(a.evrakId || ""), "tr");
      })
      .slice(0, 6);

  const countBorcaItirazBefore = (evraklarFromTum, cutoffMsUtc) => {
    if (!Array.isArray(evraklarFromTum) || !Number.isFinite(cutoffMsUtc) || cutoffMsUtc <= 0) {
      return 0;
    }
    const unique = dedupeByEvrakId(evraklarFromTum);
    let count = 0;
    for (const evrak of unique) {
      const tur = normalizeText(evrak && evrak.tur);
      if (!tur.includes("borca itiraz talebi")) {
        continue;
      }
      const tarih = String((evrak && evrak.sistemeGonderildigiTarih) || "").trim();
      const t = parseTrDateToTime(tarih);
      if (t > 0 && t <= cutoffMsUtc) {
        count += 1;
      }
    }
    return count;
  };

  const getEvrakDateMs = (evrak) => {
    if (!evrak || typeof evrak !== "object") {
      return 0;
    }
    const candidates = [
      String(evrak.onaylandigiTarih || "").trim(),
      String(evrak.sistemeGonderildigiTarih || "").trim()
    ].filter(Boolean);
    for (const tarih of candidates) {
      const ms = parseTrDateToTime(tarih);
      if (ms > 0) {
        return ms;
      }
    }
    return 0;
  };

  const shouldTreatAsIlamliByItirazSonrasiOdemeEmri = (evraklarFromTum) => {
    const rows = Array.isArray(evraklarFromTum) ? evraklarFromTum : [];
    let latestItirazMs = 0;
    let latestOdemeIcraEmriMs = 0;

    for (const evrak of rows) {
      const tur = normalizeText(evrak && evrak.tur);
      if (!tur) {
        continue;
      }
      const ms = getEvrakDateMs(evrak);
      if (ms <= 0) {
        continue;
      }
      if (tur.includes("borca itiraz talebi") && ms > latestItirazMs) {
        latestItirazMs = ms;
      }
      if (tur.includes("odeme icra emri") && ms > latestOdemeIcraEmriMs) {
        latestOdemeIcraEmriMs = ms;
      }
    }

    return {
      value: latestItirazMs > 0 && latestOdemeIcraEmriMs > latestItirazMs,
      latestItirazMs,
      latestOdemeIcraEmriMs
    };
  };

  window.__EWR_PR_ExtractEvrak = {
    collectEvrakItems,
    collectTumEvraklarItems,
    countBorcaItirazBefore,
    dedupeByEvrakId,
    estimateDosyaKesinlesmeInfoFromEvrakList,
    extractLatestTakipTalebiDate,
    extractTebligDateFromPtt,
    extractTebligDateFromPttApi,
    getEvrakDateMs,
    hasAvukatPortalHacizTalebi,
    isBarcodeEvrak,
    selectBarcodeCandidates,
    selectOdemeIcraEmriCandidates,
    selectTakipTalebiCandidates,
    selectVekaletPuluCandidates,
    shouldTreatAsIlamliByItirazSonrasiOdemeEmri,
    toTrDateFromCompact
  };
})();

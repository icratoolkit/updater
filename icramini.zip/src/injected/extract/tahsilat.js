(() => {
  const C = window.__EWR_PR_Core;
  if (!C) {
    console.error("extract/tahsilat.js: page-runner-core.js önce yüklenmeli.");
    return;
  }

  const { numberOrNull, normalizeText } = C;
  const { matchIslemYapanToAlacakli } = window.__EWR_PR_ExtractTaraf;

  const normalizeDosyaNo = (value) =>
    String(value || "")
      .replace(/\s+/g, "")
      .trim();

  const extractDosyaMasrafBilgileri = (payload, expectedDosyaNo, alacakliNameKeys) => {
    const out = {
      tebligatGideri: null,
      pesinHarc: null,
      basvurmaHarci: null,
      vekaletSuretHarci: null
    };

    if (!payload || typeof payload !== "object") {
      return out;
    }

    out.tebligatGideri = numberOrNull(payload.haricen);
    const harcList = Array.isArray(payload.harcList) ? payload.harcList : [];
    const dosyaNoKey = normalizeDosyaNo(expectedDosyaNo);

    const collect = (requireNameMatch) => {
      let pesin = 0;
      let basvurma = 0;
      let vekaletSuret = 0;
      let pesinHit = false;
      let basvurmaHit = false;
      let vekaletHit = false;

      for (const row of harcList) {
        if (!row || typeof row !== "object") {
          continue;
        }
        if (dosyaNoKey && normalizeDosyaNo(row.dosyaNo) !== dosyaNoKey) {
          continue;
        }
        if (requireNameMatch && !matchIslemYapanToAlacakli(row.odeyenKisi, alacakliNameKeys)) {
          continue;
        }

        const tur = normalizeText(row.tahsilatTuru).replace(/\s+/g, " ").trim();
        const miktar = numberOrNull(row.miktar);
        if (miktar === null) {
          continue;
        }

        if (tur.includes("pesin harc")) {
          pesin += miktar;
          pesinHit = true;
          continue;
        }
        if (tur.includes("basvurma harci")) {
          basvurma += miktar;
          basvurmaHit = true;
          continue;
        }
        if (tur.includes("vekalet suret harci")) {
          vekaletSuret += miktar;
          vekaletHit = true;
        }
      }

      return {
        pesinHarc: pesinHit ? Number(pesin.toFixed(2)) : null,
        basvurmaHarci: basvurmaHit ? Number(basvurma.toFixed(2)) : null,
        vekaletSuretHarci: vekaletHit ? Number(vekaletSuret.toFixed(2)) : null,
        any: pesinHit || basvurmaHit || vekaletHit
      };
    };

    let fees = collect(true);
    if (!fees.any) {
      fees = collect(false);
    }

    out.pesinHarc = fees.pesinHarc;
    out.basvurmaHarci = fees.basvurmaHarci;
    out.vekaletSuretHarci = fees.vekaletSuretHarci;
    return out;
  };

  const extractReddiyatKalanMiktari = (payload, expectedDosyaNo) => {
    if (!payload || typeof payload !== "object") {
      return null;
    }

    const tahsilatList = Array.isArray(payload.tahsilatList) ? payload.tahsilatList : [];
    const dosyaNoKey = normalizeDosyaNo(expectedDosyaNo);
    let best = null;

    for (const row of tahsilatList) {
      if (!row || typeof row !== "object") {
        continue;
      }
      if (dosyaNoKey && normalizeDosyaNo(row.dosyaNo) !== dosyaNoKey) {
        continue;
      }
      const tahsilatTuru = normalizeText(row.tahsilatTuru).replace(/\s+/g, " ").trim();
      if (!tahsilatTuru.includes("borc tahsilati")) {
        continue;
      }
      const kalanMiktar = numberOrNull(row.kalanMiktar);
      if (kalanMiktar === null || kalanMiktar <= 0) {
        continue;
      }
      best = best === null ? kalanMiktar : Math.max(best, kalanMiktar);
    }

    return best;
  };

  const extractReddiyatTahsilatKalemleri = (payload, expectedDosyaNo, alacakliNameKeys, options) => {
    if (!payload || typeof payload !== "object") {
      return [];
    }
    const tahsilatList = Array.isArray(payload.tahsilatList) ? payload.tahsilatList : [];
    const dosyaNoKey = normalizeDosyaNo(expectedDosyaNo);
    const isDosyaKapali = !!(options && options.isDosyaKapali);
    const out = [];
    const matchingRows = tahsilatList.filter((row) => {
      if (!row || typeof row !== "object") {
        return false;
      }
      return !dosyaNoKey || normalizeDosyaNo(row.dosyaNo) === dosyaNoKey;
    });
    const hasBorcTahsilati = matchingRows.some(
      (row) => normalizeText(row.tahsilatTuru).replace(/\s+/g, " ").trim() === "borc tahsilati"
    );
    const hasAlacakliKeys = alacakliNameKeys instanceof Set && alacakliNameKeys.size > 0;

    for (const row of matchingRows) {
      if (!row || typeof row !== "object") {
        continue;
      }
      const tahsilatTuru = String(row.tahsilatTuru || "").trim();
      const normalizedTahsilatTuru = normalizeText(tahsilatTuru).replace(/\s+/g, " ").trim();
      const kalanMiktar = numberOrNull(row.kalanMiktar);
      if (isDosyaKapali) {
        out.push({
          birimAdi: String(row.birimAdi || "").trim(),
          dosyaNo: String(row.dosyaNo || expectedDosyaNo || "").trim(),
          tahsilatTuru,
          kalanMiktar
        });
        continue;
      }

      const isMasrafAvansi = normalizedTahsilatTuru === "masraf avansi tahsilati";
      const isBorcTahsilati = normalizedTahsilatTuru === "borc tahsilati";
      if (!isMasrafAvansi && !isBorcTahsilati) {
        continue;
      }
      if (kalanMiktar === null || kalanMiktar <= 0) {
        continue;
      }
      if (
        isMasrafAvansi &&
        (!hasBorcTahsilati || !hasAlacakliKeys || !matchIslemYapanToAlacakli(row.odeyenKisi, alacakliNameKeys))
      ) {
        continue;
      }
      out.push({
        birimAdi: String(row.birimAdi || "").trim(),
        dosyaNo: String(row.dosyaNo || expectedDosyaNo || "").trim(),
        tahsilatTuru,
        kalanMiktar
      });
    }

    return out;
  };

  window.__EWR_PR_ExtractTahsilat = {
    extractDosyaMasrafBilgileri,
    extractReddiyatKalanMiktari,
    extractReddiyatTahsilatKalemleri,
    normalizeDosyaNo
  };
})();

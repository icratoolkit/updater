(() => {
  const C = window.__EWR_PR_Core;
  if (!C) {
    console.error("extract/takip-talebi.js: page-runner-core.js önce yüklenmeli.");
    return;
  }

  const {
    numberOrNull,
    fixMojibake,
    normalizeText,
    sumNumericAmounts,
    addAmount,
    SharedHesapNormalizers,
    SharedHesapClassifiers,
    SharedHesapScoring,
    SharedHesapExtractors
  } = C;
  const { unzipFromLocalHeaders } = window.__EWR_PR_ExtractBinary;
  const { collectPdfTextCandidates } = window.__EWR_PR_ExtractPdf;

  const extractTakipTalebiAmountsFromText = (inputText) => {
    const norm = normalizeText(inputText)
      .replace(/[^a-z0-9.,/%\s]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    if (!norm) {
      return { asilAlacak: null, gecmisGunFaizi: null };
    }

    const parseAmountToken = (token) => {
      const compact = String(token || "")
        .replace(/\s+/g, "")
        .replace(/(?<=\d)[^\d.,-]+(?=\d)/g, "");
      const n = numberOrNull(compact);
      return Number.isFinite(n) ? n : null;
    };

    const collectCandidates = (segment) => {
      const candidates = [];
      const regex = /[0-9][0-9\s.,]*/g;
      let match;

      while ((match = regex.exec(segment)) !== null) {
        const token = match[0];
        const trimmedToken = String(token).trim();
        const amount = parseAmountToken(token);
        if (amount === null) {
          continue;
        }

        const start = match.index;
        const end = start + token.length;
        const before = segment.slice(Math.max(0, start - 8), start);
        const after = segment.slice(end, Math.min(segment.length, end + 12));
        const around = `${before} ${token} ${after}`;
        let score = 0;

        if (/[.,]\d{2}$/.test(trimmedToken) || /\d+\.\d{3}(?:,\d{2})?$/.test(trimmedToken)) {
          score += 4;
        }
        if (/\btl\b/i.test(around)) {
          score += 3;
        }
        if (/%\s*$/.test(before) || /^\s*%/.test(after)) {
          score -= 6;
        }
        if (/^\d{1,2}$/.test(trimmedToken)) {
          score -= 4;
        }
        if (amount < 100 && !/[.,]\d{2}$/.test(trimmedToken)) {
          score -= 3;
        }
        if (/^\d{1,2}$/.test(trimmedToken) && !/\btl\b/i.test(around) && !/[.,]\d{2}$/.test(trimmedToken)) {
          score -= 3;
        }

        candidates.push({ amount, score, index: start });
      }

      return candidates;
    };

    const pickBestAmount = (candidates) => {
      const viable = candidates.filter((candidate) => candidate.score > 0);
      const pool = viable.length > 0 ? viable : candidates;
      if (pool.length === 0) {
        return null;
      }
      pool.sort((a, b) => {
        if (b.score !== a.score) {
          return b.score - a.score;
        }
        return b.index - a.index;
      });
      return pool[0].amount;
    };

    const findAmountNearKeyword = (sourceText, keywordRegex) => {
      const mKey = sourceText.match(keywordRegex);
      if (!mKey || typeof mKey.index !== "number") {
        return null;
      }

      const left = sourceText.slice(Math.max(0, mKey.index - 260), mKey.index);
      const leftAmount = pickBestAmount(collectCandidates(left));
      if (leftAmount !== null) {
        return leftAmount;
      }

      const right = sourceText.slice(mKey.index, Math.min(sourceText.length, mKey.index + 160));
      return pickBestAmount(collectCandidates(right));
    };

    const emptyIlamli = {
      aracMahrumiyetBedeli: null,
      aracMahrumiyetFaizi: null,
      mahkemeVekaletUcreti: null,
      mahkemeVekaletUcretiFaizi: null,
      mahkemeYargilamaGiderleri: null,
      mahkemeYargilamaGiderleriFaizi: null,
      mahkemeHarclari: null,
      mahkemeHarclariFaizi: null
    };

    const narrativeAggregated = aggregateTakipEntries(parseNarrativeEntriesFromPlainText(inputText));
    if (
      narrativeAggregated.asilAlacak !== null ||
      narrativeAggregated.gecmisGunFaizi !== null ||
      narrativeAggregated.mahkemeYargilamaGiderleri !== null ||
      narrativeAggregated.mahkemeHarclari !== null ||
      narrativeAggregated.mahkemeVekaletUcreti !== null
    ) {
      return narrativeAggregated;
    }

    const degerKaybiBedeli =
      findAmountNearKeyword(norm, /deger[a-z\s]{0,10}kaybi[a-z\s]{0,25}(?:alacag|alacak|bedel|tazminat|tazminati)/i) ||
      null;
    const ikameAracBedeli =
      findAmountNearKeyword(norm, /ikame[a-z\s]{0,10}arac[a-z\s]{0,25}(?:alacag|alacak|bedel|tazminat|tazminati)/i) ||
      null;
    const degerKaybiFaizi =
      findAmountNearKeyword(norm, /deger[a-z\s]{0,10}kaybi[a-z\s]{0,20}(?:islemis|gecmis)[a-z\s]{0,20}faiz/i) || null;
    const ikameAracFaizi =
      findAmountNearKeyword(norm, /ikame[a-z\s]{0,10}arac[a-z\s]{0,20}(?:islemis|gecmis)[a-z\s]{0,20}faiz/i) || null;
    const degerIkameBedelToplami = sumNumericAmounts([degerKaybiBedeli, ikameAracBedeli]);
    const degerIkameFaizToplami = sumNumericAmounts([degerKaybiFaizi, ikameAracFaizi]);

    let gecmisGunFaizi =
      degerIkameFaizToplami ||
      findAmountNearKeyword(norm, /inkar[a-z\s]{0,20}tazminat[a-z\s]{0,30}(?:islemis|gecmis)[a-z\s]{0,20}faiz/i) ||
      findAmountNearKeyword(norm, /gecmis[a-z\s]{0,15}gun[a-z\s]{0,15}faiz/i) ||
      null;
    const toplamAlacak = findAmountNearKeyword(norm, /toplam\s*alacak/i) || null;

    const inkarTazminati = findAmountNearKeyword(norm, /(?:icra|icda)?[a-z\s]{0,8}inkar[a-z\s]{0,20}tazminat/i) || null;

    let asilAlacak =
      inkarTazminati ||
      degerIkameBedelToplami ||
      findAmountNearKeyword(norm, /kazanc[a-z\s]{0,10}kaybi[a-z\s]{0,25}(?:alacag|alacak|bedel|tazminat|tazminati)/i) ||
      findAmountNearKeyword(norm, /hak\s*mahrum[a-z\s]{0,30}(?:alacag|alacak|bedel|tazminat|tazminati)/i) ||
      findAmountNearKeyword(norm, /asil\s*alacak/i) ||
      null;

    if (toplamAlacak !== null && (gecmisGunFaizi === null || asilAlacak === null)) {
      const topIndex = norm.search(/toplam\s*alacak/i);
      if (topIndex >= 0) {
        const left = norm.slice(Math.max(0, topIndex - 260), topIndex);
        const previousAmount = pickBestAmount(collectCandidates(left));
        if (previousAmount !== null && gecmisGunFaizi === null) {
          gecmisGunFaizi = previousAmount;
        }
      }
    }

    if (asilAlacak === null && toplamAlacak !== null && gecmisGunFaizi !== null) {
      asilAlacak = Number((toplamAlacak - gecmisGunFaizi).toFixed(2));
    }

    const ilamli = {
      aracMahrumiyetBedeli:
        degerIkameBedelToplami ||
        findAmountNearKeyword(
          norm,
          /(?:(?:hak|arac)[a-z\s]{0,12}mahrum[a-z\s]{0,30}|deger[a-z\s]{0,10}kaybi[a-z\s]{0,20}|kazanc[a-z\s]{0,10}kaybi[a-z\s]{0,20}|ikame[a-z\s]{0,10}arac[a-z\s]{0,20})(?:bedel|tazminat|tazminati|alacag|alacak)/i
        ) ||
        null,
      aracMahrumiyetFaizi:
        degerIkameFaizToplami ||
        findAmountNearKeyword(
          norm,
          /(?:(?:hak|arac)[a-z\s]{0,12}mahrum[a-z\s]{0,30}|deger[a-z\s]{0,10}kaybi[a-z\s]{0,20}|kazanc[a-z\s]{0,10}kaybi[a-z\s]{0,20}|ikame[a-z\s]{0,10}arac[a-z\s]{0,20})(?:islemis|gecmis)[a-z\s]{0,20}faiz/i
        ) ||
        null,
      mahkemeVekaletUcreti:
        findAmountNearKeyword(norm, /(mahkeme|ilam)[a-z\s]{0,20}vekalet[a-z\s]{0,10}ucret/i) || null,
      mahkemeVekaletUcretiFaizi:
        findAmountNearKeyword(
          norm,
          /(mahkeme|ilam)[a-z\s]{0,20}vekalet[a-z\s]{0,20}ucret[a-z\s]{0,20}(?:islemis|gecmis)[a-z\s]{0,15}faiz/i
        ) || null,
      mahkemeYargilamaGiderleri:
        findAmountNearKeyword(norm, /(mahkeme[a-z\s]{0,10})?yargilama[a-z\s]{0,10}gider/i) || null,
      mahkemeYargilamaGiderleriFaizi:
        findAmountNearKeyword(
          norm,
          /(mahkeme[a-z\s]{0,10})?yargilama[a-z\s]{0,20}gider[a-z\s]{0,20}(?:islemis|gecmis)[a-z\s]{0,15}faiz/i
        ) || null,
      mahkemeHarclari: findAmountNearKeyword(norm, /mahkeme[a-z\s]{0,10}harc/i) || null,
      mahkemeHarclariFaizi:
        findAmountNearKeyword(norm, /mahkeme[a-z\s]{0,20}harc[a-z\s]{0,20}(?:islemis|gecmis)[a-z\s]{0,15}faiz/i) || null
    };

    return { asilAlacak, gecmisGunFaizi, ...emptyIlamli, ...ilamli };
  };

  const buildCustomFaizKey = (desc) =>
    typeof SharedHesapNormalizers.buildCustomFaizKey === "function"
      ? SharedHesapNormalizers.buildCustomFaizKey(desc)
      : String(desc || "")
          .replace(/\([^)]*\)/g, " ")
          .replace(
            /\b(?:tl|istenen|yillik|adi|kanuni|faiz|gecmis|gun|islemis|bedel|tazminat|tazminati|alacagi|alacag|alacak)\b/g,
            " "
          )
          .replace(/\s+/g, " ")
          .trim();

  const fixMojibakeMultiline = (value) =>
    typeof SharedHesapNormalizers.fixMojibakeMultiline === "function"
      ? SharedHesapNormalizers.fixMojibakeMultiline(value)
      : String(value || "")
          .replace(/\r\n/g, "\n")
          .split("\n")
          .map((line) => fixMojibake(line))
          .join("\n");

  const parseStructuredEntriesFromXml = (xmlText) => {
    if (typeof SharedHesapExtractors.parseStructuredEntriesFromXml === "function") {
      return SharedHesapExtractors.parseStructuredEntriesFromXml(xmlText);
    }
    const rows = String(xmlText || "").match(/<rowXbXb[\s\S]*?<\/rowXbXb>/gi) || [];
    const entries = [];

    for (const row of rows) {
      const amountRaw = (
        (row.match(
          /<takipTalebiDortMaddeAlacaginTlOlarakKarsiligiFaizMiktari>([\s\S]*?)<\/takipTalebiDortMaddeAlacaginTlOlarakKarsiligiFaizMiktari>/i
        ) || [])[1] || ""
      ).trim();
      const descRaw = (
        (row.match(/<faizinIslemeyeBasladigiGun>([\s\S]*?)<\/faizinIslemeyeBasladigiGun>/i) || [])[1] || ""
      ).trim();
      const amount = numberOrNull(amountRaw);
      const desc = normalizeText(descRaw);
      if (amount === null || !desc) {
        continue;
      }
      entries.push({ amount, desc, source: "structured" });
    }

    return entries;
  };

  const parseFieldEntriesFromXml = (xmlText) => {
    if (typeof SharedHesapExtractors.parseFieldEntriesFromXml === "function") {
      return SharedHesapExtractors.parseFieldEntriesFromXml(xmlText);
    }
    const entries = [];
    const pairRegex =
      /<takipTalebiDortMaddeAlacaginTlOlarakKarsiligiFaizMiktari>([\s\S]*?)<\/takipTalebiDortMaddeAlacaginTlOlarakKarsiligiFaizMiktari>[\s\S]*?<faizinIslemeyeBasladigiGun>([\s\S]*?)<\/faizinIslemeyeBasladigiGun>/gi;
    let match;

    while ((match = pairRegex.exec(String(xmlText || ""))) !== null) {
      const amount = numberOrNull((match[1] || "").trim());
      const desc = normalizeText((match[2] || "").trim());
      if (amount === null || !desc) {
        continue;
      }
      entries.push({ amount, desc, source: "field-pair" });
    }

    return entries;
  };

  const extractCdataText = (xmlText) => {
    if (typeof SharedHesapExtractors.extractCdataText === "function") {
      return SharedHesapExtractors.extractCdataText(xmlText);
    }
    const match = String(xmlText || "").match(/<content><!\[CDATA\[([\s\S]*?)\]\]>\s*<\/content>/i);
    return match ? fixMojibakeMultiline(match[1]) : "";
  };

  const isTakipUcuncuMaddeHeader = (line) => {
    if (typeof SharedHesapExtractors.isTakipUcuncuMaddeHeader === "function") {
      return SharedHesapExtractors.isTakipUcuncuMaddeHeader(line);
    }
    const raw = fixMojibake(line || "").toLocaleLowerCase("tr-TR");
    return /^3\s*[-.)]/.test(raw) && (raw.includes("alacağ") || raw.includes("alacag") || raw.includes("teminat"));
  };

  const isTakipDorduncuMaddeHeader = (line) => {
    if (typeof SharedHesapExtractors.isTakipDorduncuMaddeHeader === "function") {
      return SharedHesapExtractors.isTakipDorduncuMaddeHeader(line);
    }
    const raw = fixMojibake(line || "").toLocaleLowerCase("tr-TR");
    return /^4\s*[-.)]/.test(raw) && (raw.includes("senet") || raw.includes("borcun sebebi"));
  };

  const extractNarrativeSection = (xmlText) => {
    if (typeof SharedHesapExtractors.extractNarrativeSection === "function") {
      return SharedHesapExtractors.extractNarrativeSection(xmlText);
    }
    const cdataText = extractCdataText(xmlText);
    if (!cdataText) {
      return "";
    }

    const lines = cdataText
      .split(/\r?\n/)
      .map((line) => String(line || "").trim())
      .filter(Boolean);

    let startIndex = -1;
    let endIndex = lines.length;

    for (let index = 0; index < lines.length; index += 1) {
      if (startIndex === -1 && isTakipUcuncuMaddeHeader(lines[index])) {
        startIndex = index + 1;
        continue;
      }
      if (startIndex !== -1 && isTakipDorduncuMaddeHeader(lines[index])) {
        endIndex = index;
        break;
      }
    }

    if (startIndex === -1) {
      return "";
    }

    return lines.slice(startIndex, endIndex).join("\n");
  };

  const parseNarrativeEntriesFromXml = (xmlText) => {
    if (typeof SharedHesapExtractors.parseNarrativeEntriesFromXml === "function") {
      return SharedHesapExtractors.parseNarrativeEntriesFromXml(xmlText);
    }
    const sectionText = extractNarrativeSection(xmlText);
    if (!sectionText) {
      return [];
    }

    const lines = sectionText
      .split(/\r?\n/)
      .map((line) => fixMojibake(line).replace(/\s+/g, " ").trim())
      .filter(Boolean);

    const entries = [];
    let pendingAmount = null;

    const tryParseStandaloneAmount = (line) => {
      const match = line.match(/^(\d[\d.\s]*,\d{2}|\d[\d.\s]*)$/);
      return match ? numberOrNull(match[1]) : null;
    };

    const tryParseInlineAmount = (line) => {
      const match = line.match(/(\d[\d.\s]*,\d{2}|\d[\d.\s]*)\s*(?:TL)?\s*$/i);
      return match ? numberOrNull(match[1]) : null;
    };

    const stripTrailingAmount = (line) =>
      line
        .replace(/(\d[\d.\s]*,\d{2}|\d[\d.\s]*)\s*(?:TL)?\s*$/i, "")
        .replace(/[.:;,]+$/g, "")
        .trim();

    for (const line of lines) {
      const standaloneAmount = tryParseStandaloneAmount(line);
      if (standaloneAmount !== null) {
        pendingAmount = standaloneAmount;
        continue;
      }

      if (pendingAmount !== null) {
        const desc = normalizeText(line);
        if (desc) {
          entries.push({ amount: pendingAmount, desc, source: "cdata" });
          pendingAmount = null;
          continue;
        }
      }

      const inlineAmount = tryParseInlineAmount(line);
      if (inlineAmount === null) {
        continue;
      }

      const desc = normalizeText(stripTrailingAmount(line));
      if (!desc) {
        continue;
      }
      entries.push({ amount: inlineAmount, desc, source: "cdata-inline" });
    }

    return entries;
  };

  const classifyTakipEntry = (desc) => {
    if (typeof SharedHesapClassifiers.classifyTakipEntry === "function") {
      return SharedHesapClassifiers.classifyTakipEntry(desc);
    }
    const normalized = normalizeText(desc);
    const isExplicitPrimaryGecmisGunFaizi =
      normalized === "gecmis gun faizi" || normalized.startsWith("gecmis gun faizi ");
    const hasExplicitFaizLabel =
      /\bfaizi\b/.test(normalized) ||
      /\bfaizidir\b/.test(normalized) ||
      ((normalized.includes("gecmis") || normalized.includes("islemis")) && normalized.includes("faiz"));
    const isFaiz = hasExplicitFaizLabel || isExplicitPrimaryGecmisGunFaizi;
    const hasMahrumAnahtar = normalized.includes("hak mahrum") || normalized.includes("arac mahrum");
    const hasDegerKaybiAnahtar = normalized.includes("deger kaybi");
    const hasKazancKaybiAnahtar = normalized.includes("kazanc kaybi");
    const hasIkameAracAnahtar = normalized.includes("ikame arac");
    const hasCekiciAnahtar = normalized.includes("cekici");
    const hasHasarAnahtar = normalized.includes("hasar");
    const hasMahrumAlacakEtiketi =
      normalized.includes("bedel") ||
      normalized.includes("tazminat") ||
      normalized.includes("tazminati") ||
      normalized.includes("zarar") ||
      normalized.includes("zarari") ||
      normalized.includes("alacagi") ||
      normalized.includes("alacag") ||
      normalized.includes("alacak");
    const isHakMahrum = normalized.includes("hak mahrum") && hasMahrumAlacakEtiketi && !isFaiz;
    const isAracMahrum = normalized.includes("arac mahrum") && hasMahrumAlacakEtiketi && !isFaiz;
    const isDegerKaybi = hasDegerKaybiAnahtar && hasMahrumAlacakEtiketi && !isFaiz;
    const isKazancKaybi = hasKazancKaybiAnahtar && hasMahrumAlacakEtiketi && !isFaiz;
    const isIkameArac = hasIkameAracAnahtar && hasMahrumAlacakEtiketi && !isFaiz;
    const isCekiciBedeli = hasCekiciAnahtar && hasMahrumAlacakEtiketi && !isFaiz;
    const isHasarBedeli = hasHasarAnahtar && hasMahrumAlacakEtiketi && !isFaiz;
    const isInkarTazminati = normalized.includes("inkar") && normalized.includes("tazminat") && !isFaiz;
    const isAsil = normalized.includes("asil alacak") && !isFaiz;
    const isToplam = normalized.includes("toplam") && normalized.includes("alacak");
    const hasGecmisFaiz = hasExplicitFaizLabel;

    let asilType = "";
    let field = "";

    if (isHakMahrum) {
      asilType = "hak_mahrum";
      field = "asilAlacak";
    } else if (isAracMahrum) {
      asilType = "arac_mahrum";
      field = "asilAlacak";
    } else if (isDegerKaybi) {
      asilType = "deger_kaybi";
      field = "asilAlacak";
    } else if (isKazancKaybi) {
      asilType = "kazanc_kaybi";
      field = "asilAlacak";
    } else if (isIkameArac) {
      asilType = "ikame_arac";
      field = "asilAlacak";
    } else if (isCekiciBedeli) {
      asilType = "cekici_bedeli";
      field = "asilAlacak";
    } else if (isHasarBedeli) {
      asilType = "hasar_bedeli";
      field = "asilAlacak";
    } else if (isInkarTazminati) {
      asilType = "inkar_tazminat";
      field = "asilAlacak";
    } else if (isAsil) {
      asilType = "asil_alacak";
      field = "asilAlacak";
    } else if (
      (hasMahrumAnahtar ||
        hasDegerKaybiAnahtar ||
        hasKazancKaybiAnahtar ||
        hasIkameAracAnahtar ||
        hasCekiciAnahtar ||
        hasHasarAnahtar) &&
      hasMahrumAlacakEtiketi
    ) {
      field = hasGecmisFaiz ? "gecmisGunFaizi" : "asilAlacak";
    } else if (
      (normalized.includes("vekalet") || normalized.includes("vekaelt")) &&
      normalized.includes("ucret") &&
      !normalized.includes("icra vekalet")
    ) {
      field = hasGecmisFaiz ? "mahkemeVekaletUcretiFaizi" : "mahkemeVekaletUcreti";
    } else if (normalized.includes("yargilama") && normalized.includes("gider")) {
      field = hasGecmisFaiz ? "mahkemeYargilamaGiderleriFaizi" : "mahkemeYargilamaGiderleri";
    } else if (normalized.includes("harc")) {
      field = hasGecmisFaiz ? "mahkemeHarclariFaizi" : "mahkemeHarclari";
    } else if (isToplam) {
      field = "toplamAlacak";
    } else if (isExplicitPrimaryGecmisGunFaizi) {
      field = "gecmisGunFaizi";
    } else if (isFaiz) {
      field = "gecmisGunFaizi";
    } else if (hasMahrumAlacakEtiketi) {
      // Bilinen türlere uymayan ama parasal etiketi olan asıl alacak kalemleri
      // (ör. "BİRLEŞEN DAVA PERT FARKI BEDELİ") kaybolmasın diye asıl alacağa yazılır.
      field = "asilAlacak";
    }

    return {
      normalized,
      isFaiz,
      asilType,
      field,
      customFaizKey: isAsil ? buildCustomFaizKey(normalized) : ""
    };
  };

  const isGenericPrimaryFaizCandidate = (desc) => {
    const normalizedDesc = normalizeText(desc);
    if (!normalizedDesc || !normalizedDesc.includes("faiz")) {
      return false;
    }
    if (normalizedDesc === "gecmis gun faizi" || normalizedDesc.startsWith("gecmis gun faizi ")) {
      return true;
    }
    if (
      normalizedDesc.includes("vekalet") ||
      normalizedDesc.includes("yargilama") ||
      normalizedDesc.includes("gider") ||
      normalizedDesc.includes("harc")
    ) {
      return false;
    }
    return (
      normalizedDesc === "faiz" ||
      normalizedDesc === "faizi" ||
      normalizedDesc.includes("gecmis gun faizi") ||
      normalizedDesc.includes("islemis faiz") ||
      normalizedDesc.includes("gecmis faiz")
    );
  };

  const aggregateTakipEntries = (entries) => {
    if (typeof SharedHesapExtractors.aggregateTakipEntries === "function") {
      return SharedHesapExtractors.aggregateTakipEntries(entries);
    }
    const result = {
      asilAlacak: null,
      gecmisGunFaizi: null,
      toplamAlacak: null,
      aracMahrumiyetBedeli: null,
      aracMahrumiyetFaizi: null,
      mahkemeVekaletUcreti: null,
      mahkemeVekaletUcretiFaizi: null,
      mahkemeYargilamaGiderleri: null,
      mahkemeYargilamaGiderleriFaizi: null,
      mahkemeHarclari: null,
      mahkemeHarclariFaizi: null
    };
    let asilBedelType = "";
    let asilCustomFaizKey = "";
    let hasPrimaryDebtContext = false;
    const faizCandidates = [];

    for (const entry of Array.isArray(entries) ? entries : []) {
      const amount = numberOrNull(entry && entry.amount);
      const desc = normalizeText(entry && entry.desc);
      if (amount === null || !desc) {
        continue;
      }

      const classification = classifyTakipEntry(desc);

      if (classification.field === "asilAlacak") {
        hasPrimaryDebtContext = true;
        result.asilAlacak = addAmount(result.asilAlacak, amount);
        if (classification.asilType && classification.asilType !== "asil_alacak") {
          asilBedelType = classification.asilType;
        }
        if (classification.customFaizKey) {
          asilCustomFaizKey = classification.customFaizKey;
        }
      } else if (classification.field === "toplamAlacak") {
        result.toplamAlacak = addAmount(result.toplamAlacak, amount);
      } else if (classification.field) {
        result[classification.field] = addAmount(result[classification.field], amount);
      }

      if (classification.isFaiz) {
        faizCandidates.push({ amount, desc });
      }

      if (
        classification.asilType === "hak_mahrum" ||
        classification.asilType === "arac_mahrum" ||
        classification.asilType === "deger_kaybi" ||
        classification.asilType === "kazanc_kaybi" ||
        classification.asilType === "ikame_arac" ||
        classification.asilType === "cekici_bedeli" ||
        classification.asilType === "hasar_bedeli"
      ) {
        result.aracMahrumiyetBedeli = addAmount(result.aracMahrumiyetBedeli, amount);
      }
      if (
        classification.isFaiz &&
        (desc.includes("hak mahrum") ||
          desc.includes("arac mahrum") ||
          desc.includes("deger kaybi") ||
          desc.includes("kazanc kaybi") ||
          desc.includes("ikame arac") ||
          desc.includes("cekici") ||
          desc.includes("hasar"))
      ) {
        result.aracMahrumiyetFaizi = addAmount(result.aracMahrumiyetFaizi, amount);
      }
    }

    if (
      result.gecmisGunFaizi === null &&
      faizCandidates.length > 0 &&
      (hasPrimaryDebtContext || !!asilBedelType || !!asilCustomFaizKey)
    ) {
      const explicitPrimaryFaizCandidates = faizCandidates.filter((candidate) => {
        const normalizedDesc = normalizeText(candidate.desc);
        return normalizedDesc === "gecmis gun faizi" || normalizedDesc.startsWith("gecmis gun faizi ");
      });
      if (explicitPrimaryFaizCandidates.length > 0) {
        result.gecmisGunFaizi = sumNumericAmounts(explicitPrimaryFaizCandidates.map((candidate) => candidate.amount));
        return result;
      }

      let matchedFaizCandidates = faizCandidates.filter((candidate) => {
        if (asilBedelType === "hak_mahrum") {
          return candidate.desc.includes("hak mahrum");
        }
        if (asilBedelType === "arac_mahrum") {
          return candidate.desc.includes("arac mahrum");
        }
        if (asilBedelType === "deger_kaybi") {
          return candidate.desc.includes("deger kaybi");
        }
        if (asilBedelType === "kazanc_kaybi") {
          return candidate.desc.includes("kazanc kaybi");
        }
        if (asilBedelType === "ikame_arac") {
          return candidate.desc.includes("ikame arac");
        }
        if (asilBedelType === "cekici_bedeli") {
          return candidate.desc.includes("cekici");
        }
        if (asilBedelType === "hasar_bedeli") {
          return candidate.desc.includes("hasar");
        }
        if (asilBedelType === "inkar_tazminat") {
          return candidate.desc.includes("inkar") && candidate.desc.includes("tazminat");
        }
        if (asilCustomFaizKey) {
          return candidate.desc.includes(asilCustomFaizKey);
        }
        return true;
      });
      if (matchedFaizCandidates.length === 0) {
        matchedFaizCandidates = faizCandidates.filter((candidate) => isGenericPrimaryFaizCandidate(candidate.desc));
      }
      result.gecmisGunFaizi = sumNumericAmounts(matchedFaizCandidates.map((candidate) => candidate.amount));
    }

    if (
      result.asilAlacak === null &&
      result.toplamAlacak !== null &&
      result.gecmisGunFaizi !== null &&
      (hasPrimaryDebtContext || !!asilBedelType || !!asilCustomFaizKey)
    ) {
      result.asilAlacak = Number((result.toplamAlacak - result.gecmisGunFaizi).toFixed(2));
    }

    return result;
  };

  const extractNarrativeSectionFromPlainText = (inputText) => {
    if (typeof SharedHesapExtractors.extractNarrativeSectionFromPlainText === "function") {
      return SharedHesapExtractors.extractNarrativeSectionFromPlainText(inputText);
    }
    const raw = fixMojibakeMultiline(inputText || "");
    if (!raw) {
      return "";
    }

    const lines = raw
      .split(/\r?\n/)
      .map((line) => String(line || "").trim())
      .filter(Boolean);

    let startIndex = -1;
    let endIndex = lines.length;

    for (let index = 0; index < lines.length; index += 1) {
      if (startIndex === -1 && isTakipUcuncuMaddeHeader(lines[index])) {
        startIndex = index + 1;
        continue;
      }
      if (startIndex !== -1 && isTakipDorduncuMaddeHeader(lines[index])) {
        endIndex = index;
        break;
      }
    }

    if (startIndex === -1) {
      return "";
    }

    return lines.slice(startIndex, endIndex).join("\n");
  };

  const parseNarrativeEntriesFromPlainText = (inputText) => {
    if (typeof SharedHesapExtractors.parseNarrativeEntriesFromPlainText === "function") {
      return SharedHesapExtractors.parseNarrativeEntriesFromPlainText(inputText);
    }
    const sectionText = extractNarrativeSectionFromPlainText(inputText);
    if (!sectionText) {
      return [];
    }

    const lines = sectionText
      .split(/\r?\n/)
      .map((line) => fixMojibake(line).replace(/\s+/g, " ").trim())
      .filter(Boolean);

    const entries = [];
    let pendingAmount = null;

    const tryParseStandaloneAmount = (line) => {
      const match = line.match(/^(\d[\d.\s]*,\d{2}|\d[\d.\s]*)$/);
      return match ? numberOrNull(match[1]) : null;
    };

    const tryParseInlineAmount = (line) => {
      const match = line.match(/(\d[\d.\s]*,\d{2}|\d[\d.\s]*)\s*(?:TL)?\s*$/i);
      return match ? numberOrNull(match[1]) : null;
    };

    const stripTrailingAmount = (line) =>
      line
        .replace(/(\d[\d.\s]*,\d{2}|\d[\d.\s]*)\s*(?:TL)?\s*$/i, "")
        .replace(/[.:;,]+$/g, "")
        .trim();

    for (const line of lines) {
      const standaloneAmount = tryParseStandaloneAmount(line);
      if (standaloneAmount !== null) {
        pendingAmount = standaloneAmount;
        continue;
      }

      if (pendingAmount !== null) {
        const desc = normalizeText(line);
        if (desc) {
          entries.push({ amount: pendingAmount, desc, source: "plain-text" });
          pendingAmount = null;
          continue;
        }
      }

      const inlineAmount = tryParseInlineAmount(line);
      if (inlineAmount === null) {
        continue;
      }

      const desc = normalizeText(stripTrailingAmount(line));
      if (!desc) {
        continue;
      }
      entries.push({ amount: inlineAmount, desc, source: "plain-text-inline" });
    }

    return entries;
  };

  const extractTakipTalebiAmountsFromContentXml = (xmlText) => {
    if (typeof SharedHesapExtractors.extractTakipTalebiAmountsFromContentXml === "function") {
      return SharedHesapExtractors.extractTakipTalebiAmountsFromContentXml(xmlText);
    }
    const candidates = [];
    const structuredEntries = parseStructuredEntriesFromXml(xmlText);
    const fieldEntries = parseFieldEntriesFromXml(xmlText);
    const narrativeEntries = parseNarrativeEntriesFromXml(xmlText);

    if (structuredEntries.length > 0) {
      candidates.push(aggregateTakipEntries(structuredEntries));
    }
    if (fieldEntries.length > 0) {
      candidates.push(aggregateTakipEntries(fieldEntries));
    }
    if (narrativeEntries.length > 0) {
      candidates.push(aggregateTakipEntries(narrativeEntries));
    }

    let aggregated = null;
    let bestScore = -1;

    for (const candidate of candidates) {
      const score = getTakipParseQualityScore(candidate);
      if (score > bestScore) {
        aggregated = candidate;
        bestScore = score;
      }
    }

    if (aggregated && bestScore >= 0) {
      return aggregated;
    }

    const fallback = extractTakipTalebiAmountsFromText(xmlText);
    return fallback;
  };

  const getTakipParseQualityScore = (parsed) => {
    if (typeof SharedHesapScoring.getTakipParseQualityScore === "function") {
      return SharedHesapScoring.getTakipParseQualityScore(parsed);
    }
    if (!parsed || typeof parsed !== "object") {
      return -1;
    }
    let score = 0;
    if (numberOrNull(parsed.asilAlacak) !== null) {
      score += 5;
    }
    if (numberOrNull(parsed.gecmisGunFaizi) !== null) {
      score += 5;
    }
    if (numberOrNull(parsed.toplamAlacak) !== null) {
      score += 2;
    }
    if (numberOrNull(parsed.aracMahrumiyetBedeli) !== null) {
      score += 2;
    }
    if (numberOrNull(parsed.aracMahrumiyetFaizi) !== null) {
      score += 2;
    }
    if (numberOrNull(parsed.mahkemeYargilamaGiderleri) !== null) {
      score += 1;
    }
    if (numberOrNull(parsed.mahkemeHarclari) !== null) {
      score += 1;
    }
    if (numberOrNull(parsed.mahkemeVekaletUcreti) !== null) {
      score += 1;
    }
    // Mahkeme kalemlerinin geçmiş gün faizleri de puanlanır; aksi halde bu
    // kalemleri getiren eksiksiz bir parse, getirmeyenle aynı skoru alıyordu.
    if (numberOrNull(parsed.mahkemeYargilamaGiderleriFaizi) !== null) {
      score += 1;
    }
    if (numberOrNull(parsed.mahkemeHarclariFaizi) !== null) {
      score += 1;
    }
    if (numberOrNull(parsed.mahkemeVekaletUcretiFaizi) !== null) {
      score += 1;
    }
    return score;
  };

  const extractTakipTalebiAmountsFromUdfBytes = (bytes) => {
    try {
      const fflate = window.fflate;
      if (!fflate || typeof fflate.unzipSync !== "function") {
        return {
          asilAlacak: null,
          gecmisGunFaizi: null,
          aracMahrumiyetBedeli: null,
          aracMahrumiyetFaizi: null,
          mahkemeVekaletUcreti: null,
          mahkemeVekaletUcretiFaizi: null,
          mahkemeYargilamaGiderleri: null,
          mahkemeYargilamaGiderleriFaizi: null,
          mahkemeHarclari: null,
          mahkemeHarclariFaizi: null
        };
      }
      let files;
      try {
        files = fflate.unzipSync(bytes);
      } catch (error) {
        files = unzipFromLocalHeaders(bytes);
        if (!files || Object.keys(files).length === 0) {
          throw error;
        }
      }
      const names = Object.keys(files || {});
      const contentKey = names.find((n) => /(^|\/)content\.xml$/i.test(String(n || "")));
      if (!contentKey) {
        return {
          asilAlacak: null,
          gecmisGunFaizi: null,
          aracMahrumiyetBedeli: null,
          aracMahrumiyetFaizi: null,
          mahkemeVekaletUcreti: null,
          mahkemeVekaletUcretiFaizi: null,
          mahkemeYargilamaGiderleri: null,
          mahkemeYargilamaGiderleriFaizi: null,
          mahkemeHarclari: null,
          mahkemeHarclariFaizi: null
        };
      }
      const xmlBytes = files[contentKey];
      const xmlText = new TextDecoder("utf-8", { fatal: false }).decode(xmlBytes);
      return extractTakipTalebiAmountsFromContentXml(xmlText);
    } catch {
      return {
        asilAlacak: null,
        gecmisGunFaizi: null,
        aracMahrumiyetBedeli: null,
        aracMahrumiyetFaizi: null,
        mahkemeVekaletUcreti: null,
        mahkemeVekaletUcretiFaizi: null,
        mahkemeYargilamaGiderleri: null,
        mahkemeYargilamaGiderleriFaizi: null,
        mahkemeHarclari: null,
        mahkemeHarclariFaizi: null
      };
    }
  };

  const extractTakipTalebiAmountsFromPdfBytes = async (bytes) => {
    const texts = await collectPdfTextCandidates(bytes);
    let bestParsed = null;
    let bestScore = -1;

    for (const rawText of texts) {
      const parsed = extractTakipTalebiAmountsFromText(rawText);
      const score = getTakipParseQualityScore(parsed);
      if (score > bestScore) {
        bestParsed = parsed;
        bestScore = score;
      }
      // Mahkeme kalemi okunup faizi okunamadıysa metin varyantı eksiktir;
      // diğer varyantlar bu kalemleri hâlâ getirebilir.
      const eksikFaizVar =
        (parsed.mahkemeVekaletUcreti !== null && parsed.mahkemeVekaletUcretiFaizi === null) ||
        (parsed.mahkemeYargilamaGiderleri !== null && parsed.mahkemeYargilamaGiderleriFaizi === null) ||
        (parsed.mahkemeHarclari !== null && parsed.mahkemeHarclariFaizi === null);
      if (score >= 10 && !eksikFaizVar) {
        break;
      }
    }

    return bestParsed || { asilAlacak: null, gecmisGunFaizi: null };
  };

  window.__EWR_PR_ExtractTakipTalebi = {
    aggregateTakipEntries,
    buildCustomFaizKey,
    classifyTakipEntry,
    extractCdataText,
    extractNarrativeSection,
    extractNarrativeSectionFromPlainText,
    extractTakipTalebiAmountsFromContentXml,
    extractTakipTalebiAmountsFromPdfBytes,
    extractTakipTalebiAmountsFromText,
    extractTakipTalebiAmountsFromUdfBytes,
    fixMojibakeMultiline,
    getTakipParseQualityScore,
    isTakipDorduncuMaddeHeader,
    isTakipUcuncuMaddeHeader,
    parseFieldEntriesFromXml,
    parseNarrativeEntriesFromPlainText,
    parseNarrativeEntriesFromXml,
    parseStructuredEntriesFromXml
  };
})();

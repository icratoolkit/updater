(() => {
  const C = window.__EWR_PR_Core;
  if (!C) {
    console.error("extract/taraf.js: page-runner-core.js önce yüklenmeli.");
    return;
  }

  const { numberOrNull, fixMojibake, normalizeText } = C;

  const normalizePersonKey = (value) =>
    normalizeText(value)
      .replace(/\[[^\]]*\]/g, " ")
      .replace(/[^a-z0-9\s]/g, " ")
      .replace(/\s+/g, " ")
      .trim();

  const extractNamesFromBracketText = (value) => {
    const raw = fixMojibake(value || "");
    if (!raw) {
      return [];
    }
    const out = [];
    const reNames = /\[([^\]]+)\]/g;
    let m;
    while ((m = reNames.exec(raw)) !== null) {
      const name = String(m[1] || "").trim();
      if (name) {
        out.push(name);
      }
    }
    if (out.length === 0) {
      const t = raw.trim();
      if (t) {
        out.push(t);
      }
    }
    return out;
  };

  const collectAlacakliNameKeys = (tarafJson) => {
    const rows = Array.isArray(tarafJson) ? tarafJson : [];
    const keys = new Set();

    const addName = (value) => {
      const key = normalizePersonKey(value);
      if (key) {
        keys.add(key);
      }
    };

    for (const row of rows) {
      if (!row || typeof row !== "object") {
        continue;
      }
      const rol = normalizeText(row.rol).replace(/\s+/g, " ").trim();
      if (!rol.includes("alacakli")) {
        continue;
      }
      addName(row.adi);
      const vekilNames = extractNamesFromBracketText(row.vekil);
      for (const v of vekilNames) {
        addName(v);
      }
    }

    return keys;
  };

  const matchIslemYapanToAlacakli = (islemYapan, alacakliNameKeys) => {
    if (!(alacakliNameKeys instanceof Set) || alacakliNameKeys.size === 0) {
      return true;
    }

    const source = normalizePersonKey(islemYapan);
    if (!source) {
      return false;
    }

    for (const key of alacakliNameKeys) {
      if (!key) {
        continue;
      }
      if (source === key || source.includes(key) || key.includes(source)) {
        return true;
      }
    }
    return false;
  };

  const extractIslemYapanFromVekaletHtml = (rawHtml) => {
    const raw = fixMojibake(rawHtml || "");
    if (!raw) {
      return "";
    }

    const plain = raw
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/gi, " ")
      .replace(/\s+/g, " ")
      .trim();

    if (!plain) {
      return "";
    }

    const plainNorm = normalizeText(plain).replace(/\s+/g, " ").trim();
    const m = plainNorm.match(
      /islemi\s*gerceklestirenin\s*adi,?\s*soyadi\s*:?\s*(.+?)(?=\s*islemi\s*gerceklestirenin\s*tc|\s*birim\s*adi\s*\/\s*dosya\s*no|\s*islem\s*tarihi|$)/i
    );
    if (m && m[1]) {
      return m[1].replace(/\s+/g, " ").trim();
    }

    return "";
  };

  const extractVekaletPuluInfoFromHtmlText = (htmlText) => {
    const raw = fixMojibake(htmlText || "");
    if (!raw) {
      return { tutar: null, islemYapan: "" };
    }

    const islemYapan = extractIslemYapanFromVekaletHtml(raw);

    const rowMatch = raw.match(/<tr[\s\S]{0,1200}?toplam[\s\S]*?<\/tr>/i);
    if (rowMatch && rowMatch[0]) {
      const nums = rowMatch[0].match(/[0-9][0-9.,]*/g) || [];
      const parsed = nums.map((n) => numberOrNull(n)).filter((n) => n !== null);
      if (parsed.length > 0) {
        return { tutar: parsed[parsed.length - 1], islemYapan };
      }
    }

    const norm = normalizeText(raw).replace(/\s+/g, " ").trim();
    if (!norm) {
      return { tutar: null, islemYapan };
    }

    const m = norm.match(/toplam[^0-9]{0,80}([0-9][0-9.,]*)/i);
    if (m && m[1]) {
      return { tutar: numberOrNull(m[1]), islemYapan };
    }

    return { tutar: null, islemYapan };
  };

  const extractKisiFromAciklama = (aciklama) => {
    const raw = fixMojibake(aciklama).trim();
    if (!raw) {
      return "";
    }
    const closed = raw.match(/\[([^\]]+)\]/);
    let inside;
    if (closed && closed[1]) {
      inside = closed[1];
    } else {
      // UYAP açıklamayı ~150 karakterde kesiyor; uzun kurum adlarında kapanış köşeli
      // ayracı hiç gelmiyor; ad, kapanış gelmeden ortasından kesiliyor.
      // Bu durumda açılış ayracından sonrasını ad kabul ediyoruz; aksi halde ad yerine
      // açıklamanın tamamı okunup borçlu eşleştirmesi bozuluyordu.
      const openIndex = raw.lastIndexOf("[");
      inside = openIndex >= 0 ? raw.slice(openIndex + 1) : raw;
    }
    return inside
      .trim()
      .replace(/^BORÇLU VE MÜFLİS\s*/i, "")
      .replace(/^BORCLU VE MUFLIS\s*/i, "")
      .trim();
  };

  const normalizeNameKey = (value) =>
    normalizeText(value)
      .replace(/[^a-z0-9\s]/g, " ")
      .replace(/\s+/g, " ")
      .trim();

  const cleanupKisiName = (value) => {
    let s = fixMojibake(value || "");
    s = s.replace(/\bve\s+di[ğg]erleri\b.*$/i, "");
    s = s.replace(/\bvekili\b.*$/i, "");
    s = s.replace(/\bav\.\b.*$/i, "");
    s = s.replace(/\bavukat\b.*$/i, "");
    s = s.replace(/\s+/g, " ").trim();
    return s;
  };

  const pickBestKisiName = (candidates, fallback) => {
    const cleanCandidates = (Array.isArray(candidates) ? candidates : [])
      .map((x) => cleanupKisiName(x))
      .filter((x) => !!x);
    const fb = cleanupKisiName(fallback || "");
    if (cleanCandidates.length === 0) {
      return fb;
    }
    if (!fb) {
      return cleanCandidates[0];
    }

    const fbKey = normalizeNameKey(fb);
    let best = cleanCandidates[0];
    let bestScore = -1;

    for (const c of cleanCandidates) {
      const ck = normalizeNameKey(c);
      let score = 0;
      if (ck === fbKey) {
        score += 100;
      }
      if (ck && fbKey && (ck.includes(fbKey) || fbKey.includes(ck))) {
        score += 50;
      }
      const fbTokens = new Set(fbKey.split(" ").filter(Boolean));
      const cTokens = ck.split(" ").filter(Boolean);
      for (const t of cTokens) {
        if (fbTokens.has(t)) {
          score += 5;
        }
      }
      if (score > bestScore) {
        bestScore = score;
        best = c;
      }
    }

    return best || fb;
  };

  // Evrak göndereni "Av. <ad soyad>" gibi unvanla geliyor. cleanupKisiName burada
  // kullanılamaz: o, "av." gördüğü yerden sonrasını siliyor (ad + vekil birleşik yazılan
  // alanlar için). Burada yalnız baştaki unvanı atıyoruz.
  const normalizeGonderenKey = (value) => normalizePersonKey(value).replace(/^(?:av|avukat)\s+/, "");

  // Borca itiraz evrakları borçlunun kendisi ya da vekili adına geliyor; itirazı doğru
  // borçluya yazabilmek için her borçlunun ad ve vekil anahtarlarını topluyoruz.
  const collectBorcluKimlikleri = (tarafJson) => {
    const rows = Array.isArray(tarafJson) ? tarafJson : [];
    const out = [];

    for (const row of rows) {
      if (!row || typeof row !== "object") {
        continue;
      }
      const rol = normalizeText(row.rol).replace(/\s+/g, " ").trim();
      if (!rol.includes("borclu")) {
        continue;
      }
      const adi = cleanupKisiName(row.adi);
      const nameKey = normalizePersonKey(adi);
      if (!nameKey) {
        continue;
      }
      const vekilKeys = new Set();
      for (const vekil of extractNamesFromBracketText(row.vekil)) {
        const key = normalizePersonKey(vekil);
        if (key) {
          vekilKeys.add(key);
        }
      }
      out.push({ adi, nameKey, vekilKeys: [...vekilKeys] });
    }

    return out;
  };

  window.__EWR_PR_ExtractTaraf = {
    cleanupKisiName,
    collectAlacakliNameKeys,
    collectBorcluKimlikleri,
    extractIslemYapanFromVekaletHtml,
    extractKisiFromAciklama,
    extractNamesFromBracketText,
    extractVekaletPuluInfoFromHtmlText,
    matchIslemYapanToAlacakli,
    normalizeGonderenKey,
    normalizeNameKey,
    normalizePersonKey,
    pickBestKisiName
  };
})();

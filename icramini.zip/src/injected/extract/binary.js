(() => {
  const C = window.__EWR_PR_Core;
  if (!C) {
    console.error("extract/binary.js: page-runner-core.js önce yüklenmeli.");
    return;
  }

  const tryDecodeBase64ToBytes = (b64) => {
    try {
      const clean = String(b64 || "").replace(/\s+/g, "");
      if (!clean || clean.length < 20) {
        return null;
      }
      const bin = atob(clean);
      const out = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i += 1) {
        out[i] = bin.charCodeAt(i) & 0xff;
      }
      return out;
    } catch {
      return null;
    }
  };

  const unwrapPdfLikeBytes = (bytes) => {
    if (!(bytes instanceof Uint8Array) || bytes.length < 5) {
      return null;
    }
    const sig = new TextDecoder("latin1").decode(bytes.slice(0, 8));
    if (sig.includes("%PDF-")) {
      return bytes;
    }

    const asUtf8 = new TextDecoder("utf-8", { fatal: false }).decode(bytes);
    const asLatin = new TextDecoder("latin1").decode(bytes);

    const findPdfStart = (s) => {
      const idx = s.indexOf("%PDF-");
      if (idx >= 0) {
        const tail = s.slice(idx);
        const arr = new Uint8Array(tail.length);
        for (let i = 0; i < tail.length; i += 1) {
          arr[i] = tail.charCodeAt(i) & 0xff;
        }
        return arr;
      }
      return null;
    };

    const directUtf = findPdfStart(asUtf8);
    if (directUtf) {
      return directUtf;
    }
    const directLatin = findPdfStart(asLatin);
    if (directLatin) {
      return directLatin;
    }

    const b64Patterns = [
      /data:application\/pdf;base64,([A-Za-z0-9+/=\s]{200,})/i,
      /"([A-Za-z0-9+/=\s]{400,})"/g,
      /(JVBERi0[A-Za-z0-9+/=\s]{200,})/g
    ];

    for (const pattern of b64Patterns) {
      if (pattern.global) {
        pattern.lastIndex = 0;
        let m;
        while ((m = pattern.exec(asUtf8)) !== null) {
          const candidate = m[1] || m[0];
          const decoded = tryDecodeBase64ToBytes(candidate);
          if (!decoded) {
            continue;
          }
          const dsig = new TextDecoder("latin1").decode(decoded.slice(0, 8));
          if (dsig.includes("%PDF-")) {
            return decoded;
          }
        }
      } else {
        const m = asUtf8.match(pattern);
        if (m && m[1]) {
          const decoded = tryDecodeBase64ToBytes(m[1]);
          if (decoded) {
            const dsig = new TextDecoder("latin1").decode(decoded.slice(0, 8));
            if (dsig.includes("%PDF-")) {
              return decoded;
            }
          }
        }
      }
    }

    return null;
  };

  const decodeEscapedTextVariants = (input) => {
    const out = [];
    const push = (v) => {
      const s = String(v || "");
      if (s && !out.includes(s)) {
        out.push(s);
      }
    };

    const raw = String(input || "");
    push(raw);

    try {
      const uni = raw
        .replace(/\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16)))
        .replace(/\\x([0-9a-fA-F]{2})/g, (_, h) => String.fromCharCode(parseInt(h, 16)))
        .replace(/\\n/g, "\n")
        .replace(/\\r/g, "\r")
        .replace(/\\t/g, "\t");
      push(uni);
    } catch {}

    try {
      const ta = document.createElement("textarea");
      ta.innerHTML = raw;
      push(ta.value || ta.textContent || "");
    } catch {}

    try {
      push(decodeURIComponent(raw));
    } catch {}

    return out;
  };

  const extractInnerDocumentUrls = (bodyText, baseUrl) => {
    const out = [];
    const s = String(bodyText || "");
    if (!s) {
      return out;
    }

    const add = (u) => {
      const raw = String(u || "").trim();
      if (!raw) {
        return;
      }
      try {
        const abs = new URL(raw, baseUrl || window.location.href).toString();
        if (!/^https?:/i.test(abs)) {
          return;
        }
        if (!out.includes(abs)) {
          out.push(abs);
        }
      } catch {}
    };

    const patterns = [
      /(?:href|src)=["']([^"']+)["']/gi,
      /https?:\/\/[^"'\s<>]+/gi,
      /\/(?:view_document(?:_brd)?\.uyap[^"'\s<>]*)/gi,
      /[^"'\s<>]+\.pdf(?:\?[^"'\s<>]*)?/gi
    ];

    for (const re of patterns) {
      re.lastIndex = 0;
      let m;
      while ((m = re.exec(s)) !== null) {
        add(m[1] || m[0]);
      }
    }

    return out.slice(0, 8);
  };

  const LOCAL_FILE_HEADER_SIGNATURE = 0x04034b50;

  const getUint16Le = (bytes, offset) => bytes[offset] | (bytes[offset + 1] << 8);

  const getUint32Le = (bytes, offset) =>
    (bytes[offset] | (bytes[offset + 1] << 8) | (bytes[offset + 2] << 16) | (bytes[offset + 3] << 24)) >>> 0;

  const decodeZipEntryName = (bytes) => {
    try {
      return new TextDecoder("utf-8", { fatal: false }).decode(bytes);
    } catch {
      return String.fromCharCode(...bytes);
    }
  };

  const inflateZipEntryFallback = (compressedBytes) => {
    const inflateSync =
      window.fflate && typeof window.fflate.inflateSync === "function" ? window.fflate.inflateSync : null;
    if (!inflateSync) {
      throw new Error("ZIP icerigi acilamadi.");
    }

    const trims = [0, 12, 16, 20, 24, 28];
    for (const trim of trims) {
      if (compressedBytes.length <= trim) {
        continue;
      }
      try {
        return inflateSync(compressedBytes.subarray(0, compressedBytes.length - trim));
      } catch {}
    }

    return inflateSync(compressedBytes);
  };

  const unzipFromLocalHeaders = (bytes) => {
    const files = {};
    const headerOffsets = [];

    for (let offset = 0; offset <= bytes.length - 4; offset += 1) {
      if (getUint32Le(bytes, offset) === LOCAL_FILE_HEADER_SIGNATURE) {
        headerOffsets.push(offset);
      }
    }

    for (let index = 0; index < headerOffsets.length; index += 1) {
      const headerOffset = headerOffsets[index];
      const nameLength = getUint16Le(bytes, headerOffset + 26);
      const extraLength = getUint16Le(bytes, headerOffset + 28);
      const compressionMethod = getUint16Le(bytes, headerOffset + 8);
      const nameStart = headerOffset + 30;
      const nameEnd = nameStart + nameLength;
      const dataStart = nameEnd + extraLength;
      const dataEnd = index + 1 < headerOffsets.length ? headerOffsets[index + 1] : bytes.length;
      const fileName = decodeZipEntryName(bytes.subarray(nameStart, nameEnd));
      const payload = bytes.subarray(dataStart, dataEnd);

      if (!fileName) {
        continue;
      }

      if (compressionMethod === 0) {
        files[fileName] = payload;
        continue;
      }

      if (compressionMethod === 8) {
        files[fileName] = inflateZipEntryFallback(payload);
      }
    }

    return files;
  };

  window.__EWR_PR_ExtractBinary = {
    decodeEscapedTextVariants,
    extractInnerDocumentUrls,
    tryDecodeBase64ToBytes,
    unwrapPdfLikeBytes,
    unzipFromLocalHeaders
  };
})();

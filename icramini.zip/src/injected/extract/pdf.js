(() => {
  const C = window.__EWR_PR_Core;
  if (!C) {
    console.error("extract/pdf.js: page-runner-core.js önce yüklenmeli.");
    return;
  }

  const { fixMojibake, normalizeText, ensurePdfJsLib } = C;
  const { pickBestKisiName } = window.__EWR_PR_ExtractTaraf;

  const extractBarcodeFromText = (text, depth = 0) => {
    const raw = String(text || "");
    const candidates = [];
    const seen = new Set();

    const pickFromChunk = (chunk) => {
      const onlyDigits = String(chunk || "").replace(/\D+/g, "");
      if (onlyDigits.length === 13 && !onlyDigits.startsWith("0")) {
        return onlyDigits;
      }
      return null;
    };
    const addCandidate = (value, score) => {
      const v = String(value || "");
      if (!v || seen.has(v)) {
        return;
      }
      seen.add(v);
      candidates.push({ value: v, score: Number(score) || 0 });
    };

    const exactStarRe = /\*(\d{13})\*/g;
    let m;
    while ((m = exactStarRe.exec(raw)) !== null) {
      addCandidate(m[1], 100);
    }

    const starChunkRe = /\*([^*\r\n]{1,200})\*/g;
    while ((m = starChunkRe.exec(raw)) !== null) {
      const picked = pickFromChunk(m[1]);
      if (picked) {
        addCandidate(picked, 90);
      }
    }

    const taahhutluRe = /taahh[uü]tl[uü][\s\S]{0,180}/gi;
    while ((m = taahhutluRe.exec(raw)) !== null) {
      const local = m[0];
      const localSeqRe = /(\d(?:[^\d]{0,4}\d){12})/g;
      let lm;
      while ((lm = localSeqRe.exec(local)) !== null) {
        const picked = pickFromChunk(lm[1]);
        if (picked) {
          addCandidate(picked, 80);
        }
      }
    }

    const ornekNoRe = /[oö]rnek\s*no[\s\S]{0,220}/gi;
    while ((m = ornekNoRe.exec(raw)) !== null) {
      const local = m[0];
      const localStarRe = /\*([^*\r\n]{1,200})\*/g;
      let lm;
      while ((lm = localStarRe.exec(local)) !== null) {
        const picked = pickFromChunk(lm[1]);
        if (picked) {
          addCandidate(picked, 95);
        }
      }

      const localSeqRe = /(\d(?:[^\d]{0,4}\d){12})/g;
      while ((lm = localSeqRe.exec(local)) !== null) {
        const picked = pickFromChunk(lm[1]);
        if (picked) {
          addCandidate(picked, 85);
        }
      }
    }

    if (depth < 2) {
      const hexChunkRe = /<([0-9a-fA-F\s]{24,800})>/g;
      while ((m = hexChunkRe.exec(raw)) !== null) {
        const hex = String(m[1] || "").replace(/[^0-9a-fA-F]/g, "");
        if (hex.length < 26 || hex.length % 2 !== 0) {
          continue;
        }

        const bytes = new Uint8Array(hex.length / 2);
        for (let i = 0; i < bytes.length; i += 1) {
          const part = hex.slice(i * 2, i * 2 + 2);
          bytes[i] = Number.parseInt(part, 16);
        }

        let utf16beText = "";
        if (bytes.length % 2 === 0) {
          for (let i = 0; i < bytes.length; i += 2) {
            utf16beText += String.fromCharCode((bytes[i] << 8) | bytes[i + 1]);
          }
        }
        const utf16Match = extractBarcodeFromText(utf16beText, depth + 1);
        if (utf16Match) {
          addCandidate(utf16Match, 70);
        }

        const singleByteText = new TextDecoder("latin1").decode(bytes);
        const singleByteMatch = extractBarcodeFromText(singleByteText, depth + 1);
        if (singleByteMatch) {
          addCandidate(singleByteMatch, 60);
        }
      }
    }

    if (candidates.length === 0) {
      return null;
    }

    candidates.sort((a, b) => b.score - a.score);
    return candidates[0].value;
  };

  const tryExtractWithPdfJs = async (bytes) => {
    try {
      const lib = await ensurePdfJsLib();
      if (!lib || typeof lib.getDocument !== "function") {
        return null;
      }

      const task = lib.getDocument({ data: bytes });
      const pdf = await task.promise;
      try {
        for (let i = 1; i <= pdf.numPages; i += 1) {
          const page = await pdf.getPage(i);
          const textContent = await page.getTextContent();
          const joined = (textContent.items || []).map((x) => String(x.str || "")).join(" ");
          const found = extractBarcodeFromText(joined);
          if (found) {
            return found;
          }
        }
      } finally {
        if (pdf && typeof pdf.destroy === "function") {
          pdf.destroy();
        }
      }
    } catch {}
    return null;
  };

  const indexOfBytes = (haystack, needle, fromIndex) => {
    if (!haystack || !needle || needle.length === 0) {
      return -1;
    }
    outer: for (let i = Math.max(0, fromIndex || 0); i <= haystack.length - needle.length; i += 1) {
      for (let j = 0; j < needle.length; j += 1) {
        if (haystack[i + j] !== needle[j]) {
          continue outer;
        }
      }
      return i;
    }
    return -1;
  };

  const collectPdfStreams = (bytes) => {
    const streamWord = new Uint8Array([115, 116, 114, 101, 97, 109]);
    const endWord = new Uint8Array([101, 110, 100, 115, 116, 114, 101, 97, 109]);
    const streams = [];
    let cursor = 0;

    while (cursor < bytes.length) {
      const streamAt = indexOfBytes(bytes, streamWord, cursor);
      if (streamAt < 0) {
        break;
      }

      let dataStart = streamAt + streamWord.length;
      if (bytes[dataStart] === 13 && bytes[dataStart + 1] === 10) {
        dataStart += 2;
      } else if (bytes[dataStart] === 10 || bytes[dataStart] === 13) {
        dataStart += 1;
      }

      const endAt = indexOfBytes(bytes, endWord, dataStart);
      if (endAt < 0) {
        break;
      }

      if (endAt > dataStart) {
        streams.push(bytes.slice(dataStart, endAt));
      }

      cursor = endAt + endWord.length;
    }

    return streams;
  };

  const tryDecompressDeflate = async (bytes) => {
    const formats = ["deflate", "deflate-raw"];

    for (const format of formats) {
      try {
        if (typeof DecompressionStream === "undefined") {
          throw new Error("DecompressionStream unavailable");
        }
        const ds = new DecompressionStream(format);
        const decompressed = await new Response(new Blob([bytes]).stream().pipeThrough(ds)).arrayBuffer();
        return new Uint8Array(decompressed);
      } catch {}
    }

    try {
      const fflate = window.fflate;
      if (fflate && typeof fflate.decompressSync === "function") {
        return fflate.decompressSync(bytes);
      }
    } catch {}

    return null;
  };

  const collectPdfTextCandidates = async (bytes) => {
    const out = [];
    const pushText = (t) => {
      const s = String(t || "");
      if (!s || s.length < 20) {
        return;
      }
      out.push(fixMojibake(s));
    };

    if (!(bytes instanceof Uint8Array) || bytes.length === 0) {
      return out;
    }

    pushText(new TextDecoder("latin1").decode(bytes));
    pushText(new TextDecoder("utf-8", { fatal: false }).decode(bytes));

    const streams = collectPdfStreams(bytes);
    for (const stream of streams) {
      pushText(new TextDecoder("latin1").decode(stream));
      const inflated = await tryDecompressDeflate(stream);
      if (inflated) {
        pushText(new TextDecoder("latin1").decode(inflated));
      }
    }

    try {
      const lib = await ensurePdfJsLib();
      if (lib && typeof lib.getDocument === "function") {
        const task = lib.getDocument({ data: bytes });
        const pdf = await task.promise;
        try {
          const parts = [];
          for (let i = 1; i <= pdf.numPages; i += 1) {
            const page = await pdf.getPage(i);
            const tc = await page.getTextContent();
            parts.push((tc.items || []).map((x) => String(x.str || "")).join(" "));
          }
          pushText(parts.join("\n"));
        } finally {
          if (pdf && typeof pdf.destroy === "function") {
            pdf.destroy();
          }
        }
      }
    } catch {}

    return out;
  };

  const containsIcraEmriTebligZarfi = (text) => {
    const normalized = normalizeText(text).replace(/\s+/g, " ").trim();
    if (!normalized) {
      return false;
    }
    const zarfRegex = /\bbu zarfta\b(.{0,300}?)\bvardir\b/g;
    let match;
    while ((match = zarfRegex.exec(normalized)) !== null) {
      if (/\b(?:odeme\s+)?icra\s+emri\b/.test(match[1])) {
        return true;
      }
    }
    return false;
  };

  const pdfContainsOdemeIcraEmri = async (bytes) => {
    const texts = await collectPdfTextCandidates(bytes);
    return texts.some(containsIcraEmriTebligZarfi);
  };
  const extractBarcodeFromPdfBytes = async (bytes) => {
    if (!(bytes instanceof Uint8Array) || bytes.length === 0) {
      return null;
    }

    const latin1 = new TextDecoder("latin1").decode(bytes);
    const direct = extractBarcodeFromText(latin1);
    if (direct) {
      return direct;
    }

    const utf8 = new TextDecoder("utf-8", { fatal: false }).decode(bytes);
    const utf8Match = extractBarcodeFromText(utf8);
    if (utf8Match) {
      return utf8Match;
    }

    const streams = collectPdfStreams(bytes);
    for (const stream of streams) {
      const rawText = new TextDecoder("latin1").decode(stream);
      const rawMatch = extractBarcodeFromText(rawText);
      if (rawMatch) {
        return rawMatch;
      }

      const inflated = await tryDecompressDeflate(stream);
      if (!inflated) {
        continue;
      }

      const inflatedText = new TextDecoder("latin1").decode(inflated);
      const inflatedMatch = extractBarcodeFromText(inflatedText);
      if (inflatedMatch) {
        return inflatedMatch;
      }
    }

    const pdfJsMatch = await tryExtractWithPdfJs(bytes);
    if (pdfJsMatch) {
      return pdfJsMatch;
    }

    const textCandidates = await collectPdfTextCandidates(bytes);
    for (const candidateText of textCandidates) {
      const found = extractBarcodeFromText(candidateText);
      if (found) {
        return found;
      }
    }

    return null;
  };

  const extractETebligInfoFromPdfBytes = async (bytes, fallbackKisi) => {
    if (!(bytes instanceof Uint8Array) || bytes.length === 0) {
      return null;
    }

    const textCandidates = [];
    const pushText = (t) => {
      const s = String(t || "");
      if (!s || s.length < 20) {
        return;
      }
      textCandidates.push(fixMojibake(s));
    };

    pushText(new TextDecoder("latin1").decode(bytes));
    pushText(new TextDecoder("utf-8", { fatal: false }).decode(bytes));

    const streams = collectPdfStreams(bytes);
    for (const stream of streams) {
      pushText(new TextDecoder("latin1").decode(stream));
      const inflated = await tryDecompressDeflate(stream);
      if (inflated) {
        pushText(new TextDecoder("latin1").decode(inflated));
      }
    }

    const pdfJsText = await (async () => {
      try {
        const lib = await ensurePdfJsLib();
        if (!lib || typeof lib.getDocument !== "function") {
          return "";
        }
        const task = lib.getDocument({ data: bytes });
        const pdf = await task.promise;
        try {
          const parts = [];
          for (let i = 1; i <= pdf.numPages; i += 1) {
            const page = await pdf.getPage(i);
            const tc = await page.getTextContent();
            parts.push((tc.items || []).map((x) => String(x.str || "")).join(" "));
          }
          return parts.join("\n");
        } finally {
          if (pdf && typeof pdf.destroy === "function") {
            pdf.destroy();
          }
        }
      } catch {
        return "";
      }
    })();
    pushText(pdfJsText);

    if (!textCandidates.some(containsIcraEmriTebligZarfi)) {
      return null;
    }

    const foundKisiCandidates = [];
    let bestDateMs = 0;
    let bestDateStr = null;
    let fallbackDateMs = 0;
    let fallbackDateStr = null;

    for (const raw of textCandidates) {
      const text = raw.replace(/\s+/g, " ");
      const nameLine = text.match(/Ad[ıi]\s*ve\s*Soyad[ıi]\s*:\s*([^)\n\r]{2,220})/i);
      const name1 = text.match(/UETS\s+Hesap\s+Sahibi:\s*([^)]+?)(?:\)|$)/i);
      const name2 = text.match(/Bor[çc]lu\s+([^)]+?)(?:\)|$)/i);
      const extracted = [
        nameLine && nameLine[1] ? nameLine[1] : "",
        name1 && name1[1] ? name1[1] : "",
        name2 && name2[1] ? name2[1] : ""
      ].filter(Boolean);
      for (const n of extracted) {
        foundKisiCandidates.push(n);
      }

      const normalizedText = normalizeText(text).replace(/\s+/g, " ").trim();
      const dateRegex =
        /(\d{2})\/(\d{2})\/(\d{4})(?:\s+(\d{2}):(\d{2})(?::(\d{2}))?)?[^\d]{0,260}(?:otomatik\s+olarak\s+okundu\s+sayildi|okunmus\s+sayildi|teblig\s+edilmis\s+sayildi)/g;
      let m;
      while ((m = dateRegex.exec(normalizedText)) !== null) {
        const day = Number(m[1]);
        const month = Number(m[2]);
        const year = Number(m[3]);
        const hour = Number(m[4] || "0");
        const minute = Number(m[5] || "0");
        const second = Number(m[6] || "0");
        if (!Number.isFinite(day) || !Number.isFinite(month) || !Number.isFinite(year)) {
          continue;
        }
        if (year < 2000 || year > 2100 || month < 1 || month > 12 || day < 1 || day > 31) {
          continue;
        }
        const ms = Date.UTC(year, month - 1, day, hour, minute, second);
        if (ms > bestDateMs) {
          bestDateMs = ms;
          bestDateStr = `${String(day).padStart(2, "0")}/${String(month).padStart(2, "0")}/${year}`;
        }
      }

      // PDF.js bazı mazbatalarda metin parçalarını görsel sıradan farklı döndürüyor.
      // Belge zarfı icra emri olarak doğrulandıysa bağlam eşleşmediğinde son tarihi kullan.
      if (containsIcraEmriTebligZarfi(text)) {
        const fallbackDateRegex = /(\d{2})\/(\d{2})\/(\d{4})(?:\s+(\d{2}):(\d{2})(?::(\d{2}))?)?/g;
        let fallbackMatch;
        while ((fallbackMatch = fallbackDateRegex.exec(normalizedText)) !== null) {
          const day = Number(fallbackMatch[1]);
          const month = Number(fallbackMatch[2]);
          const year = Number(fallbackMatch[3]);
          const hour = Number(fallbackMatch[4] || "0");
          const minute = Number(fallbackMatch[5] || "0");
          const second = Number(fallbackMatch[6] || "0");
          if (year < 2000 || year > 2100 || month < 1 || month > 12 || day < 1 || day > 31) {
            continue;
          }
          const ms = Date.UTC(year, month - 1, day, hour, minute, second);
          if (ms > fallbackDateMs) {
            fallbackDateMs = ms;
            fallbackDateStr = `${String(day).padStart(2, "0")}/${String(month).padStart(2, "0")}/${year}`;
          }
        }
      }
    }

    if (!bestDateStr && fallbackDateStr) {
      bestDateStr = fallbackDateStr;
    }

    if (!bestDateStr) {
      return null;
    }

    const kisi = pickBestKisiName(foundKisiCandidates, fallbackKisi);
    return {
      kisi: fixMojibake(kisi),
      tebligTarihi: bestDateStr
    };
  };

  window.__EWR_PR_ExtractPdf = {
    collectPdfStreams,
    collectPdfTextCandidates,
    extractBarcodeFromPdfBytes,
    extractBarcodeFromText,
    extractETebligInfoFromPdfBytes,
    indexOfBytes,
    pdfContainsOdemeIcraEmri,
    tryDecompressDeflate,
    tryExtractWithPdfJs
  };
})();

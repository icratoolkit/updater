(() => {
  const C = window.__EWR_PR_Core;
  const Progress = window.__EWR_PR_QueryProgress;
  if (!C || !Progress) {
    console.error("query/talep-sender.js: page-runner-core.js ve query/progress.js önce yüklenmeli.");
    return;
  }

  const { DEFAULT_SETTINGS, parseHeaders, toAbsoluteUrl, normalizeJsonBodyValue, runRequest } = C;
  const { setActiveStep } = Progress;

  const NO_TIMEOUT = { timeoutMs: 0 };

  const IBAN_PATTERN = /^TR\d{24}$/;

  const getTalepDefinition = (runMode) => {
    if (runMode === "talepBorcluOdemeAktar") {
      return {
        talepKodu: 14,
        talepAdi: "Borçlu Tarafından Yapılan Ödemelerin Hesaba Aktarılması",
        className: "AvukatTalepGenelOdemeAktarDVO",
        outputName: "Borçlu Ödemelerinin Hesaba Aktarılması",
        dosyaDurum: "H",
        requiresIban: true
      };
    }
    if (runMode === "talepKesinlestirme") {
      return {
        talepKodu: 31,
        talepAdi: "Takibin Kesinleşmesi",
        className: "AvukatTalepGenelTakibiKesinlestirDVO",
        outputName: "Kesinleştirme Talebi",
        dosyaDurum: "A",
        requiresIban: false
      };
    }
    return {
      talepKodu: 37,
      talepAdi: "Dosyadaki Avansın İadesi",
      className: "AvukatTalepDosyaAvansIadesiDvo",
      outputName: "Masraf Avans İadesi",
      dosyaDurum: "H",
      requiresIban: true
    };
  };

  const buildTalepBilgileri = (ibanNo, runMode) => {
    const definition = getTalepDefinition(runMode);
    const talep = {
      grupKodu: 2,
      talepKodu: definition.talepKodu,
      talepAdi: definition.talepAdi,
      talepKisaAdi: definition.talepAdi,
      talepMasrafi: 0,
      className: definition.className,
      postaMasrafId: 0,
      dosyaDurum: definition.dosyaDurum || "H",
      masraf: 0,
      fields:
        definition.requiresIban === false
          ? [{ id: "", title: "" }]
          : [
              { id: "hesapKimeAitText", title: "Hesap Kime Ait" },
              { id: "ibanNo", title: "IBAN No" }
            ],
      id: 0
    };

    if (definition.requiresIban !== false) {
      talep.hesapKimeAit = "V";
      talep.hesapKimeAitText = "Vekil";
      talep.ibanNo = ibanNo;
    }

    return [talep];
  };

  const TALEP_EVRAK_ITEMS = [
    {
      id: 1,
      evrakTuruOptionDVO: {
        tur: "ICR_AVUKAT_PORTAL_GENEL_TALEP",
        label: "Genel Talebi",
        mandatory: true,
        max: 1,
        ekEvrakMax: 2,
        sablonTurKodu: "",
        acceptTypeList: [".udf", ".UDF"],
        ekEvrakAcceptTypeList: [
          ".udf",
          ".pdf",
          ".jpg",
          ".jpeg",
          ".png",
          ".tif",
          ".tiff",
          ".UDF",
          ".PDF",
          ".JPG",
          ".JPEG",
          ".PNG",
          ".TIF",
          ".TIFF"
        ]
      },
      tur: "ICR_AVUKAT_PORTAL_GENEL_TALEP",
      turAciklama: "Genel Talebi",
      mandatory: true,
      file: {},
      path: "C:/fakepath/Talep.udf",
      kullaniciEvrakAciklama: "",
      parentId: -1,
      isVekalet: false,
      isVekaletBilgiFormu: false,
      fileId: 1
    }
  ];

  const buildIbanDegisikligiEvrakItems = (fileName) => [
    {
      id: Date.now(),
      evrakTuruOptionDVO: {
        tur: "ICR_GNL_HCZ_BLDRM",
        label: "Genel Haciz Talebi",
        mandatory: false,
        max: 1,
        ekEvrakMax: 5,
        sablonTurKodu: "",
        acceptTypeList: [".udf", ".UDF"],
        ekEvrakAcceptTypeList: [
          ".udf",
          ".pdf",
          ".jpg",
          ".png",
          ".jpeg",
          ".image/jpg",
          ".image/jpeg",
          ".tif",
          ".tiff",
          ".UDF",
          ".JPG",
          ".JPEG",
          ".PNG",
          ".PDF",
          ".TIF",
          ".TIFF"
        ]
      },
      tur: "ICR_GNL_HCZ_BLDRM",
      turAciklama: "Genel Haciz Talebi",
      mandatory: false,
      file: {},
      path: `C:/fakepath/${fileName}`,
      kullaniciEvrakAciklama: "",
      parentId: -1,
      isVekalet: false,
      isVekaletBilgiFormu: false,
      fileId: 1
    }
  ];

  const getBorcluAdi = (borclu) => {
    if (borclu && borclu.kisi) {
      return String(borclu.kisi).trim();
    }
    const kisi = (borclu && borclu.kisiTumDVO) || {};
    const adSoyad = [kisi.adi, kisi.soyadi].filter(Boolean).join(" ");
    if (adSoyad) {
      return adSoyad;
    }
    const kurum = (borclu && borclu.kurumDVO) || {};
    if (kurum.kurumAdi) {
      return String(kurum.kurumAdi).trim();
    }
    return "Bilinmeyen";
  };

  const buildBorcluHeaderValue = (borclu) => {
    if (!borclu) {
      return "undefined";
    }
    if (borclu.borcluHeaderValue) {
      return String(borclu.borcluHeaderValue);
    }

    const kisi = borclu.kisiTumDVO || {};
    const adi = String(kisi.adi || "").trim();
    const soyadi = String(kisi.soyadi || "").trim();
    const tcKimlikNo = String(kisi.tcKimlikNo || "").trim();
    if (adi || soyadi) {
      const name = [adi, soyadi].filter(Boolean).join(" ");
      return tcKimlikNo ? `${name} - ${tcKimlikNo}` : name;
    }

    const kurum = borclu.kurumDVO || {};
    if (kurum.kurumAdi) {
      const vergiNo = String(kurum.vergiNo || "").trim();
      return vergiNo ? `${kurum.kurumAdi} - ${vergiNo}` : String(kurum.kurumAdi);
    }

    return "undefined";
  };

  const readResponseMessage = (json) =>
    json && typeof json === "object" ? String(json.message || json.error || "") : "";

  // multipart gönderimde Content-Type elle verilmemeli; boundary'yi tarayıcı ekler.
  const withoutContentType = (headers) => {
    const next = { ...headers };
    delete next["Content-Type"];
    delete next["content-type"];
    return next;
  };

  const sendIbanDegisikligiTalebi = async (parsed, settings, secondCtx) => {
    const Template = window.MiniIcraTalepTemplate;
    if (!Template || typeof Template.buildUdfFiles !== "function") {
      return { ok: false, status: 0, error: "IBAN değişikliği şablon modülü yüklenemedi." };
    }

    setActiveStep(parsed.raw, "2. istek: IBAN değişikliği UDF hazırlama");
    const [udfFile] = await Template.buildUdfFiles([
      {
        dosyaNo: parsed.raw,
        birimAdi: secondCtx.birimAdi || parsed.birimAdi || settings.defaultBirimAdi || ""
      }
    ]);
    if (!udfFile || !udfFile.bytes) {
      return { ok: false, status: 0, error: "IBAN değişikliği UDF dosyası oluşturulamadı." };
    }

    const formData = new FormData();
    formData.append("file_1", new Blob([udfFile.bytes], { type: "application/octet-stream" }), udfFile.fileName);
    formData.append("items", JSON.stringify(buildIbanDegisikligiEvrakItems(udfFile.fileName)));
    formData.append("dosyaId", normalizeJsonBodyValue(secondCtx.dosyaId || ""));
    formData.append("isDusurme", "false");
    formData.append("evrakTipi", "undefined");
    formData.append("dosyaNo", parsed.raw);
    formData.append("birimId", String(secondCtx.birimId || ""));
    formData.append("birimAdi", String(secondCtx.birimAdi || ""));

    setActiveStep(parsed.raw, "3. istek: IBAN değişikliği evrak gönderme");
    const response = await fetch(toAbsoluteUrl("/evrakGonder_brd.ajx"), {
      method: "POST",
      headers: withoutContentType(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
      body: formData,
      credentials: "include"
    });

    const text = await response.text();
    let json = null;
    try {
      json = JSON.parse(text);
    } catch {
      json = null;
    }

    const isError = json && json.type === "error";
    return {
      ok: response.ok && !isError,
      status: response.status,
      json,
      text,
      message: readResponseMessage(json),
      fileName: udfFile.fileName,
      talepAdi: "IBAN Değişikliği Talebi"
    };
  };

  const sendTalepForBorclu = async ({ parsed, settings, secondCtx, runMode, borclu, index, total, ibanNo }) => {
    const normalizedDosyaId = normalizeJsonBodyValue(secondCtx.dosyaId);
    const talepBilgileri = buildTalepBilgileri(ibanNo, runMode);
    const baseHeaders = {
      ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
      "X-Borclu": encodeURIComponent(buildBorcluHeaderValue(borclu))
    };
    const borcluInfo = { borclu: getBorcluAdi(borclu), kisiKurumId: borclu.kisiKurumId };
    const isKesinlestirme = runMode === "talepKesinlestirme";

    if (isKesinlestirme) {
      setActiveStep(parsed.raw, `3. istek: Kesinleşme kontrolü (${index + 1}/${total})`);
      const kesinlesme = await runRequest(
        toAbsoluteUrl("/dosya_icra_kesinlesme.ajx"),
        "POST",
        { ...baseHeaders, "Content-Type": "application/json" },
        JSON.stringify({ dosyaId: normalizedDosyaId, kisiKurumId: borclu.kisiKurumId }),
        NO_TIMEOUT
      );

      const basarilimi =
        kesinlesme.json && typeof kesinlesme.json === "object" ? kesinlesme.json.basarilimi : kesinlesme.json;
      const kesinlesmeDevam = basarilimi === false || basarilimi === "false";
      const kesinlesmeHata = basarilimi === true || basarilimi === "true";

      if (!kesinlesme.ok && !kesinlesmeDevam) {
        return {
          ok: false,
          status: kesinlesme.status,
          error: `Kesinleşme kontrolü başarısız (HTTP ${kesinlesme.status})`,
          text: kesinlesme.text,
          json: kesinlesme.json,
          ...borcluInfo
        };
      }
      if (kesinlesmeHata) {
        return {
          ok: false,
          status: kesinlesme.status,
          error: readResponseMessage(kesinlesme.json) || "Borçlu için kesinleştirme hatası.",
          text: kesinlesme.text,
          json: kesinlesme.json,
          ...borcluInfo
        };
      }
    }

    setActiveStep(parsed.raw, `${isKesinlestirme ? "4" : "3"}. istek: Talep evrakı hazırlama (${index + 1}/${total})`);
    const hazirla = await runRequest(
      toAbsoluteUrl("/getIcraTalepEvrakHazirla.uyap"),
      "POST",
      { ...baseHeaders, "Content-Type": "application/json" },
      JSON.stringify({
        dosyaId: normalizedDosyaId,
        filename: parsed.raw,
        kisiKurumId: borclu.kisiKurumId,
        talepBilgileri: JSON.stringify(talepBilgileri)
      }),
      NO_TIMEOUT
    );

    if (!hazirla.ok || !hazirla.text) {
      return {
        ok: false,
        status: hazirla.status,
        error: `Talep evrakı hazırlanamadı (HTTP ${hazirla.status})`,
        text: hazirla.text,
        json: hazirla.json,
        ...borcluInfo
      };
    }

    setActiveStep(parsed.raw, `${isKesinlestirme ? "5" : "4"}. istek: Talep gönderme (${index + 1}/${total})`);
    const formData = new FormData();
    formData.append("file_1", new Blob([hazirla.text], { type: "application/octet-stream" }), "Talep.udf");
    formData.append("items", JSON.stringify(TALEP_EVRAK_ITEMS));
    formData.append("dosyaId", normalizedDosyaId);
    formData.append("kisiKurumId", String(borclu.kisiKurumId));
    formData.append("tutar", "0");
    formData.append("talepGrupId", "2");
    formData.append("talepBilgileri", JSON.stringify(talepBilgileri));

    const response = await fetch(toAbsoluteUrl("/avukatIcraTalepEvrakiGonder.ajx"), {
      method: "POST",
      headers: withoutContentType(baseHeaders),
      body: formData,
      credentials: "include"
    });

    const text = await response.text();
    let json = null;
    try {
      json = JSON.parse(text);
    } catch {
      json = null;
    }

    const message = readResponseMessage(json);
    const isError = json && json.type === "error";
    const ok = response.ok && !isError;

    return {
      ok,
      status: response.status,
      json,
      text,
      message,
      error: ok ? null : message || `Talep gönderme HTTP ${response.status}`,
      ...borcluInfo
    };
  };

  const sendGenelTalep = async (parsed, settings, secondCtx, runMode) => {
    const definition = getTalepDefinition(runMode);
    const ibanNo = String(settings.talepIbanNo || DEFAULT_SETTINGS.talepIbanNo || "TR620001009010684338705009")
      .replace(/\s+/g, "")
      .toUpperCase();

    if (definition.requiresIban !== false && !IBAN_PATTERN.test(ibanNo)) {
      return { ok: false, status: 0, error: "Geçerli IBAN bulunamadı.", talepAdi: definition.outputName };
    }

    setActiveStep(parsed.raw, "2. istek: Borçlu listesi");
    const borcluResponse = await runRequest(
      toAbsoluteUrl("/dosya_borclu_list.ajx"),
      "POST",
      {
        ...(parseHeaders(settings.secondHeadersText, secondCtx) || {}),
        "Content-Type": "application/json",
        "X-Borclu": "undefined"
      },
      JSON.stringify({ dosyaId: normalizeJsonBodyValue(secondCtx.dosyaId) }),
      NO_TIMEOUT
    );

    if (!borcluResponse.ok || !Array.isArray(borcluResponse.json)) {
      return {
        ok: false,
        status: borcluResponse.status,
        error: `Borçlu listesi alınamadı (HTTP ${borcluResponse.status})`,
        talepAdi: definition.outputName
      };
    }

    const borclular = borcluResponse.json.filter((item) => item && typeof item.kisiKurumId !== "undefined");
    if (borclular.length === 0) {
      return {
        ok: false,
        status: borcluResponse.status,
        error: "Borçlu listesinde kisiKurumId bulunamadı.",
        talepAdi: definition.outputName
      };
    }

    const targetBorclular = runMode === "talepKesinlestirme" ? borclular : [borclular[0]];
    const results = [];
    for (let index = 0; index < targetBorclular.length; index += 1) {
      const result = await sendTalepForBorclu({
        parsed,
        settings,
        secondCtx,
        runMode,
        borclu: targetBorclular[index],
        index,
        total: targetBorclular.length,
        ibanNo
      });
      results.push(result);
    }

    const failed = results.filter((result) => !result || !result.ok);
    const successCount = results.length - failed.length;
    const firstResult = results[0] || {};

    const describe = (result) => `${result.borclu || result.kisiKurumId || "Borçlu"}`;

    return {
      ok: successCount > 0 && failed.length === 0,
      partialOk: successCount > 0 && failed.length > 0,
      status: failed[0]?.status || firstResult.status || 0,
      json: firstResult.json || null,
      text: firstResult.text || null,
      message: results
        .map((result) => `${describe(result)}: ${result.ok ? "Gönderildi" : result.error || result.message || "Hata"}`)
        .join(" | "),
      error:
        failed.length > 0
          ? failed.map((result) => `${describe(result)}: ${result.error || result.message || "Hata"}`).join(" | ")
          : null,
      borclu: results
        .map((result) => result.borclu)
        .filter(Boolean)
        .join(", "),
      kisiKurumId: targetBorclular.length === 1 ? targetBorclular[0].kisiKurumId : null,
      talepAdi: definition.outputName,
      borcluResults: results
    };
  };

  window.__EWR_PR_QueryTalep = {
    buildBorcluHeaderValue,
    buildTalepBilgileri,
    getBorcluAdi,
    getTalepDefinition,
    sendGenelTalep,
    sendIbanDegisikligiTalebi
  };
})();

(() => {
  const C = window.__EWR_PR_Core;
  const E = window.__EWR_PR_Extract;
  const Progress = window.__EWR_PR_QueryProgress;
  if (!C || !E || !Progress) {
    console.error("query/dosya-hesabi.js: çekirdek, çıkarım ve ilerleme modülleri önce yüklenmeli.");
    return;
  }

  const {
    applyTemplate,
    applyJsonBodyTemplate,
    parseHeaders,
    toAbsoluteUrl,
    normalizeJsonBodyValue,
    findByKeyDeep,
    numberOrNull,
    extractDosyaHesapSummary,
    parseOdemeDateInput,
    computeIcraFaizTutari,
    sumNumericAmounts,
    runRequest,
    runRequestBinary,
    normalizeText,
    parseTrDateToTime
  } = C;

  const {
    collectTumEvraklarItems,
    dedupeByEvrakId,
    selectTakipTalebiCandidates,
    selectOdemeIcraEmriCandidates,
    selectVekaletPuluCandidates,
    extractLatestTakipTalebiDate,
    hasAvukatPortalHacizTalebi,
    estimateDosyaKesinlesmeInfoFromEvrakList,
    extractTakipTalebiAmountsFromText,
    extractTakipTalebiAmountsFromUdfBytes,
    extractTakipTalebiAmountsFromPdfBytes,
    getTakipParseQualityScore,
    extractVekaletPuluInfoFromHtmlText,
    extractDosyaMasrafBilgileri,
    unwrapPdfLikeBytes,
    decodeEscapedTextVariants,
    extractInnerDocumentUrls,
    collectAlacakliNameKeys,
    shouldTreatAsIlamliByItirazSonrasiOdemeEmri,
    matchIslemYapanToAlacakli
  } = E;

  const setQueryActiveStep = Progress.setActiveStep;

  const createDosyaHesabiDebug = () => ({
    aday: 0,
    source: "",
    asilFaizSource: "",
    asilFaizUrl: "",
    asilFaizEvrakTur: "",
    asilFaizEvrakId: "",
    ilamliForcedByItirazOdemeEmri: false,
    evrakIdAday: 0,
    urlTried: 0,
    pdfOk: 0,
    innerUrlTried: 0,
    jsonHit: false,
    parsed: false,
    udfTried: 0,
    udfParsed: 0,
    contentTypes: []
  });

  // Takip talebi birden çok kaynaktan (UDF, PDF, düz metin) okunmaya çalışılır.
  // Bu puana ulaşan sonuç yeterince güvenilir sayılıp arama durdurulur.
  const TAKIP_PARSE_GOOD_ENOUGH_SCORE = 10;

  const collectDosyaHesabiData = async ({ parsed, settings, secondCtx, firstJson }) => {
    let secondUrl = null;
    let thirdUrl = null;
    let fourthUrl = null;
    let evrakPayloadForTracking = null;
    let dosyaHesabiOk = true;
    let dosyaHesabiStatus = null;

    let dosyaKesinlesmeMs = 0;
    let tebligTarihi = null;
    let talepTarihi = null;
    let takibinTuruAciklama = "";
    let isIlamliTakip = false;

    let takipteKesinlesenMiktar = null;
    let vekaletUcretiDosyaHesap = null;
    let tebligatGideri = null;
    let pesinHarc = null;
    let basvurmaHarci = null;
    let vekaletSuretHarci = null;
    let vekaletPulu = null;
    let tahsilHarciHesap = null;

    let asilAlacak = null;
    let gecmisGunFaizi = null;
    let aracMahrumiyetBedeli = null;
    let aracMahrumiyetFaizi = null;
    let mahkemeVekaletUcreti = null;
    let mahkemeVekaletUcretiFaizi = null;
    let mahkemeYargilamaGiderleri = null;
    let mahkemeYargilamaGiderleriFaizi = null;
    let mahkemeHarclari = null;
    let mahkemeHarclariFaizi = null;

    const dosyaHesabiDebug = createDosyaHesabiDebug();

    let bestTakipParseScore = -1;
    const maybeAdoptTakipParse = (candidate, source, sourceUrl, evrakTur, evrakId) => {
      if (!candidate || typeof candidate !== "object") {
        return false;
      }
      if (candidate.asilAlacak === null && candidate.gecmisGunFaizi === null) {
        return false;
      }
      const score = typeof getTakipParseQualityScore === "function" ? getTakipParseQualityScore(candidate) : -1;
      if (score < bestTakipParseScore) {
        return false;
      }

      bestTakipParseScore = score;
      asilAlacak = candidate.asilAlacak;
      gecmisGunFaizi = candidate.gecmisGunFaizi;
      aracMahrumiyetBedeli = candidate.aracMahrumiyetBedeli ?? aracMahrumiyetBedeli;
      aracMahrumiyetFaizi = candidate.aracMahrumiyetFaizi ?? aracMahrumiyetFaizi;
      mahkemeVekaletUcreti = candidate.mahkemeVekaletUcreti ?? mahkemeVekaletUcreti;
      mahkemeVekaletUcretiFaizi = candidate.mahkemeVekaletUcretiFaizi ?? mahkemeVekaletUcretiFaizi;
      mahkemeYargilamaGiderleri = candidate.mahkemeYargilamaGiderleri ?? mahkemeYargilamaGiderleri;
      mahkemeYargilamaGiderleriFaizi = candidate.mahkemeYargilamaGiderleriFaizi ?? mahkemeYargilamaGiderleriFaizi;
      mahkemeHarclari = candidate.mahkemeHarclari ?? mahkemeHarclari;
      mahkemeHarclariFaizi = candidate.mahkemeHarclariFaizi ?? mahkemeHarclariFaizi;
      dosyaHesabiDebug.parsed = true;
      dosyaHesabiDebug.asilFaizSource = source;
      dosyaHesabiDebug.asilFaizUrl = sourceUrl;
      dosyaHesabiDebug.asilFaizEvrakTur = String(evrakTur || "");
      dosyaHesabiDebug.asilFaizEvrakId = String(evrakId || "");
      return score >= TAKIP_PARSE_GOOD_ENOUGH_SCORE;
    };

    setQueryActiveStep(parsed.raw, "3. istek: Evrak listesi");
    const thirdUrlResolved = toAbsoluteUrl(applyTemplate(settings.thirdEndpointPath, secondCtx));
    const thirdMethod = String(settings.thirdMethod || "POST").toUpperCase();
    const thirdHeaders = parseHeaders(settings.thirdHeadersText, secondCtx);
    const thirdBody = applyJsonBodyTemplate(settings.thirdBodyTemplate, secondCtx);
    const third = await runRequest(thirdUrlResolved, thirdMethod, thirdHeaders, thirdBody);
    thirdUrl = thirdUrlResolved;
    dosyaHesabiStatus = third.status;
    dosyaHesabiOk = !!(third.ok && third.json);
    if (dosyaHesabiOk) {
      evrakPayloadForTracking = third.json;
      const tumEvrakList = collectTumEvraklarItems(third.json);
      const ilamliOverrideInfo = shouldTreatAsIlamliByItirazSonrasiOdemeEmri(tumEvrakList);
      const hasHacizTalebi = hasAvukatPortalHacizTalebi(tumEvrakList);
      const dosyaKesinlesmeInfo = estimateDosyaKesinlesmeInfoFromEvrakList(tumEvrakList);
      dosyaKesinlesmeMs = dosyaKesinlesmeInfo.kesinlesmeMs || 0;
      tebligTarihi = dosyaKesinlesmeInfo.tebligTarihi || null;
      talepTarihi = extractLatestTakipTalebiDate(tumEvrakList);

      let alacakliNameKeys = new Set();
      try {
        setQueryActiveStep(parsed.raw, "4. istek: Taraf bilgileri");
        const tarafUrl = toAbsoluteUrl("/dosya_taraf_bilgileri_brd.ajx");
        const tarafHeaders = parseHeaders(settings.thirdHeadersText, secondCtx);
        const tarafBody = JSON.stringify({ dosyaId: normalizeJsonBodyValue(secondCtx.dosyaId || "") });
        const taraf = await runRequest(tarafUrl, "POST", tarafHeaders, tarafBody);
        if (taraf.ok && Array.isArray(taraf.json)) {
          alacakliNameKeys = collectAlacakliNameKeys(taraf.json);
        }
      } catch {}

      try {
        setQueryActiveStep(parsed.raw, "5. istek: Dosya ayrıntı bilgileri");
        const ayrintiUrl = toAbsoluteUrl("/dosyaAyrintiBilgileri_brd.ajx");
        const ayrintiHeaders = parseHeaders(settings.thirdHeadersText, secondCtx);
        const ayrintiBody = JSON.stringify({ dosyaId: normalizeJsonBodyValue(secondCtx.dosyaId || "") });
        const ayrinti = await runRequest(ayrintiUrl, "POST", ayrintiHeaders, ayrintiBody);
        if (ayrinti.ok && ayrinti.json && typeof ayrinti.json === "object") {
          takibinTuruAciklama = String(ayrinti.json.takibinTuruAciklama || "").trim();
          isIlamliTakip = normalizeText(takibinTuruAciklama).includes("ilamli");
        }
      } catch {}

      if (ilamliOverrideInfo.value) {
        isIlamliTakip = true;
        dosyaHesabiDebug.ilamliForcedByItirazOdemeEmri = true;
      }

      {
        try {
          setQueryActiveStep(parsed.raw, "6. istek: Dosya hesap bilgileri");
          secondUrl = toAbsoluteUrl(applyTemplate(settings.secondEndpointPath, secondCtx));
          const secondMethod = String(settings.secondMethod || "POST").toUpperCase();
          const secondHeaders = parseHeaders(settings.secondHeadersText, secondCtx);
          const secondBody = applyJsonBodyTemplate(settings.secondBodyTemplate, secondCtx);
          const second = await runRequest(secondUrl, secondMethod, secondHeaders, secondBody);
          if (second.ok && second.json) {
            const summary = extractDosyaHesapSummary(second.json);
            takipteKesinlesenMiktar = summary.takipteKesinlesenMiktar;
            vekaletUcretiDosyaHesap = summary.vekaletUcreti;
          }
        } catch {}

        try {
          const tahsilatUrl = toAbsoluteUrl("/dosya_tahsilat_reddiyat_bilgileri_brd.ajx");
          const tahsilatHeaders = parseHeaders(settings.thirdHeadersText, secondCtx);
          const tahsilatBody = JSON.stringify({
            dosyaId: normalizeJsonBodyValue(secondCtx.dosyaId || ""),
            dosyaTurKod: Number(findByKeyDeep(firstJson, "dosyaTurKod")) || 35
          });
          const tahsilat = await runRequest(tahsilatUrl, "POST", tahsilatHeaders, tahsilatBody);
          if (tahsilat.ok && tahsilat.json && typeof tahsilat.json === "object") {
            const masraf = extractDosyaMasrafBilgileri(tahsilat.json, parsed.raw, alacakliNameKeys);
            tebligatGideri = masraf.tebligatGideri;
            pesinHarc = masraf.pesinHarc;
            basvurmaHarci = masraf.basvurmaHarci;
            vekaletSuretHarci = masraf.vekaletSuretHarci;
          }
        } catch {}

        const odemeIcraEmriAdaylari = selectOdemeIcraEmriCandidates(tumEvrakList);
        const takipTalebiAdaylari = selectTakipTalebiCandidates(tumEvrakList);

        const thirdJsonText = (() => {
          try {
            return JSON.stringify(third.json);
          } catch {
            return "";
          }
        })();
        if (thirdJsonText && odemeIcraEmriAdaylari.length === 0 && takipTalebiAdaylari.length === 0) {
          const jsonAmounts = extractTakipTalebiAmountsFromText(thirdJsonText);
          if (maybeAdoptTakipParse(jsonAmounts, "evrak-listesi-json", thirdUrlResolved, "liste fallback", "")) {
            dosyaHesabiDebug.jsonHit = true;
          }
        }

        const adayGruplari = [
          { source: "odemeIcraEmri", items: odemeIcraEmriAdaylari },
          { source: "takipTalebi", items: takipTalebiAdaylari }
        ];
        dosyaHesabiDebug.aday = adayGruplari.reduce((sum, group) => sum + group.items.length, 0);

        for (const adayGrubu of adayGruplari) {
          if (!Array.isArray(adayGrubu.items) || adayGrubu.items.length === 0) {
            continue;
          }
          dosyaHesabiDebug.source = adayGrubu.source;
          for (const asilFaizEvraki of adayGrubu.items) {
            if (!asilFaizEvraki || !asilFaizEvraki.evrakId) {
              continue;
            }
            const fourthMethod = String(settings.fourthMethod || "GET").toUpperCase();
            const docDosyaIdCandidates = [String(asilFaizEvraki.dosyaId || ""), String(secondCtx.dosyaId || "")].filter(
              Boolean
            );
            const uniqueDocDosyaIds = [...new Set(docDosyaIdCandidates)];
            const evrakIdCandidates = [String(asilFaizEvraki.evrakId || "")];
            const uniqueEvrakIds = [...new Set(evrakIdCandidates.filter(Boolean))];
            dosyaHesabiDebug.evrakIdAday += uniqueEvrakIds.length;
            let shouldTryFallbackDosyaId = false;

            for (let idx = 0; idx < uniqueDocDosyaIds.length; idx += 1) {
              const docDosyaId = uniqueDocDosyaIds[idx];
              if (idx > 0 && !shouldTryFallbackDosyaId) {
                break;
              }

              let gotAnyOkPdf = false;
              for (const evrakIdCandidate of uniqueEvrakIds) {
                const isOdemeIcraEmriDoc = normalizeText(asilFaizEvraki.tur).includes("odeme icra emri");
                const docCtx = {
                  ...secondCtx,
                  dosyaId: docDosyaId,
                  dosyaIdEncoded: encodeURIComponent(String(docDosyaId || "")),
                  evrakId: String(evrakIdCandidate || ""),
                  evrakIdEncoded: encodeURIComponent(String(evrakIdCandidate || "")),
                  evrakEncoded: encodeURIComponent(String(asilFaizEvraki.tur || "")),
                  tarihEncoded: encodeURIComponent(String(asilFaizEvraki.onaylandigiTarih || ""))
                };
                const candidateFourthUrl = toAbsoluteUrl(applyTemplate(settings.fourthEndpointPath, docCtx));

                const udfUrl = toAbsoluteUrl(
                  `/download_document_brd.uyap?dosyaId=${encodeURIComponent(String(docDosyaId || ""))}` +
                    `&evrakId=${encodeURIComponent(String(evrakIdCandidate || ""))}` +
                    `&evrak=${encodeURIComponent(String(asilFaizEvraki.tur || ""))}` +
                    `&tarih=${encodeURIComponent(String(asilFaizEvraki.onaylandigiTarih || ""))}` +
                    `&sira=undefined`
                );
                dosyaHesabiDebug.udfTried += 1;
                const udfHeaders = parseHeaders(settings.fourthHeadersText, docCtx);
                const udf = await runRequestBinary(udfUrl, "GET", udfHeaders, undefined);
                if (udf.ok) {
                  const udfAmounts = extractTakipTalebiAmountsFromUdfBytes(udf.bytes);
                  if (udfAmounts.asilAlacak !== null || udfAmounts.gecmisGunFaizi !== null) {
                    fourthUrl = udfUrl;
                    dosyaHesabiDebug.udfParsed += 1;
                    if (maybeAdoptTakipParse(udfAmounts, "udf", udfUrl, asilFaizEvraki.tur, evrakIdCandidate)) {
                      break;
                    }
                  }
                }

                if (isOdemeIcraEmriDoc) {
                  continue;
                }

                const candidateUrls = [candidateFourthUrl];
                if (candidateFourthUrl.includes("/view_document_brd.uyap")) {
                  candidateUrls.push(candidateFourthUrl.replace("/view_document_brd.uyap", "/view_document.uyap"));
                }

                for (const docUrl of [...new Set(candidateUrls)]) {
                  dosyaHesabiDebug.urlTried += 1;
                  const fourthHeaders = parseHeaders(settings.fourthHeadersText, docCtx);
                  const fourth = await runRequestBinary(docUrl, fourthMethod, fourthHeaders, undefined);
                  if (!fourth.ok) {
                    continue;
                  }
                  gotAnyOkPdf = true;
                  dosyaHesabiDebug.pdfOk += 1;
                  if (fourth.contentType && dosyaHesabiDebug.contentTypes.length < 5) {
                    dosyaHesabiDebug.contentTypes.push(fourth.contentType);
                  }
                  fourthUrl = docUrl;

                  const unwrappedPdf = unwrapPdfLikeBytes(fourth.bytes);
                  const amounts = unwrappedPdf
                    ? await extractTakipTalebiAmountsFromPdfBytes(unwrappedPdf)
                    : await extractTakipTalebiAmountsFromPdfBytes(fourth.bytes);

                  let finalAsil = amounts.asilAlacak;
                  let finalFaiz = amounts.gecmisGunFaizi;
                  let finalSource = unwrappedPdf ? "pdf" : "binary-pdf";
                  let finalSourceUrl = docUrl;

                  if (finalAsil === null && finalFaiz === null) {
                    const bodyText = [
                      new TextDecoder("utf-8", { fatal: false }).decode(fourth.bytes),
                      new TextDecoder("latin1").decode(fourth.bytes)
                    ].join("\n");

                    for (const variant of decodeEscapedTextVariants(bodyText)) {
                      const txtAmounts = extractTakipTalebiAmountsFromText(variant);
                      if (txtAmounts.asilAlacak !== null || txtAmounts.gecmisGunFaizi !== null) {
                        finalAsil = txtAmounts.asilAlacak;
                        finalFaiz = txtAmounts.gecmisGunFaizi;
                        finalSource = "view-document-text";
                        finalSourceUrl = docUrl;
                        break;
                      }
                    }

                    if (finalAsil === null && finalFaiz === null) {
                      const innerUrls = extractInnerDocumentUrls(bodyText, docUrl);
                      for (const innerUrl of innerUrls) {
                        dosyaHesabiDebug.innerUrlTried += 1;
                        const inner = await runRequestBinary(innerUrl, fourthMethod, fourthHeaders, undefined);
                        if (!inner.ok) {
                          continue;
                        }
                        if (inner.contentType && dosyaHesabiDebug.contentTypes.length < 5) {
                          dosyaHesabiDebug.contentTypes.push(inner.contentType);
                        }
                        const unwrappedInner = unwrapPdfLikeBytes(inner.bytes);
                        const innerAmounts = unwrappedInner
                          ? await extractTakipTalebiAmountsFromPdfBytes(unwrappedInner)
                          : await extractTakipTalebiAmountsFromPdfBytes(inner.bytes);
                        if (innerAmounts.asilAlacak !== null || innerAmounts.gecmisGunFaizi !== null) {
                          finalAsil = innerAmounts.asilAlacak;
                          finalFaiz = innerAmounts.gecmisGunFaizi;
                          fourthUrl = innerUrl;
                          finalSource = unwrappedInner ? "inner-pdf" : "inner-binary-pdf";
                          finalSourceUrl = innerUrl;
                          break;
                        }
                      }
                    }
                  }

                  if (finalAsil !== null || finalFaiz !== null) {
                    if (
                      maybeAdoptTakipParse(
                        {
                          ...amounts,
                          asilAlacak: finalAsil,
                          gecmisGunFaizi: finalFaiz
                        },
                        finalSource,
                        finalSourceUrl,
                        asilFaizEvraki.tur,
                        evrakIdCandidate
                      )
                    ) {
                      break;
                    }
                  }
                }

                if (bestTakipParseScore >= TAKIP_PARSE_GOOD_ENOUGH_SCORE) {
                  break;
                }
              }

              shouldTryFallbackDosyaId = !gotAnyOkPdf;
              if (bestTakipParseScore >= TAKIP_PARSE_GOOD_ENOUGH_SCORE) {
                break;
              }
            }

            if (bestTakipParseScore >= TAKIP_PARSE_GOOD_ENOUGH_SCORE) {
              break;
            }
          }
          if (bestTakipParseScore >= TAKIP_PARSE_GOOD_ENOUGH_SCORE) {
            break;
          }
        }

        if (asilAlacak !== null && gecmisGunFaizi === null) {
          const faizTamamlamaAdaylari = dedupeByEvrakId(
            (Array.isArray(tumEvrakList) ? tumEvrakList : []).filter((item) => {
              const tur = normalizeText(item && item.tur);
              return (
                tur.includes("takip talebi") ||
                (tur.includes("takip") && tur.includes("talep")) ||
                tur.includes("odeme icra emri")
              );
            })
          )
            .sort((a, b) => {
              const dateDiff = parseTrDateToTime(b.onaylandigiTarih) - parseTrDateToTime(a.onaylandigiTarih);
              if (dateDiff !== 0) {
                return dateDiff;
              }
              return String(b.evrakId || "").localeCompare(String(a.evrakId || ""), "tr");
            })
            .slice(0, 50);

          for (const evrak of faizTamamlamaAdaylari) {
            if (!evrak || !evrak.evrakId || gecmisGunFaizi !== null) {
              continue;
            }
            const docDosyaIdCandidates = [String(evrak.dosyaId || ""), String(secondCtx.dosyaId || "")].filter(Boolean);
            const uniqueDocDosyaIds = [...new Set(docDosyaIdCandidates)];
            for (const docDosyaId of uniqueDocDosyaIds) {
              if (gecmisGunFaizi !== null) {
                break;
              }
              const udfUrl = toAbsoluteUrl(
                `/download_document_brd.uyap?dosyaId=${encodeURIComponent(String(docDosyaId || ""))}` +
                  `&evrakId=${encodeURIComponent(String(evrak.evrakId || ""))}` +
                  `&evrak=${encodeURIComponent(String(evrak.tur || ""))}` +
                  `&tarih=${encodeURIComponent(String(evrak.onaylandigiTarih || ""))}` +
                  `&sira=undefined`
              );
              const docCtx = {
                ...secondCtx,
                dosyaId: docDosyaId,
                dosyaIdEncoded: encodeURIComponent(String(docDosyaId || "")),
                evrakId: String(evrak.evrakId || ""),
                evrakIdEncoded: encodeURIComponent(String(evrak.evrakId || "")),
                evrakEncoded: encodeURIComponent(String(evrak.tur || "")),
                tarihEncoded: encodeURIComponent(String(evrak.onaylandigiTarih || ""))
              };
              const udfHeaders = parseHeaders(settings.fourthHeadersText, docCtx);
              const udf = await runRequestBinary(udfUrl, "GET", udfHeaders, undefined);
              if (!udf.ok) {
                continue;
              }
              const udfAmounts = extractTakipTalebiAmountsFromUdfBytes(udf.bytes);
              const parsedFaiz = numberOrNull(udfAmounts.gecmisGunFaizi);
              const parsedAsil = numberOrNull(udfAmounts.asilAlacak);
              if (parsedFaiz === null) {
                continue;
              }
              if (asilAlacak !== null && parsedAsil !== null && Math.abs(parsedAsil - asilAlacak) > 0.01) {
                continue;
              }
              gecmisGunFaizi = parsedFaiz;
              if (aracMahrumiyetFaizi === null && numberOrNull(udfAmounts.aracMahrumiyetFaizi) !== null) {
                aracMahrumiyetFaizi = udfAmounts.aracMahrumiyetFaizi;
              }
              break;
            }
          }
        }
        const vekaletAdaylari = selectVekaletPuluCandidates(tumEvrakList);
        for (const vekalet of vekaletAdaylari) {
          if (!vekalet || !vekalet.evrakId) {
            continue;
          }
          const fourthMethod = String(settings.fourthMethod || "GET").toUpperCase();
          const docDosyaIdCandidates = [String(vekalet.dosyaId || ""), String(secondCtx.dosyaId || "")].filter(Boolean);
          const uniqueDocDosyaIds = [...new Set(docDosyaIdCandidates)];
          const evrakIdCandidates = [String(vekalet.evrakId || "")];
          const uniqueEvrakIds = [...new Set(evrakIdCandidates.filter(Boolean))];

          let foundVekalet = false;
          for (const docDosyaId of uniqueDocDosyaIds) {
            if (foundVekalet) {
              break;
            }
            for (const evrakIdCandidate of uniqueEvrakIds) {
              const docCtx = {
                ...secondCtx,
                dosyaId: docDosyaId,
                dosyaIdEncoded: encodeURIComponent(String(docDosyaId || "")),
                evrakId: String(evrakIdCandidate || ""),
                evrakIdEncoded: encodeURIComponent(String(evrakIdCandidate || "")),
                evrakEncoded: encodeURIComponent(String(vekalet.tur || "")),
                tarihEncoded: encodeURIComponent(String(vekalet.onaylandigiTarih || ""))
              };
              const candidateFourthUrl = toAbsoluteUrl(applyTemplate(settings.fourthEndpointPath, docCtx));
              const candidateUrls = [candidateFourthUrl];
              if (candidateFourthUrl.includes("/view_document_brd.uyap")) {
                candidateUrls.push(candidateFourthUrl.replace("/view_document_brd.uyap", "/view_document.uyap"));
              }

              for (const docUrl of [...new Set(candidateUrls)]) {
                const fourthHeaders = parseHeaders(settings.fourthHeadersText, docCtx);
                const fourth = await runRequestBinary(docUrl, fourthMethod, fourthHeaders, undefined);
                if (!fourth.ok) {
                  continue;
                }

                const bodyText = [
                  new TextDecoder("utf-8", { fatal: false }).decode(fourth.bytes),
                  new TextDecoder("latin1").decode(fourth.bytes)
                ].join("\n");

                for (const variant of decodeEscapedTextVariants(bodyText)) {
                  const info = extractVekaletPuluInfoFromHtmlText(variant);
                  if (info.tutar === null) {
                    continue;
                  }
                  if (!matchIslemYapanToAlacakli(info.islemYapan, alacakliNameKeys)) {
                    continue;
                  }
                  vekaletPulu = info.tutar;
                  foundVekalet = true;
                  break;
                }

                if (foundVekalet) {
                  break;
                }
              }

              if (foundVekalet) {
                break;
              }
            }
          }

          if (foundVekalet) {
            break;
          }
        }

        {
          const oran = hasHacizTalebi ? 4.55 : 2.275;
          const bazMiktar =
            takipteKesinlesenMiktar !== null
              ? takipteKesinlesenMiktar
              : asilAlacak !== null && gecmisGunFaizi !== null
                ? asilAlacak + gecmisGunFaizi
                : null;
          const pesinHarcDegeri = pesinHarc !== null ? pesinHarc : 0;
          if (bazMiktar !== null) {
            tahsilHarciHesap = Number(((bazMiktar * oran) / 100 - pesinHarcDegeri).toFixed(2));
          }
        }
      }
    }

    return {
      secondUrl,
      thirdUrl,
      fourthUrl,
      evrakPayloadForTracking,
      dosyaHesabiOk,
      dosyaHesabiStatus,
      dosyaKesinlesmeMs,
      tebligTarihi,
      talepTarihi,
      takibinTuruAciklama,
      isIlamliTakip,
      takipteKesinlesenMiktar,
      vekaletUcretiDosyaHesap,
      tebligatGideri,
      pesinHarc,
      basvurmaHarci,
      vekaletSuretHarci,
      vekaletPulu,
      tahsilHarciHesap,
      asilAlacak,
      gecmisGunFaizi,
      aracMahrumiyetBedeli,
      aracMahrumiyetFaizi,
      mahkemeVekaletUcreti,
      mahkemeVekaletUcretiFaizi,
      mahkemeYargilamaGiderleri,
      mahkemeYargilamaGiderleriFaizi,
      mahkemeHarclari,
      mahkemeHarclariFaizi,
      dosyaHesabiDebug
    };
  };

  const computeDosyaHesabiTotals = (row, settings) => {
    let { asilAlacak, gecmisGunFaizi } = row;
    const {
      talepTarihi,
      vekaletPulu,
      tebligatGideri,
      pesinHarc,
      basvurmaHarci,
      vekaletSuretHarci,
      tahsilHarciHesap,
      indirimTutari,
      dosyaHesabiHesapTuru,
      aracMahrumiyetBedeli,
      aracMahrumiyetFaizi,
      mahkemeVekaletUcreti,
      mahkemeVekaletUcretiFaizi,
      mahkemeYargilamaGiderleri,
      mahkemeYargilamaGiderleriFaizi,
      mahkemeHarclari,
      mahkemeHarclariFaizi,
      isIlamliTakip,
      dosyaKesinlesmeMs,
      dosyaHesabiDebug
    } = row;

    let vekaletUcretiDosyaHesap = row.vekaletUcretiDosyaHesap;
    let icraFaizTutari = null;
    let danismanlikUcreti = null;
    let toplamBorcHesap = null;
    let masrafToplami = null;
    let vazgecmeHesabi = null;
    let anaPara = null;
    let hakEdis = null;
    let indirimliToplamBorc = null;
    let indirimYeniAsilAlacak = null;
    let indirimYeniDanismanlikUcreti = null;
    let ygIcraFaiz = null;
    let harcIcraFaiz = null;
    let ivuIcraFaiz = null;

    if (isIlamliTakip && !dosyaHesabiDebug.ilamliForcedByItirazOdemeEmri) {
      // Asıl (tazminat) alacak kalemleri parser tarafından zaten toplanmış
      // durumda (ör. hak mahrumiyeti + birleşen dava pert farkı = asilAlacak).
      // Bunu, yalnızca tek tazminat türünü içeren aracMahrumiyetBedeli ile
      // EZMEYELİM; aksi halde pert farkı gibi ek asıl alacak kalemleri düşer.
      // Yalnızca hiç asıl alacak yoksa, ilamlı takipte ferî kalemlerden birini
      // asıl alacak olarak kullan (öncelik: vekalet > yargılama > harç).
      if (asilAlacak === null) {
        if (mahkemeVekaletUcreti !== null) {
          asilAlacak = mahkemeVekaletUcreti;
          if (mahkemeVekaletUcretiFaizi !== null) {
            gecmisGunFaizi = mahkemeVekaletUcretiFaizi;
          }
        } else if (mahkemeYargilamaGiderleri !== null) {
          asilAlacak = mahkemeYargilamaGiderleri;
          if (mahkemeYargilamaGiderleriFaizi !== null) {
            gecmisGunFaizi = mahkemeYargilamaGiderleriFaizi;
          }
        } else if (mahkemeHarclari !== null) {
          asilAlacak = mahkemeHarclari;
          if (mahkemeHarclariFaizi !== null) {
            gecmisGunFaizi = mahkemeHarclariFaizi;
          }
        }
      }
    }

    const odemeDate = parseOdemeDateInput(settings.dosyaHesabiOdemeTarihi);
    icraFaizTutari = odemeDate ? computeIcraFaizTutari(asilAlacak, talepTarihi, odemeDate, settings) : null;

    const odemeMs = odemeDate
      ? Date.UTC(odemeDate.getUTCFullYear(), odemeDate.getUTCMonth(), odemeDate.getUTCDate())
      : 0;
    const odemeTarihindeKesinlesmis = dosyaKesinlesmeMs > 0 && odemeMs >= dosyaKesinlesmeMs;
    const kesinlesmeEsigiGecildi = odemeTarihindeKesinlesmis;

    if (!isIlamliTakip && asilAlacak !== null) {
      const vekaletBaz = Number(Math.min(asilAlacak, 9000).toFixed(2));
      const oran = kesinlesmeEsigiGecildi ? 1 : 0.75;
      vekaletUcretiDosyaHesap = Number((vekaletBaz * oran).toFixed(2));
    }

    if (!isIlamliTakip && asilAlacak !== null && gecmisGunFaizi !== null && icraFaizTutari !== null) {
      danismanlikUcreti = Number((((asilAlacak + gecmisGunFaizi + icraFaizTutari) * 20) / 100).toFixed(2));
    }

    if (isIlamliTakip && odemeDate) {
      ygIcraFaiz =
        mahkemeYargilamaGiderleri !== null
          ? computeIcraFaizTutari(mahkemeYargilamaGiderleri, talepTarihi, odemeDate, settings)
          : null;
      harcIcraFaiz =
        mahkemeHarclari !== null ? computeIcraFaizTutari(mahkemeHarclari, talepTarihi, odemeDate, settings) : null;
      ivuIcraFaiz =
        mahkemeVekaletUcreti !== null
          ? computeIcraFaizTutari(mahkemeVekaletUcreti, talepTarihi, odemeDate, settings)
          : null;
    }

    const toplamKalemler = [
      asilAlacak,
      gecmisGunFaizi,
      icraFaizTutari,
      pesinHarc,
      basvurmaHarci,
      vekaletSuretHarci,
      tahsilHarciHesap,
      vekaletPulu,
      tebligatGideri,
      vekaletUcretiDosyaHesap
    ];

    if (isIlamliTakip) {
      toplamKalemler.push(
        mahkemeVekaletUcreti,
        mahkemeVekaletUcretiFaizi,
        mahkemeYargilamaGiderleri,
        mahkemeYargilamaGiderleriFaizi,
        mahkemeHarclari,
        mahkemeHarclariFaizi,
        ygIcraFaiz,
        harcIcraFaiz,
        ivuIcraFaiz
      );
    }

    toplamBorcHesap = sumNumericAmounts(toplamKalemler);

    masrafToplami = sumNumericAmounts([
      vekaletPulu,
      tebligatGideri,
      basvurmaHarci,
      vekaletSuretHarci,
      pesinHarc,
      tahsilHarciHesap
    ]);

    vazgecmeHesabi = sumNumericAmounts([
      vekaletUcretiDosyaHesap,
      danismanlikUcreti,
      tahsilHarciHesap,
      vekaletPulu,
      tebligatGideri,
      pesinHarc,
      basvurmaHarci,
      vekaletSuretHarci
    ]);

    anaPara = sumNumericAmounts([asilAlacak, gecmisGunFaizi, icraFaizTutari]);
    if (anaPara !== null && danismanlikUcreti !== null) {
      hakEdis = Number((anaPara - danismanlikUcreti).toFixed(2));
    }

    const indirimBaz = sumNumericAmounts([asilAlacak, gecmisGunFaizi, icraFaizTutari]);
    const indirimEkKalemler = sumNumericAmounts([
      mahkemeYargilamaGiderleri,
      mahkemeYargilamaGiderleriFaizi,
      ygIcraFaiz,
      mahkemeHarclari,
      mahkemeHarclariFaizi,
      harcIcraFaiz,
      mahkemeVekaletUcreti,
      mahkemeVekaletUcretiFaizi,
      ivuIcraFaiz,
      vekaletPulu,
      tebligatGideri,
      basvurmaHarci,
      vekaletSuretHarci,
      pesinHarc,
      tahsilHarciHesap,
      vekaletUcretiDosyaHesap
    ]);

    if (indirimBaz !== null) {
      indirimYeniAsilAlacak = Number(((indirimBaz * 0.8 - indirimTutari) * 1.25).toFixed(2));
    }
    if (indirimYeniAsilAlacak !== null && danismanlikUcreti !== null) {
      indirimYeniDanismanlikUcreti = Number((danismanlikUcreti - indirimYeniAsilAlacak * 0.2).toFixed(2));
    }
    indirimliToplamBorc = sumNumericAmounts([indirimYeniAsilAlacak, indirimYeniDanismanlikUcreti, indirimEkKalemler]);

    if (dosyaHesabiHesapTuru === "vazgecme" && vazgecmeHesabi !== null) {
      toplamBorcHesap = vazgecmeHesabi;
    }
    if (dosyaHesabiHesapTuru === "indirim" && indirimliToplamBorc !== null) {
      toplamBorcHesap = indirimliToplamBorc;
    }

    return {
      asilAlacak,
      gecmisGunFaizi,
      vekaletUcretiDosyaHesap,
      icraFaizTutari,
      danismanlikUcreti,
      toplamBorcHesap,
      masrafToplami,
      vazgecmeHesabi,
      anaPara,
      hakEdis,
      indirimliToplamBorc,
      indirimYeniAsilAlacak,
      indirimYeniDanismanlikUcreti,
      ygIcraFaiz,
      harcIcraFaiz,
      ivuIcraFaiz
    };
  };

  window.__EWR_PR_QueryDosyaHesabi = {
    collectDosyaHesabiData,
    computeDosyaHesabiTotals,
    createDosyaHesabiDebug
  };
})();

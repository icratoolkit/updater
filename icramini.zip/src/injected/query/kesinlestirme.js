(() => {
  const C = window.__EWR_PR_Core;
  const E = window.__EWR_PR_Extract;
  if (!C || !E) {
    console.error("query/kesinlestirme.js: çekirdek ve çıkarım modülleri önce yüklenmeli.");
    return;
  }

  const {
    applyTemplate,
    applyJsonBodyTemplate,
    parseHeaders,
    toAbsoluteUrl,
    runRequest,
    runRequestBinary,
    runRequestViaExtension,
    normalizeText,
    parseTrDateToTime
  } = C;

  const {
    extractTebligDateFromPtt,
    extractTebligDateFromPttApi,
    collectEvrakItems,
    collectTumEvraklarItems,
    selectBarcodeCandidates,
    extractBarcodeFromPdfBytes,
    pdfContainsOdemeIcraEmri,
    extractETebligInfoFromPdfBytes,
    extractKisiFromAciklama,
    countBorcaItirazBefore,
    unwrapPdfLikeBytes
  } = E;

  const createBarcodeDebug = () => ({
    thirdOk: false,
    evrakCount: 0,
    candidateCount: 0,
    triedPdfCount: 0,
    tried: []
  });

  // Tebliğ gününü takip eden 7 tam gün dolduktan sonra, yani 8. günde kesinleşir.
  const KESINLESME_GUN_SAYISI = 8;
  const DAY_MS = 24 * 60 * 60 * 1000;

  const collectTebligBilgileri = async ({
    settings,
    secondCtx,
    runMode,
    evrakPayloadForTracking,
    thirdUrl: previousThirdUrl,
    fourthUrl: previousFourthUrl
  }) => {
    let thirdUrl = previousThirdUrl;
    let fourthUrl = previousFourthUrl;
    let dosyaKesinlesmeMs = 0;
    let tebligTarihi = null;
    let tebligYediGunSonrasi = null;
    let barcode = null;
    let barcodeSource = null;
    let barcodeEvrakId = null;
    let pttUrl = null;
    let borcaItirazSayisi = 0;
    let borcluSayisi = 0;
    let itirazKontrolTarihi = null;
    const tebligDetaylari = [];

    const barcodeDebug = createBarcodeDebug();

    // Kesinleşme ve dosya hesabında tebliğ tarihi yalnız doğrulanan ödeme/icra emri PDFinden gelir.
    dosyaKesinlesmeMs = 0;
    tebligTarihi = null;
    let thirdJsonForTracking = evrakPayloadForTracking;

    if (!thirdJsonForTracking) {
      const thirdUrlResolved = toAbsoluteUrl(applyTemplate(settings.thirdEndpointPath, secondCtx));
      const thirdMethod = String(settings.thirdMethod || "POST").toUpperCase();
      const thirdHeaders = parseHeaders(settings.thirdHeadersText, secondCtx);
      const thirdBody = applyJsonBodyTemplate(settings.thirdBodyTemplate, secondCtx);
      const third = await runRequest(thirdUrlResolved, thirdMethod, thirdHeaders, thirdBody);
      thirdUrl = thirdUrlResolved;
      barcodeDebug.thirdOk = !!(third.ok && third.json);
      thirdJsonForTracking = third.ok && third.json ? third.json : null;
    } else {
      barcodeDebug.thirdOk = true;
    }

    if (thirdJsonForTracking) {
      const evrakList = collectEvrakItems(thirdJsonForTracking);
      const tumEvrakList = collectTumEvraklarItems(thirdJsonForTracking);
      const candidates = selectBarcodeCandidates(evrakList);
      barcodeDebug.evrakCount = evrakList.length;
      barcodeDebug.candidateCount = candidates.length;

      for (const evrak of candidates) {
        const evrakTurNorm = normalizeText(evrak && evrak.tur);
        const isETeblig = evrakTurNorm.includes("kapali e-teblig mazbatasi");
        let evrakBarcode = null;
        let evrakBarcodeUrl = null;
        const fourthMethod = String(settings.fourthMethod || "GET").toUpperCase();
        const docDosyaIdCandidates = [String(evrak.dosyaId || ""), String(secondCtx.dosyaId || "")].filter(Boolean);
        const uniqueDocDosyaIds = [...new Set(docDosyaIdCandidates)];
        let shouldTryFallbackDosyaId = false;

        for (let idx = 0; idx < uniqueDocDosyaIds.length; idx += 1) {
          const docDosyaId = uniqueDocDosyaIds[idx];
          if (idx > 0 && !shouldTryFallbackDosyaId) {
            break;
          }
          const docCtx = {
            ...secondCtx,
            dosyaId: docDosyaId,
            dosyaIdEncoded: encodeURIComponent(String(docDosyaId || "")),
            evrakId: String(evrak.evrakId || ""),
            evrakIdEncoded: encodeURIComponent(String(evrak.evrakId || "")),
            evrakEncoded: encodeURIComponent(String(evrak.tur || "")),
            tarihEncoded: encodeURIComponent(String(evrak.onaylandigiTarih || ""))
          };

          const downloadUrl = toAbsoluteUrl(
            `/download_document_brd.uyap?dosyaId=${encodeURIComponent(String(docDosyaId || ""))}` +
              `&evrakId=${encodeURIComponent(String(evrak.evrakId || ""))}` +
              `&evrak=${encodeURIComponent(String(evrak.tur || ""))}` +
              `&tarih=${encodeURIComponent(String(evrak.onaylandigiTarih || ""))}` +
              `&sira=undefined`
          );
          const candidateFourthUrl = toAbsoluteUrl(applyTemplate(settings.fourthEndpointPath, docCtx));
          const fourthHeaders = parseHeaders(settings.fourthHeadersText, docCtx);
          const binaryCandidates = [];
          const downloaded = await runRequestBinary(downloadUrl, fourthMethod, fourthHeaders, undefined);
          barcodeDebug.triedPdfCount += 1;
          if (barcodeDebug.tried.length < 10) {
            barcodeDebug.tried.push({
              evrakId: String(evrak.evrakId || ""),
              dosyaId: String(docDosyaId || ""),
              status: downloaded.status,
              ok: !!downloaded.ok,
              size: downloaded.bytes ? downloaded.bytes.length : 0
            });
          }
          if (downloaded.ok) {
            binaryCandidates.push({
              url: downloadUrl,
              bytes: unwrapPdfLikeBytes(downloaded.bytes) || downloaded.bytes
            });
          }

          const fourth = await runRequestBinary(candidateFourthUrl, fourthMethod, fourthHeaders, undefined);
          barcodeDebug.triedPdfCount += 1;
          if (barcodeDebug.tried.length < 10) {
            barcodeDebug.tried.push({
              evrakId: String(evrak.evrakId || ""),
              dosyaId: String(docDosyaId || ""),
              status: fourth.status,
              ok: !!fourth.ok,
              size: fourth.bytes ? fourth.bytes.length : 0
            });
          }
          if (fourth.ok) {
            binaryCandidates.push({
              url: candidateFourthUrl,
              bytes: unwrapPdfLikeBytes(fourth.bytes) || fourth.bytes
            });
          }

          if (binaryCandidates.length === 0) {
            shouldTryFallbackDosyaId = true;
            continue;
          }
          shouldTryFallbackDosyaId = false;

          if (isETeblig) {
            for (const candidate of binaryCandidates) {
              const eteblig = await extractETebligInfoFromPdfBytes(
                candidate.bytes,
                extractKisiFromAciklama(evrak.aciklama)
              );
              if (eteblig && eteblig.tebligTarihi) {
                let evrakYediGunSonrasi = null;
                let evrakIsMatch = false;
                const tebligMs = parseTrDateToTime(eteblig.tebligTarihi);
                if (tebligMs > 0) {
                  evrakYediGunSonrasi = new Date(tebligMs + KESINLESME_GUN_SAYISI * DAY_MS).toISOString();
                  const now = new Date();
                  const todayUtc = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
                  evrakIsMatch = todayUtc >= Date.parse(evrakYediGunSonrasi);
                }

                tebligDetaylari.push({
                  evrakId: String(evrak.evrakId || ""),
                  kisi: eteblig.kisi || extractKisiFromAciklama(evrak.aciklama),
                  barcode: "",
                  tebligTarihi: eteblig.tebligTarihi,
                  tebligYediGunSonrasi: evrakYediGunSonrasi,
                  isMatch: evrakIsMatch,
                  fourthUrl: candidate.url
                });
                evrakBarcodeUrl = candidate.url;
                break;
              }
            }
            continue;
          } else {
            for (const candidate of binaryCandidates) {
              if (!(await pdfContainsOdemeIcraEmri(candidate.bytes))) {
                continue;
              }
              const found = await extractBarcodeFromPdfBytes(candidate.bytes);
              if (found) {
                evrakBarcode = found;
                evrakBarcodeUrl = candidate.url;
                break;
              }
            }
            if (evrakBarcode) {
              break;
            }
          }
        }

        if (isETeblig) {
          continue;
        }

        if (!evrakBarcode) {
          continue;
        }

        const pttHeaders = {
          Accept: "application/json",
          "Content-Type": "application/json; charset=UTF-8",
          Origin: "https://www.ptt.gov.tr",
          Referer: "https://www.ptt.gov.tr/"
        };

        let evrakTebligTarihi = null;
        let evrakYediGunSonrasi = null;
        let evrakIsMatch = false;

        pttUrl = toAbsoluteUrl("/ptt_barkod_sorgula.ajx");
        const ptt = await runRequest(pttUrl, "POST", pttHeaders, JSON.stringify({ barcode: evrakBarcode }));

        if (ptt.ok && ptt.json) {
          evrakTebligTarihi = extractTebligDateFromPtt(ptt.json);
        }

        if (!evrakTebligTarihi) {
          const pttApiUrl = "https://api.ptt.gov.tr/api/ShipmentTracking";
          const pttApi = await runRequestViaExtension(pttApiUrl, "POST", pttHeaders, JSON.stringify([evrakBarcode]));
          if (pttApi.ok && pttApi.json) {
            evrakTebligTarihi = extractTebligDateFromPttApi(pttApi.json);
          }
        }

        if (evrakTebligTarihi) {
          const tebligMs = parseTrDateToTime(evrakTebligTarihi);
          if (tebligMs > 0) {
            // Kesinlesme, teslim gununu takip eden 7 tam gun bittikten sonra (8. gun) olur.
            evrakYediGunSonrasi = new Date(tebligMs + KESINLESME_GUN_SAYISI * DAY_MS).toISOString();
            const now = new Date();
            const todayUtc = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
            evrakIsMatch = todayUtc >= Date.parse(evrakYediGunSonrasi);
          }
        }

        tebligDetaylari.push({
          evrakId: String(evrak.evrakId || ""),
          kisi: extractKisiFromAciklama(evrak.aciklama),
          barcode: evrakBarcode,
          tebligTarihi: evrakTebligTarihi,
          tebligYediGunSonrasi: evrakYediGunSonrasi,
          isMatch: evrakIsMatch,
          fourthUrl: evrakBarcodeUrl
        });
      }

      if (tebligDetaylari.length > 0) {
        const borcluKeys = new Set(tebligDetaylari.map((x) => normalizeText(x && x.kisi)).filter((x) => !!x));
        borcluSayisi = borcluKeys.size;
        let maxKesinlesmeMs = 0;
        let minKesinlesmeMs = 0;
        for (const d of tebligDetaylari) {
          const ms = Date.parse(String(d.tebligYediGunSonrasi || ""));
          if (!Number.isFinite(ms) || ms <= 0) {
            continue;
          }
          if (ms > maxKesinlesmeMs) {
            maxKesinlesmeMs = ms;
          }
          if (minKesinlesmeMs <= 0 || ms < minKesinlesmeMs) {
            minKesinlesmeMs = ms;
          }
        }
        if (maxKesinlesmeMs > 0) {
          itirazKontrolTarihi = new Date(maxKesinlesmeMs).toISOString();
          borcaItirazSayisi = countBorcaItirazBefore(tumEvrakList, maxKesinlesmeMs);
        }
        if (runMode === "dosyaHesabi" && minKesinlesmeMs > 0) {
          // Dosya Hesabi kurali: herhangi bir borcluya teblig +8 gun yeterli.
          dosyaKesinlesmeMs = minKesinlesmeMs;
        }

        const firstWithDate =
          tebligDetaylari
            .filter((x) => parseTrDateToTime(x && x.tebligTarihi) > 0)
            .sort((a, b) => parseTrDateToTime(a.tebligTarihi) - parseTrDateToTime(b.tebligTarihi))[0] ||
          tebligDetaylari[0];
        if (firstWithDate) {
          barcode = firstWithDate.barcode || null;
          barcodeSource = "pdf";
          barcodeEvrakId = firstWithDate.evrakId || null;
          tebligTarihi = firstWithDate.tebligTarihi || null;
          tebligYediGunSonrasi = firstWithDate.tebligYediGunSonrasi || null;
          fourthUrl = firstWithDate.fourthUrl || null;
        }
      }
    }

    return {
      thirdUrl,
      fourthUrl,
      dosyaKesinlesmeMs,
      tebligTarihi,
      tebligYediGunSonrasi,
      barcode,
      barcodeSource,
      barcodeEvrakId,
      pttUrl,
      borcaItirazSayisi,
      borcluSayisi,
      itirazKontrolTarihi,
      tebligDetaylari,
      barcodeDebug
    };
  };

  window.__EWR_PR_QueryKesinlestirme = {
    collectTebligBilgileri,
    createBarcodeDebug
  };
})();

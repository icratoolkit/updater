(() => {
  const C = window.__EWR_PR_Core;
  const E = window.__EWR_PR_Extract;
  if (!C || !E) {
    console.error("query/kesinlestirme.js: çekirdek ve çıkarım modülleri önce yüklenmeli.");
    return;
  }

  const {
    applyTemplate,
    applyJsonBodyTemplate,
    parseHeaders,
    toAbsoluteUrl,
    runRequest,
    runRequestBinary,
    runRequestViaExtension,
    normalizeJsonBodyValue,
    normalizeText,
    parseTrDateToTime
  } = C;

  const {
    extractTebligDateFromPtt,
    extractTebligDateFromPttApi,
    extractIadeBilgisiFromPtt,
    extractIadeBilgisiFromPttApi,
    collectEvrakItems,
    collectTumEvraklarItems,
    selectBarcodeCandidates,
    extractBarcodeFromPdfBytes,
    pdfContainsOdemeIcraEmri,
    extractETebligInfoFromPdfBytes,
    extractKisiFromAciklama,
    countBorcaItirazBefore,
    collectBorcaItirazTalepleri,
    collectBorcluKimlikleri,
    extractTebligBilgisiFromAciklama,
    normalizeGonderenKey,
    normalizePersonKey,
    unwrapPdfLikeBytes
  } = E;

  const createBarcodeDebug = () => ({
    thirdOk: false,
    evrakCount: 0,
    candidateCount: 0,
    triedPdfCount: 0,
    aciklamadanBarkod: 0,
    errors: [],
    tried: []
  });

  // Tebliğ gününü takip eden 7 tam gün dolduktan sonra, yani 8. günde kesinleşir.
  const KESINLESME_GUN_SAYISI = 8;
  const DAY_MS = 24 * 60 * 60 * 1000;

  const collectTebligBilgileri = async ({
    settings,
    secondCtx,
    runMode,
    evrakPayloadForTracking,
    thirdUrl: previousThirdUrl,
    fourthUrl: previousFourthUrl
  }) => {
    let thirdUrl = previousThirdUrl;
    let fourthUrl = previousFourthUrl;
    let dosyaKesinlesmeMs = 0;
    let tebligTarihi = null;
    let tebligYediGunSonrasi = null;
    let barcode = null;
    let barcodeSource = null;
    let barcodeEvrakId = null;
    let pttUrl = null;
    let borcaItirazSayisi = 0;
    let borcluSayisi = 0;
    let kesinlesenBorcluSayisi = 0;
    let belirsizItirazSayisi = 0;
    let itirazKontrolTarihi = null;
    const tebligDetaylari = [];
    // Muhataba ulaşmayıp geri dönen tebligatlar kesinleşme hesabına girmez; ayrı
    // listelenip kullanıcıya "iade" olarak gösterilir.
    const iadeDetaylari = [];

    const barcodeDebug = createBarcodeDebug();

    // Kesinleşme ve dosya hesabında tebliğ tarihi yalnız doğrulanan ödeme/icra emri PDFinden gelir.
    dosyaKesinlesmeMs = 0;
    tebligTarihi = null;
    let thirdJsonForTracking = evrakPayloadForTracking;

    if (!thirdJsonForTracking) {
      const thirdUrlResolved = toAbsoluteUrl(applyTemplate(settings.thirdEndpointPath, secondCtx));
      const thirdMethod = String(settings.thirdMethod || "POST").toUpperCase();
      const thirdHeaders = parseHeaders(settings.thirdHeadersText, secondCtx);
      const thirdBody = applyJsonBodyTemplate(settings.thirdBodyTemplate, secondCtx);
      const third = await runRequest(thirdUrlResolved, thirdMethod, thirdHeaders, thirdBody);
      thirdUrl = thirdUrlResolved;
      barcodeDebug.thirdOk = !!(third.ok && third.json);
      thirdJsonForTracking = third.ok && third.json ? third.json : null;
    } else {
      barcodeDebug.thirdOk = true;
    }

    if (thirdJsonForTracking) {
      const evrakList = collectEvrakItems(thirdJsonForTracking);
      const tumEvrakList = collectTumEvraklarItems(thirdJsonForTracking);
      const candidates = selectBarcodeCandidates(evrakList);
      barcodeDebug.evrakCount = evrakList.length;
      barcodeDebug.candidateCount = candidates.length;

      // Tek bir evrakın indirilememesi ya da zaman aşımına uğraması dosyanın
      // tamamını düşürmesin; o evrak atlanır, diğerleriyle devam edilir.
      const processEvrakCandidate = async (evrak) => {
        const evrakTurNorm = normalizeText(evrak && evrak.tur);
        const isETeblig = evrakTurNorm.includes("kapali e-teblig mazbatasi");
        let evrakBarcode = null;
        let evrakBarcodeUrl = null;
        let evrakBarcodeKaynak = null;

        // Bazı icra daireleri barkodu doğrudan evrak açıklamasına yazıyor. Varsa PDF
        // indirip zarf metnini çözmeye gerek kalmıyor; açıklama yoksa ya da ödeme/icra
        // emri tebligatı olduğunu göstermiyorsa mevcut PDF akışı aynen çalışıyor.
        const aciklamaBilgisi = isETeblig ? null : extractTebligBilgisiFromAciklama(evrak && evrak.aciklama);
        if (aciklamaBilgisi) {
          evrakBarcode = aciklamaBilgisi.barcode;
          evrakBarcodeKaynak = "aciklama";
          barcodeDebug.aciklamadanBarkod += 1;
        }

        const fourthMethod = String(settings.fourthMethod || "GET").toUpperCase();
        const docDosyaIdCandidates = [String(evrak.dosyaId || ""), String(secondCtx.dosyaId || "")].filter(Boolean);
        const uniqueDocDosyaIds = [...new Set(docDosyaIdCandidates)];
        let shouldTryFallbackDosyaId = false;

        for (let idx = 0; idx < uniqueDocDosyaIds.length; idx += 1) {
          if (evrakBarcode) {
            break;
          }
          const docDosyaId = uniqueDocDosyaIds[idx];
          if (idx > 0 && !shouldTryFallbackDosyaId) {
            break;
          }
          const docCtx = {
            ...secondCtx,
            dosyaId: docDosyaId,
            dosyaIdEncoded: encodeURIComponent(String(docDosyaId || "")),
            evrakId: String(evrak.evrakId || ""),
            evrakIdEncoded: encodeURIComponent(String(evrak.evrakId || "")),
            evrakEncoded: encodeURIComponent(String(evrak.tur || "")),
            tarihEncoded: encodeURIComponent(String(evrak.onaylandigiTarih || ""))
          };

          const downloadUrl = toAbsoluteUrl(
            `/download_document_brd.uyap?dosyaId=${encodeURIComponent(String(docDosyaId || ""))}` +
              `&evrakId=${encodeURIComponent(String(evrak.evrakId || ""))}` +
              `&evrak=${encodeURIComponent(String(evrak.tur || ""))}` +
              `&tarih=${encodeURIComponent(String(evrak.onaylandigiTarih || ""))}` +
              `&sira=undefined`
          );
          const candidateFourthUrl = toAbsoluteUrl(applyTemplate(settings.fourthEndpointPath, docCtx));
          const fourthHeaders = parseHeaders(settings.fourthHeadersText, docCtx);
          const binaryCandidates = [];
          const downloaded = await runRequestBinary(downloadUrl, fourthMethod, fourthHeaders, undefined);
          barcodeDebug.triedPdfCount += 1;
          if (barcodeDebug.tried.length < 10) {
            barcodeDebug.tried.push({
              evrakId: String(evrak.evrakId || ""),
              dosyaId: String(docDosyaId || ""),
              status: downloaded.status,
              ok: !!downloaded.ok,
              size: downloaded.bytes ? downloaded.bytes.length : 0
            });
          }
          if (downloaded.ok) {
            binaryCandidates.push({
              url: downloadUrl,
              bytes: unwrapPdfLikeBytes(downloaded.bytes) || downloaded.bytes
            });
          }

          const fourth = await runRequestBinary(candidateFourthUrl, fourthMethod, fourthHeaders, undefined);
          barcodeDebug.triedPdfCount += 1;
          if (barcodeDebug.tried.length < 10) {
            barcodeDebug.tried.push({
              evrakId: String(evrak.evrakId || ""),
              dosyaId: String(docDosyaId || ""),
              status: fourth.status,
              ok: !!fourth.ok,
              size: fourth.bytes ? fourth.bytes.length : 0
            });
          }
          if (fourth.ok) {
            binaryCandidates.push({
              url: candidateFourthUrl,
              bytes: unwrapPdfLikeBytes(fourth.bytes) || fourth.bytes
            });
          }

          if (binaryCandidates.length === 0) {
            shouldTryFallbackDosyaId = true;
            continue;
          }
          shouldTryFallbackDosyaId = false;

          if (isETeblig) {
            for (const candidate of binaryCandidates) {
              const eteblig = await extractETebligInfoFromPdfBytes(
                candidate.bytes,
                extractKisiFromAciklama(evrak.aciklama)
              );
              if (eteblig && eteblig.tebligTarihi) {
                let evrakYediGunSonrasi = null;
                let evrakIsMatch = false;
                const tebligMs = parseTrDateToTime(eteblig.tebligTarihi);
                if (tebligMs > 0) {
                  evrakYediGunSonrasi = new Date(tebligMs + KESINLESME_GUN_SAYISI * DAY_MS).toISOString();
                  const now = new Date();
                  const todayUtc = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
                  evrakIsMatch = todayUtc >= Date.parse(evrakYediGunSonrasi);
                }

                tebligDetaylari.push({
                  evrakId: String(evrak.evrakId || ""),
                  kisi: eteblig.kisi || extractKisiFromAciklama(evrak.aciklama),
                  barcode: "",
                  tebligTarihi: eteblig.tebligTarihi,
                  tebligYediGunSonrasi: evrakYediGunSonrasi,
                  isMatch: evrakIsMatch,
                  fourthUrl: candidate.url
                });
                evrakBarcodeUrl = candidate.url;
                break;
              }
            }
            continue;
          } else {
            for (const candidate of binaryCandidates) {
              if (!(await pdfContainsOdemeIcraEmri(candidate.bytes))) {
                continue;
              }
              const found = await extractBarcodeFromPdfBytes(candidate.bytes);
              if (found) {
                evrakBarcode = found;
                evrakBarcodeUrl = candidate.url;
                evrakBarcodeKaynak = "pdf";
                break;
              }
            }
            if (evrakBarcode) {
              break;
            }
          }
        }

        if (isETeblig) {
          return;
        }

        if (!evrakBarcode) {
          return;
        }

        const pttHeaders = {
          Accept: "application/json",
          "Content-Type": "application/json; charset=UTF-8",
          Origin: "https://www.ptt.gov.tr",
          Referer: "https://www.ptt.gov.tr/"
        };

        let evrakTebligTarihi = null;
        let evrakYediGunSonrasi = null;
        let evrakIsMatch = false;
        let evrakIadeBilgisi = null;

        pttUrl = toAbsoluteUrl("/ptt_barkod_sorgula.ajx");
        const ptt = await runRequest(pttUrl, "POST", pttHeaders, JSON.stringify({ barcode: evrakBarcode }));

        if (ptt.ok && ptt.json) {
          evrakTebligTarihi = extractTebligDateFromPtt(ptt.json);
          if (!evrakTebligTarihi) {
            evrakIadeBilgisi = extractIadeBilgisiFromPtt(ptt.json);
          }
        }

        if (!evrakTebligTarihi) {
          const pttApiUrl = "https://api.ptt.gov.tr/api/ShipmentTracking";
          const pttApi = await runRequestViaExtension(pttApiUrl, "POST", pttHeaders, JSON.stringify([evrakBarcode]));
          if (pttApi.ok && pttApi.json) {
            evrakTebligTarihi = extractTebligDateFromPttApi(pttApi.json);
            if (!evrakTebligTarihi && !evrakIadeBilgisi) {
              evrakIadeBilgisi = extractIadeBilgisiFromPttApi(pttApi.json);
            }
          }
        }

        // Tebligat geri döndüyse ayrıca iade listesine yazılıyor. Tebligat detayı yine de
        // eklenmeye devam ediyor: borca itirazın borçluya atfı bu listeden yapılıyor ve
        // tarihi olmayan detay kesinleşme sayımına zaten girmiyor.
        if (!evrakTebligTarihi && evrakIadeBilgisi) {
          iadeDetaylari.push({
            evrakId: String(evrak.evrakId || ""),
            kisi: extractKisiFromAciklama(evrak.aciklama),
            barcode: evrakBarcode,
            barcodeSource: evrakBarcodeKaynak,
            iadeTarihi: evrakIadeBilgisi.tarih || null,
            iadeAciklama: evrakIadeBilgisi.aciklama || "",
            fourthUrl: evrakBarcodeUrl
          });
        }

        if (evrakTebligTarihi) {
          const tebligMs = parseTrDateToTime(evrakTebligTarihi);
          if (tebligMs > 0) {
            // Kesinlesme, teslim gununu takip eden 7 tam gun bittikten sonra (8. gun) olur.
            evrakYediGunSonrasi = new Date(tebligMs + KESINLESME_GUN_SAYISI * DAY_MS).toISOString();
            const now = new Date();
            const todayUtc = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
            evrakIsMatch = todayUtc >= Date.parse(evrakYediGunSonrasi);
          }
        }

        tebligDetaylari.push({
          evrakId: String(evrak.evrakId || ""),
          kisi: extractKisiFromAciklama(evrak.aciklama),
          barcode: evrakBarcode,
          barcodeSource: evrakBarcodeKaynak,
          tebligTarihi: evrakTebligTarihi,
          tebligYediGunSonrasi: evrakYediGunSonrasi,
          isMatch: evrakIsMatch,
          fourthUrl: evrakBarcodeUrl
        });
      };

      for (const evrak of candidates) {
        try {
          await processEvrakCandidate(evrak);
        } catch (error) {
          const message = String((error && error.message) || error);
          if (message === "STOP_REQUESTED") {
            throw error;
          }
          if (barcodeDebug.errors.length < 10) {
            barcodeDebug.errors.push({ evrakId: String(evrak.evrakId || ""), message });
          }
        }
      }

      // Borca itirazı doğru borçluya atfetmek için taraf bilgileri gerekiyor. Dosya
      // Hesabı kesinleşmeyi borçlu bazlı değerlendirmediğinden orada istenmiyor; istek
      // başarısız olursa itirazların tamamı "atfedilemeyen" sayılıp temkinli davranılıyor.
      let borcluKimlikleri = [];
      if (tebligDetaylari.length > 0 && runMode !== "dosyaHesabi") {
        try {
          const tarafHeaders = parseHeaders(settings.thirdHeadersText, secondCtx);
          const tarafBody = JSON.stringify({ dosyaId: normalizeJsonBodyValue(secondCtx.dosyaId || "") });
          const taraf = await runRequest(
            toAbsoluteUrl("/dosya_taraf_bilgileri_brd.ajx"),
            "POST",
            tarafHeaders,
            tarafBody
          );
          if (taraf.ok && Array.isArray(taraf.json)) {
            borcluKimlikleri = collectBorcluKimlikleri(taraf.json);
          }
        } catch (error) {
          const message = String((error && error.message) || error);
          if (message === "STOP_REQUESTED") {
            throw error;
          }
          barcodeDebug.errors.push({ evrakId: "", message: `taraf bilgileri alınamadı: ${message}` });
        }
      }

      if (tebligDetaylari.length > 0) {
        // Kesinleşme dosya değil borçlu bazlıdır: İİK 66'ya göre borca itiraz eden
        // borçlu bakımından takip durur, itiraz etmeyen diğer borçlular için 8. günde
        // kesinleşir. Bu yüzden her borçlu kendi tebligat tarihiyle değerlendiriliyor.
        const gruplar = new Map();
        for (const detay of tebligDetaylari) {
          const key = normalizeText(detay && detay.kisi);
          if (!gruplar.has(key)) {
            gruplar.set(key, { kisi: String((detay && detay.kisi) || ""), kesinlesmeMs: 0, detaylar: [] });
          }
          const grup = gruplar.get(key);
          grup.detaylar.push(detay);
          const ms = Date.parse(String((detay && detay.tebligYediGunSonrasi) || ""));
          if (Number.isFinite(ms) && ms > 0 && (grup.kesinlesmeMs <= 0 || ms < grup.kesinlesmeMs)) {
            // Borçlunun ilk geçerli tebligatı itiraz süresini başlatır.
            grup.kesinlesmeMs = ms;
          }
        }
        borcluSayisi = gruplar.size;

        // Aynı borçlu birden çok tebligat grubuna düşebiliyor (ör. açıklaması kesilmiş
        // mazbata ile tam adlı kapalı tebligat ayrı gruplar oluşturuyor), bu yüzden
        // eşleşen grupların tamamı döndürülüyor.
        const grupKeysForBorclu = (borclu) => {
          const keys = [];
          for (const [key, grup] of gruplar) {
            const grupKey = normalizePersonKey(grup.kisi);
            if (!grupKey || !borclu.nameKey) {
              continue;
            }
            if (grupKey === borclu.nameKey || grupKey.includes(borclu.nameKey) || borclu.nameKey.includes(grupKey)) {
              keys.push(key);
            }
          }
          return keys;
        };

        // İtiraz evraklarının açıklaması boş geliyor; atıf yalnız gönderen üzerinden
        // (borçlunun kendisi ya da vekili) yapılabiliyor.
        const itirazlar = collectBorcaItirazTalepleri(tumEvrakList);
        const belirsizItirazlar = [];
        const itirazMsByKey = new Map();
        for (const itiraz of itirazlar) {
          const gonderenKey = normalizeGonderenKey(itiraz.gonderen);
          // Ortak vekil tek dilekçeyle birden çok borçlu adına itiraz edebiliyor
          // Gönderen kaç borçluya bağlıysa itiraz hepsine yazılır.
          const sahipler = gonderenKey
            ? borcluKimlikleri.filter((b) => b.nameKey === gonderenKey || b.vekilKeys.includes(gonderenKey))
            : [];
          const keys = [...new Set(sahipler.flatMap((b) => grupKeysForBorclu(b)))];
          if (keys.length === 0) {
            belirsizItirazlar.push(itiraz);
            continue;
          }
          for (const key of keys) {
            itirazMsByKey.set(key, [...(itirazMsByKey.get(key) || []), itiraz.ms]);
          }
        }

        const now = new Date();
        const todayUtc = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
        let enGecKesinlesmeMs = 0;
        for (const [key, grup] of gruplar) {
          const olgun = grup.kesinlesmeMs > 0 && todayUtc >= grup.kesinlesmeMs;
          const itirazVar = (itirazMsByKey.get(key) || []).some((ms) => ms <= grup.kesinlesmeMs);
          if (itirazVar) {
            // İtiraz eden borçlu satırda kesinleşmiş görünmesin.
            for (const detay of grup.detaylar) {
              detay.isMatch = false;
            }
            continue;
          }
          if (olgun) {
            kesinlesenBorcluSayisi += 1;
            if (grup.kesinlesmeMs > enGecKesinlesmeMs) {
              enGecKesinlesmeMs = grup.kesinlesmeMs;
            }
          }
        }

        // Atfedilemeyen itiraz herhangi bir borçluya ait olabilir; bu yüzden kesinleşen
        // borçlu sayısını aşmadıkça dosyada kesinleşmiş borçlu kaldığı kabul edilir.
        belirsizItirazSayisi =
          enGecKesinlesmeMs > 0 ? belirsizItirazlar.filter((x) => x.ms <= enGecKesinlesmeMs).length : 0;

        let maxKesinlesmeMs = 0;
        let minKesinlesmeMs = 0;
        for (const d of tebligDetaylari) {
          const ms = Date.parse(String(d.tebligYediGunSonrasi || ""));
          if (!Number.isFinite(ms) || ms <= 0) {
            continue;
          }
          if (ms > maxKesinlesmeMs) {
            maxKesinlesmeMs = ms;
          }
          if (minKesinlesmeMs <= 0 || ms < minKesinlesmeMs) {
            minKesinlesmeMs = ms;
          }
        }
        if (maxKesinlesmeMs > 0) {
          itirazKontrolTarihi = new Date(maxKesinlesmeMs).toISOString();
          borcaItirazSayisi = countBorcaItirazBefore(tumEvrakList, maxKesinlesmeMs);
        }
        if (runMode === "dosyaHesabi" && minKesinlesmeMs > 0) {
          // Dosya Hesabi kurali: herhangi bir borcluya teblig +8 gun yeterli.
          dosyaKesinlesmeMs = minKesinlesmeMs;
        }

        const firstWithDate =
          tebligDetaylari
            .filter((x) => parseTrDateToTime(x && x.tebligTarihi) > 0)
            .sort((a, b) => parseTrDateToTime(a.tebligTarihi) - parseTrDateToTime(b.tebligTarihi))[0] ||
          tebligDetaylari[0];
        if (firstWithDate) {
          barcode = firstWithDate.barcode || null;
          barcodeSource = firstWithDate.barcodeSource || (firstWithDate.barcode ? "pdf" : null);
          barcodeEvrakId = firstWithDate.evrakId || null;
          tebligTarihi = firstWithDate.tebligTarihi || null;
          tebligYediGunSonrasi = firstWithDate.tebligYediGunSonrasi || null;
          fourthUrl = firstWithDate.fourthUrl || null;
        }
      }
    }

    return {
      thirdUrl,
      fourthUrl,
      dosyaKesinlesmeMs,
      tebligTarihi,
      tebligYediGunSonrasi,
      barcode,
      barcodeSource,
      barcodeEvrakId,
      pttUrl,
      borcaItirazSayisi,
      borcluSayisi,
      kesinlesenBorcluSayisi,
      belirsizItirazSayisi,
      itirazKontrolTarihi,
      tebligDetaylari,
      iadeDetaylari,
      iadeSayisi: iadeDetaylari.length,
      barcodeDebug
    };
  };

  window.__EWR_PR_QueryKesinlestirme = {
    collectTebligBilgileri,
    createBarcodeDebug
  };
})();

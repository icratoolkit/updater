(() => {
  const C = window.__EWR_PR_Core;
  if (!C) {
    console.error("query/progress.js: page-runner-core.js önce yüklenmeli.");
    return;
  }

  const { runState } = C;

  const setActiveStep = (inputValue, stepLabel) => {
    runState.activeInput = typeof inputValue === "object" ? String(inputValue.dosyaNo || "") : String(inputValue || "");
    runState.activeStepLabel = String(stepLabel || "");
  };

  const clearActiveStep = () => {
    runState.activeInput = "";
    runState.activeStepLabel = "";
  };

  const DOSYA_HESABI_PROGRESS_FIELDS = [
    "input",
    "talepTarihi",
    "tebligTarihi",
    "asilAlacak",
    "gecmisGunFaizi",
    "vekaletPulu",
    "tebligatGideri",
    "pesinHarc",
    "basvurmaHarci",
    "vekaletSuretHarci",
    "tahsilHarciHesap",
    "takipteKesinlesenMiktar",
    "vekaletUcretiDosyaHesap",
    "icraFaizTutari",
    "danismanlikUcreti",
    "toplamBorcHesap",
    "masrafToplami",
    "vazgecmeHesabi",
    "anaPara",
    "hakEdis",
    "indirimTutari",
    "indirimYeniAsilAlacak",
    "indirimYeniDanismanlikUcreti",
    "indirimliToplamBorc",
    "dosyaHesabiHesapTuru",
    "aracMahrumiyetBedeli",
    "aracMahrumiyetFaizi",
    "mahkemeVekaletUcreti",
    "mahkemeVekaletUcretiFaizi",
    "mahkemeYargilamaGiderleri",
    "mahkemeYargilamaGiderleriFaizi",
    "mahkemeHarclari",
    "mahkemeHarclariFaizi",
    "ygIcraFaiz",
    "harcIcraFaiz",
    "ivuIcraFaiz",
    "takibinTuruAciklama",
    "dosyaHesabiDebug"
  ];

  const TALEP_RUN_MODES = new Set(["talepMasrafAvansIadesi", "talepBorcluOdemeAktar", "talepEvrakiOlustur"]);

  const pickFields = (item, fields) => Object.fromEntries(fields.map((field) => [field, item[field]]));

  const selectMatchedForProgress = (items, runMode) => {
    if (runMode === "kesinlestirme") {
      return items
        .filter((item) => item.isMatch && Array.isArray(item.tebligDetaylari) && item.tebligDetaylari.length > 0)
        .map((item) => ({
          input: item.input,
          tebligDetaylari: item.tebligDetaylari.filter((detay) => !!detay.tebligTarihi)
        }));
    }

    if (runMode === "dosyaHesabi") {
      return items
        .filter((item) => item.isMatch && !!item.talepTarihi)
        .map((item) => pickFields(item, DOSYA_HESABI_PROGRESS_FIELDS));
    }

    if (runMode === "reddiyat") {
      return items
        .filter((item) => item.isMatch)
        .map((item) => ({ input: item.input, reddiyatKalemleri: item.reddiyatKalemleri }));
    }

    if (TALEP_RUN_MODES.has(runMode)) {
      return items
        .filter((item) => item.success || item.error)
        .map((item) => pickFields(item, ["input", "birimAdi", "success", "error", "message", "talepAdi"]));
    }

    return items
      .filter((item) => item.isMatch)
      .map((item) =>
        pickFields(item, ["input", "yatanPara", "reddiyatKalanMiktari", "kalanBorc", "kalanQueryThreshold"])
      );
  };

  const emitProgress = (requestId, total, items, runMode, stopped = false) => {
    const matched = selectMatchedForProgress(items, runMode);

    window.postMessage(
      {
        __EWR_PAGE_PROGRESS__: true,
        requestId,
        progress: {
          total,
          processed: items.length,
          matchCount: matched.length,
          barcodeCount: items.filter((item) => !!item.barcode).length,
          runMode,
          matched,
          stopped,
          activeInput: String(runState.activeInput || ""),
          activeStepLabel: String(runState.activeStepLabel || "")
        }
      },
      "*"
    );
  };

  window.__EWR_PR_QueryProgress = {
    clearActiveStep,
    emitProgress,
    selectMatchedForProgress,
    setActiveStep
  };
})();

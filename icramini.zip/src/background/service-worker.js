﻿const parseJsonSafe = (text) => {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
};

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.action !== "externalFetch") {
    return;
  }

  const url = String(message.url || "").trim();
  const method = String(message.method || "GET").toUpperCase();
  const headers = message.headers && typeof message.headers === "object" ? { ...message.headers } : {};
  const body = typeof message.body === "string" ? message.body : undefined;

  if (!url) {
    sendResponse({ ok: false, status: 0, text: null, json: null, error: "URL bos." });
    return;
  }

  delete headers.Origin;
  delete headers.origin;
  delete headers.Referer;
  delete headers.referer;

  fetch(url, {
    method,
    headers,
    body,
    credentials: "include",
    referrer: "https://www.ptt.gov.tr/"
  })
    .then(async (response) => {
      const text = await response.text();
      sendResponse({
        ok: response.ok,
        status: response.status,
        text,
        json: parseJsonSafe(text),
        error: null
      });
    })
    .catch((err) => {
      sendResponse({ ok: false, status: 0, text: null, json: null, error: String(err && err.message ? err.message : err) });
    });

  return true;
});

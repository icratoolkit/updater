(function () {
  "use strict";

  if (window.MiniIcraHesapClassifiers) {
    return;
  }

  const Normalizers = window.MiniIcraHesapNormalizers || {};
  const { buildCustomFaizKey, normalizeText, numberOrNull } = Normalizers;

  const MAHKEME_KALEM_ALANLARI = [
    "mahkemeVekaletUcreti",
    "mahkemeVekaletUcretiFaizi",
    "mahkemeYargilamaGiderleri",
    "mahkemeYargilamaGiderleriFaizi",
    "mahkemeHarclari",
    "mahkemeHarclariFaizi"
  ];

  // Takip talebinde mahkeme yargılama gideri, ilam vekalet ücreti veya mahkeme
  // harcı gibi bir kalem varsa dosya ilamlıdır. UYAP'tan gelen takip türü
  // açıklaması boş ya da yanlış geldiğinde bu kalemler ve faizleri toplam
  // borçtan düşmesin diye hesap tarafında ayrıca kontrol edilir.
  const hasMahkemeKalemi = (source) => {
    if (!source || typeof source !== "object") {
      return false;
    }
    return MAHKEME_KALEM_ALANLARI.some((field) => numberOrNull(source[field]) !== null);
  };

  const classifyTakipEntry = (desc) => {
    const normalized = normalizeText(desc);
    const isExplicitPrimaryGecmisGunFaizi =
      normalized === "gecmis gun faizi" || normalized.startsWith("gecmis gun faizi ");
    const hasExplicitFaizLabel =
      /\bfaizi\b/.test(normalized) ||
      /\bfaizidir\b/.test(normalized) ||
      ((normalized.includes("gecmis") || normalized.includes("islemis")) && normalized.includes("faiz"));
    const isFaiz = hasExplicitFaizLabel || isExplicitPrimaryGecmisGunFaizi;
    const hasMahrumAnahtar = normalized.includes("hak mahrum") || normalized.includes("arac mahrum");
    const hasDegerKaybiAnahtar = normalized.includes("deger kaybi");
    const hasKazancKaybiAnahtar = normalized.includes("kazanc kaybi");
    const hasIkameAracAnahtar = normalized.includes("ikame arac");
    const hasCekiciAnahtar = normalized.includes("cekici");
    const hasHasarAnahtar = normalized.includes("hasar");
    const hasMahrumAlacakEtiketi =
      normalized.includes("bedel") ||
      normalized.includes("tazminat") ||
      normalized.includes("tazminati") ||
      normalized.includes("zarar") ||
      normalized.includes("zarari") ||
      normalized.includes("alacagi") ||
      normalized.includes("alacag") ||
      normalized.includes("alacak");
    const isHakMahrum = normalized.includes("hak mahrum") && hasMahrumAlacakEtiketi && !isFaiz;
    const isAracMahrum = normalized.includes("arac mahrum") && hasMahrumAlacakEtiketi && !isFaiz;
    const isDegerKaybi = hasDegerKaybiAnahtar && hasMahrumAlacakEtiketi && !isFaiz;
    const isKazancKaybi = hasKazancKaybiAnahtar && hasMahrumAlacakEtiketi && !isFaiz;
    const isIkameArac = hasIkameAracAnahtar && hasMahrumAlacakEtiketi && !isFaiz;
    const isCekiciBedeli = hasCekiciAnahtar && hasMahrumAlacakEtiketi && !isFaiz;
    const isHasarBedeli = hasHasarAnahtar && hasMahrumAlacakEtiketi && !isFaiz;
    const isInkarTazminati = normalized.includes("inkar") && normalized.includes("tazminat") && !isFaiz;
    const isAsil = normalized.includes("asil alacak") && !isFaiz;
    const isToplam = normalized.includes("toplam") && normalized.includes("alacak");
    const hasGecmisFaiz = hasExplicitFaizLabel;

    let asilType = "";
    let field = "";

    if (isHakMahrum) {
      asilType = "hak_mahrum";
      field = "asilAlacak";
    } else if (isAracMahrum) {
      asilType = "arac_mahrum";
      field = "asilAlacak";
    } else if (isDegerKaybi) {
      asilType = "deger_kaybi";
      field = "asilAlacak";
    } else if (isKazancKaybi) {
      asilType = "kazanc_kaybi";
      field = "asilAlacak";
    } else if (isIkameArac) {
      asilType = "ikame_arac";
      field = "asilAlacak";
    } else if (isCekiciBedeli) {
      asilType = "cekici_bedeli";
      field = "asilAlacak";
    } else if (isHasarBedeli) {
      asilType = "hasar_bedeli";
      field = "asilAlacak";
    } else if (isInkarTazminati) {
      asilType = "inkar_tazminat";
      field = "asilAlacak";
    } else if (isAsil) {
      asilType = "asil_alacak";
      field = "asilAlacak";
    } else if (
      (hasMahrumAnahtar ||
        hasDegerKaybiAnahtar ||
        hasKazancKaybiAnahtar ||
        hasIkameAracAnahtar ||
        hasCekiciAnahtar ||
        hasHasarAnahtar) &&
      hasMahrumAlacakEtiketi
    ) {
      field = hasGecmisFaiz ? "gecmisGunFaizi" : "asilAlacak";
    } else if (
      (normalized.includes("vekalet") || normalized.includes("vekaelt")) &&
      normalized.includes("ucret") &&
      !normalized.includes("icra vekalet")
    ) {
      field = hasGecmisFaiz ? "mahkemeVekaletUcretiFaizi" : "mahkemeVekaletUcreti";
    } else if (normalized.includes("yargilama") && normalized.includes("gider")) {
      field = hasGecmisFaiz ? "mahkemeYargilamaGiderleriFaizi" : "mahkemeYargilamaGiderleri";
    } else if (normalized.includes("harc")) {
      field = hasGecmisFaiz ? "mahkemeHarclariFaizi" : "mahkemeHarclari";
    } else if (isToplam) {
      field = "toplamAlacak";
    } else if (isExplicitPrimaryGecmisGunFaizi) {
      field = "gecmisGunFaizi";
    } else if (isFaiz) {
      field = "gecmisGunFaizi";
    } else if (hasMahrumAlacakEtiketi) {
      // Bilinen türlere uymayan ama parasal etiketi (bedel/tazminat/alacak/zarar)
      // taşıyan asıl alacak kalemleri (ör. "BİRLEŞEN DAVA PERT FARKI BEDELİ")
      // kaybolmasın diye asıl alacağa yazılır.
      field = "asilAlacak";
    }

    return {
      normalized,
      isFaiz,
      asilType,
      field,
      customFaizKey: isAsil ? buildCustomFaizKey(normalized) : ""
    };
  };

  window.MiniIcraHesapClassifiers = {
    MAHKEME_KALEM_ALANLARI,
    classifyTakipEntry,
    hasMahkemeKalemi
  };
})();

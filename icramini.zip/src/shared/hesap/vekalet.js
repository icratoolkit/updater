(function () {
  "use strict";

  if (window.MiniIcraHesapVekalet) {
    return;
  }

  const Normalizers = window.MiniIcraHesapNormalizers || {};
  const { numberOrNull, sumNumericAmounts, truncateMoney } = Normalizers;

  // Avukatlık Asgari Ücret Tarifesi üçüncü kısım (nispi) dilimleri.
  // Türkiye Barolar Birliği hesaplama aracındaki dilim ve oranlarla aynıdır.
  const ICRA_MAKTU_VEKALET = 9000;
  const ICRA_NISPI_DILIMLER = [
    { limit: 600000, oran: 0.16 },
    { limit: 600000, oran: 0.15 },
    { limit: 1200000, oran: 0.14 },
    { limit: 1200000, oran: 0.13 },
    { limit: 1800000, oran: 0.11 },
    { limit: 2400000, oran: 0.08 },
    { limit: 3000000, oran: 0.05 },
    { limit: 3600000, oran: 0.03 },
    { limit: 4200000, oran: 0.02 },
    { limit: Infinity, oran: 0.01 }
  ];

  // Nispi tarife: dilim dilim hesaplanır, maktu ücretin altına inemez ve
  // takip tutarını aşamaz.
  const calculateIcraNispiVekalet = (amount) => {
    const takipTutari = Math.max(0, numberOrNull(amount) ?? 0);
    if (!takipTutari) {
      return 0;
    }

    let remaining = takipTutari;
    let calculated = 0;
    for (const dilim of ICRA_NISPI_DILIMLER) {
      if (remaining <= 0) {
        break;
      }
      const slice = dilim.limit === Infinity ? remaining : Math.min(remaining, dilim.limit);
      calculated += slice * dilim.oran;
      remaining -= slice;
    }

    return Math.min(Math.max(calculated, ICRA_MAKTU_VEKALET), takipTutari);
  };

  // Nispi tarifenin uygulandığı taban: takip talebindeki kalemler.
  // Takip sonrası işleyen icra faizleri bu tabana girmez.
  const calculateTakipTutari = (row) =>
    sumNumericAmounts([
      row && row.asilAlacak,
      row && row.gecmisGunFaizi,
      row && row.mahkemeYargilamaGiderleri,
      row && row.mahkemeYargilamaGiderleriFaizi,
      row && row.mahkemeHarclari,
      row && row.mahkemeHarclariFaizi,
      row && row.mahkemeVekaletUcreti,
      row && row.mahkemeVekaletUcretiFaizi
    ]);

  // Dosya kesinleşmişse tarifenin tamamı (4/4), kesinleşmemişse 3/4'ü istenir.
  const getKesinlesmeCarpani = (kesinlesti) => (kesinlesti ? 1 : 0.75);

  // İlamlı takipte nispi tarife uygulanır. İlamsız takipte icra vekalet ücreti
  // maktu tutarı (9.000 TL) aşamaz; asıl alacak bundan düşükse onunla sınırlıdır.
  const computeIcraVekaletUcreti = (row, options) => {
    const isIlamli = !!(options && options.isIlamli);
    const carpan = getKesinlesmeCarpani(options && options.kesinlesti);

    if (!isIlamli) {
      const asilAlacak = numberOrNull(row && row.asilAlacak);
      if (asilAlacak === null) {
        return null;
      }
      return truncateMoney(Math.min(asilAlacak, ICRA_MAKTU_VEKALET) * carpan);
    }

    const takipTutari = calculateTakipTutari(row);
    if (takipTutari === null) {
      return null;
    }
    return truncateMoney(calculateIcraNispiVekalet(takipTutari) * carpan);
  };

  // İcra vekalet ücretini hesap tarihine göre çözer. UYAP'ın dosya_hesap_bilgileri
  // isteği "Vekalet Ücreti"ni yalnızca BUGÜN itibarıyla verir; ileri/geri tarihli
  // hesapta bu değer dosyanın o tarihteki kesinleşme durumunu yansıtmaz.
  //  - Hesap tarihi bugünse: UYAP değeri birebir kullanılır (kendi kestirimimize
  //    gerek yok; en güvenilir kaynak odur).
  //  - Diğer tarihlerde: kesinleşme tarihine göre 4/4 veya 3/4 tarife seçilir.
  //    Bugünkü kesinleşme gerçeği, mümkünse UYAP değerinin hangi tarifeye eşit
  //    olduğuna bakılarak (çıpa) belirlenir.
  // Dönen nesne: { value, uyari }. `uyari`, kesinleşme tarihi bilinmeden geri
  // tarihli hesapta 4/4'e düşüldüğünde doldurulur.
  const resolveIcraVekaletUcreti = (row, options) => {
    const opts = options || {};
    const isIlamli = !!opts.isIlamli;
    const odemeMs = Number(opts.odemeMs) || 0;
    const bugunMs = Number(opts.bugunMs) || 0;
    const kesinlesmeMs = Number(opts.kesinlesmeMs) || 0;
    const uyap = numberOrNull(opts.uyapBugunValue);

    const uc34 = computeIcraVekaletUcreti(row, { isIlamli, kesinlesti: false });
    const tam44 = computeIcraVekaletUcreti(row, { isIlamli, kesinlesti: true });

    // Ödeme tarihi verilmemişse "bugün" varsayılır.
    const hesapMs = odemeMs > 0 ? odemeMs : bugunMs;

    // Hesap tarihi bugünse UYAP'ın dosya hesabındaki değerini esas al.
    if (uyap !== null && bugunMs > 0 && hesapMs === bugunMs) {
      return { value: uyap, uyari: null };
    }

    // Kendi hesabımızı üretemiyorsak (ör. asıl alacak yok) UYAP değerine düşülür.
    if (uc34 === null && tam44 === null) {
      return { value: uyap, uyari: null };
    }

    // Bugünkü kesinleşme gerçeği: mümkünse UYAP değeri hangi tarifeye eşitse ondan,
    // UYAP yoksa kesinleşme tarihi kestiriminden.
    let bugunKesinlesmis;
    if (uyap !== null && uc34 !== null && tam44 !== null) {
      bugunKesinlesmis = Math.abs(uyap - tam44) <= Math.abs(uyap - uc34);
    } else {
      bugunKesinlesmis = kesinlesmeMs > 0 && bugunMs > 0 && bugunMs >= kesinlesmeMs;
    }

    let hesapKesinlesmis;
    let uyari = null;
    if (kesinlesmeMs > 0) {
      hesapKesinlesmis = hesapMs > 0 && hesapMs >= kesinlesmeMs;
    } else if (bugunKesinlesmis) {
      if (hesapMs >= bugunMs) {
        // Bugün/ileri: dosya bugün kesinleşmişse ileri tarihte de kesinleşmiştir.
        hesapKesinlesmis = true;
      } else {
        // Geri tarih + kesinleşme tarihi bilinmiyor: 4/4'ten al ama uyar.
        hesapKesinlesmis = true;
        uyari = "Kesinleşme tarihi belirlenemedi; geri tarihli İcra Vekalet Ücreti 4/4 tarifeden alındı.";
      }
    } else {
      hesapKesinlesmis = false;
    }

    const secilen = hesapKesinlesmis ? tam44 : uc34;
    return { value: secilen !== null ? secilen : uyap, uyari };
  };

  window.MiniIcraHesapVekalet = {
    ICRA_MAKTU_VEKALET,
    ICRA_NISPI_DILIMLER,
    calculateIcraNispiVekalet,
    calculateTakipTutari,
    computeIcraVekaletUcreti,
    resolveIcraVekaletUcreti,
    getKesinlesmeCarpani,
    truncateMoney
  };
})();

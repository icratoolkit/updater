(function () {
  "use strict";

  if (window.MiniIcraHesapExtractors) {
    return;
  }

  const Normalizers = window.MiniIcraHesapNormalizers || {};
  const Classifiers = window.MiniIcraHesapClassifiers || {};
  const Scoring = window.MiniIcraHesapScoring || {};
  const { addAmount, fixMojibake, fixMojibakeMultiline, normalizeText, numberOrNull, sumNumericAmounts } = Normalizers;
  const { classifyTakipEntry } = Classifiers;
  const { getTakipParseQualityScore } = Scoring;

  const parseStructuredEntriesFromXml = (xmlText) => {
    const rows = String(xmlText || "").match(/<rowXbXb[\s\S]*?<\/rowXbXb>/gi) || [];
    const entries = [];

    for (const row of rows) {
      const amountRaw = (
        (row.match(
          /<takipTalebiDortMaddeAlacaginTlOlarakKarsiligiFaizMiktari>([\s\S]*?)<\/takipTalebiDortMaddeAlacaginTlOlarakKarsiligiFaizMiktari>/i
        ) || [])[1] || ""
      ).trim();
      const descRaw = (
        (row.match(/<faizinIslemeyeBasladigiGun>([\s\S]*?)<\/faizinIslemeyeBasladigiGun>/i) || [])[1] || ""
      ).trim();
      const amount = numberOrNull(amountRaw);
      const desc = normalizeText(descRaw);
      if (amount === null || !desc) {
        continue;
      }
      entries.push({ amount, desc, source: "structured" });
    }

    return entries;
  };

  const parseFieldEntriesFromXml = (xmlText) => {
    const entries = [];
    const pairRegex =
      /<takipTalebiDortMaddeAlacaginTlOlarakKarsiligiFaizMiktari>([\s\S]*?)<\/takipTalebiDortMaddeAlacaginTlOlarakKarsiligiFaizMiktari>[\s\S]*?<faizinIslemeyeBasladigiGun>([\s\S]*?)<\/faizinIslemeyeBasladigiGun>/gi;
    let match;

    while ((match = pairRegex.exec(String(xmlText || ""))) !== null) {
      const amount = numberOrNull((match[1] || "").trim());
      const desc = normalizeText((match[2] || "").trim());
      if (amount === null || !desc) {
        continue;
      }
      entries.push({ amount, desc, source: "field-pair" });
    }

    return entries;
  };

  const extractCdataText = (xmlText) => {
    const match = String(xmlText || "").match(/<content><!\[CDATA\[([\s\S]*?)\]\]>\s*<\/content>/i);
    return match ? fixMojibakeMultiline(match[1]) : "";
  };

  const isAlacakSectionHeader = (line) => {
    const raw = fixMojibake(line || "").toLocaleLowerCase("tr-TR");
    if (!/^\d+\s*[-.):]/.test(raw)) {
      return false;
    }
    const hasAlacakKeyword = raw.includes("alacağ") || raw.includes("alacag") || raw.includes("teminat");
    const hasAmountKeyword =
      raw.includes("tutar") || raw.includes("faiz") || raw.includes("miktar") || raw.includes("kur");
    return hasAlacakKeyword && hasAmountKeyword;
  };

  const isNextNumberedSectionHeader = (line) => {
    const raw = fixMojibake(line || "").toLocaleLowerCase("tr-TR");
    return /^\d+\s*[-.):]\s*\S/.test(raw) && raw.length > 15;
  };

  const isTakipUcuncuMaddeHeader = isAlacakSectionHeader;

  const isTakipDorduncuMaddeHeader = (line) => {
    if (isAlacakSectionHeader(line)) {
      return false;
    }
    return isNextNumberedSectionHeader(line);
  };

  const extractNarrativeSection = (xmlText) => {
    const cdataText = extractCdataText(xmlText);
    if (!cdataText) {
      return "";
    }

    const lines = cdataText
      .split(/\r?\n/)
      .map((line) => String(line || "").trim())
      .filter(Boolean);

    let startIndex = -1;
    let endIndex = lines.length;

    for (let index = 0; index < lines.length; index += 1) {
      if (startIndex === -1 && isTakipUcuncuMaddeHeader(lines[index])) {
        startIndex = index + 1;
        continue;
      }
      if (startIndex !== -1 && isTakipDorduncuMaddeHeader(lines[index])) {
        endIndex = index;
        break;
      }
    }

    if (startIndex === -1) {
      return "";
    }

    return lines.slice(startIndex, endIndex).join("\n");
  };

  const stripTlPrefix = (line) =>
    String(line || "")
      .replace(/^TL\s+/i, "")
      .trim();

  const isSkippableLine = (line) => {
    const stripped = String(line || "").trim();
    if (stripped === ":" || stripped === "-" || stripped === "") {
      return true;
    }
    if (/^[A-ZÇĞİÖŞÜ\s,]+$/.test(stripped) && !/\d/.test(stripped) && stripped.length < 120) {
      return true;
    }
    return false;
  };

  const parseNarrativeLines = (sectionText, sourceBase) => {
    const lines = String(sectionText || "")
      .split(/\r?\n/)
      .map((line) => fixMojibake(line).replace(/\s+/g, " ").trim())
      .filter(Boolean);

    const entries = [];
    let pendingAmount = null;

    const tryParseStandaloneAmount = (line) => {
      const match = line.match(/^(\d[\d.\s]*,\d{2}|\d[\d.\s]*)\s*(?:TL)?\s*$/);
      return match ? numberOrNull(match[1]) : null;
    };

    const tryParseLeadingAmountWithDesc = (line) => {
      const match = line.match(/^(\d[\d.\s]*,\d{2})\s*TL\s+(.+)$/i);
      if (!match) {
        return null;
      }
      const amount = numberOrNull(match[1]);
      const desc = normalizeText(match[2]);
      return amount !== null && desc ? { amount, desc } : null;
    };

    const tryParseLabelColonAmount = (line) => {
      const match = line.match(/^(.+?)\s*[:]\s*(\d[\d.\s]*,\d{2})\s*(?:TL)?\s*$/i);
      if (!match) {
        return null;
      }
      const desc = normalizeText(match[1]);
      const amount = numberOrNull(match[2]);
      return amount !== null && desc ? { amount, desc } : null;
    };

    const tryParseInlineAmount = (line) => {
      const match = line.match(/(\d[\d.\s]*,\d{2}|\d[\d.\s]*)\s*(?:TL)?\s*$/i);
      return match ? numberOrNull(match[1]) : null;
    };

    const stripTrailingAmount = (line) =>
      line
        .replace(/(\d[\d.\s]*,\d{2}|\d[\d.\s]*)\s*(?:TL)?\s*$/i, "")
        .replace(/[.:;,]+$/g, "")
        .trim();

    for (const line of lines) {
      if (isSkippableLine(line)) {
        continue;
      }

      const standaloneAmount = tryParseStandaloneAmount(line);
      if (standaloneAmount !== null) {
        pendingAmount = standaloneAmount;
        continue;
      }

      if (pendingAmount !== null) {
        const desc = normalizeText(stripTlPrefix(line));
        if (desc) {
          entries.push({ amount: pendingAmount, desc, source: sourceBase });
          pendingAmount = null;
          continue;
        }
      }

      const leadingParsed = tryParseLeadingAmountWithDesc(line);
      if (leadingParsed) {
        entries.push({ amount: leadingParsed.amount, desc: leadingParsed.desc, source: `${sourceBase}-leading` });
        continue;
      }

      const labelColonParsed = tryParseLabelColonAmount(line);
      if (labelColonParsed) {
        entries.push({ amount: labelColonParsed.amount, desc: labelColonParsed.desc, source: `${sourceBase}-label` });
        continue;
      }

      const inlineAmount = tryParseInlineAmount(line);
      if (inlineAmount === null) {
        continue;
      }

      const desc = normalizeText(stripTrailingAmount(line));
      if (!desc) {
        continue;
      }
      entries.push({ amount: inlineAmount, desc, source: `${sourceBase}-inline` });
    }

    return entries;
  };

  const parseNarrativeEntriesFromXml = (xmlText) => parseNarrativeLines(extractNarrativeSection(xmlText), "cdata");

  const extractNarrativeSectionFromPlainText = (inputText) => {
    const raw = fixMojibakeMultiline(inputText || "");
    if (!raw) {
      return "";
    }

    const lines = raw
      .split(/\r?\n/)
      .map((line) => String(line || "").trim())
      .filter(Boolean);

    let startIndex = -1;
    let endIndex = lines.length;

    for (let index = 0; index < lines.length; index += 1) {
      if (startIndex === -1 && isTakipUcuncuMaddeHeader(lines[index])) {
        startIndex = index + 1;
        continue;
      }
      if (startIndex !== -1 && isTakipDorduncuMaddeHeader(lines[index])) {
        endIndex = index;
        break;
      }
    }

    if (startIndex === -1) {
      return "";
    }

    return lines.slice(startIndex, endIndex).join("\n");
  };

  const parseNarrativeEntriesFromPlainText = (inputText) =>
    parseNarrativeLines(extractNarrativeSectionFromPlainText(inputText), "plain-text");

  const isGenericPrimaryFaizCandidate = (desc) => {
    const normalizedDesc = normalizeText(desc);
    if (!normalizedDesc || !normalizedDesc.includes("faiz")) {
      return false;
    }
    if (normalizedDesc === "gecmis gun faizi" || normalizedDesc.startsWith("gecmis gun faizi ")) {
      return true;
    }
    if (
      normalizedDesc.includes("vekalet") ||
      normalizedDesc.includes("yargilama") ||
      normalizedDesc.includes("gider") ||
      normalizedDesc.includes("harc")
    ) {
      return false;
    }
    return (
      normalizedDesc === "faiz" ||
      normalizedDesc === "faizi" ||
      normalizedDesc.includes("gecmis gun faizi") ||
      normalizedDesc.includes("islemis faiz") ||
      normalizedDesc.includes("gecmis faiz")
    );
  };

  const aggregateTakipEntries = (entries) => {
    const result = {
      asilAlacak: null,
      gecmisGunFaizi: null,
      toplamAlacak: null,
      entries: [],
      aracMahrumiyetBedeli: null,
      aracMahrumiyetFaizi: null,
      mahkemeVekaletUcreti: null,
      mahkemeVekaletUcretiFaizi: null,
      mahkemeYargilamaGiderleri: null,
      mahkemeYargilamaGiderleriFaizi: null,
      mahkemeHarclari: null,
      mahkemeHarclariFaizi: null
    };
    let asilBedelType = "";
    let asilCustomFaizKey = "";
    let hasPrimaryDebtContext = false;
    const faizCandidates = [];

    for (const entry of Array.isArray(entries) ? entries : []) {
      const amount = numberOrNull(entry && entry.amount);
      const desc = normalizeText(entry && entry.desc);
      if (amount === null || !desc) {
        continue;
      }

      const classification = classifyTakipEntry(desc);
      result.entries.push({ amount, desc, source: entry.source || "unknown" });

      if (classification.field === "asilAlacak") {
        hasPrimaryDebtContext = true;
        result.asilAlacak = addAmount(result.asilAlacak, amount);
        if (classification.asilType && classification.asilType !== "asil_alacak") {
          asilBedelType = classification.asilType;
        }
        if (classification.customFaizKey) {
          asilCustomFaizKey = classification.customFaizKey;
        }
      } else if (classification.field === "toplamAlacak") {
        result.toplamAlacak = addAmount(result.toplamAlacak, amount);
      } else if (classification.field) {
        result[classification.field] = addAmount(result[classification.field], amount);
      }

      if (classification.isFaiz) {
        faizCandidates.push({ amount, desc });
      }

      if (
        classification.asilType === "hak_mahrum" ||
        classification.asilType === "arac_mahrum" ||
        classification.asilType === "deger_kaybi" ||
        classification.asilType === "kazanc_kaybi" ||
        classification.asilType === "ikame_arac" ||
        classification.asilType === "cekici_bedeli" ||
        classification.asilType === "hasar_bedeli"
      ) {
        result.aracMahrumiyetBedeli = addAmount(result.aracMahrumiyetBedeli, amount);
      }
      if (
        classification.isFaiz &&
        (desc.includes("hak mahrum") ||
          desc.includes("arac mahrum") ||
          desc.includes("deger kaybi") ||
          desc.includes("kazanc kaybi") ||
          desc.includes("ikame arac") ||
          desc.includes("cekici") ||
          desc.includes("hasar"))
      ) {
        result.aracMahrumiyetFaizi = addAmount(result.aracMahrumiyetFaizi, amount);
      }
    }

    if (
      result.gecmisGunFaizi === null &&
      faizCandidates.length > 0 &&
      (hasPrimaryDebtContext || !!asilBedelType || !!asilCustomFaizKey)
    ) {
      const explicitPrimaryFaizCandidates = faizCandidates.filter((candidate) => {
        const normalizedDesc = normalizeText(candidate.desc);
        return normalizedDesc === "gecmis gun faizi" || normalizedDesc.startsWith("gecmis gun faizi ");
      });
      if (explicitPrimaryFaizCandidates.length > 0) {
        result.gecmisGunFaizi = sumNumericAmounts(explicitPrimaryFaizCandidates.map((candidate) => candidate.amount));
        return result;
      }

      let matchedFaizCandidates = faizCandidates.filter((candidate) => {
        if (asilBedelType === "hak_mahrum") {
          return candidate.desc.includes("hak mahrum");
        }
        if (asilBedelType === "arac_mahrum") {
          return candidate.desc.includes("arac mahrum");
        }
        if (asilBedelType === "deger_kaybi") {
          return candidate.desc.includes("deger kaybi");
        }
        if (asilBedelType === "kazanc_kaybi") {
          return candidate.desc.includes("kazanc kaybi");
        }
        if (asilBedelType === "ikame_arac") {
          return candidate.desc.includes("ikame arac");
        }
        if (asilBedelType === "cekici_bedeli") {
          return candidate.desc.includes("cekici");
        }
        if (asilBedelType === "hasar_bedeli") {
          return candidate.desc.includes("hasar");
        }
        if (asilBedelType === "inkar_tazminat") {
          return candidate.desc.includes("inkar") && candidate.desc.includes("tazminat");
        }
        if (asilCustomFaizKey) {
          return candidate.desc.includes(asilCustomFaizKey);
        }
        return true;
      });
      if (matchedFaizCandidates.length === 0) {
        matchedFaizCandidates = faizCandidates.filter((candidate) => isGenericPrimaryFaizCandidate(candidate.desc));
      }
      result.gecmisGunFaizi = sumNumericAmounts(matchedFaizCandidates.map((candidate) => candidate.amount));
    }

    if (
      result.asilAlacak === null &&
      result.toplamAlacak !== null &&
      result.gecmisGunFaizi !== null &&
      (hasPrimaryDebtContext || !!asilBedelType || !!asilCustomFaizKey)
    ) {
      result.asilAlacak = Number((result.toplamAlacak - result.gecmisGunFaizi).toFixed(2));
    }

    return result;
  };

  const pickBestAggregated = (candidates) => {
    let best = null;
    let bestScore = -1;

    for (const candidate of Array.isArray(candidates) ? candidates : []) {
      const score = getTakipParseQualityScore(candidate);
      if (score > bestScore) {
        best = candidate;
        bestScore = score;
      }
    }

    return best;
  };

  const extractTakipTalebiAmountsFromContentXml = (xmlText) => {
    const candidates = [];
    const structuredEntries = parseStructuredEntriesFromXml(xmlText);
    const fieldEntries = parseFieldEntriesFromXml(xmlText);
    const narrativeEntries = parseNarrativeEntriesFromXml(xmlText);

    if (structuredEntries.length > 0) {
      candidates.push(aggregateTakipEntries(structuredEntries));
    }
    if (fieldEntries.length > 0) {
      candidates.push(aggregateTakipEntries(fieldEntries));
    }
    if (narrativeEntries.length > 0) {
      candidates.push(aggregateTakipEntries(narrativeEntries));
    }

    return pickBestAggregated(candidates) || aggregateTakipEntries([]);
  };

  window.MiniIcraHesapExtractors = {
    aggregateTakipEntries,
    extractCdataText,
    extractNarrativeSection,
    extractNarrativeSectionFromPlainText,
    extractTakipTalebiAmountsFromContentXml,
    isAlacakSectionHeader,
    isNextNumberedSectionHeader,
    isTakipDorduncuMaddeHeader,
    isTakipUcuncuMaddeHeader,
    parseFieldEntriesFromXml,
    parseNarrativeEntriesFromPlainText,
    parseNarrativeEntriesFromXml,
    parseStructuredEntriesFromXml
  };
})();

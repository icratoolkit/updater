(function () {
  "use strict";

  if (window.MiniIcraHesapScoring) {
    return;
  }

  const Normalizers = window.MiniIcraHesapNormalizers || {};
  const { numberOrNull } = Normalizers;

  const getTakipParseQualityScore = (parsed) => {
    if (!parsed || typeof parsed !== "object") {
      return -1;
    }

    let score = 0;
    if (numberOrNull(parsed.asilAlacak) !== null) {
      score += 5;
    }
    if (numberOrNull(parsed.gecmisGunFaizi) !== null) {
      score += 5;
    }
    if (numberOrNull(parsed.toplamAlacak) !== null) {
      score += 2;
    }
    if (numberOrNull(parsed.aracMahrumiyetBedeli) !== null) {
      score += 2;
    }
    if (numberOrNull(parsed.aracMahrumiyetFaizi) !== null) {
      score += 2;
    }
    if (numberOrNull(parsed.mahkemeYargilamaGiderleri) !== null) {
      score += 1;
    }
    if (numberOrNull(parsed.mahkemeHarclari) !== null) {
      score += 1;
    }
    if (numberOrNull(parsed.mahkemeVekaletUcreti) !== null) {
      score += 1;
    }
    if (Array.isArray(parsed.entries)) {
      score += Math.min(parsed.entries.length, 6);
    }

    return score;
  };

  window.MiniIcraHesapScoring = {
    getTakipParseQualityScore
  };
})();

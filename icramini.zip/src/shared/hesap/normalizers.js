(function () {
  "use strict";

  if (window.MiniIcraHesapNormalizers) {
    return;
  }

  const TextUtils = window.MiniIcraTextUtils || {};
  const fixMojibake =
    typeof TextUtils.fixMojibake === "function" ? TextUtils.fixMojibake : ((value) => String(value || ""));
  const normalizeText =
    typeof TextUtils.normalizeText === "function"
      ? TextUtils.normalizeText
      : ((value) =>
          fixMojibake(value)
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .toLocaleLowerCase("tr-TR")
            .replace(/ı/g, "i")
            .replace(/ğ/g, "g")
            .replace(/ş/g, "s")
            .replace(/ç/g, "c")
            .replace(/ö/g, "o")
            .replace(/ü/g, "u")
            .replace(/\s+/g, " ")
            .trim());

  const numberOrNull = (value) => {
    if (value === null || typeof value === "undefined") {
      return null;
    }
    if (typeof value === "number") {
      return Number.isFinite(value) ? Number(value.toFixed(2)) : null;
    }

    const raw = String(value).trim();
    if (!raw || raw === "-") {
      return null;
    }

    const normalized = raw
      .replace(/\s+/g, "")
      .replace(/\.(?=\d{3}(?:\D|$))/g, "")
      .replace(",", ".");
    const parsed = Number(normalized);
    return Number.isFinite(parsed) ? Number(parsed.toFixed(2)) : null;
  };

  const sumNumericAmounts = (values) => {
    const nums = (Array.isArray(values) ? values : []).map(numberOrNull).filter((x) => x !== null);
    if (nums.length === 0) {
      return null;
    }
    return Number(nums.reduce((acc, x) => acc + x, 0).toFixed(2));
  };

  const addAmount = (currentValue, nextValue) => {
    const current = numberOrNull(currentValue);
    const next = numberOrNull(nextValue);
    if (next === null) {
      return current;
    }
    if (current === null) {
      return next;
    }
    return Number((current + next).toFixed(2));
  };

  const buildCustomFaizKey = (desc) =>
    String(desc || "")
      .replace(/\([^)]*\)/g, " ")
      .replace(/\b(?:tl|istenen|yillik|adi|kanuni|faiz|gecmis|gun|islemis|bedel|tazminat|tazminati|alacagi|alacag|alacak)\b/g, " ")
      .replace(/\s+/g, " ")
      .trim();

  const fixMojibakeMultiline = (value) =>
    String(value || "")
      .replace(/\r\n/g, "\n")
      .split("\n")
      .map((line) => fixMojibake(line))
      .join("\n");

  window.MiniIcraHesapNormalizers = {
    addAmount,
    buildCustomFaizKey,
    fixMojibake,
    fixMojibakeMultiline,
    normalizeText,
    numberOrNull,
    sumNumericAmounts
  };
})();

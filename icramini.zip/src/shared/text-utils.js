(function () {
  "use strict";

  if (window.MiniIcraTextUtils) {
    return;
  }

  const CP1252_UNICODE_TO_BYTE = {
    "\u20AC": 0x80,
    "\u201A": 0x82,
    "\u0192": 0x83,
    "\u201E": 0x84,
    "\u2026": 0x85,
    "\u2020": 0x86,
    "\u2021": 0x87,
    "\u02C6": 0x88,
    "\u2030": 0x89,
    "\u0160": 0x8a,
    "\u2039": 0x8b,
    "\u0152": 0x8c,
    "\u017D": 0x8e,
    "\u2018": 0x91,
    "\u2019": 0x92,
    "\u201C": 0x93,
    "\u201D": 0x94,
    "\u2022": 0x95,
    "\u2013": 0x96,
    "\u2014": 0x97,
    "\u02DC": 0x98,
    "\u2122": 0x99,
    "\u0161": 0x9a,
    "\u203A": 0x9b,
    "\u0153": 0x9c,
    "\u017E": 0x9e,
    "\u0178": 0x9f
  };

  const sanitizeText = (value) =>
    String(value || "")
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, " ")
      .replace(/\s+/g, " ")
      .trim();

  const decodeUtf16LeMojibake = (value) => {
    const s = String(value || "");
    if (!/[\u0000-\u001F]/.test(s)) {
      return s;
    }
    const bytes = [];
    for (const ch of s) {
      const code = ch.charCodeAt(0);
      if (code > 0xff) {
        return s;
      }
      bytes.push(code);
    }
    if (bytes.length < 4 || bytes.length % 2 !== 0) {
      return s;
    }

    let odd01 = 0;
    for (let i = 1; i < bytes.length; i += 2) {
      if (bytes[i] === 0x00 || bytes[i] === 0x01) {
        odd01 += 1;
      }
    }
    const ratio = odd01 / Math.max(1, Math.floor(bytes.length / 2));
    if (ratio < 0.25) {
      return s;
    }

    try {
      const decoded = new TextDecoder("utf-16le", { fatal: false }).decode(Uint8Array.from(bytes));
      return decoded || s;
    } catch {
      return s;
    }
  };

  const decodeUtf8Mojibake = (value) => {
    let s = String(value || "");
    for (let pass = 0; pass < 2; pass += 1) {
      if (!/[ÃÄÅâ]/.test(s)) {
        break;
      }
      const bytes = [];
      let ok = true;
      for (const ch of s) {
        const code = ch.charCodeAt(0);
        if (code <= 0xff) {
          bytes.push(code);
          continue;
        }
        if (Object.prototype.hasOwnProperty.call(CP1252_UNICODE_TO_BYTE, ch)) {
          bytes.push(CP1252_UNICODE_TO_BYTE[ch]);
          continue;
        }
        ok = false;
        break;
      }
      if (!ok) {
        break;
      }
      try {
        const decoded = new TextDecoder("utf-8", { fatal: false }).decode(Uint8Array.from(bytes));
        if (!decoded || decoded === s) {
          break;
        }
        s = decoded;
      } catch {
        break;
      }
    }
    return decodeUtf16LeMojibake(s);
  };

  const fixMojibake = (value) =>
    sanitizeText(
      decodeUtf8Mojibake(value)
        .replace(/Ä°/g, "İ")
        .replace(/Ý/g, "İ")
        .replace(/ý/g, "ı")
        .replace(/Ð/g, "Ğ")
        .replace(/ð/g, "ğ")
        // ISO-8859-9 baytları latin1 olarak çözülünce Ş/ş de bozuluyor. Bunlar eksik
        // olduğu için PDF'ten okunan "İNÞAAT", UYAP'tan gelen "İNŞAAT" ile eşleşmiyor
        // ve aynı borçlu iki ayrı kişi sayılabiliyordu.
        .replace(/Þ/g, "Ş")
        .replace(/þ/g, "ş")
        .replace(/ÄŸ/g, "ğ")
        .replace(/Ã¼/g, "ü")
        .replace(/Ã‡/g, "Ç")
        .replace(/Ãœ/g, "Ü")
        .replace(/Ã–/g, "Ö")
        .replace(/Åž/g, "Ş")
    );

  const normalizeText = (value) =>
    fixMojibake(value)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLocaleLowerCase("tr-TR")
      .replace(/ı/g, "i")
      .replace(/ğ/g, "g")
      .replace(/ş/g, "s")
      .replace(/ç/g, "c")
      .replace(/ö/g, "o")
      .replace(/ü/g, "u")
      .replace(/\s+/g, " ")
      .trim();

  const normalizeKey = (value) => normalizeText(value).replace(/[^a-z0-9]/g, "");

  const parseTrDateToTime = (value) => {
    const s = String(value || "").trim();
    const m = s.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (!m) {
      return 0;
    }
    return Date.UTC(Number(m[3]), Number(m[2]) - 1, Number(m[1]));
  };

  const formatAmount2 = (value) => {
    const n = Number(value);
    if (!Number.isFinite(n)) {
      return String(value ?? "");
    }
    return n.toFixed(2);
  };

  window.MiniIcraTextUtils = {
    sanitizeText,
    decodeUtf16LeMojibake,
    decodeUtf8Mojibake,
    fixMojibake,
    normalizeText,
    normalizeKey,
    parseTrDateToTime,
    formatAmount2
  };
})();

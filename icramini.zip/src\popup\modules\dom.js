(function () {
  "use strict";

  if (window.MiniIcraPopupDom) {
    return;
  }

  const getById = (id) => document.getElementById(id);

  const getPopupElements = () => ({
    inputs: getById("inputs"),
    firstEndpointPath: getById("firstEndpointPath"),
    firstMethod: getById("firstMethod"),
    firstHeadersText: getById("firstHeadersText"),
    firstBodyTemplate: getById("firstBodyTemplate"),
    secondEndpointPath: getById("secondEndpointPath"),
    secondMethod: getById("secondMethod"),
    secondHeadersText: getById("secondHeadersText"),
    secondBodyTemplate: getById("secondBodyTemplate"),
    defaultBirimId: getById("defaultBirimId"),
    defaultBirimAdi: getById("defaultBirimAdi"),
    defaultDosyaDurum: getById("defaultDosyaDurum"),
    dosyaHesabiOdemeTarihi: getById("dosyaHesabiOdemeTarihi"),
    dosyaHesabiHesapTuru: getById("dosyaHesabiHesapTuru"),
    dosyaHesabiDosyaDurumKod: getById("dosyaHesabiDosyaDurumKod"),
    dosyaHesabiIndirimTutari: getById("dosyaHesabiIndirimTutari"),
    faizOranDusuk: getById("faizOranDusuk"),
    faizOranYuksek: getById("faizOranYuksek"),
    faizBolunmeTarihi: getById("faizBolunmeTarihi"),
    dosyaIndirimWrap: getById("dosyaIndirimWrap"),
    status: getById("status"),
    matched: getById("matched"),
    tabQuery: getById("tabQuery"),
    tabDosya: getById("tabDosya"),
    tabTalep: getById("tabTalep"),
    queryPanel: getById("queryPanel"),
    dosyaPanel: getById("dosyaPanel"),
    talepPanel: getById("talepPanel"),
    runMode: getById("runMode"),
    datedFilter: getById("datedFilter"),
    datedCustomRange: getById("datedCustomRange"),
    datedFrom: getById("datedFrom"),
    datedTo: getById("datedTo"),
    kalanQueryWrap: getById("kalanQueryWrap"),
    kalanQueryAmount: getById("kalanQueryAmount"),
    runBtn: getById("runBtn"),
    talepType: getById("talepType"),
    talepIbanNo: getById("talepIbanNo"),
    talepRunBtn: getById("talepRunBtn"),
    dosyaRunBtn: getById("dosyaRunBtn"),
    dosyaTakipUpload: getById("dosyaTakipUpload"),
    dosyaTakipUploadBtn: getById("dosyaTakipUploadBtn"),
    stopBtn: getById("stopBtn"),
    saveBtn: getById("saveBtn"),
    exportBtn: getById("exportBtn"),
    clearBtn: getById("clearBtn"),
    themeToggle: getById("themeToggle"),
    helpBtn: getById("helpBtn"),
    docsPanel: getById("docsPanel"),
    docsCloseBtn: getById("docsCloseBtn"),
    docsContent: getById("docsContent"),
    updateNotice: getById("updateNotice"),
    updateNoticeText: getById("updateNoticeText"),
    updateNoticeClose: getById("updateNoticeClose"),
    rowCount: getById("rowCount"),
    progressWrap: getById("progressWrap"),
    progressFill: getById("progressFill"),
    progressText: getById("progressText")
  });

  window.MiniIcraPopupDom = {
    getPopupElements
  };
})();

@echo off
setlocal
chcp 65001 >nul

set "SCRIPT_DIR=%~dp0"
set "PS_SCRIPT=%SCRIPT_DIR%scripts\update-icramini.ps1"

if not exist "%PS_SCRIPT%" (
  echo Guncelleme scripti bulunamadi: %PS_SCRIPT%
  pause
  exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%" -TargetDir "%SCRIPT_DIR%." -NoBackup
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if "%EXIT_CODE%"=="0" (
  echo Guncelleme tamamlandi.
) else (
  echo Guncelleme basarisiz oldu. Hata kodu: %EXIT_CODE%
)

pause
exit /b %EXIT_CODE%

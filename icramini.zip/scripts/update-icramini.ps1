﻿[CmdletBinding()]
param(
  [string]$PackageUrl = "https://github.com/icratoolkit/updater/raw/refs/heads/main/icramini.zip",
  [string]$TargetDir = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path,
  [switch]$NoBackup
)

$ErrorActionPreference = "Stop"
$utf8NoBom = New-Object System.Text.UTF8Encoding $false
[Console]::OutputEncoding = $utf8NoBom
$OutputEncoding = $utf8NoBom

function Write-Step {
  param([string]$Message)
  Write-Host ""
  Write-Host "==> $Message"
}

function Remove-IfExists {
  param([string]$Path)
  if (Test-Path -LiteralPath $Path) {
    Remove-Item -LiteralPath $Path -Recurse -Force
  }
}

function Copy-DirectoryContent {
  param(
    [string]$SourceDir,
    [string]$DestinationDir,
    [string[]]$ExcludeNames,
    [switch]$SkipMissing
  )

  Get-ChildItem -LiteralPath $SourceDir -Force | ForEach-Object {
    $item = $_
    if ($ExcludeNames -contains $item.Name) {
      return
    }

    $destinationPath = Join-Path $DestinationDir $item.Name

    if ($item.PSIsContainer) {
      if (-not (Test-Path -LiteralPath $destinationPath)) {
        New-Item -ItemType Directory -Path $destinationPath | Out-Null
      }

      Copy-DirectoryContent -SourceDir $item.FullName -DestinationDir $destinationPath -ExcludeNames $ExcludeNames -SkipMissing:$SkipMissing
      return
    }

    # Yedek alinirken kurulum klasorune baska bir surec yaziyor olabilir;
    # arada kaybolan tek bir dosya guncellemeyi durdurmamali. Paketi kurarken
    # ise eksik dosya gercek hatadir, bu yuzden yutma yalnizca -SkipMissing ile.
    try {
      Copy-Item -LiteralPath $item.FullName -Destination $destinationPath -Force
    }
    catch {
      if (-not $SkipMissing) {
        throw
      }

      Write-Host "Yedeklenemedi, atlandı: $($item.FullName)"
    }
  }
}

function Clear-TargetDirectory {
  param(
    [string]$TargetDir,
    [string[]]$ExcludeNames,
    [string[]]$PreservePaths = @()
  )

  Get-ChildItem -LiteralPath $TargetDir -Force | ForEach-Object {
    if ($ExcludeNames -contains $_.Name) {
      return
    }

    $fullPath = [System.IO.Path]::GetFullPath($_.FullName).TrimEnd("\")
    if ($PreservePaths -contains $fullPath) {
      return
    }

    # Kurulum klasorune baska bir surec yaziyor olabilir (log dosyalari gibi).
    # Listeleme ile silme arasinda kaybolan dosya hata degildir; diger hatalar
    # bilerek yukari birakilir ki guncelleme sessizce yarim kalmasin.
    try {
      if ($_.PSIsContainer) {
        Clear-TargetDirectory -TargetDir $_.FullName -ExcludeNames @() -PreservePaths $PreservePaths
        if (-not (Get-ChildItem -LiteralPath $_.FullName -Force)) {
          Remove-Item -LiteralPath $_.FullName -Force
        }
        return
      }

      Remove-Item -LiteralPath $_.FullName -Force
    }
    catch [System.Management.Automation.ItemNotFoundException] {
      return
    }
  }
}

$TargetDir = $TargetDir.Trim().Trim('"')
$TargetDir = [System.IO.Path]::GetFullPath($TargetDir)
if (-not (Test-Path -LiteralPath $TargetDir -PathType Container)) {
  throw "Hedef klasör bulunamadı: $TargetDir"
}
$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("icramini-update-" + [System.Guid]::NewGuid().ToString("N"))
$zipPath = Join-Path $tempRoot "icramini.zip"
$extractDir = Join-Path $tempRoot "paket"
# Yedek kurulum klasorune yazilmaz. Chrome o klasoru paketlenmemis uzanti
# olarak yukluyor; icine birakilan kopya hem uzantiyi sisirir hem her
# guncellemede birikir. Sistem gecici klasoru bu is icin dogru yer.
$backupRoot = Join-Path ([System.IO.Path]::GetTempPath()) "icramini-yedek"
$backupKeep = 1
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupDir = Join-Path $backupRoot $timestamp
$backupExcludeNames = @(".git", "_update_backups")
# _update_backups temizleme listesinde yok: eski surumler yedegi kurulum
# klasorune biraktigi icin mevcut birikinti bu adimda silinsin.
$clearExcludeNames = @(".git")
$preservePaths = @(
  [System.IO.Path]::GetFullPath((Join-Path $TargetDir "update-icramini.bat")).TrimEnd("\"),
  [System.IO.Path]::GetFullPath((Join-Path $TargetDir "scripts\update-icramini.ps1")).TrimEnd("\")
)

try {
  Write-Step "Hazırlanıyor"
  Write-Host "Hedef klasör: $TargetDir"
  New-Item -ItemType Directory -Path $tempRoot, $extractDir | Out-Null

  Write-Step "Güncelleme paketi indiriliyor"
  Invoke-WebRequest -Uri $PackageUrl -OutFile $zipPath -UseBasicParsing

  Write-Step "ZIP paketi açılıyor"
  Expand-Archive -LiteralPath $zipPath -DestinationPath $extractDir -Force

  $packageRoot = $extractDir
  $entries = Get-ChildItem -LiteralPath $extractDir -Force
  if ($entries.Count -eq 1 -and $entries[0].PSIsContainer) {
    $packageRoot = $entries[0].FullName
  }

  $manifestPath = Join-Path $packageRoot "manifest.json"
  if (-not (Test-Path -LiteralPath $manifestPath)) {
    throw "Paket kökünde manifest.json bulunamadı. ZIP içeriği beklenen icramini paketi gibi görünmüyor."
  }

  $packageVersion = (Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json).version
  if ($packageVersion) {
    Write-Host "Paket sürümü: $packageVersion"
  }

  if (-not $NoBackup) {
    Write-Step "Mevcut dosyalar yedekleniyor"
    New-Item -ItemType Directory -Path $backupDir | Out-Null
    Copy-DirectoryContent -SourceDir $TargetDir -DestinationDir $backupDir -ExcludeNames $backupExcludeNames -SkipMissing
    Write-Host "Yedek: $backupDir"

    # Klasor adlari zaman damgasi oldugu icin siralama kronolojik.
    $olds = @(Get-ChildItem -LiteralPath $backupRoot -Directory -Force | Sort-Object Name)
    if ($olds.Count -gt $backupKeep) {
      $olds[0..($olds.Count - $backupKeep - 1)] | ForEach-Object {
        Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
      }
    }
  }

  Write-Step "Dosyalar güncelleniyor"
  Clear-TargetDirectory -TargetDir $TargetDir -ExcludeNames $clearExcludeNames -PreservePaths $preservePaths
  Copy-DirectoryContent -SourceDir $packageRoot -DestinationDir $TargetDir -ExcludeNames $clearExcludeNames

  $newManifestPath = Join-Path $TargetDir "manifest.json"
  if (Test-Path -LiteralPath $newManifestPath) {
    $version = (Get-Content -Raw -LiteralPath $newManifestPath | ConvertFrom-Json).version
    if ($version) {
      Write-Host "Kurulan sürüm: $version"
    }
  }

  Write-Step "Tamamlandı"
  Write-Host "Chrome eklentisi açıksa chrome://extensions sayfasından eklentiyi yenileyin."
  exit 0
}
catch {
  Write-Host ""
  Write-Host "Güncelleme başarısız oldu:" -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Write-Host ""
  Write-Host "Yedek alındıysa buradan geri dönebilirsiniz: $backupDir"
  exit 1
}
finally {
  Remove-IfExists -Path $tempRoot
}

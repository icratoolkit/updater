<p align="center">
  <img src="assets/icons/favicon.png" alt="Mini İcra Yardımcısı" width="120" />
</p>

<h1 align="center">Mini İcra Yardımcısı</h1>

<p align="center">
  <strong>Avukatlar ve icra dairesi çalışanları için toplu dosya sorgulama, hesaplama ve haciz yönetim aracı</strong>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/platform-Chrome-4285F4?logo=googlechrome&logoColor=white" alt="Chrome" />
  <img src="https://img.shields.io/badge/manifest-v3-34A853" alt="Manifest V3" />
  <img src="https://img.shields.io/badge/version-1.0.0-blue" alt="Versiyon" />
  <img src="https://img.shields.io/badge/language-JavaScript-F7DF1E?logo=javascript&logoColor=black" alt="JavaScript" />
  <img src="https://img.shields.io/badge/arayüz-Türkçe-E30A17" alt="Türkçe" />
</p>

---

## Hakkında

**Mini İcra Yardımcısı**, UYAP / icra portalında oturumu açık sekme üzerinde çalışan bir **Google Chrome uzantısıdır**. Toplu dosya listesiyle sorgulama, dosya hesabı, kesinleştirme, talep gönderimi ve haciz işlemlerini tek popup arayüzünden yönetir.

---

## Özellikler

| Özellik                     | Açıklama                                                                                                  |
| :-------------------------- | :-------------------------------------------------------------------------------------------------------- |
| **Normal Sorgu**            | Dosyalarda yatan para ve kalan borç bilgisini listeler                                                    |
| **Tarih Filtreli Sorgu**    | Bugün, bu hafta, bu ay veya özel tarih aralığına göre ödeme filtreler                                     |
| **Reddiyat Sorgulama**      | Tahsilat / reddiyat verisine göre iade veya ödeme aktarımı bekleyen dosyaları ayıklar                     |
| **Kalan Sorgulama**         | `Bakiye Borç Miktarı` girilen üst sınırın altında olan dosyaları listeler                                 |
| **Kesinleştirme Sorgulama** | Tebligat barkodu, PTT verisi ve evrak geçmişi üzerinden kesinleşme yorumlar, iade dönenleri ayrı listeler |
| **Dosya Hesabı**            | İlamlı / ilamsız dosyalar için ayrıntılı borç hesabı üretir                                               |
| **Takip Evrakı Yükleme**    | `UDF`, `ZIP` veya `content.xml` ile mevcut hesabı yeniden günceller                                       |
| **Talep Modu**              | Masraf avans iadesi ve borçlu ödemelerinin hesaba aktarılması taleplerini gönderir                        |
| **Araç Haciz Sorgusu**      | Borçlulara ait araçları toplu sorgular                                                                    |
| **Banka Haciz Sorgusu**     | Borçlulara ait banka kayıtlarını toplu sorgular ve eşleştirir                                             |
| **Takbis Sorgusu**          | Borçlulara ait taşınmaz kayıtlarını toplu sorgular                                                        |
| **İcra Dosyası Sorgusu**    | Borçlunun alacaklı olduğu icra dosyalarını sorgular                                                       |
| **Haciz Talep Gönderimi**   | Araç, banka, Takbis ve İcra Dosyası için uygun talepleri gönderir                                         |
| **Durdur / Devam Et**       | İşlem durdurulduğunda son durak saklanır, aynı yerden devam edilir                                        |
| **Dışa Aktarma**            | Sonuçları `.xlsx` olarak dışa aktarır                                                                     |
| **Koyu / Açık Tema**        | Sistem temasına uyumlu veya manuel tema seçimi sunar                                                      |
| **Renk Paleti**             | Varsayılan, pembe, yeşil, gri ve kırmızı paletlerden birini seçtirir                                      |

---

## Mimari

```text
Popup UI
  -> chrome.tabs.sendMessage
Content Script
  -> window.postMessage
Injected Runner
  -> chrome.runtime.sendMessage
Background Service Worker
  -> HTTP istekleri
UYAP / İcra Portalı
```

Her katmanın giriş noktası:

| Katman          | Dosya                                     | Görevi                                                       |
| :-------------- | :---------------------------------------- | :----------------------------------------------------------- |
| Popup           | `src/popup/main.js`                       | Modülleri kurar, olayları bağlar, kayıtlı durumu geri yükler |
| İçerik betiği   | `src/content/content-script.js`           | Popup ile sayfa arasında mesaj köprüsü, betik enjeksiyonu    |
| Sorgu akışı     | `src/injected/page-runner.js`             | Sorgu / dosya hesabı / talep akışının sıralaması             |
| Haciz akışı     | `src/injected/haciz/page-runner-haciz.js` | Haciz sorgu ve talep akışının sıralaması                     |
| Servis çalışanı | `src/background/service-worker.js`        | Sayfanın erişemediği çapraz köken istekleri                  |

---

## Proje Yapısı

Uzantı paketleyici (bundler) kullanmaz; tüm dosyalar klasik `<script>`
olarak yüklenir ve modüller `window.MiniIcra*` / `window.__EWR_*` ad alanları
üzerinden haberleşir. Yükleme sırası üç yerde bildirilir: `manifest.json`,
`src/content/content-script.js` (`INJECTED_SCRIPTS`) ve
`src/popup/index.html`.

```text
icramini/
|- manifest.json
|- assets/
|  |- data/            birim ve banka listeleri
|  |- icons/
|  |- templates/       UDF talep şablonu
|  `- vendor/          fflate, pdf.js, xlsx
|- scripts/            paketleme ve doğrulama betikleri
|- src/
|  |- background/      service-worker.js
|  |- content/         content-script.js (mesaj köprüsü)
|  |- injected/        sayfa bağlamında çalışan kod
|  |  |- page-runner-core.js      HTTP, şablon, tutar/tarih ilkelleri
|  |  |- extract/                 UYAP yanıtlarından veri çıkarma
|  |  |  |- evrak.js              evrak listesi, PTT tebligat tarihleri
|  |  |  |- taraf.js              alacaklı/borçlu ad eşleştirme
|  |  |  |- tahsilat.js           tahsilat-reddiyat ve masraf kalemleri
|  |  |  |- binary.js             base64 / PDF sarmalama / ZIP
|  |  |  |- pdf.js                PDF metni, barkod, e-tebligat
|  |  |  `- takip-talebi.js       takip talebi tutarlarının ayrıştırılması
|  |  |- page-runner-extract.js   extract/ modüllerinin birleştiricisi
|  |  |- query/                   sorgu iş akışı aşamaları
|  |  |  |- progress.js           ilerleme raporlama
|  |  |  |- talep-sender.js       talep gönderimi
|  |  |  |- dosya-hesabi.js       dosya hesabı verisi ve toplamları
|  |  |  `- kesinlestirme.js      tebligat tarihi ve barkod
|  |  |- page-runner.js           sorgu akışı orkestrasyonu
|  |  `- haciz/
|  |     |- core.js               ortak durum, banka eşleştirme, yeniden deneme
|  |     |- sorgu.js              araç / banka / Takbis / icra dosyası sorguları
|  |     |- talep.js              haciz talebi gönderimi
|  |     `- page-runner-haciz.js  haciz akışı orkestrasyonu
|  |- popup/
|  |  |- index.html
|  |  |- main.js       önyükleme: modülleri kurar ve olayları bağlar
|  |  |- state/        paylaşılan çalışma zamanı durumu
|  |  |- ui/           kabuk: durum çubuğu, sonuç listesi, sekmeler
|  |  |- services/     tema, yardım paneli, sürüm kontrolü, sekme iletişimi
|  |  |- controllers/  sorgu ve haciz akış denetleyicileri
|  |  |- modules/      yapılandırma, DOM, hesap, dışa aktarma, haciz biçimleme
|  |  `- styles/
|  `- shared/          popup ve sayfa bağlamının ortak kullandığı yardımcılar
|     |- text-utils.js
|     `- hesap/
|- README.md
`- PROJE_DOKUMANTASYONU.md
```

---

## Kurulum

### Chrome'a Yükleme

1. Chrome'da `chrome://extensions` adresine gidin.
2. Sağ üstten **Geliştirici modu**'nu açın.
3. **Paketlenmemiş öğe yükle** seçeneğine tıklayın.
4. Bu repo klasörünü seçin.

Not:

- Repo doğrudan geliştirici modu ile yüklenebilir yapıdadır.

---

## Kullanım

### Sorgulama

1. UYAP / icra portalında oturum açın.
2. Uzantı popup’ını açın.
3. **Sorgulama** sekmesinde modu seçin.
4. Dosya listesini yapıştırın:
   ```text
   Ankara 1. Genel İcra Dairesi	2026/3450
   Düzce İcra Dairesi	2025/654
   ```
5. **Çalıştır** ile işlemi başlatın.

### Dosya Hesabı

1. **Dosya Hesabı** sekmesine geçin.
2. Ödeme tarihi ve hesap türünü seçin.
3. Gerekirse `UDF / ZIP / content.xml` yükleyin.
4. **Hesapla** ile sonucu üretin.

### Talep

1. **Talep** sekmesine geçin.
2. Talep türünü seçin:
   - `Masraf Avans İadesi`
   - `Borçlu Tarafından Yapılan Ödemelerin Hesaba Aktarılması`
   - `IBAN Değişikliği Talebi`
3. Gönderim talepleri varsayılan IBAN ile hazırlanır.
4. **Talep Gönder** ile gönderim talepleri için talep evrakı hazırlanıp gönderilir.
5. `IBAN Değişikliği Talebi` seçiliyken şablondan UDF üretilir ve her dosya için `/evrakGonder_brd.ajx` ile gönderilir.

### Haciz

1. **Haciz** sekmesine geçin.
2. Türleri seçin:
   - `Araç`
   - `Banka`
   - `Takbis`
   - `İcra Dosyası`
3. **Başlat** ile sorgu + talep akışını çalıştırın.

---

## Çalışma Modları

### Sorgulama Sekmesi

| Mod                     | Açıklama                                                        |
| :---------------------- | :-------------------------------------------------------------- |
| Normal Sorgu            | Yatan para bulunan dosyaları listeler                           |
| Tarih Filtreli Sorgu    | Tarih filtresine göre ödeme içeren dosyaları listeler           |
| Reddiyat Sorgulama      | Tahsilat / reddiyat kurallarına göre uygun dosyaları listeler   |
| Kalan Sorgulama         | Kalan borcu girilen üst sınırın altında olan dosyaları listeler |
| Kesinleştirme Sorgulama | Tebligat / barkod verisinden kesinleşme bilgisi üretir          |

### Dosya Hesabı Sekmesi

| Mod               | Açıklama                            |
| :---------------- | :---------------------------------- |
| Genel Hesap       | Standart dosya hesabı               |
| Vazgeçme Hesabı   | Vazgeçme senaryosu için hesap       |
| İndirim Hesaplama | İndirim tutarıyla yeniden hesaplama |

### Talep Sekmesi

| Talep                                                   | Açıklama                                                                                      |
| :------------------------------------------------------ | :-------------------------------------------------------------------------------------------- |
| Masraf Avans İadesi                                     | `Dosyadaki Avansın İadesi` talebini hazırlar ve gönderir                                      |
| Borçlu Tarafından Yapılan Ödemelerin Hesaba Aktarılması | Borçlu tarafından yapılan ödemelerin vekil IBAN’ına aktarılması talebini hazırlar ve gönderir |

### Haciz Sekmesi

| Özellik      | Açıklama                                                   |
| :----------- | :--------------------------------------------------------- |
| Araç         | Araç sorgusu ve uygun talep üretimi                        |
| Banka        | Banka sorgusu ve uygun talep üretimi                       |
| Takbis       | Taşınmaz sorgusu, gecikirse arka planda bekleme            |
| İcra Dosyası | Alacaklı olduğu dosyalar için sorgu ve uygun talep üretimi |

---

## Güncel Davranışlar

### Sorgulama Tarafı

- `Normal`, `Tarih Filtreli`, `Reddiyat` ve `Kalan` modlarında sorgular timeout olmadan çalışır.
- Dosyalar arası bekleme `1 saniye`dir.
- `Kalan Sorgulama`, `Bakiye Borç Miktarı < üst sınır` kuralıyla çalışır.
- `Reddiyat Sorgulama`, dosya hesap bilgileri isteği atmadan doğrudan tahsilat / reddiyat bilgisinden ilerler.
- Kapalı dosyada herhangi bir tahsilat satırı sonuç kabul edilir.
- Açık dosyada `Borç Tahsilatı` için `kalanMiktar > 0` aranır.
- Açık dosyada `Masraf Avansı Tahsilatı` için `kalanMiktar > 0`, dosyada bir `Borç Tahsilatı` girişi ve `odeyenKisi` ile alacaklı / alacaklı vekili eşleşmesi aranır.
- Reddiyat Excel çıktısı `Birim`, `Dosya No`, `Tahsilat Türü`, `Kalan Miktar` kolonlarıyla üretilir.
- `Kesinleştirme Sorgulama` sonucu `Kesinleştirme` ve `İade` sekmelerinde gösterilir; her dosya kişi bazında kart olarak listelenir.
- PTT hareketlerinde teslim yerine iade görülen tebligatlar kesinleşme sayılmaz, `İade` sekmesinde iade tarihi ve nedeniyle listelenir.
- Kesinleştirme Excel çıktısı `Birim`, `Dosya No`, `Durum`, `Kişi No`, `Tebligat No`, `Kişi`, `Tebliğ Tarihi`, `Kesinleşme Tarihi`, `İade Tarihi`, `Açıklama`, `Barkod` kolonlarıyla üretilir.

### Dosya Hesabı Tarafı

- `DEĞER KAYBI BEDELİ` ve `ÇEKİCİ BEDELİ` gibi çoklu kalemlerde asıl alacak toplamına dahil edilir.
- `Tahsil Harcı`, `Masraf Toplamı` hesabına dahildir.

### Talep Tarafı

- Talep modu her dosya için önce dosya araması yapar, sonra `/dosya_borclu_list.ajx` yanıtından herhangi bir `kisiKurumId` alır.
- Talep evrakı `/getIcraTalepEvrakHazirla.uyap` ile hazırlanır.
- Hazırlanan `Talep.udf`, `/avukatIcraTalepEvrakiGonder.ajx` endpoint’ine multipart olarak gönderilir.
- `IBAN Değişikliği Talebi` seçeneği `assets/templates/iban_degisikligi_talebi.udf` şablonundan dosya üretir ve `/evrakGonder_brd.ajx` ile gönderir.
- Bu şablonda `__ILILCE__`, `__ICRADAIRESI__`, `__DOSYANO__` ve `__TARIH__` marker’ları girilen dosya satırına ve güncel tarihe göre doldurulur.
- `Masraf Avans İadesi` için `talepKodu: 37`, `className: "AvukatTalepDosyaAvansIadesiDvo"` kullanılır.
- `Borçlu Tarafından Yapılan Ödemelerin Hesaba Aktarılması` için `talepKodu: 14`, `className: "AvukatTalepGenelOdemeAktarDVO"` kullanılır.
- Talep Excel çıktısı `Birim`, `Dosya No`, `Talep`, `Durum`, `Mesaj` kolonlarıyla üretilir.

### Haciz Tarafı

- Tüm haciz sorgularının (araç, banka, Takbis, İcra Dosyası) bekleme süresi `60 saniye`dir.
- Bir sorgu `5 saniye`yi aşarsa popup’ta `yanıt bekleniyor` bilgisi gösterilir.
- Takbis gecikirse araç, banka ve İcra Dosyası tarafı bekletilmeden ilerlenir.
- Timeout olan haciz sorgularında aynı `dosya + kişi + sorgu türü` için `3 dakika` otomatik yeniden deneme yapılmaz.
  Timeout, sorgunun başarısız olduğu anlamına gelmez; dış sistemde (EGM / banka / TAKBİS) hâlâ sürüyor olabilir.
- Haciz talebinde kategori başına en fazla `10` kayıt gönderilir.
  Araç `10`, banka `10`, Takbis `10`, İcra Dosyası `10`.
- Toplu talepte imza / içerik değişikliği uyarısı gelirse sistem tekli denemeye düşer.

### Durdur / Devam Et

- Query / Dosya Hesabı tarafında son aktif dosya ve son aktif istek saklanır.
- Haciz tarafında son aktif dosya ve son aktif sorgu etiketi saklanır.
- Popup yeniden açıldığında `Durdur` butonu gerekirse `Devam Et` olur.
- Devam et, kontrol noktasından mantıksal olarak sürer; yarım HTTP isteğini ağ seviyesinde devam ettirmez.

---

## Güvenlik

- Veriler yalnızca `chrome.storage.local` üzerinde tutulur.
- Service worker, açık oturum çerezleriyle istek yapar.
- Uygulama dış sunucuya özel kullanıcı verisi göndermez.

---

## Teknolojiler

| Katman       | Teknoloji                        |
| :----------- | :------------------------------- |
| Platform     | Chrome Extension Manifest V3     |
| Dil          | Vanilla JavaScript               |
| PDF İşleme   | PDF.js                           |
| Excel Export | SheetJS                          |
| ZIP İşleme   | fflate                           |
| Stil         | Custom CSS                       |
| Kod kalitesi | ESLint 9 (flat config), Prettier |

---

---

## Lisans

Bu proje özel kullanım amaçlıdır. Tüm hakları saklıdır.

---

<p align="center">
  <sub>&#x2696;&#xFE0F; İcra süreçlerinizi hızlandırın, işlerinizi kolaylaştırın.</sub>
</p>

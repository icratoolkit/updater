@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "PS_SCRIPT=%SCRIPT_DIR%scripts\create-icramini-zip.ps1"

if not exist "%PS_SCRIPT%" (
  echo Paketleme scripti bulunamadi: %PS_SCRIPT%
  pause
  exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%" -SourceDir "%SCRIPT_DIR%."
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if "%EXIT_CODE%"=="0" (
  echo Paket olusturma tamamlandi.
) else (
  echo Paket olusturma basarisiz oldu. Hata kodu: %EXIT_CODE%
)

pause
exit /b %EXIT_CODE%

﻿(function () {
  "use strict";

  if (window.MiniIcraPopupUtils) {
    return;
  }

  const TextUtils = window.MiniIcraTextUtils || {};
  const fixMojibake = (s) => (typeof TextUtils.fixMojibake === "function" ? TextUtils.fixMojibake(s) : String(s || ""));
  const normalizeKey = (s) =>
    typeof TextUtils.normalizeKey === "function"
      ? TextUtils.normalizeKey(s)
      : fixMojibake(s)
          .toLocaleLowerCase("tr-TR")
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "")
          .replace(/[^a-z0-9]/g, "");
  const formatAmount2 = (value) =>
    typeof TextUtils.formatAmount2 === "function"
      ? TextUtils.formatAmount2(value)
      : (Number.isFinite(Number(value)) ? Number(value).toFixed(2) : String(value ?? ""));
  const formatOptionalAmount2 = (value) => {
    if (value === null || typeof value === "undefined" || String(value).trim() === "") {
      return "-";
    }
    return formatAmount2(value);
  };

  const toNum = (v) => {
    if (v === null || typeof v === "undefined") {
      return null;
    }
    const n = Number(String(v).replace(",", "."));
    return Number.isFinite(n) ? n : null;
  };

  const RUN_MODES = Object.freeze({
    NORMAL: "normal",
    DATED: "datedCurrentMonth",
    REDDIYAT: "reddiyat",
    KALAN: "kalan",
    KESINLESTIRME: "kesinlestirme",
    DOSYA_HESABI: "dosyaHesabi",
    TALEP_MASRAF_AVANS_IADESI: "talepMasrafAvansIadesi",
    TALEP_BORCLU_ODEME_AKTAR: "talepBorcluOdemeAktar",
    TALEP_EVRAKI_OLUSTUR: "talepEvrakiOlustur"
  });

  const linesToArray = (text) =>
    String(text || "")
      .split(/\r?\n/)
      .map((x) => x.trim())
      .filter(Boolean);

  const normalizeOdemeDateForUi = (value) => {
    const raw = String(value || "").trim();
    if (!raw) {
      return "";
    }
    const isoDate = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (isoDate) {
      return `${isoDate[1]}-${isoDate[2]}-${isoDate[3]}`;
    }
    const trDate = raw.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (trDate) {
      return `${trDate[3]}-${trDate[2]}-${trDate[1]}`;
    }
    const isoDateTime = raw.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/);
    if (isoDateTime) {
      return `${isoDateTime[1]}-${isoDateTime[2]}-${isoDateTime[3]}`;
    }
    return "";
  };

  const splitInputLine = (line) => {
    const t = String(line || "").trim();
    if (!t) {
      return null;
    }
    const byTab = t.split("\t").map((x) => x.trim()).filter(Boolean);
    if (byTab.length >= 2) {
      return { birimAdi: byTab[0], dosyaNo: byTab[1] };
    }
    const bySemi = t.split(";").map((x) => x.trim()).filter(Boolean);
    if (bySemi.length >= 2) {
      return { birimAdi: bySemi[0], dosyaNo: bySemi[1] };
    }
    const byManySpaces = t.split(/\s{2,}/).map((x) => x.trim()).filter(Boolean);
    if (byManySpaces.length >= 2) {
      return { birimAdi: byManySpaces[0], dosyaNo: byManySpaces[1] };
    }
    return { birimAdi: "", dosyaNo: t };
  };

  const parseRowsFromInput = (rawText, settings) => {
    const lines = linesToArray(rawText);
    const results = [];

    for (const line of lines) {
      const parsed = splitInputLine(line);
      if (!parsed) {
        continue;
      }
      if (/^birimadi$/i.test(parsed.birimAdi) || /^dosyano$/i.test(parsed.dosyaNo)) {
        continue;
      }
      const dosyaNo = parsed.dosyaNo.replace(/\s+/g, "");
      if (!/^\d{4}\/\d+$/.test(dosyaNo)) {
        continue;
      }
      const birimAdi = parsed.birimAdi || settings.defaultBirimAdi || "";
      const birimId = settings.defaultBirimId || "";
      results.push({ dosyaNo, birimAdi, birimId });
    }

    return results;
  };

  const buildKesinlestirmeGroups = (detaylar) => {
    const map = new Map();
    for (const d of Array.isArray(detaylar) ? detaylar : []) {
      if (!d || !d.tebligTarihi || !d.isMatch) {
        continue;
      }
      const kisiRaw = fixMojibake(d.kisi || "").trim();
      const kisi = kisiRaw || "Bilinmeyen Kişi";
      const key = normalizeKey(kisi) || kisi.toLocaleLowerCase("tr-TR");
      if (!map.has(key)) {
        map.set(key, {
          kisi,
          details: []
        });
      }
      map.get(key).details.push({
        tebligTarihi: fixMojibake(d.tebligTarihi || ""),
        barkod: fixMojibake(d.barcode || "")
      });
    }

    return Array.from(map.values()).map((g) => ({
      kisi: g.kisi,
      details: g.details.sort((a, b) => {
        const ta = Date.parse(`${a.tebligTarihi.slice(6, 10)}-${a.tebligTarihi.slice(3, 5)}-${a.tebligTarihi.slice(0, 2)}T00:00:00Z`);
        const tb = Date.parse(`${b.tebligTarihi.slice(6, 10)}-${b.tebligTarihi.slice(3, 5)}-${b.tebligTarihi.slice(0, 2)}T00:00:00Z`);
        return ta - tb;
      })
    }));
  };

  const formatDosyaHesabiLine = (x) => {
    const tebligText = fixMojibake(x.tebligTarihi || "") || "-";
    const hesapTuru = String(x?.dosyaHesabiHesapTuru || "normal");
    const isIndirimHesabi = hesapTuru === "indirim";
    const isVazgecmeHesabi = hesapTuru === "vazgecme";

    const anaParaCalc = (x.anaPara !== null && typeof x.anaPara !== "undefined")
      ? x.anaPara
      : (() => {
          const a = toNum(x.asilAlacak);
          const g = toNum(x.gecmisGunFaizi);
          const i = toNum(x.icraFaizTutari);
          return (a !== null || g !== null || i !== null)
            ? ((a || 0) + (g || 0) + (i || 0)).toFixed(2)
            : null;
        })();

    const hakEdisCalc = (x.hakEdis !== null && typeof x.hakEdis !== "undefined")
      ? x.hakEdis
      : (() => {
          const ana = toNum(anaParaCalc);
          const d = toNum(x.danismanlikUcreti);
          return (ana !== null && d !== null) ? (ana - d).toFixed(2) : null;
        })();

    const indirimOutput = isIndirimHesabi
      ? `\nİndirim Tutarı: ${formatOptionalAmount2(x.indirimTutari)} | Yeni Asıl Alacak: ${formatOptionalAmount2(x.indirimYeniAsilAlacak)} | Yeni Danışmanlık Ücreti: ${formatOptionalAmount2(x.indirimYeniDanismanlikUcreti)} | İndirimli Toplam Borç: ${formatOptionalAmount2(x.indirimliToplamBorc)}`
      : "";

    const vazgecmeOutput = isVazgecmeHesabi
      ? `\nAna Para: ${formatOptionalAmount2(anaParaCalc)}\nHakediş: ${formatOptionalAmount2(hakEdisCalc)}`
      : "";
    return `${fixMojibake(x.input)} -> Talep Tarihi -> ${fixMojibake(x.talepTarihi)} | Tebliğ Edildiği Tarih: ${tebligText} | Asıl Alacak: ${formatOptionalAmount2(x.asilAlacak)} | Geçmiş Gün Faizi: ${formatOptionalAmount2(x.gecmisGunFaizi)} | Hesaplanan Faiz (Asıl Alacak): ${formatOptionalAmount2(x.icraFaizTutari)} | Danışmanlık Ücreti (%20): ${formatOptionalAmount2(x.danismanlikUcreti)} | Yargılama Gideri: ${formatOptionalAmount2(x.mahkemeYargilamaGiderleri)} | YG Geçmiş Gün Faizi: ${formatOptionalAmount2(x.mahkemeYargilamaGiderleriFaizi)} | YG Hesaplanan Faiz: ${formatOptionalAmount2(x.ygIcraFaiz)} | Harç: ${formatOptionalAmount2(x.mahkemeHarclari)} | Harç Geçmiş Gün Faizi: ${formatOptionalAmount2(x.mahkemeHarclariFaizi)} | Harç Hesaplanan Faiz: ${formatOptionalAmount2(x.harcIcraFaiz)} | İlam Vekalet Ücreti: ${formatOptionalAmount2(x.mahkemeVekaletUcreti)} | İVÜ Geçmiş Gün Faizi: ${formatOptionalAmount2(x.mahkemeVekaletUcretiFaizi)} | İVÜ Hesaplanan Faiz: ${formatOptionalAmount2(x.ivuIcraFaiz)} | Vekalet Pulu: ${formatOptionalAmount2(x.vekaletPulu)} | Tebligat Gideri: ${formatOptionalAmount2(x.tebligatGideri)} | Başvurma Harcı: ${formatOptionalAmount2(x.basvurmaHarci)} | Vekalet Suret Harcı: ${formatOptionalAmount2(x.vekaletSuretHarci)} | Peşin Harç: ${formatOptionalAmount2(x.pesinHarc)} | Tahsil Harcı: ${formatOptionalAmount2(x.tahsilHarciHesap)} | İcra Vekalet Ücreti: ${formatOptionalAmount2(x.vekaletUcretiDosyaHesap)} | Takip Türü: ${fixMojibake(x.takibinTuruAciklama || "") || "-"}\nMasraf Toplamı: ${formatOptionalAmount2(x.masrafToplami)}${vazgecmeOutput}${indirimOutput}\nToplam Borç: ${formatOptionalAmount2(x.toplamBorcHesap)}`;
  };

  const formatRunStatus = (progress) => `Çalışıyor... ${progress.processed}/${progress.total} | Eşleşen: ${progress.matchCount}`;

  const getKesinlestirmeRow = (item, separator, allowEmpty) => {
    if (!item || !Array.isArray(item.tebligDetaylari)) {
      return null;
    }
    const groups = buildKesinlestirmeGroups(item.tebligDetaylari || []);
    const parts = groups.map((g) => `${g.kisi} (${g.details.length} tebligat): ${g.details.map((d) => `"${d.tebligTarihi}"`).join(", ")}`);
    if (parts.length === 0 && !allowEmpty) {
      return null;
    }
    return `${fixMojibake(item.input)} -> ${parts.join(separator)}`;
  };

  const getMatchedRowsForMode = (items, mode, source) => {
    const safeItems = Array.isArray(items) ? items : [];

    if (mode === RUN_MODES.KESINLESTIRME) {
      return safeItems
        .filter((x) => {
          if (!x) {
            return false;
          }
          if (source === "result") {
            return x.isMatch && Array.isArray(x.tebligDetaylari) && x.tebligDetaylari.some((d) => !!d.tebligTarihi);
          }
          return Array.isArray(x.tebligDetaylari);
        })
        .map((x) => getKesinlestirmeRow(x, source === "result" ? " | " : ", ", source === "result"))
        .filter(Boolean);
    }

    if (mode === RUN_MODES.DOSYA_HESABI) {
      return safeItems
        .filter((x) => x && (source === "result" ? x.isMatch : true) && x.talepTarihi)
        .map((x) => formatDosyaHesabiLine(x));
    }

    if (mode === RUN_MODES.TALEP_MASRAF_AVANS_IADESI || mode === RUN_MODES.TALEP_BORCLU_ODEME_AKTAR || mode === RUN_MODES.TALEP_EVRAKI_OLUSTUR) {
      return safeItems
        .filter((x) => x && (source === "result" ? x.success || x.error : true))
        .map((x) => {
          const durum = x.success ? "Gönderildi" : `Hata: ${fixMojibake(x.error || x.message || "")}`;
          return `${fixMojibake(x.input)} -> ${fixMojibake(x.talepAdi || "Talep")}: ${durum}`;
        });
    }

    if (mode === RUN_MODES.REDDIYAT) {
      const rows = [];
      for (const item of safeItems) {
        if (!item || (source === "result" && !item.isMatch)) {
          continue;
        }
        const kalemler = Array.isArray(item.reddiyatKalemleri) ? item.reddiyatKalemleri : [];
        for (const kalem of kalemler) {
          if (!kalem) {
            continue;
          }
          rows.push(
            `${fixMojibake(kalem.dosyaNo || item.input)} -> Tahsilat Türü: ${fixMojibake(kalem.tahsilatTuru || "")} | Kalan Miktar: ${formatOptionalAmount2(kalem.kalanMiktar)} .`
          );
        }
      }
      return rows;
    }

    if (mode === RUN_MODES.KALAN) {
      return safeItems
        .filter((x) => {
          const threshold = Number(x?.kalanQueryThreshold);
          const kalan = Number(x?.kalanBorc);
          if (!Number.isFinite(threshold) || threshold < 0 || !Number.isFinite(kalan)) {
            return false;
          }
          return source === "result" ? !!x?.isMatch && kalan < threshold : kalan < threshold;
        })
        .map((x) => `${fixMojibake(x.input)} -> Kalan Borç: ${formatAmount2(x.kalanBorc)} | Üst Sınır: ${formatOptionalAmount2(x.kalanQueryThreshold)} | Yatan Para: ${formatOptionalAmount2(x.yatanPara)} .`);
    }

    return safeItems
      .filter((x) => (source === "result" ? !!x?.isMatch : x && typeof x.yatanPara !== "undefined" && x.yatanPara !== null))
      .map((x) => `${fixMojibake(x.input)} -> Yatan Para: ${formatAmount2(x.yatanPara)} | Kalan Borç: ${formatOptionalAmount2(x.kalanBorc)} .`);
  };

  const csvEscape = (value) => `"${String(value ?? "").replace(/"/g, '""')}"`;

  const HEADER_TO_FIELD = Object.freeze({
    "Birim": "birimAdi",
    "Dosya No": "dosyaNo",
    "Yatan Para": "yatanPara",
    "Reddiyat Kalan Miktarı": "reddiyatKalanMiktari",
    "Tahsilat Türü": "tahsilatTuru",
    "Kalan Miktar": "kalanMiktar",
    "Kalan Borç": "kalanBorc",
    "Üst Sınır": "kalanQueryThreshold",
    "Talep": "talepAdi",
    "Durum": "durum",
    "Mesaj": "message",
    "Kişi No": "kisiNo",
    "Tebligat No": "tebligatNo",
    "Kişi": "kisi",
    "Tebliğ Tarihi": "tebligTarihi",
    "Barkod": "barkod",
    "Talep Tarihi": "talepTarihi",
    "Tebliğ Edildiği Tarih": "tebligTarihi",
    "Asıl Alacak": "asilAlacak",
    "Geçmiş Gün Faizi": "gecmisGunFaizi",
    "Vekalet Pulu": "vekaletPulu",
    "Tebligat Gideri": "tebligatGideri",
    "Peşin Harç": "pesinHarc",
    "Başvurma Harcı": "basvurmaHarci",
    "Vekalet Suret Harcı": "vekaletSuretHarci",
    "Tahsil Harcı (Hesap)": "tahsilHarciHesap",
    "Tahsil Harcı": "tahsilHarciHesap",
    "Takipte Kesinleşen": "takipteKesinlesenMiktar",
    "Vekalet Ücreti": "vekaletUcretiDosyaHesap",
    "İcra Vekalet Ücreti": "vekaletUcretiDosyaHesap",
    "İcra/Faiz Hesap": "icraFaizTutari",
    "Hesaplanan Faiz (Asıl Alacak)": "icraFaizTutari",
    "Danışmanlık Ücreti": "danismanlikUcreti",
    "Danışmanlık Ücreti (%20)": "danismanlikUcreti",
    "Toplam Borç": "toplamBorcHesap",
    "Masraf Toplamı": "masrafToplami",
    "Ana Para": "anaPara",
    "Hakediş": "hakEdis",
    "İndirim Tutarı": "indirimTutari",
    "Yeni Asıl Alacak": "indirimYeniAsilAlacak",
    "Yeni Danışmanlık Ücreti": "indirimYeniDanismanlikUcreti",
    "İndirimli Toplam Borç": "indirimliToplamBorc",
    "Mahkeme Vekalet Ücreti": "mahkemeVekaletUcreti",
    "İlam Vekalet Ücreti": "mahkemeVekaletUcreti",
    "Mahkeme Vekalet Ücreti Faizi": "mahkemeVekaletUcretiFaizi",
    "İVÜ Geçmiş Gün Faizi": "mahkemeVekaletUcretiFaizi",
    "Mahkeme Yargılama Giderleri": "mahkemeYargilamaGiderleri",
    "Yargılama Gideri": "mahkemeYargilamaGiderleri",
    "Mahkeme Yargılama Giderleri Faizi": "mahkemeYargilamaGiderleriFaizi",
    "YG Geçmiş Gün Faizi": "mahkemeYargilamaGiderleriFaizi",
    "YG İcra Faiz": "ygIcraFaiz",
    "YG Hesaplanan Faiz": "ygIcraFaiz",
    "Mahkeme Harçları": "mahkemeHarclari",
    "Harç": "mahkemeHarclari",
    "Mahkeme Harçları Faizi": "mahkemeHarclariFaizi",
    "Harç Geçmiş Gün Faizi": "mahkemeHarclariFaizi",
    "Harç İcra Faiz": "harcIcraFaiz",
    "Harç Hesaplanan Faiz": "harcIcraFaiz",
    "İVÜ İcra Faiz": "ivuIcraFaiz",
    "İVÜ Hesaplanan Faiz": "ivuIcraFaiz",
    "Takip Türü": "takibinTuruAciklama"
  });

  const getRowValueByHeader = (row, header) => {
    const field = HEADER_TO_FIELD[header];
    return field ? (row?.[field] ?? "") : "";
  };

  const XLSX_NUMERIC_HEADERS = new Set([
    "Yatan Para",
    "Reddiyat Kalan Miktarı",
    "Kalan Miktar",
    "Kalan Borç",
    "Üst Sınır",
    "Kişi No",
    "Tebligat No",
    "Asıl Alacak",
    "Geçmiş Gün Faizi",
    "Hesaplanan Faiz (Asıl Alacak)",
    "Danışmanlık Ücreti (%20)",
    "Yargılama Gideri",
    "YG Geçmiş Gün Faizi",
    "YG Hesaplanan Faiz",
    "Harç",
    "Harç Geçmiş Gün Faizi",
    "Harç Hesaplanan Faiz",
    "İlam Vekalet Ücreti",
    "İVÜ Geçmiş Gün Faizi",
    "İVÜ Hesaplanan Faiz",
    "Vekalet Pulu",
    "Tebligat Gideri",
    "Başvurma Harcı",
    "Vekalet Suret Harcı",
    "Peşin Harç",
    "Tahsil Harcı",
    "İcra Vekalet Ücreti",
    "Masraf Toplamı",
    "Ana Para",
    "Hakediş",
    "İndirim Tutarı",
    "Yeni Asıl Alacak",
    "Yeni Danışmanlık Ücreti",
    "İndirimli Toplam Borç",
    "Toplam Borç"
  ]);

  const toXlsxNumberIfPossible = (value) => {
    if (value === null || typeof value === "undefined") {
      return "";
    }
    const raw = String(value).trim();
    if (!raw || raw === "-") {
      return "";
    }
    const n = Number(raw.replace(/,/g, "."));
    return Number.isFinite(n) ? n : raw;
  };

  const syncDosyaHesapTuruVisibility = (els) => {
    if (!els || !els.dosyaIndirimWrap || !els.dosyaHesabiHesapTuru) {
      return;
    }
    const isIndirim = String(els.dosyaHesabiHesapTuru.value || "normal") === "indirim";
    els.dosyaIndirimWrap.style.display = isIndirim ? "" : "none";
  };

  window.MiniIcraPopupUtils = {
    RUN_MODES,
    linesToArray,
    fixMojibake,
    normalizeKey,
    formatAmount2,
    formatOptionalAmount2,
    normalizeOdemeDateForUi,
    splitInputLine,
    parseRowsFromInput,
    buildKesinlestirmeGroups,
    formatDosyaHesabiLine,
    formatRunStatus,
    getMatchedRowsForMode,
    csvEscape,
    HEADER_TO_FIELD,
    getRowValueByHeader,
    XLSX_NUMERIC_HEADERS,
    toXlsxNumberIfPossible,
    syncDosyaHesapTuruVisibility
  };

  
  window.MiniIcraPopupDosya = {
    syncDosyaHesapTuruVisibility
  };
})();

#!/usr/bin/env bash
# -E olmadan ERR tuzagi fonksiyonlara gecmez; main icinde olusan hata
# sessizce yutulur ve akis "Tamamlandi" yazarak devam eder.
set -Eeuo pipefail

PACKAGE_URL="https://github.com/icratoolkit/updater/raw/refs/heads/main/icramini.zip"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="$SCRIPT_DIR"
# Yedek varsayilan olarak alinir. Guncelleme once hedef klasoru
# temizledigi icin yarida kalan bir kurulum geri donusu olmayan kayip
# demekti; PowerShell surumu de bastan beri yedek aliyor.
NO_BACKUP=0

usage() {
  cat <<'EOF'
Kullanım:
  ./update-icramini.sh [--package-url URL] [--target-dir KLASOR] [--backup|--no-backup]

Varsayılan:
  --target-dir scriptin bulunduğu klasör
  --backup
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --package-url)
      [[ $# -ge 2 ]] || { printf 'Eksik parametre: --package-url\n' >&2; exit 2; }
      PACKAGE_URL="$2"
      shift 2
      ;;
    --target-dir)
      [[ $# -ge 2 ]] || { printf 'Eksik parametre: --target-dir\n' >&2; exit 2; }
      TARGET_DIR="$2"
      shift 2
      ;;
    --backup)
      NO_BACKUP=0
      shift
      ;;
    --no-backup)
      NO_BACKUP=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      printf 'Bilinmeyen parametre: %s\n' "$1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

write_step() {
  printf '\n==> %s\n' "$1"
}

cleanup() {
  if [[ -n "${TEMP_ROOT:-}" && -d "$TEMP_ROOT" ]]; then
    rm -rf "$TEMP_ROOT"
  fi
}

download_file() {
  local url="$1"
  local output="$2"

  if command -v curl >/dev/null 2>&1; then
    curl -fL --retry 3 --connect-timeout 20 -o "$output" "$url"
    return
  fi

  if command -v wget >/dev/null 2>&1; then
    wget -O "$output" "$url"
    return
  fi

  python3 - "$url" "$output" <<'PY'
import sys
import urllib.request

url, output = sys.argv[1], sys.argv[2]
with urllib.request.urlopen(url, timeout=60) as response:
    with open(output, "wb") as file:
        file.write(response.read())
PY
}

TARGET_DIR="$(python3 - "$TARGET_DIR" <<'PY'
import os
import sys

print(os.path.abspath(os.path.expanduser(sys.argv[1])))
PY
)"
if [[ ! -d "$TARGET_DIR" ]]; then
  printf 'Hedef klasör bulunamadı: %s\n' "$TARGET_DIR" >&2
  exit 1
fi

TEMP_ROOT="$(mktemp -d "${TMPDIR:-/tmp}/icramini-update-XXXXXXXX")"
ZIP_PATH="$TEMP_ROOT/icramini.zip"
EXTRACT_DIR="$TEMP_ROOT/paket"
# Yedek kurulum klasorune yazilmaz. Chrome o klasoru paketlenmemis uzanti
# olarak yukluyor; icine birakilan kopya hem uzantinin kendisini sisirir hem
# de her guncellemede birikir. Sistem gecici klasoru bu is icin dogru yer.
BACKUP_ROOT="${TMPDIR:-/tmp}/icramini-yedek"
BACKUP_KEEP=1
TIMESTAMP="$(date '+%Y%m%d-%H%M%S')"
BACKUP_DIR="$BACKUP_ROOT/$TIMESTAMP"

trap cleanup EXIT

finish() {
  local code="$1"
  printf '\n'
  if [[ "$code" -eq 0 ]]; then
    printf 'Güncelleme tamamlandı.\n'
  else
    printf 'Güncelleme başarısız oldu. Hata kodu: %s\n' "$code"
  fi
  if [[ -t 0 && -t 1 ]]; then
    read -r -p "Devam etmek için Enter'a basın..." _
  fi
  exit "$code"
}

main() {
  write_step "Hazırlanıyor"
  printf 'Hedef klasör: %s\n' "$TARGET_DIR"
  mkdir -p "$EXTRACT_DIR"

  write_step "Güncelleme paketi indiriliyor"
  download_file "$PACKAGE_URL" "$ZIP_PATH"

  write_step "ZIP paketi açılıyor"
  python3 - "$ZIP_PATH" "$EXTRACT_DIR" <<'PY'
import sys
import zipfile

zip_path, extract_dir = sys.argv[1], sys.argv[2]
with zipfile.ZipFile(zip_path) as archive:
    archive.extractall(extract_dir)
PY

  PACKAGE_ROOT="$(python3 - "$EXTRACT_DIR" <<'PY'
import os
import sys

extract_dir = sys.argv[1]
entries = [os.path.join(extract_dir, name) for name in os.listdir(extract_dir)]
if len(entries) == 1 and os.path.isdir(entries[0]):
    print(os.path.realpath(entries[0]))
else:
    print(os.path.realpath(extract_dir))
PY
)"

  MANIFEST_PATH="$PACKAGE_ROOT/manifest.json"
  if [[ ! -f "$MANIFEST_PATH" ]]; then
    printf 'Paket kökünde manifest.json bulunamadı. ZIP içeriği beklenen icramini paketi gibi görünmüyor.\n' >&2
    return 1
  fi

  PACKAGE_VERSION="$(python3 - "$MANIFEST_PATH" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8-sig") as file:
    print(json.load(file).get("version", ""))
PY
)"
  if [[ -n "$PACKAGE_VERSION" ]]; then
    printf 'Paket sürümü: %s\n' "$PACKAGE_VERSION"
  fi

  if [[ "$NO_BACKUP" -eq 0 ]]; then
    write_step "Mevcut dosyalar yedekleniyor"
    mkdir -p "$BACKUP_DIR"
    TARGET_DIR="$TARGET_DIR" BACKUP_DIR="$BACKUP_DIR" python3 - <<'PY'
import os
import shutil

target_dir = os.environ["TARGET_DIR"]
backup_dir = os.environ["BACKUP_DIR"]
exclude_names = {".git", "_update_backups"}

for name in os.listdir(target_dir):
    if name in exclude_names:
        continue
    source = os.path.join(target_dir, name)
    destination = os.path.join(backup_dir, name)
    # Yedeklenemeyen tek bir dosya yuzunden guncelleme durmamali; kaynak
    # klasore baska bir surec yaziyorsa dosya arada kaybolabiliyor.
    try:
        if os.path.isdir(source) and not os.path.islink(source):
            shutil.copytree(source, destination, dirs_exist_ok=True, ignore_dangling_symlinks=True)
        else:
            os.makedirs(os.path.dirname(destination), exist_ok=True)
            shutil.copy2(source, destination)
    except (FileNotFoundError, shutil.Error) as error:
        print("Yedeklenemedi, atlandi: %s (%s)" % (source, error))
PY
    printf 'Yedek: %s\n' "$BACKUP_DIR"

    BACKUP_ROOT="$BACKUP_ROOT" BACKUP_KEEP="$BACKUP_KEEP" python3 - <<'PY'
import os
import shutil

root = os.environ["BACKUP_ROOT"]
keep = int(os.environ["BACKUP_KEEP"])

try:
    names = sorted(n for n in os.listdir(root) if os.path.isdir(os.path.join(root, n)))
except FileNotFoundError:
    names = []

# Klasor adlari zaman damgasi oldugu icin siralama kronolojik.
for name in names[:-keep] if keep > 0 else names:
    shutil.rmtree(os.path.join(root, name), ignore_errors=True)
PY
  fi

  write_step "Dosyalar güncelleniyor"
  TARGET_DIR="$TARGET_DIR" PACKAGE_ROOT="$PACKAGE_ROOT" python3 - <<'PY'
import os
import shutil

target_dir = os.path.realpath(os.environ["TARGET_DIR"])
package_root = os.path.realpath(os.environ["PACKAGE_ROOT"])
# _update_backups bilerek listede yok: eski surumler yedegi kurulum klasorune
# biraktigi icin, mevcut kurulumlardaki birikinti bu adimda temizlensin.
exclude_names = {".git"}
preserve_paths = {
    os.path.realpath(os.path.join(target_dir, "update-icramini.bat")),
    os.path.realpath(os.path.join(target_dir, "update-icramini.sh")),
    os.path.realpath(os.path.join(target_dir, "scripts", "update-icramini.ps1")),
}


skipped = []


def clear_directory(path):
    try:
        names = os.listdir(path)
    except FileNotFoundError:
        return

    for name in names:
        if name in exclude_names:
            continue

        # Silme her zaman gercek yol uzerinden yapilir; realpath yalnizca
        # karsilastirma icin. Aksi halde sembolik bag hedefi silinir, bagin
        # kendisi kalir; bag kirikken de hedef bulunamaz ve hata verir.
        full_path = os.path.join(path, name)
        if os.path.realpath(full_path) in preserve_paths:
            continue

        # Kurulum klasorune baska bir surec yaziyor olabilir (log dosyalari
        # gibi). Listeleme ile silme arasinda kaybolan dosya hata degildir.
        try:
            if os.path.isdir(full_path) and not os.path.islink(full_path):
                clear_directory(full_path)
                if not os.listdir(full_path):
                    os.rmdir(full_path)
            else:
                os.remove(full_path)
        except FileNotFoundError:
            continue
        except OSError as error:
            # Silinemeyen dosya guncellemeyi durdurmamali; yeni paket zaten
            # uzerine yazilacak. Yine de sessizce gecilmez, sonunda bildirilir.
            skipped.append("%s (%s)" % (full_path, error.strerror or error))


def copy_content(source_dir, destination_dir):
    for name in os.listdir(source_dir):
        if name in exclude_names:
            continue

        source = os.path.join(source_dir, name)
        destination = os.path.join(destination_dir, name)
        if os.path.isdir(source) and not os.path.islink(source):
            os.makedirs(destination, exist_ok=True)
            copy_content(source, destination)
        else:
            os.makedirs(os.path.dirname(destination), exist_ok=True)
            shutil.copy2(source, destination)


clear_directory(target_dir)
copy_content(package_root, target_dir)

if skipped:
    print("Silinemeyen %d dosya atlandi (yeni surum yine de kuruldu):" % len(skipped))
    for item in skipped[:10]:
        print("  - %s" % item)
    if len(skipped) > 10:
        print("  ... ve %d dosya daha" % (len(skipped) - 10))
PY

  NEW_MANIFEST_PATH="$TARGET_DIR/manifest.json"
  if [[ -f "$NEW_MANIFEST_PATH" ]]; then
    INSTALLED_VERSION="$(python3 - "$NEW_MANIFEST_PATH" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8-sig") as file:
    print(json.load(file).get("version", ""))
PY
)"
    if [[ -n "$INSTALLED_VERSION" ]]; then
      printf 'Kurulan sürüm: %s\n' "$INSTALLED_VERSION"
    fi
  fi

  write_step "Tamamlandı"
  printf 'Chrome eklentisi açıksa chrome://extensions sayfasından eklentiyi yenileyin.\n'
}

# main'i "if" icinde cagirmak set -e'yi tum govde boyunca devre disi birakir:
# bir adim coktugunde betik durmaz, sonraki adimlar calisir ve kullaniciya
# basarili gibi gorunur. Bu yuzden dogrudan cagirip hatayi tuzakla yakaliyoruz.
on_error() {
  local code=$?
  printf '\nGüncelleme başarısız oldu.\n' >&2
  printf 'Yedek alındıysa buradan geri dönebilirsiniz: %s\n' "$BACKUP_DIR" >&2
  finish "$code"
}

trap on_error ERR

main
finish 0

﻿[CmdletBinding()]
param(
  [string]$SourceDir = "",
  [string]$OutputPath = "",
  [switch]$IncludeUpdater
)

$ErrorActionPreference = "Stop"

function Test-IgnoredPath {
  param(
    [string]$RelativePath,
    [bool]$IsDirectory,
    [switch]$IncludeUpdater
  )

  $normalized = $RelativePath.Replace("\", "/").TrimStart("/")
  $name = Split-Path -Leaf $normalized

  if ($normalized -eq "") {
    return $false
  }

  $ignoredNames = @(
    ".git",
    ".github",
    ".vscode",
    "node_modules",
    "dist",
    "release",
    "_update_backups",
    "__MACOSX"
  )

  if ($ignoredNames -contains $name) {
    return $true
  }

  foreach ($ignoredName in $ignoredNames) {
    if ($normalized -eq $ignoredName -or $normalized.StartsWith("$ignoredName/")) {
      return $true
    }
  }

  if ($name -eq ".DS_Store") {
    return $true
  }

  if ($normalized -eq "version.json") {
    return $true
  }

  if ($name -like "*.pem") {
    return $true
  }
<#
  if (-not $IncludeUpdater) {
    if ($normalized -eq "update-icramini.bat" -or $normalized -eq "scripts/update-icramini.ps1") {
      return $true
    }
  }
#>
  return $false
}

function Get-RelativePath {
  param(
    [string]$BasePath,
    [string]$FullPath
  )

  $base = [System.IO.Path]::GetFullPath($BasePath).TrimEnd("\") + "\"
  $full = [System.IO.Path]::GetFullPath($FullPath)
  $baseUri = New-Object System.Uri($base)
  $fullUri = New-Object System.Uri($full)
  return [System.Uri]::UnescapeDataString($baseUri.MakeRelativeUri($fullUri).ToString()).Replace("/", "\")
}

if ([string]::IsNullOrWhiteSpace($SourceDir)) {
  $SourceDir = Join-Path $PSScriptRoot ".."
}

$SourceDir = [System.IO.Path]::GetFullPath($SourceDir.Trim().Trim('"'))
if (-not (Test-Path -LiteralPath $SourceDir -PathType Container)) {
  throw "Kaynak klasör bulunamadı: $SourceDir"
}

if ([string]::IsNullOrWhiteSpace($OutputPath)) {
  $OutputPath = Join-Path $SourceDir ".\icramini.zip"
}

$OutputPath = [System.IO.Path]::GetFullPath($OutputPath.Trim().Trim('"'))
$outputDir = Split-Path -Parent $OutputPath
$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("icramini-package-" + [System.Guid]::NewGuid().ToString("N"))
$stagingDir = Join-Path $tempRoot "icramini"

try {
  New-Item -ItemType Directory -Path $stagingDir, $outputDir -Force | Out-Null

  Get-ChildItem -LiteralPath $SourceDir -Recurse -Force | ForEach-Object {
    $relativePath = Get-RelativePath -BasePath $SourceDir -FullPath $_.FullName
    $isDirectory = $_.PSIsContainer

    if (Test-IgnoredPath -RelativePath $relativePath -IsDirectory $isDirectory -IncludeUpdater:$IncludeUpdater) {
      return
    }

    $destinationPath = Join-Path $stagingDir $relativePath

    if ($isDirectory) {
      New-Item -ItemType Directory -Path $destinationPath -Force | Out-Null
      return
    }

    New-Item -ItemType Directory -Path (Split-Path -Parent $destinationPath) -Force | Out-Null
    Copy-Item -LiteralPath $_.FullName -Destination $destinationPath -Force
  }

  if (Test-Path -LiteralPath $OutputPath) {
    Remove-Item -LiteralPath $OutputPath -Force
  }

  Compress-Archive -Path (Join-Path $stagingDir "*") -DestinationPath $OutputPath -Force

  $fileCount = (Get-ChildItem -LiteralPath $stagingDir -Recurse -File -Force).Count
  $sizeMb = ((Get-Item -LiteralPath $OutputPath).Length / 1MB).ToString("0.00")

  Write-Host "ZIP oluşturuldu: $OutputPath"
  Write-Host "Dosya sayısı: $fileCount"
  Write-Host "Boyut: $sizeMb MB"
}
finally {
  if (Test-Path -LiteralPath $tempRoot) {
    Remove-Item -LiteralPath $tempRoot -Recurse -Force
  }
}

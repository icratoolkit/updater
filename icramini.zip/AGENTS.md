# Proje Talimatları

Bu proje Türkçe arayüzlüdür.

## Metin ve Karakter Kullanımı

- Türkçe karakterleri koru.
- Kod, UI metinleri, hata mesajları, açıklamalar ve dokümantasyonda `ç, ğ, ı, İ, ö, ş, ü` karakterlerini bozma.
- Mevcut Türkçe metinleri ASCII'ye çevirme.
- Mojibake gibi bozulmuş metinler görürsen düzelt.
- Yeni eklenen kullanıcıya görünen metinler doğal ve düzgün Türkçe olmalı.
- Türkçe karakterler terminal veya encoding nedeniyle risk altındaysa kullanıcıya görünen yeni stringlerde `\u` Unicode escape kullanmak kabul edilir ve tercih edilir.
- Kullanıcıya görünen metinlerde `Ã`, `Ä`, `Å`, `â` gibi bozuk karakter dizileri bırakma.

## Düzenleme Kuralı

- Dosya zaten Türkçe içeriyorsa düzenlemelerde UTF-8 uyumlu kal.
- Özellikle popup, README, hata mesajları, export başlıkları ve HTML metinlerinde Türkçe karakterleri koru.
- Mümkünse dosyaları UTF-8 olarak kaydet ve repo kökündeki `.editorconfig` kurallarına uy.

## Beklenen Varsayım

- Bu repoda metin doğruluğu, Türkçe karakterleri korumaktan daha az önemli değildir.
- Şüphe varsa Türkçe karakterli sürümü tercih et.
